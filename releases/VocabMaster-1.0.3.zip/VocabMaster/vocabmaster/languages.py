"""Which languages a deck is about.

The columns in the database keep their historical names (`greek`, `swedish`)
because they are baked into every sync log ever written; what changed is
that nothing else assumes what they hold. Four settings describe a deck:

  lang_target      the language being learned — `word`, `example`, `synonyms`
  lang_definition  the language `definition` and `hook` are written in
  lang_native      what the `greek` column holds (blank = column unused)
  lang_second      what the `swedish` column holds (blank = column unused)

A deck that already has words but no language settings is Mike's original:
English learned, English definitions, Greek + Swedish translations. A fresh
deck starts as English/English with no translation columns until its owner
says otherwise in Settings.
"""

KEYS = ("lang_target", "lang_definition", "lang_native", "lang_second")
# What the Settings dropdowns offer. Any deck picks up to three of these:
# the language learned, a translation, an optional second translation.
CHOICES = ("English", "Swedish", "Greek", "Korean", "Japanese")
NONE = "— none —"
LEGACY = {"lang_target": "English", "lang_definition": "English",
          "lang_native": "Greek", "lang_second": "Swedish"}
FRESH = {"lang_target": "English", "lang_definition": "English",
         "lang_native": "", "lang_second": ""}

# Card labels in the language's own script: a Greek speaker reads ΕΛΛΗΝΙΚΑ
# faster than GREEK. Anything not listed is shown upper-cased as typed.
LABELS = {
    "english": "ENGLISH", "greek": "ΕΛΛΗΝΙΚΑ", "swedish": "SVENSKA",
    "korean": "한국어", "japanese": "日本語", "chinese": "中文",
    "spanish": "ESPAÑOL", "french": "FRANÇAIS", "german": "DEUTSCH",
    "italian": "ITALIANO", "portuguese": "PORTUGUÊS", "dutch": "NEDERLANDS",
    "russian": "РУССКИЙ", "turkish": "TÜRKÇE", "arabic": "العربية",
    "polish": "POLSKI", "norwegian": "NORSK", "danish": "DANSK",
    "finnish": "SUOMI", "hindi": "हिन्दी",
}


# System voices: Windows SAPI language id (hex LCID) and the macOS locale
# prefix `say -v ?` prints, so the Say button can pick a matching voice.
VOICES = {
    "english": ("409", "en"), "swedish": ("41D", "sv"), "greek": ("408", "el"),
    "korean": ("412", "ko"), "japanese": ("411", "ja"), "chinese": ("804", "zh"),
    "spanish": ("40A", "es"), "french": ("40C", "fr"), "german": ("407", "de"),
    "italian": ("410", "it"), "portuguese": ("816", "pt"), "dutch": ("413", "nl"),
    "russian": ("419", "ru"), "turkish": ("41F", "tr"), "arabic": ("401", "ar"),
    "polish": ("415", "pl"), "norwegian": ("414", "nb"), "danish": ("406", "da"),
    "finnish": ("40B", "fi"), "hindi": ("439", "hi"),
}


def voice(name):
    """(windows_lcid, mac_locale) for a language, or (None, None)."""
    return VOICES.get((name or "").strip().lower(), (None, None))


# Scripts a beginner cannot sound out yet: the card shows a reading
# (romanisation / pinyin / kana) under the word.
NON_LATIN = {"korean", "japanese", "chinese", "greek", "russian", "arabic", "hindi"}


def needs_reading(name):
    return (name or "").strip().lower() in NON_LATIN


def label(name):
    """Short upper-case tag for a card row; '' when the column is unused."""
    name = (name or "").strip()
    return LABELS.get(name.lower(), name.upper()) if name else ""


class Languages:
    """Plain holder; built from settings by `load`."""

    def __init__(self, target, definition, native, second):
        self.target = target or "English"
        self.definition = definition or self.target
        self.native = (native or "").strip()
        self.second = (second or "").strip()

    @property
    def native_label(self):
        return label(self.native)

    @property
    def second_label(self):
        return label(self.second)

    def describe(self):
        parts = [f"learning {self.target}", f"definitions in {self.definition}"]
        if self.native:
            parts.append(f"{self.native} translations")
        if self.second:
            parts.append(f"{self.second} translations")
        return " · ".join(parts)


def load(get_setting):
    return Languages(*(get_setting(key) for key in KEYS))


def ensure_defaults(conn):
    """Settle the four settings once. Runs inside Database.__init__."""
    row = conn.execute("SELECT 1 FROM settings WHERE key='lang_target'").fetchone()
    if row:
        return
    has_words = conn.execute("SELECT 1 FROM words LIMIT 1").fetchone() is not None
    defaults = LEGACY if has_words else FRESH
    for key, value in defaults.items():
        conn.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                     (key, value))
    conn.commit()

@echo off
rem VocabMaster - one-shot Windows setup. Double-click this file.
rem Gives the app a private Python environment with PyQt6, puts a
rem VocabMaster icon on the Desktop and opens the app. Safe to run again.
rem No Python on the computer? It downloads the official installer from
rem python.org, checks its signature, and installs it for this user only
rem (no administrator rights). Every failure stops on a red screen that says
rem what happened and what to do; setup-log.txt records each run.
rem
rem Test hooks (tests/test_setup_windows.py): the first argument is the folder
rem for the shortcut; VM_SETUP_NOLAUNCH=1 does not open the app at the end;
rem VM_SETUP_NO_INSTALL=1 never installs Python.
setlocal EnableExtensions
title VocabMaster setup
cd /d "%~dp0"
set "LOG=%~dp0setup-log.txt"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
2>nul >"%LOG%" echo VocabMaster setup %DATE% %TIME% in %CD%

echo.
echo   VocabMaster setup
echo   -----------------
echo.

rem 1. Started from inside the zip? Windows then copies only this file to a
rem    temporary folder, and the app is not next to it.
if exist "vocabmaster\main.py" goto unzipped
set "WHY=The app's files are not next to this setup file. It was probably opened from inside the zip."
set "FIX=Right-click the VocabMaster zip, choose Extract All, open the new VocabMaster folder and double-click setup-windows.bat there."
goto fail
:unzipped

rem 2. Python 3.11 or newer: on PATH, through the py launcher, or where the
rem    python.org installer puts it for one user.
echo   Looking for Python...
call :find_python
if defined PY goto have_python
if not defined VM_SETUP_NO_INSTALL goto get_python
set "WHY=Python 3.11 or newer was not found, and this test run does not install it."
set "FIX=Install Python from python.org, then run this again."
goto fail
:get_python
call :install_python
if errorlevel 1 goto fail
call :find_python
if defined PY goto have_python
set "WHY=Python was installed but cannot be found yet."
set "FIX=Restart the computer, then double-click setup-windows.bat again."
goto fail

:have_python
echo   Using:
%PY% --version
call :log python: %PY%

rem 3. The app's own environment, with PyQt6 in it.
echo.
echo   Preparing the app's own Python environment.
echo   The first time this downloads about 80 MB - one to three minutes.
if not exist ".venv\Scripts\python.exe" goto make_venv
".venv\Scripts\python.exe" -c "import sys" >nul 2>nul && goto venv_ready
echo   The old environment does not work any more - making a new one...
rmdir /s /q ".venv"
:make_venv
%PY% -m venv .venv
if not errorlevel 1 goto venv_ready
set "WHY=Python could not create the app's environment (.venv)."
set "FIX=Delete the .venv folder next to this file, if there is one, and run this again."
goto fail
:venv_ready
rem Exactly the tested PyQt6 set (requirements.txt): nothing to do when it is
rem there already; offline with an older set still installed, the app runs.
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
".venv\Scripts\python.exe" -c "import PyQt6.QtWidgets" >nul 2>nul && goto pyqt_ready
set "WHY=PyQt6, the window toolkit the app is drawn with, could not be installed."
set "FIX=Check the internet connection and run this again."
goto fail
:pyqt_ready
call :log PyQt6 ready

rem 4. The Desktop icon. Paths travel as environment variables, never inside
rem    the PowerShell text. WScript.Shell cannot save a shortcut whose path has
rem    letters outside the Windows code page (a Greek or Japanese user name on
rem    an English Windows), so it only makes a blank one in an ASCII folder;
rem    Shell.Application fills in the real, Unicode paths; then it is moved.
echo.
echo   Putting a VocabMaster icon on the Desktop...
set "VMROOT=%CD%"
set "DESK=%~1"
"%PS%" -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $r=$env:VMROOT; $d=$env:DESK; if (-not $d) { $d=[Environment]::GetFolderPath('Desktop') }; $q=[char]34; $base=$env:PUBLIC; if (-not $base) { $base=$env:TEMP }; $tmp=Join-Path $base ('vocabmaster-'+[guid]::NewGuid().ToString('N')+'.lnk'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($tmp); $s.TargetPath=Join-Path $env:SystemRoot 'System32\cmd.exe'; $s.Save(); $l=(New-Object -ComObject Shell.Application).Namespace((Split-Path $tmp)).ParseName((Split-Path $tmp -Leaf)).GetLink; $l.Path=Join-Path $r '.venv\Scripts\pythonw.exe'; $l.Arguments=$q+(Join-Path $r 'vocabmaster\main.py')+$q; $l.WorkingDirectory=Join-Path $r 'vocabmaster'; $l.SetIconLocation((Join-Path $r 'vocabmaster\vocabmaster.ico'), 0); $l.Save(); $link=Join-Path $d 'VocabMaster.lnk'; Move-Item -Force -LiteralPath $tmp -Destination $link; Write-Output ('  Icon: '+$link)"
if not errorlevel 1 goto icon_ready
echo   The Desktop icon could not be made. To open VocabMaster later,
echo   double-click setup-windows.bat again - it only takes a moment then.
call :log no desktop icon
:icon_ready

rem 5. Open the app, so nobody is left wondering whether it worked.
call :log done
echo.
echo   Done. VocabMaster is opening now.
echo   From now on, open it with the VocabMaster icon on your Desktop.
echo   First time: Settings - pick your languages and paste your OpenAI key,
echo   then Add Words - Build a starter deck.
if not defined VM_SETUP_NOLAUNCH start "" /d "%CD%\vocabmaster" "%CD%\.venv\Scripts\pythonw.exe" "%CD%\vocabmaster\main.py"
echo.
echo   You can close this window. Press any key.
pause >nul
exit /b 0


:find_python
set "PY="
call :try_python py -3
if not defined PY call :try_python python
if not defined PY call :try_python python3
for %%V in (313 312 311 314) do if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" call :try_python "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
for %%V in (313 312 311 314) do if not defined PY if exist "%ProgramFiles%\Python%%V\python.exe" call :try_python "%ProgramFiles%\Python%%V\python.exe"
exit /b 0

:try_python
rem Keeps the command in PY when it starts a real Python 3.11 or newer. The
rem Microsoft Store's "python" placeholder (it only opens the Store) fails.
%* -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>nul
if not errorlevel 1 set "PY=%*"
exit /b 0

:install_python
rem The official python.org installer, signature checked, installed quietly
rem for this user only: no administrator rights, nothing to click.
set "PYVER=3.12.10"
set "PYFILE=python-%PYVER%-amd64.exe"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "PYFILE=python-%PYVER%-arm64.exe"
if /i "%PROCESSOR_ARCHITECTURE%"=="x86" if not defined PROCESSOR_ARCHITEW6432 set "PYFILE=python-%PYVER%.exe"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/%PYFILE%"
set "PYSETUP=%TEMP%\vocabmaster-%PYFILE%"
echo.
echo   Python is not on this computer yet - getting it from python.org.
echo   Downloading Python %PYVER% - about 27 MB...
call :log downloading %PYURL%
"%PS%" -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri $env:PYURL -OutFile $env:PYSETUP; $sig=Get-AuthenticodeSignature $env:PYSETUP; if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Python Software Foundation') { Remove-Item $env:PYSETUP; exit 3 }"
if not errorlevel 1 goto python_downloaded
set "WHY=Python could not be downloaded from python.org."
set "FIX=Check the internet connection and run this again, or install Python 3.12 from python.org yourself."
exit /b 1
:python_downloaded
echo   Installing Python for this user - no administrator rights needed.
echo   This takes about a minute and shows nothing; please wait...
call :log installing %PYSETUP%
"%PYSETUP%" /quiet InstallAllUsers=0 InstallLauncherAllUsers=0 PrependPath=1 Include_test=0
set "PYCODE=%ERRORLEVEL%"
del "%PYSETUP%" >nul 2>nul
if "%PYCODE%"=="0" exit /b 0
set "WHY=The Python installer stopped with code %PYCODE%."
set "FIX=Restart the computer and run this again, or install Python 3.12 from python.org yourself."
exit /b 1

:log
2>nul >>"%LOG%" echo %*
exit /b 0

:fail
color 4F
call :log FAILED: %WHY%
echo.
echo   ==================================================================
echo   Setup did not finish.
echo.
echo   %WHY%
echo.
echo   What to do: %FIX%
echo.
echo   Still stuck? Take a photo of this window and send it to the person
echo   who gave you VocabMaster.
echo   ==================================================================
echo.
echo   Press any key to close this window.
pause >nul
exit /b 1

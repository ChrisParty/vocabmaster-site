"""Speaking in Talk: what the learner said, as text, on their own OpenAI key.

The microphone is recorded by ui.recorder (Qt, no extra package) as 16-bit
mono PCM; this module turns it into a WAV and sends it to OpenAI's
transcription endpoint through the one spending gate (kind "voice", the
AI-text cap). The partner's replies are read aloud by the computer's own
voice (ui.flashcard.speak) — free.

Bounds, so a microphone can never run up a bill:
  MAX_SECONDS   a recording stops by itself after this long
  silence       a recording without speech in it — quiet, or only the room's
                own noise — is never sent (and costs nothing)
  echo          with no clear speech the model may write back the hint text
                (the partner's line and the ideas); that counts as "not heard"
  PER_DAY       recordings sent per day, on top of the daily AI budget
  ceiling       debited before the request: the audio at RATE_PER_MINUTE
                (about twice what gpt-4o-mini-transcribe lists) plus the
                hint text at TEXT_RATE; recorded as spent, never less.
"""

import io
import json
import uuid
import urllib.request
import wave
from array import array
from datetime import datetime

import cards_ai
import languages

TRANSCRIBE_URL = "https://api.openai.com/v1/audio/transcriptions"
MODEL = "gpt-4o-mini-transcribe"
MAX_SECONDS = 15
MIN_SECONDS = 0.6
PER_DAY = 100
RATE_PER_MINUTE = 0.006      # USD per minute of audio, debited and recorded
TEXT_RATE = 2.50             # USD per 1M hint tokens (one per byte, over-estimated)
HINT_CHARS = 600
SILENT_PEAK = 200            # of 32767: below this nothing was said (or the mic is blocked)
MIN_SPEECH = 0.15            # seconds of voice (20-ms frames well above the room's noise)
VOICE_RMS = 600              # a frame this loud (≈ -35 dBFS) can be a voice …
NOISE_FACTOR = 3             # … if it is also 3× the room's own noise

# Transcription wants ISO-639-1; the voice table's macOS locales are that,
# except Norwegian.
_ISO = {"nb": "no"}


def language_code(name):
    """'Korean' -> 'ko'; '' when unknown (the model then guesses)."""
    code = languages.voice(name)[1] or ""
    return _ISO.get(code, code)


# ------------------------------------------------------------------ audio

def to_mono16(raw, sample_format, channels):
    """Raw samples from the microphone -> 16-bit mono PCM bytes. The first
    channel is kept (a microphone's channels carry the same voice)."""
    kinds = {"int16": "h", "int32": "i", "float": "f", "uint8": "B"}
    samples = array(kinds[sample_format])
    usable = len(raw) - len(raw) % (samples.itemsize * max(1, channels))
    samples.frombytes(raw[:usable])
    if channels > 1:
        samples = samples[0::channels]
    if sample_format == "int16":
        return samples.tobytes()
    if sample_format == "float":
        scaled = (int(s * 32767) for s in samples)
    elif sample_format == "int32":
        scaled = (s >> 16 for s in samples)
    else:
        scaled = ((s - 128) << 8 for s in samples)
    return array("h", (max(-32768, min(32767, s)) for s in scaled)).tobytes()


def seconds(pcm, rate):
    return len(pcm) / 2 / rate if rate else 0.0


def peak(pcm):
    samples = array("h")
    samples.frombytes(pcm[:len(pcm) - len(pcm) % 2])
    return max((abs(s) for s in samples), default=0)


def speech_seconds(pcm, rate):
    """How long someone actually spoke: 20-ms frames clearly louder than the
    quietest tenth of the recording (the room's own noise)."""
    samples = array("h")
    samples.frombytes(pcm[:len(pcm) - len(pcm) % 2])
    size = max(1, int(rate * 0.02))
    levels = []
    for start in range(0, len(samples) - size + 1, size):
        chunk = samples[start:start + size]
        levels.append((sum(s * s for s in chunk) / size) ** 0.5)
    if not levels:
        return 0.0
    noise = sorted(levels)[len(levels) // 10]
    floor = max(VOICE_RMS, noise * NOISE_FACTOR)
    return sum(1 for level in levels if level > floor) * 0.02


def echoed(text, hints):
    """The model wrote back the hints instead of what was said: two or more
    of the hint lines inside the transcript (one alone may be a learner
    reading out an idea, which is fine)."""
    def plain(value):
        return "".join(ch for ch in (value or "").lower() if ch.isalnum())
    said = plain(text)
    lines = {plain(h) for h in hints if plain(h)}
    return sum(1 for line in lines if line in said) >= 2


def _plain(text):
    import unicodedata
    return "".join(ch for ch in unicodedata.normalize("NFC", text or "").casefold() if ch.isalnum())


def _distance(a, b):
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        current = [i]
        for j, cb in enumerate(b, 1):
            current.append(min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + (ca != cb)))
        previous = current
    return previous[-1]


def compare(heard, word, reading=""):
    """How what was heard compares with the card: "right", "close" or "wrong".
    Case, punctuation and spaces don't count; the reading counts too (kana
    for Japanese). The word inside a longer answer is right (물을, "I said
    också"); a near miss is close — never for a word of one syllable."""
    import re
    import unicodedata
    tokens = [_plain(t) for t in re.findall(r"\w+", unicodedata.normalize("NFC", heard or ""))]
    said = _plain(heard)
    forms = [_plain(word.split("[")[0])] + [_plain(p) for p in (reading or "").split("·")]
    forms = [f for f in forms if f]
    if not said or not forms:
        return "wrong"
    for form in forms:
        latin = all(ord(ch) < 0x0370 for ch in form)
        if said == form or form in tokens or (not latin and form in said):
            return "right"
    for form in forms:
        allowed = 0 if len(form) < 2 else max(1, len(form) // 4)
        if _distance(said, form) <= allowed:
            return "close"
    return "wrong"


def wav_bytes(pcm, rate):
    out = io.BytesIO()
    with wave.open(out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return out.getvalue()


def _multipart(fields, filename, data, content_type):
    boundary = uuid.uuid4().hex
    parts = []
    for name, value in fields.items():
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n'
                     f"{value}\r\n".encode())
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; '
                 f'filename="{filename}"\r\nContent-Type: {content_type}\r\n\r\n'.encode()
                 + data + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


# ------------------------------------------------------------------ transcription

class Transcriber(cards_ai.CardWriter):
    """CardWriter for the key, the languages and the ledger; its own request."""

    def used_today(self):
        return self.conn.execute(
            "SELECT COUNT(*) FROM image_ledger WHERE kind='voice' AND day=? AND cost > 0",
            (datetime.now().strftime("%Y-%m-%d"),)).fetchone()[0]

    def transcribe(self, pcm, rate, language, hints=(), key=None):
        """What was said, as text. Nothing is sent (or spent) for a recording
        that is too short or silent, or past the day's recordings."""
        length = seconds(pcm, rate)
        if length < MIN_SECONDS or peak(pcm) < SILENT_PEAK or speech_seconds(pcm, rate) < MIN_SPEECH:
            raise RuntimeError("I heard nothing — speak a little closer to the microphone "
                               "(and check that it is switched on)")
        if self.used_today() >= PER_DAY:
            raise RuntimeError(f"that is {PER_DAY} recordings today — type your answers, "
                               f"or speak again tomorrow")
        key = key or self.api_key()
        if not key:
            raise RuntimeError("no OpenAI API key — add one in Settings")
        length = min(length, MAX_SECONDS + 1)
        pcm = pcm[:int((MAX_SECONDS + 1) * rate) * 2]
        hint = " ".join(h.strip() for h in hints if h and h.strip())[:HINT_CHARS]
        fields = {"model": MODEL, "response_format": "json"}
        code = language_code(language)
        if code:
            fields["language"] = code
        if hint:
            fields["prompt"] = hint
        ceiling = length / 60 * RATE_PER_MINUTE + len(hint.encode("utf-8")) * TEXT_RATE / 1e6
        ledger_id = self.ledger.debit(None, "voice", ceiling, MODEL)
        body, content_type = _multipart(fields, "speech.wav", wav_bytes(pcm, rate), "audio/wav")
        try:
            request = urllib.request.Request(
                TRANSCRIBE_URL, data=body,
                headers={"Content-Type": content_type, "Authorization": f"Bearer {key}"})
            with urllib.request.urlopen(request, timeout=60) as response:
                data = json.loads(response.read().decode())
        except Exception as exc:
            self.ledger.refund(ledger_id, "failed")
            raise RuntimeError(cards_ai.explain(exc, MODEL)) from exc
        usage = data.get("usage") if isinstance(data.get("usage"), dict) else {}
        self.ledger.settle(ledger_id, "ok", {"input_tokens": usage.get("input_tokens", 0),
                                             "output_tokens": usage.get("output_tokens", 0)})
        text = (data.get("text") or "").strip()
        if not text or echoed(text, hints):
            raise RuntimeError("I didn't catch that — try again, a little closer to the microphone")
        return text

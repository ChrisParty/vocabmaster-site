' Speaks the text in the environment variable VOCABMASTER_SAY with a
' Windows voice (offline). The text never travels on the command line:
' Windows Script Host has no escape for a quote inside an argument, so a
' card like  She said "good morning"  would split into several arguments
' (one of them taken as a file to write).
'
' The optional first argument is a language id (hex LCID, e.g. 41D for
' Swedish). The first installed voice for that language is used: the
' classic voices first, then the newer ones Windows adds from Settings ->
' Speech (Speech_OneCore). Greek and Swedish exist only there. Language
' ids are compared as numbers, because Windows writes some as "041d":
' an exact match first, then the same language from another country
' (409 English US -> 809 English UK). Without a voice for the language the
' default voice reads the text as best it can.
'
' A second argument writes the speech to that .wav file instead of the
' speakers (used by the tests, so they make no sound).

Function LangNumber(code)
    LangNumber = -1
    On Error Resume Next
    LangNumber = CLng("&H" & Trim(code))
    On Error Goto 0
End Function

Function FindVoice(lcid)
    Set FindVoice = Nothing
    want = LangNumber(lcid)
    If want < 0 Then Exit Function
    places = Array("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices", _
                   "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Speech\Voices", _
                   "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech_OneCore\Voices")
    For pass = 1 To 2
        For Each place In places
            Set category = CreateObject("SAPI.SpObjectTokenCategory")
            On Error Resume Next
            category.SetId place, False
            missing = (Err.Number <> 0)
            Err.Clear
            On Error Goto 0
            If Not missing Then
                For Each token In category.EnumerateTokens()
                    For Each part In Split(token.GetAttribute("Language"), ";")
                        have = LangNumber(part)
                        If have >= 0 Then
                            If (pass = 1 And have = want) Or _
                               (pass = 2 And (have And &H3FF) = (want And &H3FF)) Then
                                Set FindVoice = token
                                Exit Function
                            End If
                        End If
                    Next
                Next
            End If
        Next
    Next
End Function

text = CreateObject("WScript.Shell").Environment("PROCESS")("VOCABMASTER_SAY")
If Len(text) > 0 Then
    Set voice = CreateObject("SAPI.SpVoice")
    If WScript.Arguments.Count > 0 Then
        Set chosen = FindVoice(WScript.Arguments(0))
        If Not chosen Is Nothing Then Set voice.Voice = chosen
    End If
    ' 16 = SVSFIsNotXML: the text is read as plain words, never as SAPI
    ' markup (a card starting with "<" stays words). Spoken synchronously.
    If WScript.Arguments.Count > 1 Then
        Set stream = CreateObject("SAPI.SpFileStream")
        stream.Open WScript.Arguments(1), 3, False
        Set voice.AudioOutputStream = stream
        voice.Speak text, 16
        stream.Close
    Else
        voice.Speak text, 16
    End If
End If

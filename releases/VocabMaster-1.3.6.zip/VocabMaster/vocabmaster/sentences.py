"""Everyday sentences: a phrasebook beside the deck, never inside it.

The most useful sentences of the learning language, written by the AI with
how to say them (reading), what they mean (translation) and what every
piece means (parts), plus a one-line note on when to use them. A sentence
is New, Seen (meaning revealed once) or Learned (the learner said so) —
nothing more. Deliberately separate from the cards: no SM-2, no sessions,
no streak, no goal; the stats never see this table.

Sync: one more log section (`sentences`), most recent `updated_at` wins.
Removing a sentence is a soft delete (`removed = 1`), so it travels like any
other change and needs no tombstones. Sentences belong to the language they
were written for (`lang`); changing the deck's language shows that
language's sentences, and the old ones come back if it is changed back.
"""

import json
import re
import uuid
from datetime import datetime

import cards_ai
import database
import languages
from ledger import BudgetExhausted

SCHEMA = """
CREATE TABLE IF NOT EXISTS sentences (
    id TEXT PRIMARY KEY,
    lang TEXT NOT NULL,
    text TEXT NOT NULL,
    reading TEXT,
    translation TEXT,
    parts TEXT,
    note TEXT,
    topic TEXT,
    level TEXT,
    position INTEGER,
    seen_at TEXT,
    learned_at TEXT,
    removed INTEGER DEFAULT 0,
    updated_at TEXT
)"""

# What rides in the sync log, besides id and updated_at.
FIELDS = ["lang", "text", "reading", "translation", "parts", "note", "topic",
          "level", "position", "seen_at", "learned_at", "removed"]

SIZES = ("20", "50", "100", "200")
BATCH = 20                     # sentences per AI call


def ensure_schema(conn):
    conn.execute(SCHEMA)


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _key(text):
    """Two sentences are the same when only spacing / punctuation differ."""
    return re.sub(r"[\W_]+", "", (text or "").lower())


# ------------------------------------------------------------------ reading

def load(conn, lang):
    """Every sentence of `lang`, most useful first, as dicts."""
    rows = conn.execute(
        "SELECT * FROM sentences WHERE lang=? AND COALESCE(removed,0)=0 "
        "ORDER BY COALESCE(position, 0), rowid", (lang,))
    return [dict(r) for r in rows]


def counts(conn, lang):
    """(learned, total) for `lang`."""
    row = conn.execute(
        "SELECT COUNT(*), SUM(CASE WHEN learned_at IS NOT NULL THEN 1 ELSE 0 END) "
        "FROM sentences WHERE lang=? AND COALESCE(removed,0)=0", (lang,)).fetchone()
    return (row[1] or 0), (row[0] or 0)


def parts_of(sentence):
    """[(piece, meaning, reading)] from the stored JSON; [] when absent or
    broken. The reading is there for kanji languages, '' otherwise."""
    try:
        parts = json.loads(sentence.get("parts") or "[]")
    except (TypeError, ValueError):
        return []
    return [(str(p[0]), str(p[1]), str(p[2]) if len(p) > 2 else "") for p in parts
            if isinstance(p, (list, tuple)) and len(p) in (2, 3) and p[0] and p[1]]


def state(sentence):
    """'learned', 'seen' or 'new'."""
    if sentence.get("learned_at"):
        return "learned"
    return "seen" if sentence.get("seen_at") else "new"


def next_to_learn(items, after_id=None):
    """The first sentence not learned yet, starting after `after_id` and
    wrapping round; None when every one is learned."""
    if not items:
        return None
    start = 0
    if after_id is not None:
        ids = [s["id"] for s in items]
        if after_id in ids:
            start = ids.index(after_id) + 1
    ordered = items[start:] + items[:start]
    return next((s for s in ordered if not s.get("learned_at")), None)


# ------------------------------------------------------------------ writing

def _set(conn, sentence_id, **values):
    values["updated_at"] = database.utc_stamp()
    sets = ", ".join(f"{k}=?" for k in values)
    conn.execute(f"UPDATE sentences SET {sets} WHERE id=?", (*values.values(), sentence_id))
    conn.commit()


def mark_seen(conn, sentence_id):
    """The first reveal only; seeing it again changes nothing."""
    row = conn.execute("SELECT seen_at FROM sentences WHERE id=?", (sentence_id,)).fetchone()
    if row is not None and not row[0]:
        _set(conn, sentence_id, seen_at=_now())


def mark_learned(conn, sentence_id, learned=True):
    _set(conn, sentence_id, learned_at=_now() if learned else None)


def remove(conn, sentence_id):
    _set(conn, sentence_id, removed=1)


def insert(conn, lang, level, entries):
    """Save new sentences after the existing ones; duplicates are skipped.
    Returns how many were added."""
    have = {_key(r[0]) for r in conn.execute(
        "SELECT text FROM sentences WHERE lang=?", (lang,))}
    position = conn.execute(
        "SELECT COALESCE(MAX(position), 0) FROM sentences WHERE lang=?", (lang,)).fetchone()[0]
    added = 0
    for entry in entries:
        key = _key(entry["text"])
        if not key or key in have:
            continue
        have.add(key)
        position += 1
        conn.execute(
            "INSERT INTO sentences (id, lang, text, reading, translation, parts, note, "
            "topic, level, position, removed, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,0,?)",
            (uuid.uuid4().hex, lang, entry["text"], entry.get("reading", ""),
             entry.get("translation", ""), json.dumps(entry.get("parts", []), ensure_ascii=False),
             entry.get("note", ""), entry.get("topic", ""), level, position,
             database.utc_stamp()))
        added += 1
    conn.commit()
    return added


SYSTEM = """You write a phrasebook for a {level} learner of {target} whose own language
is {definition}. Return JSON:
{{"sentences": [{{"text": str, "reading": str, "translation": str,
"parts": {parts_shape}, "note": str, "topic": str}}]}}

- text (in {target} ONLY): {what}
  {length}
- reading: {reading_rule}
- translation (in {definition}): what it means, said naturally. {translation_rule}
- parts: the sentence split into its words or meaningful pieces, in order,
  each with its meaning in {definition}{parts_rule}.
  Together the pieces spell the whole sentence.
- note (in {definition}, max 100 characters): when to use it, or the one
  pattern it teaches; "" when there is nothing useful to add.
- topic (in {definition}, 1-2 words): the situation, e.g. "Greetings".
Never repeat a sentence from "avoid". No markdown anywhere."""

LENGTHS = {
    "beginner": "At most 6 words; the very first things a visitor needs.",
    "intermediate": "At most 10 words; everyday situations and small talk.",
    "advanced": "At most 14 words; natural, idiomatic everyday speech.",
    "expert": "At most 20 words.",
}
LEVELS = tuple(LENGTHS)
# What a sentence is about: everyday life up to advanced (the prompt as it
# always was); the way a well-read native speaker talks for expert.
EVERYDAY = """a short, natural sentence people really say in
  everyday life — greetings, introducing yourself, asking for things,
  shopping, food and drink, directions, time, feelings, getting help. The
  most useful first. A polite register anyone can use with a stranger."""
WHAT = {"expert": """a natural sentence a well-read native speaker really says
  when discussing, explaining, persuading or disagreeing — idioms, phrasal
  verbs and nuanced, precise turns of phrase (never archaic or bookish
  curiosities). The most useful first."""}


class SentenceWriter(cards_ai.CardWriter):
    """Same connection, key, model and daily AI budget as the cards."""

    def __init__(self, db_path):
        super().__init__(db_path)
        ensure_schema(self.conn)

    def _system(self, level):
        L = self.langs
        reading_rule = ("how it is pronounced, in Latin letters a learner can read: "
                        f"Revised Romanization for Korean, {cards_ai.JA_ROMAJI} for Japanese, pinyin "
                        "with tones for Chinese, a simple transliteration otherwise"
                        if languages.needs_reading(L.target) else 'always ""')
        same = L.target.lower() == L.definition.lower()
        if languages.needs_sentence_reading(L.target):
            # Kanji cannot be sounded out: every piece carries its reading.
            latin = cards_ai.JA_ROMAJI if L.target.lower() == "japanese" else "pinyin with tones"
            parts_shape = "[[str, str, str]]"
            parts_rule = f' and its {latin}, e.g. [["piece", "meaning", "reading"], ...]'
        else:
            parts_shape = "[[str, str]]"
            parts_rule = ', e.g. [["piece", "meaning"], ...]'
        return SYSTEM.format(
            level=level, target=L.target, definition=L.definition,
            length=LENGTHS.get(level, LENGTHS["beginner"]), what=WHAT.get(level, EVERYDAY),
            reading_rule=reading_rule,
            translation_rule='Always "" — the learner reads it already.' if same else "",
            parts_shape=parts_shape, parts_rule=parts_rule)

    def clean(self, raw):
        """The model's sentences, each checked field by field; a sentence a
        beginner could not read or understand is dropped, not shown."""
        L = self.langs
        same = L.target.lower() == L.definition.lower()
        scripted = L.target.lower() in cards_ai.SCRIPTS
        out = []
        for s in raw if isinstance(raw, list) else []:
            if not isinstance(s, dict):
                continue
            text = (s.get("text") or "").strip()
            if not text or (scripted and cards_ai.script_share(text, L.target) < 0.5):
                continue                          # not in the learning language
            translation = "" if same else cards_ai._in_language(
                (s.get("translation") or "").strip(), L.target, L.definition)
            if not same and not translation:
                continue                          # nobody could understand it
            reading = cards_ai.latin_reading(s.get("reading"), L.target)
            if languages.needs_reading(L.target) and not reading:
                continue                          # nobody could read it
            parts = []
            for p in s.get("parts") or []:
                if isinstance(p, (list, tuple)) and len(p) in (2, 3):
                    piece, meaning = str(p[0]).strip(), str(p[1]).strip()
                    if piece and meaning and (
                            same or not cards_ai.wrong_language(meaning, L.target, L.definition)):
                        said = cards_ai.sentence_reading(str(p[2]) if len(p) > 2 else "", L.target)
                        parts.append([piece, meaning, said] if said else [piece, meaning])
            note = (s.get("note") or "").strip()
            topic = (s.get("topic") or "").strip()
            if not same:
                if cards_ai.wrong_language(note, L.target, L.definition):
                    note = ""
                if cards_ai.wrong_language(topic, L.target, L.definition):
                    topic = ""
            out.append({"text": text, "reading": reading, "translation": translation,
                        "parts": parts, "note": note[:160], "topic": topic[:40]})
        return out

    def write(self, count, level, avoid, key):
        user = json.dumps({"count": count, "avoid": avoid}, ensure_ascii=False)
        data = self._chat("sentence", self._system(level), user, 220, count, key)
        return self.clean(data.get("sentences"))

    def build(self, count, level, progress=None, key=None):
        """Add `count` new sentences of `level` for this language, a batch at
        a time, each batch saved as it lands (stopping loses nothing).
        Returns (added, reason)."""
        key = key or self.api_key()
        if not key:
            return 0, "no OpenAI API key - add one in Settings"
        if level not in LEVELS:
            level = LEVELS[0]
        lang = self.langs.target
        added = 0
        try:
            while added < count:
                have = [r[0] for r in self.conn.execute(
                    "SELECT text FROM sentences WHERE lang=? AND COALESCE(removed,0)=0",
                    (lang,))]
                want = min(BATCH, count - added)
                entries = self.write(want, level, have[-200:], key)
                new = insert(self.conn, lang, level, entries)
                added += new
                if progress:
                    progress(added, count)
                if not new:
                    return added, "the AI found no more new sentences"
        except BudgetExhausted as exc:
            return added, str(exc)
        except RuntimeError as exc:
            return added, str(exc)
        return added, None

"""Badges: a small reward when the work adds up — "100 words studied", "A
whole week", "Perfect round". They are only ever given, never taken away: a
streak that breaks keeps its badges, a word reset keeps its count, and no
badge ever says what was missed. Nothing here touches the cards, the
schedule, sessions, streak or stats.

Most badges are counted from what the deck already holds (`measures`): words
studied, the longest run of days, words mastered, cards reviewed, sentences
learned, letters of the alphabet known, stories made, the best day. A few are
given at the moment they happen (`award`): a perfect round, the first
conversation, the first word the computer heard right.

Table `badges(id, earned_on, celebrated, updated_at)`, one per deck. It rides
in the sync log (most simply: a badge is never removed), so a badge
celebrated on one computer is not celebrated again on the other. The first
look at a deck that already has work in it gives what is earned quietly
(`catch_up`): the window shows one welcome, not forty popups.
"""

from collections import namedtuple
from datetime import date, datetime

import alphabets
from database import MASTERED_INTERVAL, utc_stamp

Badge = namedtuple("Badge", "id family title face line colour tier goal")

WELCOMED = "badges_welcomed"       # setting: this deck has been caught up
COMEBACK_GAP = 7                   # days without study before "Welcome back"
PERFECT_MIN = 10                   # cards in a round with no Again (or the round size, if smaller)

# family: (label on the shelf, colour)
FAMILIES = {
    "words": ("Words studied", "#3b82f6"),
    "streak": ("Days in a row", "#f97316"),
    "mastered": ("Words mastered", "#22c55e"),
    "reviews": ("Cards reviewed", "#8b5cf6"),
    "sentences": ("Sentences learned", "#14b8a6"),
    "alphabet": ("Alphabet", "#ec4899"),
    "special": ("Special moments", "#eab308"),
}
ORDER = list(FAMILIES)
COUNTED = ("words", "streak", "mastered", "reviews", "sentences")

_COUNTS = {
    "words": [
        (1, "Your first word", "Every language begins with one word — and you have begun."),
        (10, "10 words studied", "Ten words already. You are on your way."),
        (25, "25 words studied", "Twenty-five words! You can already say a little."),
        (50, "50 words studied", "Fifty words. A real start — keep it going."),
        (100, "100 words studied", "One hundred words. That is a real vocabulary."),
        (250, "250 words studied", "250 words. Everyday words are becoming yours."),
        (500, "500 words studied", "Five hundred words. Look how far you have come."),
        (1000, "1,000 words studied", "A thousand words! A milestone to be proud of."),
        (2000, "2,000 words studied", "Two thousand words. Truly impressive."),
    ],
    "streak": [
        (3, "3 days in a row", "Three days in a row. A habit is growing."),
        (7, "A whole week", "Seven days in a row — a whole week!"),
        (14, "Two weeks in a row", "Fourteen days in a row. Wonderful."),
        (30, "A month in a row", "Thirty days in a row. This is a real habit now."),
        (60, "Two months in a row", "Sixty days in a row. Steady as a clock."),
        (100, "100 days in a row", "One hundred days in a row. Extraordinary."),
        (200, "200 days in a row", "Two hundred days in a row. Very few people get here."),
        (365, "A whole year", "Every day for a whole year. Bravo!"),
    ],
    "mastered": [
        (10, "10 words mastered", "Ten words you know so well they can wait weeks before coming back."),
        (50, "50 words mastered", "Fifty words that are truly yours."),
        (100, "100 words mastered", "One hundred words you really know. Well done!"),
        (250, "250 words mastered", "250 words mastered. Your memory is doing beautiful work."),
        (500, "500 words mastered", "Five hundred words mastered. Remarkable."),
        (1000, "1,000 words mastered", "A thousand words you truly know. Outstanding."),
    ],
    "reviews": [
        (100, "100 cards reviewed", "One hundred reviews. Every one makes a word stronger."),
        (1000, "1,000 cards reviewed", "A thousand reviews. That is real practice."),
        (5000, "5,000 cards reviewed", "Five thousand reviews — that is dedication."),
        (10000, "10,000 cards reviewed", "Ten thousand reviews. Simply amazing."),
        (25000, "25,000 cards reviewed", "Twenty-five thousand reviews. You are a legend."),
    ],
    "sentences": [
        (10, "10 sentences learned", "Ten sentences you can use in real life."),
        (50, "50 sentences learned", "Fifty sentences. You can say a lot now."),
        (100, "100 sentences learned", "One hundred sentences — a whole phrasebook in your head."),
    ],
}

# id: (title, face, line, colour). Given once; how each is earned is in `_earned`.
_SPECIAL = {
    "goal": ("Daily goal reached", "🎯", "You reached your daily goal. A great day!", "#eab308"),
    "perfect": ("Perfect round", "🌟", "A whole round without a single Again. Sharp!", "#ef4444"),
    "comeback": ("Welcome back", "👋", "You came back after a break. Picking it up again is what counts.", "#0ea5e9"),
    "story_1": ("Your first story", "📖", "A story written from your own words. Reading makes them stick.", "#f472b6"),
    "story_10": ("10 stories", "📚", "Ten stories read. Your words are coming alive.", "#d946ef"),
    "talk_1": ("Your first conversation", "💬", "You had your first conversation. That takes courage!", "#06b6d4"),
    "say_right": ("Said it right", "🎤", "The computer understood your word. Your pronunciation works!", "#84cc16"),
}
EVENTS = ("perfect", "talk_1", "say_right")      # given by `award`, not counted


def _tier(index, count):
    """0 bronze · 1 silver · 2 gold · 3 diamond — later milestones shine more."""
    return min(3, index * 4 // count)


def _counted():
    out = []
    for family, rows in _COUNTS.items():
        for index, (goal, title, line) in enumerate(rows):
            out.append(Badge(f"{family}_{goal}", family, title, f"{goal:,}", line,
                             FAMILIES[family][1], _tier(index, len(rows)), goal))
    return out


def _special():
    return [Badge(key, "special", title, face, line, colour, 2, 0)
            for key, (title, face, line, colour) in _SPECIAL.items()]


def alphabet_badges(language):
    """The alphabet's badges for a learning language: the basic step of each
    track and the whole track ("Basic Hangul", "All of hiragana", "The Greek
    alphabet"). Each badge's `goal` is the number of symbols to know."""
    alphabet = alphabets.for_language(language)
    if not alphabet:
        return []
    lang = language.strip()
    key = lang.lower()
    unit = alphabet.get("unit", "letters")
    tracks = alphabets.tracks(alphabet)
    colour = FAMILIES["alphabet"][1]
    out = []
    for track, steps in tracks:
        # A whole syllable says "Korean" better than one letter (ㄱ).
        face = {"korean": "한"}.get(key) or (alphabet["icon"] if len(tracks) == 1 else steps[0][0][0])
        shown = track.lower() if unit == "kana" else track
        everything = [s for step in steps for s, _, _ in step]
        if len(steps) > 1:
            noun = shown if unit == "kana" else f"{shown} {unit}"
            out.append(Badge(f"alphabet_{key}_{track.lower()}_basic", "alphabet", f"Basic {shown}",
                             face, f"You know the {len(steps[0])} basic {noun}. "
                                   f"Reading {lang} has begun!", colour, 1, len(steps[0])))
        if track == "Letters":
            title = f"The {lang} alphabet"
            line = f"All {len(everything)} {lang} letters are yours. You can sound out any {lang} word!"
        else:
            title = f"All of {shown}"
            line = f"All of {shown} is yours. You can sound out anything written in {shown}!"
        out.append(Badge(f"alphabet_{key}_{track.lower()}", "alphabet", title, face, line,
                         colour, 3, len(everything)))
    return out


def _alphabet_symbols(language, badge_id):
    """The symbols an alphabet badge asks for."""
    alphabet = alphabets.for_language(language)
    key = language.strip().lower()
    for track, steps in alphabets.tracks(alphabet) if alphabet else []:
        base = f"alphabet_{key}_{track.lower()}"
        if badge_id == base + "_basic":
            return [s for s, _, _ in steps[0]]
        if badge_id == base:
            return [s for step in steps for s, _, _ in step]
    return []


def catalogue(language=""):
    """Every badge there is, the deck's alphabet first among the alphabets."""
    alphabet = alphabet_badges(language) if language else []
    for other in alphabets.ALPHABETS:
        if other != (language or "").strip().lower():
            alphabet += alphabet_badges(other.capitalize())
    return _counted() + alphabet + _special()


def by_id(language=""):
    return {badge.id: badge for badge in catalogue(language)}


def _target(db):
    return (db.get_setting("lang_target", "") or "").strip()


# ------------------------------------------------------------------ counting

def measures(db):
    """The numbers the badges are counted from — all already in the deck."""
    conn = db.conn

    def one(sql, *args):
        try:
            return conn.execute(sql, args).fetchone()[0] or 0
        except Exception:
            return 0                      # a table an old deck does not have

    target = _target(db)
    dates = sorted(datetime.strptime(d, "%Y-%m-%d").date() for d in db.study_dates())
    gaps = [(later - earlier).days - 1 for earlier, later in zip(dates, dates[1:])]
    known = set()
    if target:
        try:
            known = {row[0] for row in conn.execute(
                "SELECT symbol FROM alphabet_progress WHERE lang=? AND streak >= ?",
                (target, alphabets.MASTER_STREAK))}
        except Exception:
            known = set()
    return {
        "words": one("SELECT COUNT(*) FROM progress "
                     "WHERE last_studied IS NOT NULL OR repetitions > 0"),
        "streak": db.longest_streak(),
        "streak_now": db.current_streak(),
        "mastered": one("SELECT COUNT(*) FROM progress WHERE repetitions > 0 AND interval >= ?",
                        MASTERED_INTERVAL),
        "reviews": one("SELECT SUM(cards_reviewed) FROM sessions"),
        "sentences": one("SELECT COUNT(*) FROM sentences WHERE learned_at IS NOT NULL "
                         "AND COALESCE(removed, 0) = 0 AND lang = ?", target),
        "stories": one("SELECT COUNT(*) FROM stories"),
        "best_day": one("SELECT MAX(n) FROM (SELECT SUM(cards_reviewed) n FROM sessions "
                        "GROUP BY date)"),
        "goal": db.get_int_setting("daily_goal", 20),
        "longest_break": max(gaps, default=0),
        "known_symbols": known,
    }


def _earned(badge, m, language):
    if badge.family in COUNTED:
        return m[badge.family] >= badge.goal
    if badge.family == "alphabet":
        needed = _alphabet_symbols(language, badge.id)
        return bool(needed) and all(symbol in m["known_symbols"] for symbol in needed)
    return {
        "goal": m["goal"] > 0 and m["best_day"] >= m["goal"],
        "comeback": m["longest_break"] >= COMEBACK_GAP,
        "story_1": m["stories"] >= 1,
        "story_10": m["stories"] >= 10,
    }.get(badge.id, False)


def held(conn):
    """id -> the day it was earned ('' when it was given in the catch-up)."""
    return {row[0]: row[1] or "" for row in conn.execute("SELECT id, earned_on FROM badges")}


def _give(conn, badge_id, quiet):
    cursor = conn.execute(
        "INSERT OR IGNORE INTO badges (id, earned_on, celebrated, updated_at) VALUES (?, ?, ?, ?)",
        (badge_id, None if quiet else date.today().isoformat(), 1 if quiet else 0, utc_stamp()))
    return cursor.rowcount > 0


def check(db, quiet=False):
    """Give every badge the deck has earned and does not hold yet; returns the
    new ones. `quiet`: given without a celebration (the first catch-up)."""
    language = _target(db)
    have = held(db.conn)
    m = measures(db)
    fresh = [badge for badge in catalogue(language)
             if badge.id not in have and badge.id not in EVENTS and _earned(badge, m, language)]
    for badge in fresh:
        _give(db.conn, badge.id, quiet)
    db.conn.commit()
    return fresh


def award(conn, badge_id):
    """A badge given at the moment it happens (a perfect round, …); it is
    celebrated at the next pause. True when it is new."""
    if badge_id not in _SPECIAL:
        return False
    new = _give(conn, badge_id, quiet=False)
    conn.commit()
    return new


def catch_up(db):
    """The first look at this deck: what is already earned is given quietly.
    Returns how many badges the deck then holds — or None when the deck has
    been caught up before."""
    if db.get_setting(WELCOMED) == "1":
        return None
    check(db, quiet=True)
    db.conn.execute("UPDATE badges SET celebrated = 1")
    db.conn.commit()
    db.set_setting(WELCOMED, "1")
    return len(held(db.conn))


def pending(db):
    """Badges earned and not celebrated yet, smallest first (first word, then
    10 words, …, then the special ones)."""
    waiting = {row[0] for row in db.conn.execute("SELECT id FROM badges WHERE celebrated = 0")}
    return [badge for badge in catalogue(_target(db)) if badge.id in waiting]


def mark_celebrated(conn, ids):
    conn.executemany("UPDATE badges SET celebrated = 1 WHERE id = ?", [(i,) for i in ids])
    conn.commit()


def perfect_round_size(session_cap):
    return max(5, min(PERFECT_MIN, session_cap))


# ------------------------------------------------------------------ the shelf

def when(earned_on):
    """'18 Oct' (this year) or '18 Oct 2025'; '' when unknown."""
    if not earned_on:
        return ""
    try:
        day = datetime.strptime(earned_on, "%Y-%m-%d").date()
    except ValueError:
        return ""
    return f"{day.day} {day:%b}" + ("" if day.year == date.today().year else f" {day.year}")


def shelf(db):
    """What the Stats screen shows, family by family: the badges earned (with
    the day) and the next one to reach (with how far along it is). A family
    not started yet waits until it is (no row of zeros to stare at) — only
    "Words studied" is always there, for the very first badge; special
    badges show once earned."""
    language = _target(db)
    have = held(db.conn)
    m = measures(db)
    every = catalogue(language)
    rows = []
    for family in ORDER:
        mine = [b for b in every if b.family == family]
        if family == "alphabet":
            own = {b.id for b in alphabet_badges(language)} if language else set()
            mine = [b for b in mine if b.id in own or b.id in have]
        items = [{"badge": b, "earned": True, "on": have[b.id]} for b in mine if b.id in have]
        upcoming = next((b for b in mine if b.id not in have), None)
        if upcoming is not None and family in COUNTED:
            value = m["streak_now"] if family == "streak" else m[family]
            if family == "words" or value > 0 or items:
                items.append({"badge": upcoming, "earned": False,
                              "value": min(value, upcoming.goal), "goal": upcoming.goal})
        elif upcoming is not None and family == "alphabet" and upcoming.id in {
                b.id for b in alphabet_badges(language)}:
            needed = _alphabet_symbols(language, upcoming.id)
            value = sum(1 for s in needed if s in m["known_symbols"])
            if value or items:
                items.append({"badge": upcoming, "earned": False, "value": value,
                              "goal": len(needed)})
        if items:
            rows.append({"family": family, "label": FAMILIES[family][0], "items": items})
    return rows


def to_go(item):
    """The tooltip of a badge not earned yet: what is left, in plain words."""
    badge, left = item["badge"], item["goal"] - item["value"]
    if badge.family == "streak":
        return f"{badge.title}: {left} more day{'s' if left != 1 else ''} in a row to go."
    noun = {"words": "word", "mastered": "word", "reviews": "card", "sentences": "sentence",
            "alphabet": "symbol"}.get(badge.family, "")
    return f"{badge.title}: {left:,} more {noun}{'s' if left != 1 else ''} to go."

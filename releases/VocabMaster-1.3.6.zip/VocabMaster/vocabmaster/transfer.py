"""Move a whole VocabMaster between computers as one .zip — deck, progress,
pictures, settings — for when the cloud is not an option, or not yet.

A bundle is a snapshot: vocabmaster.db (taken through SQLite's backup API, so
it is consistent even while the app is running) plus images/*.webp. Restoring
it makes the other machine identical to this one at the moment of export,
with two deliberate differences so it behaves as a SECOND device, not a clone:

  - sync_device is regenerated. Sync skips log files carrying its own device
    id, so two machines sharing one id would silently ignore each other.
  - the database being replaced is kept as backups/pre-restore-<stamp>.db.
    A restore can be undone by copying that file back.

The bundle carries secrets (the sync secret, the OpenAI key). Treat it like a
password: move it privately, delete it after restoring.
"""

import os
import secrets
import shutil
import sqlite3
import tempfile
import time
import zipfile
from datetime import datetime

import images

DB_NAME = "vocabmaster.db"
IMAGE_DIR = "images"


def _set(conn, key, value):
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))


def _is_picture(member_name):
    """Only flat .webp files under images/ — a bundle is data, not a path we
    trust (no sub-directories, no traversal)."""
    return (member_name.startswith(IMAGE_DIR + "/")
            and "/" not in member_name[len(IMAGE_DIR) + 1:]
            and member_name.endswith(".webp"))


# Settings a shared deck never carries: keys, sign-ins, sync state.
PRIVATE_SETTINGS = ("openai_api_key", "sync_secret", "sync_key", "sync_url",
                    "sync_publishable", "sync_enabled", "sync_backend", "drive_decks")
PRIVATE_PREFIXES = ("gdrive_", "sync_")


def _make_shareable(copy):
    """A deck for someone else: the cards, examples, hooks, pictures and
    sentences — without the owner's keys and sign-ins, and fresh for them
    (no progress, streak, history, badges, AI spending or stories of the owner)."""
    marks = ",".join("?" * len(PRIVATE_SETTINGS))
    copy.execute(f"DELETE FROM settings WHERE key IN ({marks})", PRIVATE_SETTINGS)
    for prefix in PRIVATE_PREFIXES:
        copy.execute("DELETE FROM settings WHERE key LIKE ?", (prefix + "%",))
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    statements = [
        ("UPDATE progress SET interval=1, ease_factor=2.5, repetitions=0, due_date=?, "
         "last_studied=NULL", (now,)),
        ("UPDATE progress SET lapses=0", ()),
        ("UPDATE words SET rescue=NULL", ()),
        ("UPDATE sentences SET seen_at=NULL, learned_at=NULL", ()),
        ("DELETE FROM sessions", ()), ("DELETE FROM image_ledger", ()),
        ("DELETE FROM sync_tombstones", ()), ("DELETE FROM stories", ()),
        ("DELETE FROM alphabet_progress", ()), ("DELETE FROM badges", ()),
        ("DELETE FROM settings WHERE key='badges_welcomed'", ()),
    ]
    for sql, params in statements:
        try:
            copy.execute(sql, params)
        except sqlite3.OperationalError:
            pass                       # an older deck without that table or column


# ------------------------------------------------------------------ export

def export_bundle(db_path, zip_path, settings_overrides=None, share=False):
    """Write the bundle. settings_overrides are applied to the COPY only —
    e.g. the OpenAI key this machine borrows from Lexi, which the other
    machine cannot borrow. `share`: a deck for someone else — no keys, no
    sign-ins, no progress or history (`_make_shareable`).
    Returns {"words", "images", "bytes"}."""
    snapshot = zip_path + ".db.tmp"
    source = sqlite3.connect(db_path)
    copy = sqlite3.connect(snapshot)
    try:
        source.backup(copy)
        with copy:
            if share:
                _make_shareable(copy)
            else:
                for key, value in (settings_overrides or {}).items():
                    if value:
                        _set(copy, key, value)
        if share:
            copy.execute("VACUUM")         # leave no deleted secret in the file's free pages
        words = copy.execute("SELECT COUNT(*) FROM words").fetchone()[0]
    finally:
        source.close()
        copy.close()

    partial = zip_path + ".part"
    pictures = 0
    try:
        with zipfile.ZipFile(partial, "w", zipfile.ZIP_DEFLATED) as bundle:
            bundle.write(snapshot, DB_NAME)
            directory = images.images_dir(db_path)
            if os.path.isdir(directory):
                for name in sorted(os.listdir(directory)):
                    if name.endswith(".webp"):
                        # WebP is already compressed; storing beats deflating.
                        bundle.write(os.path.join(directory, name),
                                     f"{IMAGE_DIR}/{name}", zipfile.ZIP_STORED)
                        pictures += 1
    except BaseException:
        try:
            os.remove(partial)
        except OSError:
            pass
        raise
    finally:
        os.remove(snapshot)
    os.replace(partial, zip_path)          # never leave a half-written bundle
    return {"words": words, "images": pictures, "bytes": os.path.getsize(zip_path)}


# ----------------------------------------------------------------- inspect

def inspect_bundle(zip_path):
    """Validate and describe a bundle without changing anything. Raises
    ValueError for anything that is not a VocabMaster backup."""
    with zipfile.ZipFile(zip_path) as bundle:
        names = bundle.namelist()
        if DB_NAME not in names:
            raise ValueError("no vocabmaster.db inside — not a VocabMaster backup")
        pictures = sum(1 for name in names if _is_picture(name))
        handle, probe = tempfile.mkstemp(suffix=".db")
        os.close(handle)
        with bundle.open(DB_NAME) as src, open(probe, "wb") as dst:
            shutil.copyfileobj(src, dst)
    try:
        conn = sqlite3.connect(probe)
        try:
            tables = {row[0] for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
            if not {"words", "progress", "settings"} <= tables:
                raise ValueError("the database inside is not VocabMaster's")
            words = conn.execute("SELECT COUNT(*) FROM words").fetchone()[0]
        finally:
            conn.close()
    except sqlite3.DatabaseError as exc:
        raise ValueError(f"the database inside is unreadable: {exc}") from exc
    finally:
        try:
            os.remove(probe)
        except OSError:
            pass
    return {"words": words, "images": pictures}


# ----------------------------------------------------------------- restore

def _replace(src, dst, tries=10):
    """os.replace, retried: on Windows a background thread (sync, images)
    may still hold the old file for a moment."""
    for attempt in range(tries):
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if attempt == tries - 1:
                raise
            time.sleep(0.3)


def restore_bundle(db_path, zip_path):
    """Replace this machine's database and pictures with the bundle's. Every
    connection to db_path must be closed first. Returns inspect_bundle()."""
    info = inspect_bundle(zip_path)
    base = os.path.dirname(os.path.abspath(db_path))
    if os.path.exists(db_path):
        backups = os.path.join(base, "backups")
        os.makedirs(backups, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        shutil.copy2(db_path, os.path.join(backups, f"pre-restore-{stamp}.db"))

    directory = images.images_dir(db_path)
    os.makedirs(directory, exist_ok=True)
    partial = db_path + ".part"
    with zipfile.ZipFile(zip_path) as bundle:
        with bundle.open(DB_NAME) as src, open(partial, "wb") as dst:
            shutil.copyfileobj(src, dst)
        for member in bundle.infolist():
            if not _is_picture(member.filename):
                continue
            target = os.path.join(directory, os.path.basename(member.filename))
            with bundle.open(member) as src, open(target + ".part", "wb") as dst:
                shutil.copyfileobj(src, dst)
            os.replace(target + ".part", target)
    _replace(partial, db_path)

    # A second device now, not a clone of the first.
    conn = sqlite3.connect(db_path)
    try:
        with conn:
            _set(conn, "sync_device", secrets.token_hex(4))
    finally:
        conn.close()
    return info

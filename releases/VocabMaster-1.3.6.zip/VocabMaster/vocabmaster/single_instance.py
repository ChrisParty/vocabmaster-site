"""One VocabMaster per Windows user (and per --profile): a second launch asks
the running copy to come forward, then exits.

The request travels over a local socket (a named pipe on Windows) that only
the same user can open — never a network port: a web page can reach
127.0.0.1 ports, but not this. main.py keeps the lock file that decides which
copy is the running one; this is only the doorbell.
"""

import getpass
import hashlib

from PyQt6.QtNetwork import QLocalServer, QLocalSocket


def channel_name(profile=""):
    """Per user and profile, so two people on one PC never ring each other."""
    try:
        user = getpass.getuser()
    except Exception:
        user = "user"
    tag = hashlib.sha1(f"{user}|{profile}".encode("utf-8")).hexdigest()[:12]
    return f"vocabmaster-{tag}"


def ask_to_show(name, timeout_ms=1500):
    """Ring the running copy. True when it answered the door."""
    socket = QLocalSocket()
    socket.connectToServer(name)
    if not socket.waitForConnected(timeout_ms):
        return False
    socket.write(b"show\n")
    socket.flush()
    socket.waitForBytesWritten(timeout_ms)
    socket.disconnectFromServer()
    return True


class Doorbell:
    """Listens in the running copy and calls `on_show` when rung."""

    def __init__(self, name, on_show):
        self.on_show = on_show
        self.server = QLocalServer()
        self.server.setSocketOptions(QLocalServer.SocketOption.UserAccessOption)
        QLocalServer.removeServer(name)          # a leftover from a crash (macOS / Linux)
        self.listening = self.server.listen(name)
        self.server.newConnection.connect(self._accept)

    def _accept(self):
        while self.server.hasPendingConnections():
            connection = self.server.nextPendingConnection()
            connection.readyRead.connect(lambda c=connection: self._read(c))
            connection.disconnected.connect(connection.deleteLater)
            if connection.bytesAvailable():   # a quick caller may have rung already
                self._read(connection)

    def _read(self, connection):
        if bytes(connection.readAll()).startswith(b"show"):
            self.on_show()

"""One spending gate for everything that costs money.

The rule is that a daily cap can never be exceeded, not that it is usually
respected:

  known price   the price of the NEXT call is computed before making it —
                exact for images (fixed token counts), a deliberate over-
                estimate for text, settled to the real figure afterwards.
  debit first   the ledger row is written BEFORE the request goes out, so a
                crash mid-call leaves money debited rather than silently
                spent. Calls that produce nothing are refunded.
  one gate      debit() re-reads today's total under BEGIN IMMEDIATE plus a
                process-wide lock: two threads cannot both pass on the same
                remaining cent.

Two independent caps share the `image_ledger` table (its name predates text
generation): pictures (`image_daily_cap`, kinds image/plan) and AI-written
cards (`text_daily_cap`, kinds card/deck). Each Ledger sums only its kinds.

The money is the person's, not a deck's: with several decks (decks.py) the
day's spending of the OTHER decks counts too — OTHER_DBS (set by main.py)
names their databases. Only one deck is open at a time, so reading theirs
without a lock is safe.
"""

import os
import sqlite3
from pathlib import Path
import threading
from datetime import datetime

SCHEMA = """
CREATE TABLE IF NOT EXISTS image_ledger (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    day TEXT NOT NULL,
    word_id TEXT,
    kind TEXT,
    model TEXT,
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    cost REAL NOT NULL,
    status TEXT,
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_image_ledger_day ON image_ledger(day);
"""


# () -> [database paths of the decks that are not open]; main.py sets it.
OTHER_DBS = lambda: []


def _elsewhere(sql, params):
    """The same sum over the other decks' ledgers (missing table = 0)."""
    total = 0.0
    for path in OTHER_DBS():
        try:
            conn = sqlite3.connect(Path(os.path.abspath(path)).as_uri() + "?mode=ro", uri=True, timeout=2)
            try:
                total += conn.execute(sql, params).fetchone()[0] or 0.0
            finally:
                conn.close()
        except sqlite3.Error:
            pass
    return total


def _today():
    return datetime.now().strftime("%Y-%m-%d")


def _stamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def spending(conn):
    """What the AI has cost: today, this month, all time, and today by kind."""
    today = _today()
    month = today[:7]
    sums = ("SELECT COALESCE(SUM(CASE WHEN day=? THEN cost END), 0), "
            "COALESCE(SUM(CASE WHEN substr(day, 1, 7)=? THEN cost END), 0), "
            "COALESCE(SUM(cost), 0) FROM image_ledger")
    row = list(conn.execute(sums, (today, month)).fetchone())
    for i, column in enumerate(("CASE WHEN day=? THEN cost END",
                                "CASE WHEN substr(day, 1, 7)=? THEN cost END", "cost")):
        params = (today,) if i == 0 else (month,) if i == 1 else ()
        row[i] += _elsewhere(f"SELECT COALESCE(SUM({column}), 0) FROM image_ledger", params)
    by_kind = dict(conn.execute(
        "SELECT CASE WHEN kind IN ('image', 'plan') THEN 'pictures' ELSE 'cards' END, "
        "COALESCE(SUM(cost), 0) FROM image_ledger WHERE day=? GROUP BY 1", (today,)).fetchall())
    pictures = "kind IN ('image', 'plan')"
    cards = by_kind.get("cards", 0.0) + _elsewhere(
        f"SELECT COALESCE(SUM(cost), 0) FROM image_ledger WHERE day=? AND NOT {pictures}", (today,))
    drawn = by_kind.get("pictures", 0.0) + _elsewhere(
        f"SELECT COALESCE(SUM(cost), 0) FROM image_ledger WHERE day=? AND {pictures}", (today,))
    return {"today": row[0], "month": row[1], "all": row[2],
            "today_cards": cards, "today_pictures": drawn}


class BudgetExhausted(Exception):
    """Raised instead of spending past the daily cap."""


def open_connection(db_path):
    """Autocommit connection, as debit() needs to hold its own IMMEDIATE
    transaction across check-then-insert."""
    conn = sqlite3.connect(db_path, timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


class Ledger:
    _lock = threading.Lock()   # class-level: the caps are global, not per-instance

    def __init__(self, conn, cap_setting, default_cap, kinds):
        self.conn = conn
        self.cap_setting = cap_setting
        self.default_cap = default_cap
        self.kinds = tuple(kinds)

    def _setting(self, key, default=None):
        row = self.conn.execute(
            "SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row and row["value"] not in (None, "") else default

    def cap(self):
        try:
            return float(self._setting(self.cap_setting, self.default_cap))
        except (TypeError, ValueError):
            return self.default_cap

    def _sum(self, where="", params=()):
        marks = ",".join("?" * len(self.kinds))
        return self.conn.execute(
            f"SELECT COALESCE(SUM(cost), 0) FROM image_ledger "
            f"WHERE kind IN ({marks}) {where}", (*self.kinds, *params)).fetchone()[0]

    def spent_today(self):
        """Today, across every deck (the budget is the person's)."""
        marks = ",".join("?" * len(self.kinds))
        return self._sum("AND day=?", (_today(),)) + _elsewhere(
            f"SELECT COALESCE(SUM(cost), 0) FROM image_ledger WHERE kind IN ({marks}) AND day=?",
            (*self.kinds, _today()))

    def spent_total(self):
        return self._sum()

    def remaining_today(self):
        return max(0.0, self.cap() - self.spent_today())

    def debit(self, word_id, kind, cost, model):
        """Reserve `cost` against today's cap, or refuse. Returns the ledger
        row id so the charge can be settled or refunded afterwards."""
        with Ledger._lock:
            self.conn.execute("BEGIN IMMEDIATE")
            try:
                spent = self.spent_today()
                cap = self.cap()
                if spent + cost > cap + 1e-9:
                    raise BudgetExhausted(
                        f"today's AI budget (${cap:.2f}) is used up — it starts again "
                        f"tomorrow, or raise it in Settings (${spent:.4f} spent)")
                cursor = self.conn.execute(
                    "INSERT INTO image_ledger (day, word_id, kind, model, cost, "
                    "status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', ?)",
                    (_today(), word_id, kind, model, cost, _stamp()))
            except BaseException:
                self.conn.execute("ROLLBACK")
                raise
            self.conn.execute("COMMIT")
            return cursor.lastrowid

    def settle(self, ledger_id, status, usage=None, cost=None):
        fields = {"status": status}
        if usage:
            fields["input_tokens"] = usage.get(
                "input_tokens", usage.get("prompt_tokens", 0))
            fields["output_tokens"] = usage.get(
                "output_tokens", usage.get("completion_tokens", 0))
        if cost is not None:
            fields["cost"] = cost
        sets = ", ".join(f"{key}=?" for key in fields)
        self.conn.execute(f"UPDATE image_ledger SET {sets} WHERE id=?",
                          (*fields.values(), ledger_id))

    def refund(self, ledger_id, reason):
        """A call that never produced anything must not hold budget."""
        self.conn.execute(
            "UPDATE image_ledger SET cost=0, status=? WHERE id=?", (reason, ledger_id))

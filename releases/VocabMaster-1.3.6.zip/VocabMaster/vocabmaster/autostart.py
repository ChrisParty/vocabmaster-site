"""Start VocabMaster with the computer, hidden in the tray, so the daily
reminder can fire. Windows: a shortcut in the user's Startup folder.
macOS: a LaunchAgent. Nothing needs admin rights; disable removes the file.
"""

import os
import platform
import plistlib
import subprocess
import sys

import paths

LABEL = "local.vocabmaster"


def _python():
    """The interpreter running us, windowless on Windows."""
    exe = sys.executable
    if platform.system() == "Windows" and exe.lower().endswith("python.exe"):
        quiet = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(quiet):
            exe = quiet
    return exe


def _target():
    system = platform.system()
    if system == "Windows":
        return os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows",
                            "Start Menu", "Programs", "Startup", "VocabMaster.lnk")
    if system == "Darwin":
        return os.path.expanduser(f"~/Library/LaunchAgents/{LABEL}.plist")
    return os.path.expanduser("~/.config/autostart/vocabmaster.desktop")


def enabled():
    return os.path.exists(_target())


# The paths travel as environment variables, never inside the PowerShell text
# (an apostrophe in "O'Brien" would end a quoted string), and WScript.Shell —
# which cannot save a shortcut whose path holds letters outside the Windows
# code page (a Greek user name on an English Windows) — only makes a blank
# shortcut in an ASCII folder. Shell.Application fills in the real paths, and
# the shortcut is moved into Startup. The same method as setup-windows.bat.
_SHORTCUT_PS = (
    "$ErrorActionPreference='Stop'; $q=[char]34; "
    "$base=$env:PUBLIC; if (-not $base -or -not (Test-Path $base)) { $base=$env:TEMP }; "
    "$tmp=Join-Path $base ('vocabmaster-'+[guid]::NewGuid().ToString('N')+'.lnk'); "
    "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($tmp); "
    "$s.TargetPath=Join-Path $env:SystemRoot 'System32\\cmd.exe'; $s.Save(); "
    "$l=(New-Object -ComObject Shell.Application).Namespace((Split-Path $tmp))"
    ".ParseName((Split-Path $tmp -Leaf)).GetLink; "
    "$l.Path=$env:VM_PYTHON; $l.Arguments=$q+$env:VM_MAIN+$q+' --tray'; "
    "$l.WorkingDirectory=$env:VM_DIR; $l.SetIconLocation($env:VM_ICON, 0); $l.Save(); "
    "New-Item -ItemType Directory -Force -Path (Split-Path $env:VM_TARGET) | Out-Null; "
    "Move-Item -Force -LiteralPath $tmp -Destination $env:VM_TARGET"
)


def _windows_shortcut(target, main):
    powershell = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                              "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
    env = dict(os.environ, VM_PYTHON=_python(), VM_MAIN=main, VM_DIR=paths.app_dir(),
               VM_ICON=os.path.join(paths.app_dir(), "vocabmaster.ico"), VM_TARGET=target)
    done = subprocess.run([powershell, "-NoProfile", "-ExecutionPolicy", "Bypass",
                           "-Command", _SHORTCUT_PS],
                          env=env, capture_output=True, text=True, errors="replace",
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if done.returncode != 0 or not os.path.exists(target):
        import logging
        logging.getLogger("autostart").error("startup shortcut failed: %s", done.stderr.strip())
        raise RuntimeError("Windows did not let VocabMaster add itself to the Startup "
                           "folder. You can start it yourself from the Desktop icon.")


def enable():
    system = platform.system()
    target = _target()
    main = os.path.join(paths.app_dir(), "main.py")
    os.makedirs(os.path.dirname(target), exist_ok=True)
    if system == "Windows":
        _windows_shortcut(target, main)
    elif system == "Darwin":
        with open(target, "wb") as handle:
            plistlib.dump({"Label": LABEL, "RunAtLoad": True,
                           "ProgramArguments": [_python(), main, "--tray"],
                           "WorkingDirectory": paths.app_dir()}, handle)
        subprocess.run(["launchctl", "load", target], check=False)
    else:
        with open(target, "w", encoding="utf-8") as handle:
            handle.write("[Desktop Entry]\nType=Application\nName=VocabMaster\n"
                         f"Exec={_python()} {main} --tray\nX-GNOME-Autostart-enabled=true\n")


def disable():
    target = _target()
    if platform.system() == "Darwin" and os.path.exists(target):
        subprocess.run(["launchctl", "unload", target], check=False)
    try:
        os.remove(target)
    except OSError:
        pass

"""VocabMaster — spaced repetition vocabulary trainer.

Run with:  python main.py
"""

import ctypes
import logging
import logging.handlers
import os
import sqlite3
import subprocess
import sys
import tempfile
import threading
from datetime import datetime

from PyQt6.QtCore import QLockFile, QTimer
from PyQt6.QtGui import QFont, QIcon
from PyQt6.QtWidgets import QApplication, QMessageBox

# An update cut off halfway (power cut) is undone before the rest of the app
# is imported: a mix of old and new modules might not even load. updater
# needs only paths and version.
import updater
updater.recover_interrupted()

import database
import decks
import ledger
import paths
import single_instance
from database import Database
from styles import FONT_SIZES, app_font_family, build_stylesheet
from sync import SyncEngine
from ui.main_window import MainWindow
from version import VERSION


def _install_logging():
    """A rolling log in the data folder, and an exception hook: under
    pythonw there is no console, and PyQt aborts the process on an
    unhandled exception unless a hook is installed. With one, the error is
    written down, shown once, and the app keeps running."""
    handler = logging.handlers.RotatingFileHandler(
        paths.log_path(), maxBytes=1_000_000, backupCount=2, encoding="utf-8")
    logging.basicConfig(level=logging.INFO, handlers=[handler],
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger().info("VocabMaster %s starting (python %s)", VERSION,
                             sys.version.split()[0])

    def hook(kind, value, trace):
        logging.getLogger().error("unhandled", exc_info=(kind, value, trace))
        if QApplication.instance() is not None:
            QMessageBox.warning(
                None, "VocabMaster hit a problem",
                f"{kind.__name__}: {value}\n\nThe details were saved to\n"
                f"{paths.log_path()}\n\nThe app keeps running. If something "
                "looks wrong, close and reopen it.")

    sys.excepthook = hook

    def thread_hook(args):
        # Under pythonw a crash in a background thread (sync, AI, update
        # check) would vanish without a trace: write it down.
        logging.getLogger("thread").error(
            "unhandled in %s", getattr(args.thread, "name", "a thread"),
            exc_info=(args.exc_type, args.exc_value, args.exc_traceback))

    threading.excepthook = thread_hook


def open_deck(path):
    """The deck, or — when its file is damaged — the newest healthy backup put
    back in its place, after asking. None when it cannot be opened."""
    try:
        return Database(path)
    except sqlite3.DatabaseError as exc:
        logging.getLogger().error("the deck could not be opened: %s", exc)
    good = database.healthy_backups(path)
    if not good:
        answer = QMessageBox.question(
            None, "Your deck could not be opened",
            "The deck file is damaged, and there is no backup to bring back.\n\n"
            "Start with an empty deck? The damaged file is kept in the backups folder. "
            "If you used Google Drive sync, connect it again in Settings and your words "
            "come back from there.")
        if answer != QMessageBox.StandardButton.Yes:
            return None
        kept = database.restore_copy(path, None)
        logging.getLogger().warning("started an empty deck; the damaged one is kept as %s", kept)
        db = Database(path)
        # The settings table is small and usually still readable: keep the
        # languages, key, name and Drive sign-in — but sync as a new device
        # from the beginning, so every word comes back down from Drive.
        for key, value in database.salvage_settings(kept).items():
            if key not in database.FRESH_SYNC and value is not None:
                db.set_setting(key, value)
        if paths.DECK and paths.DECK != decks.MAIN and not db.get_setting("gdrive_space"):
            db.set_setting("gdrive_space", f"deck-{paths.DECK}")   # never the main deck's folder
        return db
    day = os.path.basename(good[0])[len("vocabmaster-"):-len(".db")]
    try:
        when = datetime.strptime(day, "%Y-%m-%d").strftime("%A %d %B")
    except ValueError:
        when = day
    answer = QMessageBox.question(
        None, "Your deck could not be opened",
        "The deck file is damaged, so VocabMaster could not open it.\n\n"
        f"Bring back your backup from {when}? Your words and progress up to that day "
        "come back; anything studied after it is lost. The damaged file is kept in "
        "the backups folder.")
    if answer != QMessageBox.StandardButton.Yes:
        return None
    kept = database.restore_copy(path, good[0])
    logging.getLogger().warning("restored %s; the damaged deck is kept as %s", good[0], kept)
    db = Database(path)
    # A new sync identity: what this computer sent to Drive after the backup
    # was taken then counts as another device's work and comes back down.
    db.set_setting("sync_device", "")
    return db


def main():
    for index, arg in enumerate(sys.argv):
        if arg == "--profile" and index + 1 < len(sys.argv):
            paths.PROFILE = "".join(ch for ch in sys.argv[index + 1] if ch.isalnum() or ch in "-_")
    _install_logging()

    # Give the process its own taskbar identity — without this, Windows
    # groups the window under pythonw.exe and shows the Python icon.
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("VocabMaster")
    except (AttributeError, OSError):
        pass

    app = QApplication(sys.argv)
    app.setApplicationName("VocabMaster")
    base = paths.app_dir()
    for icon_file in ("vocabmaster.ico", "vocabmaster.png"):
        icon_path = os.path.join(base, icon_file)
        if os.path.exists(icon_path):
            app.setWindowIcon(QIcon(icon_path))
            break

    # Single-instance guard: a second launch shows a notice instead of
    # opening a conflicting duplicate window.
    lock = QLockFile(os.path.join(tempfile.gettempdir(),
                                  f"vocabmaster{'-' + paths.PROFILE if paths.PROFILE else ''}.lock"))
    lock.setStaleLockTime(0)
    doorbell_name = single_instance.channel_name(paths.PROFILE)
    if not lock.tryLock(100):
        # Usually the copy that lives in the tray: ask it to come forward.
        if not single_instance.ask_to_show(doorbell_name):
            QMessageBox.information(
                None, "VocabMaster",
                "VocabMaster is already running.\nCheck your taskbar for the open window.",
            )
        sys.exit(0)

    # The deck chosen last (decks.py); the main deck unless another was opened.
    paths.DECK = decks.current()
    db = open_deck(paths.db_path())
    if db is None:
        sys.exit(1)
    # One daily AI budget for the person, whichever deck spends it.
    ledger.OTHER_DBS = lambda: decks.other_db_paths(db.path)
    if paths.PROFILE:
        app.setApplicationDisplayName(f"VocabMaster ({paths.PROFILE})")
    font_size = db.get_setting("font_size", "medium")
    app.setFont(QFont(app_font_family(), FONT_SIZES.get(font_size, 10)))
    app.setStyleSheet(build_stylesheet(font_size))

    window = MainWindow(db)
    window.update_title()
    # A second launch rings here: a per-user local socket, no network port
    # (the old hub server on 127.0.0.1:7843 is gone — any web page could
    # reach it).
    doorbell = single_instance.Doorbell(doorbell_name, window.show_requested.emit)
    # Can Windows still run the voice script (VBScript)? Asked once, in the
    # background, so the first Listen is not delayed (ui/flashcard.py).
    if sys.platform == "win32":
        from ui.flashcard import vbscript_works
        threading.Thread(target=vbscript_works, daemon=True).start()
    # Started with the computer (--tray): stay in the tray until the
    # reminder or a click brings the window up.
    if "--tray" in sys.argv and window.tray is not None:
        pass
    else:
        window.show()
        # macOS launches us through a shell script inside the .app bundle, and
        # a window opened that way can come up behind the Finder.
        window.raise_()
        window.activateWindow()

    # Cloud sync: silent, background, additive. No config -> instant no-op.
    # At startup, every 10 minutes, after each study session (the window
    # triggers that one) and once more on quit.
    window.start_sync()
    sync_timer = QTimer()
    sync_timer.setInterval(10 * 60 * 1000)
    sync_timer.timeout.connect(window.start_sync)
    sync_timer.start()

    # Illustrations for today's words, drawn quietly in the background and
    # hard-capped by images.ImageEngine — it debits its ledger before it
    # spends, so this can never run up a bill while you study.
    def draw_todays_images():
        import images
        engine = images.ImageEngine(db.path)
        try:
            engine.top_up_due()
        except Exception:
            logging.getLogger("images").exception("startup top-up failed")
        finally:
            engine.close()

    import images
    if images.ENABLED:                 # pictures are switched off (images.py)
        threading.Thread(target=draw_todays_images, daemon=True).start()

    # A newer release? Checked a few seconds in, off the UI thread; the
    # window shows a banner if there is one. Never blocks, never nags.
    def check_updates():
        info = updater.check()
        if info:
            window.update_available.emit(info)

    threading.Timer(4, check_updates).start()

    exit_code = app.exec()
    # One last push so the cloud copy is current the moment the app closes.
    # Not after a restore (the connection is already closed): the restored
    # database syncs on its own next launch.
    if db.conn is not None:
        closer = threading.Thread(target=lambda: SyncEngine(db).sync(), daemon=True)
        closer.start()
        closer.join(timeout=8)
    db.close()
    if window.relaunch_requested:
        # The lock must go before the new process tries to take it.
        lock.unlock()
        again = [sys.executable, os.path.join(base, "main.py")]
        if paths.PROFILE:
            again += ["--profile", paths.PROFILE]
        subprocess.Popen(again, cwd=base)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()

"""Badges, drawn with Qt: the medal (`paint_medal`), the shelf on the Stats
screen (`BadgeShelf`) and the moment one is earned (`Celebration`: the window
dims, the medal pops in over slowly turning light, confetti bursts out, one
warm sentence, Nice!). What counts and when is in badges.py."""

import math
import random

from PyQt6.QtCore import (
    QElapsedTimer, QEasingCurve, QEvent, QPointF, QRectF, QSize, Qt, QTimer,
    QVariantAnimation, pyqtSignal,
)
from PyQt6.QtGui import (
    QColor, QFont, QFontMetricsF, QLinearGradient, QPainter, QPainterPath, QPen,
    QPolygonF, QRadialGradient,
)
from PyQt6.QtWidgets import (
    QApplication, QFrame, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QToolTip,
    QVBoxLayout, QWidget,
)

import badges
from styles import ACCENT, BORDER, SURFACE, SURFACE_HOVER, TEXT, TEXT_MUTED, TEXT_SECONDARY

# The rim by tier: (light, dark) — later milestones shine more.
METALS = [("#f6c391", "#8c4f1f"),        # bronze
          ("#ffffff", "#7d8b9c"),        # silver
          ("#fff1a8", "#c98500"),        # gold
          ("#e8fbff", "#3aa6dd")]        # diamond
CONFETTI = ["#f97316", "#facc15", "#22c55e", "#3b82f6", "#ec4899", "#a855f7",
            "#14b8a6", "#ef4444"]


def _is_emoji(text):
    return any(ord(ch) >= 0x1F000 or 0x2600 <= ord(ch) <= 0x27BF for ch in text)


def paint_medal(painter, rect, badge, earned=True, progress=None):
    """One medal in `rect`: ribbon tails, a metal rim by tier, the face in the
    badge's colour with its number or sign. Not earned yet: a quiet grey
    disc, its ring filling as it gets closer (`progress` 0–1)."""
    painter.save()
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)
    size = min(rect.width(), rect.height())
    d = size * 0.8
    cx = rect.center().x()
    top = rect.top() + (rect.height() - size) / 2
    cy = top + d / 2 + size * 0.02
    bottom = top + size
    colour = QColor(badge.colour)

    def disc(share):
        return QRectF(cx - d * share / 2, cy - d * share / 2, d * share, d * share)

    painter.setPen(Qt.PenStyle.NoPen)
    if earned:
        tail = d * 0.26
        for side, shade in ((-1, 125), (1, 150)):
            points = [(0.02 * d, cy), (0.02 * d + tail, cy), (0.18 * d + tail, bottom),
                      (0.18 * d + tail / 2, bottom - tail * 0.4), (0.18 * d, bottom)]
            painter.setBrush(colour.darker(shade))
            painter.drawPolygon(QPolygonF([QPointF(cx + side * x, y) for x, y in points]))
        light, dark = METALS[max(0, min(3, badge.tier))]
        rim = QLinearGradient(QPointF(cx, cy - d / 2), QPointF(cx, cy + d / 2))
        rim.setColorAt(0, QColor(light))
        rim.setColorAt(1, QColor(dark))
        painter.setBrush(rim)
        painter.drawEllipse(disc(1.0))
        face = QRadialGradient(QPointF(cx - d * 0.16, cy - d * 0.2), d * 0.62)
        face.setColorAt(0, colour.lighter(150))
        face.setColorAt(0.55, colour)
        face.setColorAt(1, colour.darker(170))
        painter.setBrush(face)
        painter.drawEllipse(disc(0.84))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor(255, 255, 255, 80), max(1.0, d * 0.014)))
        painter.drawEllipse(disc(0.72))
        shine = QPainterPath()
        shine.addEllipse(QRectF(cx - d * 0.30, cy - d * 0.37, d * 0.40, d * 0.20))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(255, 255, 255, 46))
        painter.drawPath(shine)
        text_colour = QColor("#ffffff")
    else:
        painter.setBrush(QColor(SURFACE_HOVER))
        painter.drawEllipse(disc(0.84))
        ring = max(2.0, d * 0.07)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor(BORDER), ring))
        painter.drawEllipse(disc(0.94))
        if progress:
            pen = QPen(colour, ring)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(pen)
            painter.drawArc(disc(0.94), 90 * 16, -int(360 * 16 * max(0.03, min(1.0, progress))))
        text_colour = QColor(TEXT_SECONDARY)
    _face_text(painter, badge.face, cx, cy, d, text_colour, earned)
    painter.restore()


def _face_text(painter, text, cx, cy, d, colour, earned):
    font = QFont(painter.font())
    font.setBold(True)
    numeric = any(ch.isdigit() for ch in text)
    font.setPixelSize(max(6, int(d * (0.34 if numeric else 0.40))))
    metrics = QFontMetricsF(font)
    while metrics.horizontalAdvance(text) > d * 0.64 and font.pixelSize() > 6:
        font.setPixelSize(font.pixelSize() - 1)
        metrics = QFontMetricsF(font)
    painter.setFont(font)
    box = QRectF(cx - d / 2, cy - d / 2, d, d)
    if not earned and _is_emoji(text):
        painter.setOpacity(0.35)              # a colour sign cannot be greyed by the pen
    elif earned and not _is_emoji(text):
        painter.setPen(QColor(0, 0, 0, 90))   # a soft shadow under the number
        painter.drawText(box.translated(0, d * 0.025), Qt.AlignmentFlag.AlignCenter, text)
    painter.setPen(colour)
    painter.drawText(box, Qt.AlignmentFlag.AlignCenter, text)


# ---------------------------------------------------------------- the shelf

class BadgeShelf(QWidget):
    """The badges on the Stats screen: one line per family — its name, the
    medals earned (with the day) and, greyed, the next one with how far along
    it is. Wraps to the width it is given."""

    CELL_W = 80
    MEDAL = 56
    CAPTION = 30
    LABEL_W = 150        # the family's name, left of its medals (above them when narrow)
    LABEL_H = 22
    ROW_GAP = 10

    def __init__(self):
        super().__init__()
        self.rows = []
        self._spots = []                 # (rect, tooltip) for the medals drawn
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setMouseTracking(True)

    def set_rows(self, rows):
        self.rows = rows
        self._fit()
        self.update()

    def _geometry(self, width):
        """(label beside the medals?, medals per line, where the medals start)"""
        beside = width >= self.LABEL_W + 4 * self.CELL_W
        left = self.LABEL_W if beside else 0
        return beside, max(1, int((width - left) // self.CELL_W)), left

    def _height(self, width):
        beside, per_line, _ = self._geometry(width)
        height = 0
        for row in self.rows:
            lines = math.ceil(len(row["items"]) / per_line)
            height += (0 if beside else self.LABEL_H) + lines * (self.MEDAL + self.CAPTION) + self.ROW_GAP
        return max(0, height - self.ROW_GAP)

    def _fit(self):
        height = self._height(max(self.width(), self.CELL_W))
        if self.height() != height or self.minimumHeight() != height:
            self.setFixedHeight(height)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._fit()

    def sizeHint(self):
        return QSize(700, self._height(700))

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        beside, per_line, left = self._geometry(self.width())
        self._spots = []
        label_font = QFont(self.font())
        label_font.setBold(True)
        small = QFont(self.font())
        small.setPointSizeF(max(7.0, self.font().pointSizeF() * 0.82))
        y = 0
        for row in self.rows:
            painter.setFont(label_font)
            painter.setPen(QColor(TEXT_SECONDARY))
            if beside:
                painter.drawText(QRectF(0, y, self.LABEL_W - 8, self.MEDAL),
                                 Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
                                 | Qt.TextFlag.TextWordWrap, row["label"])
            else:
                painter.drawText(QRectF(0, y, self.width(), self.LABEL_H),
                                 Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, row["label"])
                y += self.LABEL_H
            for index, item in enumerate(row["items"]):
                line, column = divmod(index, per_line)
                x = left + column * self.CELL_W
                top = y + line * (self.MEDAL + self.CAPTION)
                medal = QRectF(x + (self.CELL_W - self.MEDAL) / 2, top, self.MEDAL, self.MEDAL)
                badge = item["badge"]
                progress = None if item["earned"] else item["value"] / max(1, item["goal"])
                paint_medal(painter, medal, badge, item["earned"], progress)
                painter.setFont(small)
                caption, tip = self._caption(row["family"], item)
                if not item["earned"]:
                    colour = badge.colour                       # how far along
                elif row["family"] in ("special", "alphabet"):
                    colour = TEXT_SECONDARY                     # its name
                else:
                    colour = TEXT_MUTED                         # the day
                painter.setPen(QColor(colour))
                painter.drawText(QRectF(x + 1, top + self.MEDAL + 1, self.CELL_W - 2, self.CAPTION - 1),
                                 Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop
                                 | Qt.TextFlag.TextWordWrap, caption)
                self._spots.append((QRectF(x, top, self.CELL_W, self.MEDAL + self.CAPTION), tip))
            lines = math.ceil(len(row["items"]) / per_line)
            y += lines * (self.MEDAL + self.CAPTION) + self.ROW_GAP

    @staticmethod
    def _caption(family, item):
        badge = item["badge"]
        if item["earned"]:
            day = badges.when(item["on"])
            tip = f"{badge.title}\n{badge.line}\n" + (f"Earned on {day}." if day else "Earned earlier.")
            caption = badge.title if family in ("special", "alphabet") else day
            return caption, tip
        progress = f"{item['value']:,} of {item['goal']:,}"
        if family == "alphabet":
            progress = f"{badge.title}\n{progress}"
        return progress, badges.to_go(item)

    def event(self, event):
        if event.type() == QEvent.Type.ToolTip:
            for rect, tip in self._spots:
                if rect.contains(QPointF(event.pos())):
                    QToolTip.showText(event.globalPos(), tip, self)
                    return True
            QToolTip.hideText()
            event.ignore()
            return True
        return super().event(event)


# ---------------------------------------------------------- the celebration

class MedalView(QWidget):
    """A medal that pops in (`pop`), over slowly turning light when `rays`."""

    def __init__(self, badge, size, medal, rays=False):
        super().__init__()
        self.badge = badge
        self.medal = medal
        self.rays = rays
        self.scale = 1.0
        self.angle = 0.0
        self.setFixedSize(size, size)
        self._pop = QVariantAnimation(self)
        self._pop.setStartValue(0.15)
        self._pop.setEndValue(1.0)
        self._pop.setDuration(650)
        self._pop.setEasingCurve(QEasingCurve.Type.OutBack)
        self._pop.valueChanged.connect(self._set_scale)
        self._turn = QTimer(self)
        self._turn.setInterval(33)
        self._turn.timeout.connect(self._step)

    def pop(self, delay=0):
        self.scale = 0.0
        self.update()
        QTimer.singleShot(delay, self._pop.start)
        if self.rays:
            self._turn.start()

    def stop(self):
        self._pop.stop()
        self._turn.stop()

    def _set_scale(self, value):
        self.scale = value
        self.update()

    def _step(self):
        self.angle = (self.angle + 0.6) % 360
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        centre = QPointF(self.width() / 2, self.height() / 2)
        if self.rays and self.scale > 0:
            radius = self.width() / 2
            colour = QColor(self.badge.colour)
            clear = QColor(colour)
            clear.setAlpha(0)
            colour.setAlpha(int(110 * min(1.0, self.scale)))
            glow = QRadialGradient(QPointF(0, 0), radius)
            glow.setColorAt(0, colour)
            glow.setColorAt(1, clear)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(glow)
            painter.save()
            painter.translate(centre)
            painter.rotate(self.angle)
            for ray in range(12):
                wedge = QPainterPath()
                wedge.moveTo(0, 0)
                wedge.arcTo(QRectF(-radius, -radius, radius * 2, radius * 2), ray * 30, 13)
                wedge.closeSubpath()
                painter.drawPath(wedge)
            painter.drawEllipse(QPointF(0, 0), radius * 0.55, radius * 0.55)
            painter.restore()
        if self.scale <= 0:
            return
        painter.translate(centre)
        painter.scale(self.scale, self.scale)
        painter.translate(-centre)
        side = self.medal
        paint_medal(painter, QRectF(centre.x() - side / 2, centre.y() - side / 2, side, side),
                    self.badge)


class Confetti(QWidget):
    """A burst of paper from a point; it falls, flutters and fades."""

    LIFE = 3200          # ms

    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.pieces = []
        self.clock = QElapsedTimer()
        self.timer = QTimer(self)
        self.timer.setInterval(16)
        self.timer.timeout.connect(self._step)
        self._last = 0

    def burst(self, origin, count=120):
        for _ in range(count):
            speed = random.uniform(5.0, 13.0)
            angle = random.uniform(math.pi * 1.05, math.pi * 1.95)     # upwards, fanned out
            self.pieces.append({
                "x": origin.x(), "y": origin.y(),
                "vx": math.cos(angle) * speed, "vy": math.sin(angle) * speed,
                "spin": random.uniform(-9, 9), "rot": random.uniform(0, 360),
                "flip": random.uniform(0, math.pi), "flip_speed": random.uniform(0.08, 0.25),
                "w": random.uniform(6, 11), "h": random.uniform(3.5, 6),
                "round": random.random() < 0.25,
                "colour": QColor(random.choice(CONFETTI)),
            })
        self.clock.start()
        self._last = 0
        self.timer.start()

    def stop(self):
        self.timer.stop()
        self.pieces = []

    def _step(self):
        now = self.clock.elapsed()
        frames = max(0.5, min(4.0, (now - self._last) / 16.0))
        self._last = now
        for piece in self.pieces:
            piece["vy"] += 0.32 * frames
            piece["vx"] *= 0.985 ** frames
            piece["vy"] = min(piece["vy"], 6.5)                       # paper floats down
            piece["x"] += (piece["vx"] + math.sin(piece["flip"]) * 0.6) * frames
            piece["y"] += piece["vy"] * frames
            piece["rot"] += piece["spin"] * frames
            piece["flip"] += piece["flip_speed"] * frames
        if now > self.LIFE:
            self.stop()
        self.update()

    def paintEvent(self, event):
        if not self.pieces:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        fade = max(0.0, min(1.0, (self.LIFE - self.clock.elapsed()) / 800.0))
        for piece in self.pieces:
            colour = QColor(piece["colour"])
            colour.setAlphaF(fade)
            painter.save()
            painter.translate(piece["x"], piece["y"])
            painter.rotate(piece["rot"])
            painter.scale(max(0.15, abs(math.cos(piece["flip"]))), 1.0)
            painter.setBrush(colour)
            if piece["round"]:
                painter.drawEllipse(QPointF(0, 0), piece["h"] / 1.6, piece["h"] / 1.6)
            else:
                painter.drawRect(QRectF(-piece["w"] / 2, -piece["h"] / 2, piece["w"], piece["h"]))
            painter.restore()


class Celebration(QWidget):
    """Over the whole window: it dims, the card with the new badge (or
    badges) appears, confetti bursts from the medal. `welcome` (the first look
    at a deck with work in it): how many badges it already holds."""

    finished = pyqtSignal(bool)          # True: "See my badges"

    SHOWN_AT_ONCE = 4

    def __init__(self, window, earned, welcome=None):
        super().__init__(window)
        self.window_ = window
        self.earned = list(earned)
        self._dim = 0
        self._before = QApplication.focusWidget()
        self.setGeometry(window.rect())
        window.installEventFilter(self)

        self.card = QFrame(self)
        self.card.setObjectName("celebration")
        self.card.setStyleSheet(
            f"QFrame#celebration {{ background: {SURFACE}; border: 1px solid {BORDER}; "
            f"border-radius: 18px; }} QFrame#celebration QLabel {{ background: transparent; }}")
        layout = QVBoxLayout(self.card)
        layout.setContentsMargins(32, 22, 32, 24)
        layout.setSpacing(6)

        many = len(self.earned) > 1
        if welcome is not None:
            head = "NEW IN VOCABMASTER"
        elif many:
            head = f"{len(self.earned)} NEW BADGES"
        else:
            head = "NEW BADGE"
        layout.addWidget(self._label(head, ACCENT, 9, bold=True, spacing=True))

        self.medals = []
        shown = self.earned[:self.SHOWN_AT_ONCE]
        if many or welcome is not None:
            row = QHBoxLayout()
            row.setSpacing(4)
            row.addStretch()
            for badge in shown:
                column = QVBoxLayout()
                column.setSpacing(0)
                view = MedalView(badge, 112, 92)
                self.medals.append(view)
                column.addWidget(view, 0, Qt.AlignmentFlag.AlignHCenter)
                name = self._label(badge.title, TEXT, 9, bold=True)
                name.setFixedWidth(116)
                column.addWidget(name)
                column.addStretch()
                row.addLayout(column)
            row.addStretch()
            layout.addLayout(row)
        else:
            view = MedalView(shown[0], 210, 124, rays=True)
            self.medals.append(view)
            layout.addWidget(view, 0, Qt.AlignmentFlag.AlignHCenter)

        if welcome is not None:
            title = (f"You have already earned {welcome} badges" if welcome != 1
                     else "You have already earned a badge")
            line = ("Badges celebrate your work — words studied, days in a row, words "
                    "mastered and more. They are yours to keep, and there are more to come.")
        elif many:
            more = len(self.earned) - len(shown)
            title = f"{len(self.earned)} new badges!"
            line = f"{len(self.earned)} badges at once. Wonderful work!" + (
                f" (And {more} more — see them all in Stats.)" if more > 0 else "")
        else:
            title, line = shown[0].title, shown[0].line
        layout.addSpacing(4)
        layout.addWidget(self._label(title, TEXT, 17, bold=True))
        layout.addWidget(self._label(line, TEXT_SECONDARY, 11))
        layout.addSpacing(12)

        buttons = QHBoxLayout()
        buttons.addStretch()
        self.see_button = QPushButton("See my badges")
        self.see_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.see_button.clicked.connect(lambda: self.finish(True))
        self.nice_button = QPushButton("Nice!")
        self.nice_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.nice_button.setMinimumWidth(110)
        self.nice_button.clicked.connect(lambda: self.finish(False))
        if welcome is not None:
            self.see_button.setObjectName("primary")
            buttons.addWidget(self.nice_button)
            buttons.addWidget(self.see_button)
            first = self.see_button
        else:
            self.nice_button.setObjectName("primary")
            buttons.addWidget(self.see_button)
            buttons.addWidget(self.nice_button)
            first = self.nice_button
        buttons.addStretch()
        layout.addLayout(buttons)
        self.card.setFixedWidth(max(440, 116 * len(shown) + 80) if (many or welcome is not None)
                                else 440)

        self.confetti = Confetti(self)
        self._fade = QVariantAnimation(self)
        self._fade.setStartValue(0)
        self._fade.setEndValue(180)
        self._fade.setDuration(220)
        self._fade.valueChanged.connect(self._set_dim)
        self._place()
        self.show()
        self.raise_()
        first.setFocus()
        self._fade.start()
        for index, view in enumerate(self.medals):
            view.pop(delay=120 + index * 140)
        QTimer.singleShot(260, self._burst)

    @staticmethod
    def _label(text, colour, size, bold=False, spacing=False):
        label = QLabel(text)
        label.setTextFormat(Qt.TextFormat.PlainText)
        label.setWordWrap(True)
        label.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        label.setStyleSheet(f"color: {colour}; font-size: {size}pt;"
                            + (" font-weight: 700;" if bold else "")
                            + (" letter-spacing: 2px;" if spacing else ""))
        return label

    def _burst(self):
        if self.isHidden() or not self.medals:
            return
        view = self.medals[0] if len(self.medals) == 1 else self.medals[len(self.medals) // 2]
        origin = view.mapTo(self, QPointF(view.width() / 2, view.height() / 2).toPoint())
        self.confetti.burst(QPointF(origin), 70 if len(self.medals) > 1 else 120)

    def _set_dim(self, value):
        self._dim = value
        self.update()

    def _place(self):
        self.setGeometry(self.window_.rect())
        self.confetti.setGeometry(self.rect())
        self.card.adjustSize()
        self.card.move((self.width() - self.card.width()) // 2,
                       max(16, (self.height() - self.card.height()) // 2))
        self.confetti.raise_()

    def eventFilter(self, watched, event):
        if watched is self.window_ and event.type() == QEvent.Type.Resize:
            self._place()
        return False

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(1, 4, 9, self._dim))

    def mousePressEvent(self, event):
        event.accept()                    # nothing underneath is clicked meanwhile

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Escape):
            self.finish(False)
            return
        event.accept()                    # keys never reach the screen underneath

    def finish(self, see=False):
        if not self.isVisible():
            return
        for view in self.medals:
            view.stop()
        self.confetti.stop()
        self.window_.removeEventFilter(self)
        self.hide()
        before = self._before
        self.deleteLater()
        if before is not None:
            try:
                before.setFocus()
            except RuntimeError:
                pass                      # that widget is gone
        self.finished.emit(see)

"""Sentences screen: everyday phrases, one at a time, beside the deck.

Three blocks, top to bottom: the sentence in front of you (reveal → meaning
and every word explained → "I know it" or "Again later"), the list of all
of them with their state (✓ learned, • seen, ○ new — click one to open it),
and "Get common sentences" (AI, same key and daily budget as the cards).

Nothing here touches cards, sessions, streak or stats (sentences.py).
"""

import html
import threading

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMenu, QMessageBox,
    QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

import cards_ai
import languages
import sentences
from styles import TEXT, TEXT_MUTED, TEXT_SECONDARY, wrapping
from ui.flashcard import has_voice, listen_button_text, listen_button_tip, speak
from ui.widgets import ComboBox, WorkingLine
from ui.wordlabel import WordAdder, WordLabel, addable as addable_word

MARKS = {"learned": "✓", "seen": "◐", "new": "○"}
FILTERS = [("To learn", "todo"), ("Learned", "learned"), ("All", "all")]


def _card(title=None):
    frame = QFrame()
    frame.setObjectName("card")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(24, 18, 24, 18)
    layout.setSpacing(10)
    label = None
    if title:
        label = QLabel(title)
        label.setStyleSheet("font-weight: 700; font-size: 12pt;")
        layout.addWidget(label)
    return frame, layout, label


def _centered(style, rich=False, target=False):
    """Selectable text; `target` = in the learning language (right-click → Add)."""
    label = WordLabel("", addable=target)
    label.setTextFormat(Qt.TextFormat.RichText if rich else Qt.TextFormat.PlainText)
    label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    label.setStyleSheet(style)
    wrapping(label)
    return label


class SentencesScreen(QWidget):
    build_progress = pyqtSignal(int, int)          # added, asked for
    build_done = pyqtSignal(int, str)              # added, reason ("" = done)

    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self.langs = languages.load(db.get_setting)
        self.items = []
        self.current = None
        self.revealed = False
        self._busy = False
        self.build_progress.connect(self._on_progress)
        self.build_done.connect(self._on_done)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(self.scroll)
        content = QWidget()
        self.scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)

        header = QLabel("Sentences")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(header)
        intro = wrapping(QLabel(
            "Everyday sentences, with how to say them and what every word means. "
            "Separate from your cards: nothing here changes your streak, goal or stats."))
        intro.setStyleSheet(f"color: {TEXT_SECONDARY};")
        layout.addWidget(intro)

        # ------------------------------------------------ the sentence
        self.practice, practice, _ = _card()
        top = QHBoxLayout()
        self.topic_label = QLabel("")
        self.topic_label.setTextFormat(Qt.TextFormat.PlainText)
        self.topic_label.setStyleSheet(
            f"color: {TEXT_SECONDARY}; font-size: 8.5pt; font-weight: 700; letter-spacing: 1px;")
        top.addWidget(self.topic_label)
        top.addStretch()
        self.count_label = QLabel("")
        self.count_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        top.addWidget(self.count_label)
        practice.addLayout(top)

        self.text_label = _centered("font-size: 22pt; font-weight: 600;", target=True)
        self.text_label.setToolTip("Select a word and right-click to add it to your deck")
        practice.addWidget(self.text_label)
        self.reading_label = _centered(f"color: {TEXT_SECONDARY}; font-size: 13pt;")
        practice.addWidget(self.reading_label)

        # The answer: straight in the card (a nested widget would paint its
        # own background and clip a wrapped last line).
        self.translation_label = _centered(f"color: {TEXT}; font-size: 15pt; margin-top: 8px;")
        self.parts_label = _centered("font-size: 11.5pt;", rich=True)
        self.note_label = _centered(f"color: {TEXT_SECONDARY}; font-style: italic;")
        self.answer_labels = (self.translation_label, self.parts_label, self.note_label)
        for label in self.answer_labels:
            practice.addWidget(label)

        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        self.say_button = QPushButton("🔊  Listen")
        self.say_button.clicked.connect(self.say)
        buttons.addWidget(self.say_button)
        buttons.addStretch()
        self.reveal_button = QPushButton("Show meaning  (Space)")
        self.reveal_button.setObjectName("primary")
        self.reveal_button.setToolTip("Try to understand it first, then look.")
        self.reveal_button.clicked.connect(self.reveal)
        self.later_button = QPushButton("Again later")
        self.later_button.setToolTip("Keep it in the sentences to learn and go on (N)")
        self.later_button.clicked.connect(self.later)
        self.know_button = QPushButton("✓  I know it")
        self.know_button.setObjectName("success")
        self.know_button.setToolTip("Mark it learned. You can open it again from the list any time (K)")
        self.know_button.clicked.connect(self.know)
        self.unlearn_button = QPushButton("↺  Learn it again")
        self.unlearn_button.setToolTip("Put it back among the sentences to learn.")
        self.unlearn_button.clicked.connect(self.unlearn)
        for button in (self.say_button, self.reveal_button, self.later_button,
                       self.know_button, self.unlearn_button):
            button.setMinimumHeight(44)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
        for button in (self.reveal_button, self.later_button, self.know_button,
                       self.unlearn_button):
            buttons.addWidget(button)
        practice.addLayout(buttons)
        self.word_working = WorkingLine()
        practice.addWidget(self.word_working)
        self.word_status = _centered(f"color: {TEXT_SECONDARY};")
        self.word_status.hide()
        practice.addWidget(self.word_status)
        layout.addWidget(self.practice)
        self.adder = WordAdder(db.path, self)
        self.adder.done.connect(self._on_word_added)

        # ------------------------------------------------ the list
        self.list_card, list_layout, _ = _card()
        list_top = QHBoxLayout()
        list_title = QLabel("Your sentences")
        list_title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        list_top.addWidget(list_title)
        list_top.addStretch()
        self.filter = ComboBox()
        for label, _ in FILTERS:
            self.filter.addItem(label)
        self.filter.setToolTip("✓ learned   ◐ seen   ○ new")
        self.filter.currentIndexChanged.connect(self.fill_list)
        list_top.addWidget(self.filter)
        list_layout.addLayout(list_top)
        self.list = QListWidget()
        self.list.setMinimumHeight(240)
        self.list.setWordWrap(True)
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self.list_menu)
        self.list.itemClicked.connect(self.open_item)
        list_layout.addWidget(self.list)
        list_note = wrapping(QLabel("Click a sentence to open it. Right-click to remove one."))
        list_note.setStyleSheet(f"color: {TEXT_MUTED};")
        list_layout.addWidget(list_note)
        layout.addWidget(self.list_card)

        # ------------------------------------------------ getting them
        gen_card, gen_layout, self.gen_title = _card("Get common sentences")
        self.gen_info = wrapping(QLabel(""))
        self.gen_info.setStyleSheet(f"color: {TEXT_SECONDARY};")
        gen_layout.addWidget(self.gen_info)
        row = QHBoxLayout()
        row.setSpacing(10)
        row.addWidget(QLabel("Add"))
        self.size = ComboBox()
        self.size.addItems(sentences.SIZES)
        self.size.setCurrentText("50")
        self.size.setToolTip("How many new sentences to add. Ones you already have are never repeated.")
        row.addWidget(self.size)
        row.addWidget(QLabel("useful sentences for a"))
        self.level = ComboBox()
        self.level.addItems(list(sentences.LEVELS))
        self.level.setToolTip("Beginner: the first things a visitor needs. "
                              "Advanced: natural everyday speech. Expert: how a well-read "
                              "native speaker discusses and explains — idioms and nuance.")
        row.addWidget(self.level)
        row.addWidget(QLabel("learner"))
        row.addStretch()
        self.gen_button = QPushButton("✨  Generate")
        self.gen_button.setObjectName("primary")
        self.gen_button.setMinimumHeight(40)
        self.gen_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.gen_button.clicked.connect(self.generate)
        row.addWidget(self.gen_button)
        gen_layout.addLayout(row)
        self.gen_working = WorkingLine()
        gen_layout.addWidget(self.gen_working)
        self.gen_status = wrapping(QLabel(""))
        self.gen_status.setTextFormat(Qt.TextFormat.PlainText)
        self.gen_status.setStyleSheet(f"color: {TEXT_SECONDARY};")
        gen_layout.addWidget(self.gen_status)
        layout.addWidget(gen_card)
        layout.addStretch()

    # ------------------------------------------------------------ loading

    def word_to_add(self, text):
        """WordLabel asks: the selected text as a word worth a card, or ''."""
        return addable_word(text, self.langs.target)

    def add_selected_word(self, word):
        if self.adder.add(word):
            self.word_status.hide()
            self.word_working.start(f"Writing the card for “{word}”…")

    def _on_word_added(self, word, message):
        self.word_working.stop()
        self.word_status.setText(f"“{word}” — {message}")
        self.word_status.show()
        self.main_window.update_status()
        if "✓" in message:
            self.main_window.start_sync()

    def refresh(self):
        self.langs = languages.load(self.db.get_setting)
        scale = languages.script_scale(self.langs.target)
        self.text_label.setStyleSheet(f"font-size: {22 * scale:.0f}pt; font-weight: 600;")
        self.items = sentences.load(self.db.conn, self.langs.target)
        self.say_button.setText(listen_button_text(self.langs.target))
        self.say_button.setToolTip(listen_button_tip(self.langs.target, "the sentence"))
        keep = self.current and next((s for s in self.items if s["id"] == self.current["id"]), None)
        self.fill_list()
        self.refresh_generator()
        if keep:
            self.show_sentence(keep, reveal=self.revealed)
        else:
            self.show_sentence(sentences.next_to_learn(self.items))
        self.setFocus()

    def refresh_generator(self):
        writer = cards_ai.CardWriter(self.db.path)
        try:
            has_key = bool(writer.api_key())
        finally:
            writer.close()
        self.gen_title.setText("Get more sentences" if self.items else "Get common sentences")
        self.gen_info.setText(
            f"{self.langs.target} sentences explained in {self.langs.definition}, written by "
            f"the AI with your OpenAI key."
            + ("" if has_key else "  ⚠ No OpenAI key — add one in Settings first."))
        self.gen_button.setEnabled(has_key and not self._busy)

    def fill_list(self, *_):
        wanted = FILTERS[max(0, self.filter.currentIndex())][1]
        self.list.clear()
        for s in self.items:
            st = sentences.state(s)
            if wanted == "todo" and st == "learned" or wanted == "learned" and st != "learned":
                continue
            meaning = s.get("translation") or s.get("reading") or ""
            item = QListWidgetItem(f"{MARKS[st]}  {s['text']}" + (f"   —   {meaning}" if meaning else ""))
            item.setData(Qt.ItemDataRole.UserRole, s["id"])
            if st == "learned":
                item.setForeground(QColor(TEXT_SECONDARY))
            self.list.addItem(item)
        learned, total = sentences.counts(self.db.conn, self.langs.target)
        self.count_label.setText(f"{learned} of {total} learned" + (" ✓" if total and learned == total else ""))
        self.practice.setVisible(total > 0)
        self.list_card.setVisible(total > 0)

    # ------------------------------------------------------------ showing

    def show_sentence(self, sentence, reveal=False):
        self.current = sentence
        self.revealed = False
        if sentence is None:
            learned, total = sentences.counts(self.db.conn, self.langs.target)
            self.topic_label.setText("")
            self.text_label.setText(f"All {total} learned ✓" if total else "")
            self.reading_label.setText(
                "Open any sentence in the list to look at it again, or get more below.")
            self._show_answer(False)
            for button in (self.say_button, self.reveal_button, self.later_button,
                           self.know_button, self.unlearn_button):
                button.hide()
            return
        self.topic_label.setText((sentence.get("topic") or "").upper())
        self.text_label.setText(sentence["text"])
        self.reading_label.setText(sentence.get("reading") or "")
        self.translation_label.setText(sentence.get("translation") or "")
        parts = sentences.parts_of(sentence)
        # piece, its reading (kanji languages), its meaning: 駅 eki σταθμός
        self.parts_label.setText("&nbsp;&nbsp;·&nbsp;&nbsp;".join(
            f"<b>{html.escape(piece)}</b>"
            + (f" <i style='color:{TEXT_SECONDARY}'>{html.escape(said)}</i>" if said else "")
            + f" <span style='color:{TEXT_SECONDARY}'>{html.escape(meaning)}</span>"
            for piece, meaning, said in parts))
        self.note_label.setText(sentence.get("note") or "")
        self.say_button.show()
        if reveal:
            self.reveal()
        else:
            self._show_answer(False)
            self.reveal_button.show()
            for button in (self.later_button, self.know_button, self.unlearn_button):
                button.hide()

    def reveal(self):
        if self.current is None or self.revealed:
            return
        self.revealed = True
        self._show_answer(True)
        self.reveal_button.hide()
        learned = bool(self.current.get("learned_at"))
        self.later_button.setText("Next" if learned else "Again later")
        self.later_button.show()
        self.know_button.setVisible(not learned)
        self.unlearn_button.setVisible(learned)
        if not self.current.get("seen_at"):
            sentences.mark_seen(self.db.conn, self.current["id"])
            self._reload()

    def _show_answer(self, on):
        for label in self.answer_labels:
            label.setVisible(on and bool(label.text()))

    def _reload(self):
        """Re-read after a change, keeping the sentence in front of you."""
        current_id = self.current["id"] if self.current else None
        self.items = sentences.load(self.db.conn, self.langs.target)
        self.current = next((s for s in self.items if s["id"] == current_id), None)
        self.fill_list()

    def later(self):
        if self.current is None:
            return
        # The next one not learned yet (the same one again when it is the
        # last); "All learned" when none is left.
        self.show_sentence(sentences.next_to_learn(self.items, self.current["id"]))

    def know(self):
        if self.current is None or not self.revealed:
            return
        sentences.mark_learned(self.db.conn, self.current["id"])
        self.main_window.celebrate_soon()             # 10, 50, 100 sentences learned
        self._reload()
        self.show_sentence(sentences.next_to_learn(
            self.items, self.current["id"] if self.current else None))

    def unlearn(self):
        if self.current is None:
            return
        sentences.mark_learned(self.db.conn, self.current["id"], learned=False)
        self._reload()
        self.show_sentence(self.current, reveal=True)

    def say(self):
        if self.current is None:
            return
        if not has_voice(self.langs.target):
            self.note_label.setText(listen_button_tip(self.langs.target, "the sentence"))
            self.note_label.setVisible(True)
            return
        speak(self.current["text"], self.langs.target)

    def open_item(self, item):
        sentence_id = item.data(Qt.ItemDataRole.UserRole)
        sentence = next((s for s in self.items if s["id"] == sentence_id), None)
        if sentence is not None:
            self.show_sentence(sentence)
            self.scroll.verticalScrollBar().setValue(0)
            self.setFocus()

    def list_menu(self, position):
        item = self.list.itemAt(position)
        if item is None:
            return
        menu = QMenu(self)
        remove_action = menu.addAction("🗑️  Remove this sentence")
        if menu.exec(self.list.viewport().mapToGlobal(position)) is not remove_action:
            return
        sentence_id = item.data(Qt.ItemDataRole.UserRole)
        if QMessageBox.question(self, "Remove sentence",
                                "Remove this sentence from your list?") \
                != QMessageBox.StandardButton.Yes:
            return
        sentences.remove(self.db.conn, sentence_id)
        was_current = self.current and self.current["id"] == sentence_id
        self._reload()
        if was_current or self.current is None:
            self.show_sentence(sentences.next_to_learn(self.items))
        self.main_window.start_sync()

    def keyPressEvent(self, event):
        key = event.key()
        if key == Qt.Key.Key_Space:
            self.reveal()
        elif key == Qt.Key.Key_N:
            if self.revealed:
                self.later()
        elif key in (Qt.Key.Key_K, Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.know()
        elif key == Qt.Key.Key_P:
            self.say()
        else:
            super().keyPressEvent(event)

    # ------------------------------------------------------------ getting

    def generate(self):
        if self._busy:
            return
        count = int(self.size.currentText())
        level = self.level.currentText()
        self._asked = count
        self._busy = True
        self.gen_button.setEnabled(False)
        self.gen_working.start(f"Writing everyday {self.langs.target} sentences…")
        self.gen_status.setText(
            f"Each batch of {sentences.BATCH} is saved as it arrives; stopping loses nothing.")

        def work():
            writer = sentences.SentenceWriter(self.db.path)
            try:
                added, reason = writer.build(
                    count, level, progress=lambda a, n: self.build_progress.emit(a, n))
            except Exception as exc:
                added, reason = 0, str(exc)
            finally:
                writer.close()
            self.build_done.emit(added, reason or "")

        threading.Thread(target=work, daemon=True).start()

    def _on_progress(self, added, asked):
        self.gen_working.set_text(f"Writing sentences — {added} of {asked} new…")
        self._reload()
        if self.current is None:
            self.show_sentence(sentences.next_to_learn(self.items))

    def _on_done(self, added, reason):
        self._busy = False
        self.gen_working.stop()
        left = getattr(self, "_asked", added) - added
        if reason and left > 0:
            if self.size.findText(str(left)) < 0:     # the rest waits in the size box
                self.size.addItem(str(left))
            self.size.setCurrentText(str(left))
            self.gen_status.setText(
                f"Added {added} of {self._asked} new sentences. {reason[:1].upper()}{reason[1:]}. "
                "Press Generate " + ("tomorrow to add" if "tomorrow" in reason else "to try for")
                + f" the other {left}.")
        elif reason:
            self.gen_status.setText(f"{reason[:1].upper()}{reason[1:]}.")
        else:
            self.gen_status.setText(f"Done — {added} new sentence{'s' if added != 1 else ''}. 🎉")
        self.main_window.start_sync()
        self.refresh()

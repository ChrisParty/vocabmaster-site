"""Text the learner can select and copy — and a word in the language being
learned can go straight into the deck: select it, right-click, "＋ Add".
Double-click a word: a small card shows it from the deck (word, reading,
translation, meaning) — no AI, no cost; a word not in the deck offers
"＋ Add to my deck".

WordLabel is a QLabel whose text can be selected with the mouse (Ctrl+C
and a right-click Copy work). When it holds learning-language text
(`addable=True`) and the screen it sits on has `word_to_add(text)` and
`add_selected_word(word)`, the right-click menu also offers to add the
selected word. WordAdder writes the card off the UI thread (the same AI
call as Add one word, under the same daily budget).
"""

import threading

from PyQt6.QtCore import QEvent, QObject, QPoint, QPointF, Qt, pyqtSignal
from PyQt6.QtGui import QGuiApplication, QMouseEvent
from PyQt6.QtWidgets import (
    QApplication, QFrame, QHBoxLayout, QLabel, QMenu, QPushButton, QVBoxLayout,
)

import cards_ai
import wordlookup
from styles import ACCENT, BORDER, SURFACE, TEXT, TEXT_SECONDARY

PUNCTUATION = " \t\r\n.,!?;:\"'“”‘’„«»()[]{}…—–-·。、！？「」『』（）"


def addable(text, target):
    """The selection as a word or short phrase worth a card in `target`,
    or '' (too long, no letters, or not in the learning language's script)."""
    word = (text or "").strip(PUNCTUATION)
    if not word or len(word) > 40 or "\n" in word or " " in word or len(word.split()) > 4:
        return ""
    if not any(ch.isalpha() for ch in word):
        return ""
    if (target or "").lower() in cards_ai.SCRIPTS:
        return word if cards_ai.script_share(word, target) >= 0.5 else ""
    # A Latin-script language: letters from another script are a translation.
    return word if all(ord(ch) < 0x0370 for ch in word if ch.isalpha()) else ""


class WordLabel(QLabel):

    def __init__(self, text="", addable=False):
        super().__init__(text)
        self.addable = addable
        self.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

    def _owner(self):
        widget = self.parentWidget()
        while widget is not None and not hasattr(widget, "add_selected_word"):
            widget = widget.parentWidget()
        return widget

    def menu_for(self, chosen):
        """The right-click menu for the selected text (built separately so
        it can be tested without a mouse)."""
        # Parented to the window, not the label: a label's own font size (a
        # story line is 19 pt) would otherwise make the menu huge.
        menu = QMenu(self.window())
        copy = menu.addAction("Copy")
        copy.setEnabled(bool(chosen))
        copy.triggered.connect(lambda: QApplication.clipboard().setText(chosen))
        owner = self._owner() if self.addable else None
        if owner is not None:
            menu.addSeparator()
            word = owner.word_to_add(chosen) if chosen else ""
            if word:
                menu.addAction(f"＋  Add “{word}” to my deck",
                               lambda: owner.add_selected_word(word))
            else:
                hint = menu.addAction("Select a word to add it to your deck")
                hint.setEnabled(False)
        return menu

    def word_at(self, pos):
        """Nothing selected: select the word under the pointer, as a double
        click would, and return it — a right-click on a word is enough."""
        point = QPointF(pos)
        self._synthetic = True                 # not a real double-click: no word card
        try:
            for kind in (QEvent.Type.MouseButtonDblClick, QEvent.Type.MouseButtonRelease):
                QApplication.sendEvent(self, QMouseEvent(
                    kind, point, self.mapToGlobal(point), Qt.MouseButton.LeftButton,
                    Qt.MouseButton.LeftButton if kind == QEvent.Type.MouseButtonDblClick
                    else Qt.MouseButton.NoButton, Qt.KeyboardModifier.NoModifier))
        finally:
            self._synthetic = False
        return self.selectedText().strip()

    def mouseDoubleClickEvent(self, event):
        super().mouseDoubleClickEvent(event)
        if getattr(self, "_synthetic", False) or not self.addable:
            return
        owner = self._owner()
        chosen = self.selectedText().strip()
        if owner is not None and chosen and hasattr(owner, "db"):
            show_word_card(owner, chosen, event.globalPosition().toPoint())

    def contextMenuEvent(self, event):
        chosen = self.selectedText().strip() or self.word_at(event.pos())
        self.menu_for(chosen).exec(event.globalPos())


def show_word_card(owner, text, where):
    """The double-click card: the word from the deck, or an offer to add it.
    Japanese has no spaces (a double-click selects the sentence): the card
    then lists the deck's words found in that sentence."""
    language = owner.langs.target
    unspaced = language.strip().lower() in ("japanese", "chinese")
    plain = wordlookup._clean(text)
    if unspaced and len(plain) > 4:
        cards, sentence = wordlookup.in_sentence(owner.db.conn, text, language), True
    else:
        card = wordlookup.find(owner.db.conn, text, language)
        cards, sentence = ([card] if card else []), False
    popup = WordCard(owner, cards, text, sentence)
    popup.adjustSize()
    screen = QGuiApplication.screenAt(where) or QGuiApplication.primaryScreen()
    room = screen.availableGeometry()
    x = min(where.x() + 12, room.right() - popup.width() - 8)
    y = where.y() + 16
    if y + popup.height() > room.bottom():
        y = max(room.top(), where.y() - popup.height() - 12)
    popup.move(QPoint(max(room.left(), x), y))
    popup.show()
    owner._word_card = popup                   # kept alive while it is open
    return popup


class WordCard(QFrame):
    """A small card beside the pointer; any click elsewhere closes it."""

    def __init__(self, owner, cards, clicked, sentence):
        super().__init__(None, Qt.WindowType.Popup)
        self.setObjectName("wordCard")
        self.setStyleSheet(
            f"QFrame#wordCard {{ background: {SURFACE}; border: 1px solid {BORDER}; "
            f"border-radius: 10px; }} QLabel {{ background: transparent; }}")
        self.setMaximumWidth(380)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 14)
        layout.setSpacing(4)
        langs = owner.langs
        if cards:
            if sentence:
                layout.addWidget(self._text("From your deck, in this sentence:", TEXT_SECONDARY, 9))
            import wordview
            for index, card in enumerate(cards):
                if index:
                    rule = QFrame()
                    rule.setFixedHeight(1)
                    rule.setStyleSheet(f"background: {BORDER};")
                    layout.addSpacing(4)
                    layout.addWidget(rule)
                    layout.addSpacing(4)
                head, reading = wordview.headline(card, langs.target, owner.db.get_setting)
                top = QHBoxLayout()
                top.addWidget(self._text(head, TEXT, 15, bold=True), 1)
                listen = self._listen_button(card["word"], langs.target)
                if listen is not None:
                    top.addWidget(listen, 0, Qt.AlignmentFlag.AlignTop)
                layout.addLayout(top)
                if reading:
                    layout.addWidget(self._text(reading, TEXT_SECONDARY, 10))
                translation = (card.get("greek") or "").strip() if langs.native else ""
                if translation:
                    layout.addWidget(self._text(translation, ACCENT, 11, bold=True))
                definition = (card.get("definition") or "").strip()
                if definition:
                    short = definition if len(definition) <= 140 else definition[:137] + "…"
                    layout.addWidget(self._text(short, TEXT, 10))
            if not sentence and wordlookup._clean(cards[0]["word"]) != wordlookup._clean(clicked):
                layout.addWidget(self._text(f"(“{clicked.strip()}” is a form of this word)",
                                            TEXT_SECONDARY, 9))
        else:
            word = owner.word_to_add(clicked) if hasattr(owner, "word_to_add") else ""
            if sentence or not word:
                layout.addWidget(self._text(
                    "None of these words are in your deck yet." if sentence
                    else f"“{clicked.strip()}” is not in your deck.", TEXT, 10))
                if sentence:
                    layout.addWidget(self._text(
                        "Select a word and right-click to add it.", TEXT_SECONDARY, 9))
            else:
                layout.addWidget(self._text(f"“{word}” is not in your deck yet.", TEXT, 11))
                add = QPushButton("＋  Add to my deck")
                add.setCursor(Qt.CursorShape.PointingHandCursor)
                add.setToolTip("The AI writes a full card for it, like Add one word")
                add.clicked.connect(lambda: (self.close(), owner.add_selected_word(word)))
                layout.addWidget(add, 0, Qt.AlignmentFlag.AlignLeft)

    @staticmethod
    def _text(text, color, size, bold=False):
        label = QLabel(text)
        label.setTextFormat(Qt.TextFormat.PlainText)
        label.setWordWrap(True)
        label.setStyleSheet(f"color: {color}; font-size: {size}pt;"
                            + (" font-weight: 700;" if bold else ""))
        return label

    @staticmethod
    def _listen_button(word, language):
        from ui.flashcard import has_voice, speak
        if not has_voice(language):
            return None
        button = QPushButton("🔊")
        button.setFixedSize(34, 28)
        button.setStyleSheet("padding: 0;")            # the app's padding would hide the icon
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setToolTip("Hear it")
        button.clicked.connect(lambda: speak(word, language))
        return button

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.close()
            return
        super().keyPressEvent(event)


class WordAdder(QObject):
    """One word → one full card, off the UI thread; `done(word, message)`."""
    done = pyqtSignal(str, str)

    def __init__(self, db_path, parent=None):
        super().__init__(parent)
        self.db_path = db_path
        self._busy = False

    def busy(self):
        return self._busy

    def add(self, word):
        if self._busy:
            return False
        self._busy = True

        def work():
            writer = cards_ai.CardWriter(self.db_path)
            try:
                entry = writer.add_word(word, as_found=True)
                if entry is None:
                    message = "already in your deck"
                elif entry["word"].strip().lower() != word.strip().lower():
                    message = f"added to your deck as “{entry['word']}” ✓"
                else:
                    message = "added to your deck ✓"
            except Exception as exc:
                message = f"not added: {exc}"
            finally:
                writer.close()
            self._busy = False
            self.done.emit(word, message)

        threading.Thread(target=work, daemon=True).start()
        return True

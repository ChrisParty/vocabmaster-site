"""Import screen: the ways to get words into a deck.

  paste / CSV      a spreadsheet, columns detected from the header row —
                   switched off (`SPREADSHEET`), the code kept
  common words     N more of the most useful words at a level (the deck's own
                   are skipped, so levels mix), cards written by the AI in
                   batches under the daily budget and cards_ai.WORDS_PER_DAY
  add a word       one word → one full AI-written card

Plus the whole-deck move (restore a backup), because a fresh install lands
here first.
"""

import os
import threading

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit,
    QMessageBox, QPushButton, QScrollArea, QTableWidget, QTableWidgetItem,
    QTextEdit, QVBoxLayout, QWidget,
)

import cards_ai
import languages
import samples
import parser as vparser
from styles import ACCENT, DANGER, SUCCESS, TEXT_SECONDARY, wrapping
from ui.widgets import ComboBox, WorkingLine

BADGE_STYLE = (
    "color: {color}; background-color: {bg}; border-radius: 9px;"
    "padding: 3px 10px; font-weight: 600;"
)

# The spreadsheet paste (and a .csv dropped on the screen) is switched off
# (Mike, 2026-10-22): it was how his first deck arrived, but a learner cannot
# know what columns a Korean sheet needs, and a wrong paste makes a mess of a
# deck. Nothing is deleted — True brings it back. A plain "add many words"
# box may take its place later.
SPREADSHEET = False

# How many new words one Generate adds; none above cards_ai.WORDS_PER_DAY.
STARTER_SIZES = ["20", "50", "100", "300"]


class PasteArea(QTextEdit):
    """Paste box that recovers the table structure from clipboard HTML.

    Copying from Excel/Sheets puts both plain text and an HTML table on the
    clipboard. Some sources produce plain text with one CELL per line (no
    tabs), which is unparseable — the HTML version always keeps the columns,
    so prefer it whenever it contains a table.
    """

    def insertFromMimeData(self, source):
        if source.hasHtml():
            tsv = vparser.html_table_to_tsv(source.html())
            if tsv:
                self.insertPlainText(tsv)
                return
        super().insertFromMimeData(source)


def _card(title):
    frame = QFrame()
    frame.setObjectName("card")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(24, 18, 24, 18)
    layout.setSpacing(10)
    label = QLabel(title)
    label.setStyleSheet("font-weight: 700; font-size: 12pt;")
    layout.addWidget(label)
    return frame, layout


class ImportScreen(QWidget):
    # AI work runs on worker threads; results come back through these.
    starter_progress = pyqtSignal(int, int)        # added, asked for
    starter_done = pyqtSignal(int, str)            # added, reason ("" = done)
    complete_done = pyqtSignal(int, str)
    add_done = pyqtSignal(str, str, str)           # word, message, word id ("" = none)

    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self.entries = []
        self.langs = languages.load(db.get_setting)
        self._busy = False
        self.setAcceptDrops(SPREADSHEET)
        self.starter_progress.connect(self._on_starter_progress)
        self.starter_done.connect(self._on_starter_done)
        self.complete_done.connect(self._on_complete_done)
        self.add_done.connect(self._on_add_done)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(14)

        header = QLabel("Add Words")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(header)

        # ------------------------------------------------ try it first
        # Only for an empty deck with a matching sample (samples.py).
        self.sample_card, sample_layout = _card("Try it first — 20 sample words")
        self.sample_info = QLabel("")
        self.sample_info.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(self.sample_info)
        sample_layout.addWidget(self.sample_info)
        self.sample_button = QPushButton("🎁  Add 20 sample words")
        self.sample_button.setObjectName("primary")
        self.sample_button.setMinimumHeight(40)
        self.sample_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.sample_button.clicked.connect(self.add_sample)
        sample_layout.addWidget(self.sample_button, 0, Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(self.sample_card)

        # ------------------------------------------------ starter deck
        starter_card, starter_layout = _card("Add common words with AI")
        self.starter_info = QLabel("")
        self.starter_info.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(self.starter_info)
        starter_layout.addWidget(self.starter_info)
        starter_row = QHBoxLayout()
        starter_row.setSpacing(10)
        starter_row.addWidget(QLabel("Add"))
        self.starter_size = ComboBox()
        self.starter_size.addItems(STARTER_SIZES)
        self.starter_size.setCurrentText("300")
        self.starter_size.setToolTip(
            "How many new words to add. Words already in your deck are skipped, "
            "so levels can be mixed: beginner words now, harder ones later.")
        starter_row.addWidget(self.starter_size)
        starter_row.addWidget(QLabel("new words for a"))
        self.starter_level = ComboBox()
        self.starter_level.addItems(list(cards_ai.LEVELS))
        self.starter_level.setToolTip(
            "beginner: the first weeks of the language. intermediate: everyday "
            "fluency. advanced: precise words an educated speaker uses. expert: "
            "words a well-read native speaker knows from serious books and newspapers.")
        starter_row.addWidget(self.starter_level)
        starter_row.addWidget(QLabel("learner"))
        starter_row.addStretch()
        self.starter_button = QPushButton("✨  Generate")
        self.starter_button.setObjectName("primary")
        self.starter_button.setMinimumHeight(40)
        self.starter_button.setToolTip(
            "Writes full cards — definition, translations, example, memory hook — "
            "with your OpenAI key, never past the daily AI budget in Settings.")
        self.starter_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.starter_button.clicked.connect(self.build_starter)
        starter_row.addWidget(self.starter_button)
        starter_layout.addLayout(starter_row)
        self.starter_working = WorkingLine()
        starter_layout.addWidget(self.starter_working)
        self.starter_status = QLabel("")
        self.starter_status.setTextFormat(Qt.TextFormat.PlainText)
        self.starter_status.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(self.starter_status)
        starter_layout.addWidget(self.starter_status)
        layout.addWidget(starter_card)

        # --------------------------------------------------- add a word
        add_card, add_layout = _card("Add one word")
        add_row = QHBoxLayout()
        add_row.setSpacing(10)
        self.add_word = QLineEdit()
        self.add_word.setPlaceholderText("a word or phrase in the language you are learning")
        self.add_word.setToolTip("Type a word, press Enter: a full card is written and added.")
        self.add_word.returnPressed.connect(self.add_one)
        add_row.addWidget(self.add_word, 1)
        self.add_button = QPushButton("✨  Write the card")
        self.add_button.setMinimumHeight(40)
        self.add_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_button.clicked.connect(self.add_one)
        add_row.addWidget(self.add_button)
        add_layout.addLayout(add_row)
        self.add_working = WorkingLine()
        add_layout.addWidget(self.add_working)
        self.add_status = QLabel("")
        self.add_status.setTextFormat(Qt.TextFormat.PlainText)
        self.add_status.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(self.add_status)
        add_layout.addWidget(self.add_status)
        # After a word is added (or found already there): straight to it.
        open_row = QHBoxLayout()
        self.add_open = QPushButton("Go to word  →")
        self.add_open.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_open.setToolTip("Open this card in Browse: see it whole, hear it, edit it")
        self.add_open.clicked.connect(self.open_added)
        self.add_open.hide()
        self._added_id = ""
        open_row.addWidget(self.add_open)
        open_row.addStretch()
        add_layout.addLayout(open_row)
        layout.addWidget(add_card)

        # ---------------------------------------------- complete old cards
        self.complete_card, complete_layout = _card("Complete your existing cards")
        self.complete_info = wrapping(QLabel(""))
        self.complete_info.setStyleSheet(f"color: {TEXT_SECONDARY};")
        complete_layout.addWidget(self.complete_info)
        self.complete_working = WorkingLine()
        complete_layout.addWidget(self.complete_working)
        self.complete_button = QPushButton("✨  Add readings and translations")
        self.complete_button.setMinimumHeight(40)
        self.complete_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.complete_button.setToolTip(
            "Cards made before this were missing the example's translation and the "
            "word's reading.")
        self.complete_button.clicked.connect(self.complete_missing)
        complete_layout.addWidget(self.complete_button)
        layout.addWidget(self.complete_card)
        self.complete_card.hide()

        # ------------------------------------------------ paste / file
        # The original way in, kept out of the way: a spreadsheet is how the
        # first deck arrived, not how a learner adds words day to day.
        self.paste_toggle = QPushButton("Paste a spreadsheet instead…")
        self.paste_toggle.setStyleSheet(
            f"color: {TEXT_SECONDARY}; background: transparent; border: none; "
            "text-align: left; padding: 4px 0;")
        self.paste_toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.paste_toggle.clicked.connect(lambda: self.toggle_paste())
        self.paste_toggle.setVisible(SPREADSHEET)
        layout.addWidget(self.paste_toggle)
        paste_card, paste_layout = _card("Paste a spreadsheet")
        self.paste_card = paste_card
        paste_card.hide()
        instructions = QLabel(
            "Open your sheet → select all (Ctrl+A) → copy (Ctrl+C) → paste below. "
            "Columns are detected from the header row. You can also drag and "
            "drop a .csv file anywhere on this screen.\n"
            "Moving from another computer? Use “Restore from a backup” instead — "
            "it brings your progress and pictures along."
        )
        instructions.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(instructions)
        paste_layout.addWidget(instructions)

        self.paste_area = PasteArea()
        self.paste_area.setPlaceholderText("Paste your spreadsheet data here…")
        self.paste_area.setMinimumHeight(120)
        self.paste_area.textChanged.connect(self.update_preview)
        paste_layout.addWidget(self.paste_area)

        self.badges_row = QHBoxLayout()
        self.badges_row.setSpacing(8)
        badges_container = QWidget()
        badges_container.setLayout(self.badges_row)
        paste_layout.addWidget(badges_container)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet(f"color: {DANGER}; font-weight: 600;")
        wrapping(self.error_label)
        self.error_label.hide()
        paste_layout.addWidget(self.error_label)

        self.preview_label = QLabel("Preview (first 5 rows):")
        self.preview_label.setStyleSheet("font-weight: 600;")
        self.preview_label.hide()
        paste_layout.addWidget(self.preview_label)

        self.preview_table = QTableWidget()
        self.preview_table.setColumnCount(7)
        self.preview_table.verticalHeader().setVisible(False)
        self.preview_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.preview_table.setAlternatingRowColors(True)
        self.preview_table.horizontalHeader().setStretchLastSection(True)
        self.preview_table.setMaximumHeight(230)
        self.preview_table.hide()
        paste_layout.addWidget(self.preview_table)

        buttons_row = QHBoxLayout()
        buttons_row.setSpacing(10)

        # The whole-deck move lives in the main window (Settings offers it
        # too); a fresh install lands on this screen, so it belongs here as well.
        self.restore_button = QPushButton("📥  Restore from a backup…")
        self.restore_button.setMinimumHeight(48)
        self.restore_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.restore_button.clicked.connect(self.main_window.restore_backup)
        buttons_row.addWidget(self.restore_button)

        self.file_button = QPushButton("📂  Choose CSV file…")
        self.file_button.setMinimumHeight(48)
        self.file_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.file_button.clicked.connect(self.choose_file)
        buttons_row.addWidget(self.file_button)

        self.import_button = QPushButton("Import words")
        self.import_button.setObjectName("primary")
        self.import_button.setMinimumHeight(48)
        self.import_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.import_button.setEnabled(False)
        self.import_button.clicked.connect(self.do_import)
        buttons_row.addWidget(self.import_button, 1)
        paste_layout.addLayout(buttons_row)
        layout.addWidget(paste_card)

        layout.addStretch()

    def add_sample(self):
        path = samples.offer(self.db, self.langs)
        if not path:
            return
        added = samples.add_to(self.db, self.langs, path)
        self.main_window.update_status()
        self.main_window.start_sync()
        self.refresh()
        self.starter_status.setText(
            f"{added} sample words added ✓ — press Study to meet them. When you want "
            f"more, build a starter deck here (it needs your OpenAI key).")

    def refresh(self):
        self.langs = languages.load(self.db.get_setting)
        sample = samples.offer(self.db, self.langs)
        self.sample_card.setVisible(bool(sample))
        if sample:
            self.sample_info.setText(
                f"Real cards to start with — 20 everyday {self.langs.target} words with how "
                f"they are read, an example and a memory hook. No OpenAI key needed; your "
                f"own words can come later.")
        self.preview_table.setHorizontalHeaderLabels([
            "Word", "Definition", "POS", self.langs.native or "Translation",
            self.langs.second or "Translation 2", "Synonyms", "Example"])
        writer = cards_ai.CardWriter(self.db.path)
        try:
            has_key = bool(writer.api_key())
        finally:
            writer.close()
        self.starter_info.setText(
            f"Deck: {self.langs.describe()} — change in Settings."
            + ("" if has_key else "  ⚠ No OpenAI key — add one in Settings first."))
        self.starter_button.setEnabled(has_key and not self._busy)
        self.add_button.setEnabled(has_key and not self._busy)
        writer = cards_ai.CardWriter(self.db.path)
        try:
            missing = len(writer.incomplete())
        finally:
            writer.close()
        self.complete_card.setVisible(missing > 0)
        self.complete_info.setText(
            f"{missing} card{'s' if missing != 1 else ''} lack a reading or the example's "
            f"translation — things a beginner needs. One click fills them in, and "
            f"keeps your progress. Rather have brand-new cards? Settings → Start over.")
        self.complete_button.setEnabled(has_key and not self._busy)

    # ------------------------------------------------------- starter deck

    def build_starter(self):
        if self._busy:
            return
        count = int(self.starter_size.currentText())
        level = self.starter_level.currentText()
        self._starter_asked = count
        self._set_busy(True)
        self.starter_button.setText("Working…")
        self.starter_working.start(f"Choosing the most common {self.langs.target} words…")
        self.starter_status.setText(
            "Cards arrive in batches of 20 and are saved as they come — you can "
            "study the first ones already, and stopping loses nothing.")

        def work():
            writer = cards_ai.CardWriter(self.db.path)
            try:
                added, reason = writer.build_starter(
                    count, level, progress=lambda a, n: self.starter_progress.emit(a, n))
            except Exception as exc:
                added, reason = 0, str(exc)
            finally:
                writer.close()
            self.starter_done.emit(added, reason or "")

        threading.Thread(target=work, daemon=True).start()

    def _on_starter_progress(self, added, asked):
        self.starter_working.set_text(f"Writing cards — {added} of {asked} new words…")

    def _on_starter_done(self, added, reason):
        self._set_busy(False)
        self.starter_working.stop()
        left = getattr(self, "_starter_asked", added) - added
        pace = self.db.get_int_setting("max_new_per_day", 20)
        if reason == cards_ai.words_limit_message(pace) and left > 0:
            if self.starter_size.findText(str(left)) < 0:
                self.starter_size.addItem(str(left))
            self.starter_size.setCurrentText(str(left))
            self.starter_status.setText(
                f"Added {added} of {self._starter_asked} new words — that makes "
                f"{cards_ai.WORDS_PER_DAY} today, {cards_ai.WORDS_PER_DAY // max(1, pace)} days of "
                f"new words at {max(1, pace)} a day. Press Generate tomorrow to add the other {left}.")
        elif reason and left > 0:
            # The rest waits in the size box: Generate adds exactly those.
            if self.starter_size.findText(str(left)) < 0:
                self.starter_size.addItem(str(left))
            self.starter_size.setCurrentText(str(left))
            self.starter_status.setText(
                f"Added {added} of {self._starter_asked} new words. "
                f"{reason[:1].upper()}{reason[1:]}. Press Generate "
                + ("tomorrow to add" if "tomorrow" in reason else "to try for") + f" the other {left}.")
        elif reason:
            self.starter_status.setText(f"{reason[:1].upper()}{reason[1:]}.")
        else:
            self.starter_status.setText(
                f"Done — {added} new card{'s' if added != 1 else ''} in the deck. 🎉")
        self.main_window.update_status()
        self.main_window.start_sync()
        self.refresh()

    def complete_missing(self):
        if self._busy:
            return
        self._set_busy(True)
        self.complete_working.start("Filling in readings and translations…")

        def work():
            writer = cards_ai.CardWriter(self.db.path)
            try:
                done, reason = writer.complete_missing()
            except Exception as exc:
                done, reason = 0, str(exc)
            finally:
                writer.close()
            self.complete_done.emit(done, reason or "")

        threading.Thread(target=work, daemon=True).start()

    def _on_complete_done(self, done, reason):
        self._set_busy(False)
        self.complete_working.stop()
        self.main_window.start_sync()
        self.refresh()
        if reason:
            self.complete_info.setText(f"Stopped after {done}: {reason}. Press again to continue.")
        elif done:
            self.complete_info.setText(f"Done — {done} cards completed. 🎉")

    # ----------------------------------------------------------- add one

    def add_one(self):
        word = self.add_word.text().strip()
        if not word or self._busy:
            return
        self._set_busy(True)
        self.add_button.setText("Writing…")
        self.add_status.setText("")
        self.add_open.hide()
        self.add_working.start(f"Writing the card for “{word}”…")

        def work():
            writer = cards_ai.CardWriter(self.db.path)
            try:
                entry = writer.add_word(word)
                found = writer.conn.execute(
                    "SELECT id FROM words WHERE lower(word) = lower(?)",
                    ((entry or {}).get("word") or word,)).fetchone()
                word_id = found[0] if found else ""
                if entry is None:
                    message = ("already in your deck" if word_id else
                               "no card came back — check the spelling and try again")
                else:
                    extras = [name for name, key in (
                        ("translation", "greek"), ("second translation", "swedish"),
                        ("synonyms", "synonyms"), ("example", "example"),
                        ("memory hook", "hook")) if entry.get(key)]
                    message = (f"added: {entry['definition']}  "
                               f"(+ {', '.join(extras)})" if extras
                               else f"added: {entry['definition']}")
            except cards_ai.DailyWordsReached as exc:
                message, word_id = f"not added — {exc}.", ""
            except Exception as exc:
                message, word_id = f"failed: {exc}", ""
            finally:
                writer.close()
            self.add_done.emit(word, message, word_id)

        threading.Thread(target=work, daemon=True).start()

    def _on_add_done(self, word, message, word_id):
        self._set_busy(False)
        self.add_working.stop()
        self.add_status.setText(f"“{word}” — {message}")
        self._added_id = word_id
        self.add_open.setText(f"Go to “{word}”  →")
        self.add_open.setVisible(bool(word_id))
        if message.startswith("added"):
            self.add_word.clear()
            self.main_window.update_status()
            self.main_window.start_sync()
        self.refresh()

    def open_added(self):
        """The word just added (or already there), opened in Browse."""
        if self._added_id:
            self.main_window.navigate("browse")
            self.main_window.screens["browse"].open_word(self._added_id)

    def toggle_paste(self, show=None):
        # isHidden(), not isVisible(): the latter is False whenever the page
        # itself is not on screen, which would make the toggle one-way.
        visible = self.paste_card.isHidden() if show is None else bool(show)
        visible = visible and SPREADSHEET            # switched off: it never opens
        self.paste_card.setVisible(visible)
        self.paste_toggle.setText("Hide the spreadsheet import" if visible
                                  else "Paste a spreadsheet instead…")

    def _set_busy(self, busy):
        self._busy = busy
        self.starter_button.setEnabled(not busy)
        self.add_button.setEnabled(not busy)
        self.complete_button.setEnabled(not busy)
        # Only the button whose job is running says so; the others just wait.
        if not busy:
            self.starter_button.setText("✨  Generate")
            self.add_button.setText("✨  Write the card")

    # -------------------------------------------------------------- preview

    def update_preview(self):
        text = self.paste_area.toPlainText()
        entries, columns, error = vparser.parse_text(text, self.langs)
        self.entries = entries
        self._render_badges(columns)

        if error and text.strip():
            self.error_label.setText(f"⚠️  {error}")
            self.error_label.show()
        else:
            self.error_label.hide()

        if entries:
            self.preview_label.show()
            self.preview_table.show()
            rows = entries[:5]
            self.preview_table.setRowCount(len(rows))
            fields = ["word", "definition", "pos", "greek", "swedish", "synonyms", "example"]
            for r, entry in enumerate(rows):
                for c, field in enumerate(fields):
                    value = entry.get(field, "")
                    if len(value) > 60:
                        value = value[:57] + "…"
                    self.preview_table.setItem(r, c, QTableWidgetItem(value))
            self.preview_table.resizeRowsToContents()
            self.import_button.setText(f"Import {len(entries)} words")
            self.import_button.setEnabled(True)
        else:
            self.preview_label.hide()
            self.preview_table.hide()
            self.import_button.setText("Import words")
            self.import_button.setEnabled(False)

    def _render_badges(self, columns):
        while self.badges_row.count():
            item = self.badges_row.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        if not columns:
            return
        colors = {
            "word": (ACCENT, "rgba(59,130,246,0.15)"),
            "definition": (SUCCESS, "rgba(34,197,94,0.15)"),
        }
        names = {"greek": self.langs.native or "translation",
                 "swedish": self.langs.second or "translation 2"}
        for field, header in columns.items():
            color, bg = colors.get(field, (TEXT_SECONDARY, "rgba(139,148,158,0.15)"))
            badge = QLabel(f"{names.get(field, field)}: {header}")
            badge.setStyleSheet(BADGE_STYLE.format(color=color, bg=bg))
            self.badges_row.addWidget(badge)
        self.badges_row.addStretch()

    # --------------------------------------------------------------- import

    def do_import(self):
        if not self.entries:
            return
        replace = False
        if self.db.word_count() > 0:
            box = QMessageBox(self)
            box.setWindowTitle("Words already exist")
            box.setText(
                f"You already have {self.db.word_count()} words.\n"
                "Append the new words, or replace everything?\n\n"
                "Replacing erases all existing words AND their progress."
            )
            append_button = box.addButton("Append", QMessageBox.ButtonRole.AcceptRole)
            replace_button = box.addButton("Replace all", QMessageBox.ButtonRole.DestructiveRole)
            box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            clicked = box.clickedButton()
            if clicked is replace_button:
                replace = True
            elif clicked is not append_button:
                return

        inserted = self.db.add_words(self.entries, replace=replace)
        skipped = len(self.entries) - inserted
        message = f"Imported {inserted} words."
        if skipped:
            message += f" Skipped {skipped} duplicates."
        QMessageBox.information(self, "Import complete", message)
        self.paste_area.clear()
        self.main_window.start_sync()
        self.main_window.navigate("dashboard")

    def choose_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose vocabulary file", "",
            "Spreadsheet files (*.csv *.tsv *.txt);;All files (*)",
        )
        if path:
            self._load_file(path)

    def _load_file(self, path):
        try:
            with open(path, "r", encoding="utf-8-sig", errors="replace") as handle:
                self.paste_area.setPlainText(handle.read())
            self.toggle_paste(True)
        except OSError as exc:
            QMessageBox.warning(self, "Import error", f"Could not read file: {exc}")

    # ---------------------------------------------------------- drag & drop

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                if url.toLocalFile().lower().endswith((".csv", ".tsv", ".txt")):
                    event.acceptProposedAction()
                    return
        event.ignore()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            path = url.toLocalFile()
            if path.lower().endswith((".csv", ".tsv", ".txt")) and os.path.isfile(path):
                self._load_file(path)
                return

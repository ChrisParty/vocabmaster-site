"""Help screen: how the app works, in the order a new user needs it.

One page, no wizard. The same words are in the tooltips; this is where
they are all in one place, plus the version and the update check.
"""

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

import paths
from styles import ACCENT, TEXT_SECONDARY, wrapping
from version import VERSION

SECTIONS = [
    ("Your daily rhythm", """
<p>Open the app, press <b>Study</b>, rate each card, done —
ten minutes. The app decides <i>which</i> words you see: ones you are about
to forget come back, ones you know well wait weeks. That is spaced
repetition; it only works if you show up most days, so the dashboard keeps
a streak (any day with at least one card counts) and a daily goal (how many
cards you aim for).</p>
<p><b>Badges.</b> As your work adds up you earn badges — your first word, 100
words studied, a whole week in a row, words mastered, a perfect round, your
first story or conversation. A badge is yours to keep: a missed day never
takes one away. See them all under <b>Stats</b>.</p>"""),
    ("The four buttons", f"""
<p>After you reveal a card, say honestly how it went:</p>
<p><b style="color:#ef4444">Again</b> (1) — blank. The card returns later in this session and tomorrow.<br>
<b style="color:#f59e0b">Hard</b> (2) — you got there, slowly. It comes back sooner than with Good.<br>
<b style="color:#22c55e">Good</b> (3) — solid recall. It comes back later than last time.<br>
<b style="color:{ACCENT}">Easy</b> (4) — instant. It comes back much later.</p>
<p>Settings → <b>Study direction</b> decides which side you see first: the word (recognition), the meaning (you produce the word — harder and worth more), or both mixed. The <b>memory hook</b> under a card (the 💡 block) is not another
example: it is a way to remember — the word's parts, a real link to a language you
know, a vivid line. If it distracts you, Settings → <b>Memory hook</b> hides it
(the cards keep it). Each button says when the card would come back — "tomorrow",
"in 2 weeks", "in 5 months". A word that comes back only every 3 weeks or more
counts as <b>mastered</b>. "Again" is information, not failure —
it is how the app learns what you need. Pressed the wrong key? <b>U</b>
takes the last rating back.</p>"""),
    ("Getting words", """
<p><b>Just starting?</b> In a new, empty deck, Add Words offers <b>20 sample
words</b> for Korean, Japanese or Swedish (explained in English or Greek) —
real cards, no OpenAI key needed.</p>
<p><b>Add Words → Add common words with AI</b>: the most useful words of your
language for your level — beginner, intermediate, advanced or expert —
written as full cards by the AI (definition, translations, example, memory
hook), in batches of 20, saved as they come. It always adds the number you
choose; words already in your deck are skipped, so levels can be mixed. Up to
300 new words a day — weeks of learning at your pace.
<b>Add one word</b> writes a single card for any word you meet. The Quiz can also ask you to <b>type</b> the word (Settings → Quiz style). Both use your
own OpenAI key (Settings) and stop at the daily AI budget.</p>
<p><b>What the AI costs.</b> Everything the AI writes — cards, sentences,
stories, conversations, Say it — goes on your own OpenAI key and never past
the daily AI budget you set in Settings. An ordinary day
costs a cent or two. Settings shows what today, this month and all time have
cost.</p>
<p>Cards made by an older version can be completed (Add Words) or replaced:
Settings → <b>Start over</b> deletes every word but keeps your settings, key
and streak, and puts the old deck aside in the backups folder.</p>"""),
    ("Practice: a story and a conversation", """
<p><b>Practice</b> in the menu uses the words you have already studied.
<b>Today's story</b> writes five to eight sentences mostly from your words,
which are highlighted. Each sentence has its reading, and the translation is
one click away. Up to two new words can go straight into your deck, and three
questions check that you understood. <b>Talk</b> is a short conversation in a
scene you pick, like a café or meeting a neighbour. The other person speaks
with your words. You answer by clicking one of three ideas or writing your
own, and a gentle "Better:" line shows how a native speaker would say it.
At most 12 turns.</p>
<p><b>What did that word mean?</b> Double-click it in a story, a conversation or a
sentence: a small card shows it from your deck — how it is read, the
translation, the meaning — free, no AI. (In Japanese, which has no spaces, the
card lists the words of your deck in that sentence.)</p>
<p><b>A word you want to keep:</b> in a story, a conversation or a sentence,
select it with the mouse (double-click selects one word), right-click and
choose <b>＋ Add to my deck</b> — it gets a full card, like Add one word. Any
text there can also be copied (Ctrl+C or right-click → Copy).</p>
<p><b>Speaking:</b> press <b>🎤 Speak</b>, say your answer (up to 15 seconds),
press it again to stop. You see what was heard before anything is sent — fix
it or say it again, then <b>Send</b>. Don't know how to say something? Press
<b>🆘 Say it in</b> your own language, say it, and you get the sentence to
say. With <b>🔊 Read the replies aloud</b> the other person speaks with your
computer's voice. A microphone (a headset works best) must be allowed: on
Windows, Settings → Privacy &amp; security → Microphone → "Let desktop apps
access your microphone".</p>
<p>Stories and conversations use the same daily AI budget as the cards.
Nothing here changes your streak, goal or stats.</p>
<p><b>Words that keep slipping:</b> when you have rated a word Again three
times, its card offers 🩺 a new way to remember it: a fresh memory hook, the
word it gets confused with, and a two-line story. It stays on the card.</p>"""),
    ("Sentences", """
<p><b>Sentences</b> in the menu is a phrasebook beside your cards: the most
useful everyday sentences, each with how to say it, what it means and what
every word in it means. Read one, press <b>Space</b> for the meaning, then
<b>K</b> if you know it or <b>N</b> to see it again later. The list shows
✓ learned, ◐ seen and ○ new; click any sentence to look at it again. It is
separate on purpose: sentences never change your streak, goal or stats.
<b>Generate</b> uses the same key and daily budget as the cards.</p>"""),
    ("Learning the alphabet", """
<p>For Korean, Japanese or Greek the menu shows <b>Alphabet</b>: a one-minute
explanation, a practice drill and the full chart. The drill goes step by
step: each new symbol is shown with its sound before it is asked, about
five are in play at a time, and three right answers in a row make one yours.
With <b>✍ Writing on paper</b> ticked, it sometimes asks you to write a symbol:
write it on paper, press Show, and compare it with the stroke order. For
kana, the stroke order is also drawn when a new symbol is introduced.
The next step opens when most of the current one is known. The
<b>Alphabet</b> button on a card (A) opens the chart beside it, so a
forgotten letter costs one glance. Ten minutes a day for a week and the
words stop looking like drawings.</p>
<p>Japanese: practise <b>Hiragana</b> first, then choose <b>Katakana</b>
above the drill; each has its voiced (が) and combined (きゃ) forms. Kanji are
not drilled — there are thousands. They come word by word on your cards,
always with the reading. While you learn kana, Settings → Languages →
<b>Japanese words: Kana first</b> (the default) shows ともだち big with 友達 under
it; switch to Kanji first when the kana come easily. In the quiz you may type
the word, its kana or its romaji, with or without long-vowel marks (kyō, kyou
and kyo all count).</p>"""),
    ("Several languages", """
<p>Each language you learn is its own <b>deck</b>, with its own words,
progress, streak and stats — so Korean never mixes into your English cards.
The button at the top left shows the deck you are in (🇰🇷 Korean · Mike);
click it to switch, to start a <b>New deck</b>, or to give this one a name
(handy when two people share a computer). Switching takes a second: the app
closes and opens again on the other deck.</p>
<p>Your OpenAI key, daily goal and Google Drive sign-in carry over to a new
deck. The daily AI budget is one for all your decks together. With Google
Drive connected, every deck syncs on its own; on your other computer the
deck menu offers the decks it does not have yet — <b>open here</b>.</p>"""),
    ("Keyboard", """
<table cellspacing="0" cellpadding="3">
<tr><td><b>Space</b></td><td>show the answer</td></tr>
<tr><td><b>1 2 3 4</b></td><td>rate the card / pick a quiz answer</td></tr>
<tr><td><b>P</b></td><td>Listen: hear the word</td></tr>
<tr><td><b>H</b></td><td>a hint (the first line of the memory hook, when shown)</td></tr>
<tr><td><b>T</b></td><td>Word map: the answer drawn as a map around the word</td></tr>
<tr><td><b>I</b></td><td>Picture: draw one for this word</td></tr>
<tr><td><b>U</b></td><td>undo the last rating (also Ctrl+Z)</td></tr>
<tr><td><b>A</b></td><td>the alphabet chart beside the card</td></tr>
<tr><td><b>More</b></td><td>on the card: edit it, reset its progress, remove it</td></tr>
<tr><td><b>Ctrl+R</b></td><td>start a review</td></tr>
<tr><td><b>Ctrl+I</b></td><td>Add Words</td></tr>
<tr><td><b>Esc</b></td><td>back to the dashboard</td></tr>
<tr><td><b>F1</b></td><td>this page</td></tr>
</table>
<p style="color:#8b949e">On a Mac, Ctrl is ⌘.</p>
<p style="color:#8b949e">Kana stroke order: KanjiVG, © Ulrich Apel, Creative Commons
Attribution-Share Alike 3.0 (kanjivg.tagaini.net).</p>"""),
    ("Pictures", """
<p>A picture reaches the meaning faster than a definition. With an OpenAI
key, the app quietly draws pictures for the day's words at startup, and
<b>I</b> draws one for the card in front of you. Spending is capped per
day in Settings (<b>$0.10</b> by default, about 11 pictures); set it to
$0.00 to turn pictures off. The model draws the scene only — the labels
are written by the app, so they are never misspelled.</p>"""),
    ("Hearing and saying words", """
<p><b>🔊 Listen</b> (P) reads the word in your computer's voice. <b>🎤 Say it</b>
(M) on a study card: say the word, click again to stop, and the app tells you
whether it sounded right — it never changes your schedule. In the Quiz, <b>🎧 Listening</b> asks with your ears: you
hear the word and pick what it means (Play again: P). Click it again for the
usual questions.</p>"""),
    ("Two computers", """
<p>Settings → <b>Connect Google Drive</b> on each computer, same Google
account. Your deck is mirrored into a hidden folder of <i>your own</i>
Drive — nothing is hosted anywhere else — and the computers stay in step:
after every study session, every 10 minutes, and when the app closes. For
each card the most recently studied version wins, so nothing done on either
side is lost. No cloud? <b>Export everything</b> makes a .zip you can
restore on the other machine.</p><p><b>Giving a deck to a friend:</b> Settings → <b>Share this deck</b> makes
a .zip with the cards, pictures and sentences — without your OpenAI key,
your Google sign-in or your progress. They use Restore from a backup, best in
a new or empty deck.</p>"""),
    ("Never forget to show up", """
<p>Settings → <b>Daily reminder</b>: at the time you choose, if cards are due
and today's goal is not met, a notification says so; click it and the session
opens. Turn on <b>Start with the computer</b> and the app waits quietly in the
tray (menu bar on a Mac) so the reminder reaches you even on days you did not
think of it. Closing the window then keeps it there; Quit from the tray icon.</p>"""),
    ("Your data", f"""
<p>Everything is in one file on this computer:<br>
<code>{paths.data_dir()}</code><br>
A copy is made there every day (the last 7 are kept). Updating the app
never touches this folder. If something ever goes wrong, the details are
in <code>vocabmaster.log</code> in the same place.</p>"""),
]


import images

if not images.ENABLED:          # pictures are switched off (images.py)
    SECTIONS = [(title, body.replace(
        "<tr><td><b>I</b></td><td>Picture: draw one for this word</td></tr>\n", ""))
        for title, body in SECTIONS if title != "Pictures"]


class HelpScreen(QWidget):
    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)

        header = QLabel("How VocabMaster works")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(header)

        for title, body in SECTIONS:
            card = QFrame()
            card.setObjectName("card")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(24, 18, 24, 18)
            card_layout.setSpacing(6)
            heading = QLabel(title)
            heading.setStyleSheet("font-weight: 700; font-size: 12pt;")
            card_layout.addWidget(heading)
            text = QLabel(body.strip())
            text.setTextFormat(Qt.TextFormat.RichText)
            wrapping(text)
            text.setOpenExternalLinks(True)
            card_layout.addWidget(text)
            layout.addWidget(card)

        # ----- version + updates -----
        version_card = QFrame()
        version_card.setObjectName("card")
        version_layout = QHBoxLayout(version_card)
        version_layout.setContentsMargins(24, 16, 24, 16)
        self.version_label = QLabel(f"VocabMaster {VERSION}")
        self.version_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        version_layout.addWidget(self.version_label)
        version_layout.addStretch()
        update_button = QPushButton("Check for updates")
        update_button.setCursor(Qt.CursorShape.PointingHandCursor)
        update_button.setToolTip("Looks for a newer version; updating never touches your data.")
        update_button.clicked.connect(self.main_window.check_updates_now)
        version_layout.addWidget(update_button)
        layout.addWidget(version_card)

        layout.addStretch()

    def refresh(self):
        pass

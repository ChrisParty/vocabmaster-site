"""Stats screen, built to be read in seconds: one sentence that says how it
is going, three numbers that matter, one chart of the long view, the
calendar of days studied, and what is waiting — in words, not bars."""

from datetime import datetime, timedelta

from PyQt6.QtCore import Qt, QRectF
from PyQt6.QtGui import QColor, QPainter
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QProgressBar, QScrollArea, QSizePolicy,
    QVBoxLayout, QWidget,
)

import badges
from database import MASTERED_INTERVAL
from styles import (
    ACCENT, BORDER, SUCCESS, SURFACE, TEXT, TEXT_MUTED, TEXT_SECONDARY, WARNING,
    wrapping,
)
from ui.badges import BadgeShelf

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


class MonthChart(QWidget):
    """Reviews per month: wide bars, the number on top, the month below.
    One idea per bar, nothing to decode."""

    def __init__(self):
        super().__init__()
        self.data = []
        self.setMinimumHeight(170)

    def set_data(self, data):
        self.data = data
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        width, height = self.width(), self.height()
        if not self.data:
            painter.setPen(QColor(TEXT_MUTED))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter,
                             "Your first review starts this chart.")
            return
        top, bottom = 22, 22
        count = len(self.data)
        slot = width / count
        bar_w = min(72.0, slot * 0.62)
        peak = max(value for _, value in self.data) or 1
        font = painter.font()
        for index, (label, value) in enumerate(self.data):
            x = index * slot + (slot - bar_w) / 2
            bar_h = (height - top - bottom) * value / peak if value else 2
            y = height - bottom - bar_h
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(ACCENT) if value else QColor(BORDER))
            painter.drawRoundedRect(QRectF(x, y, bar_w, bar_h), 5, 5)
            font.setBold(True)
            painter.setFont(font)
            painter.setPen(QColor(TEXT))
            if value:
                painter.drawText(QRectF(x - 20, y - 20, bar_w + 40, 18),
                                 Qt.AlignmentFlag.AlignCenter, f"{value:,}")
            font.setBold(False)
            painter.setFont(font)
            painter.setPen(QColor(TEXT_SECONDARY))
            painter.drawText(QRectF(x - 20, height - bottom + 4, bar_w + 40, 16),
                             Qt.AlignmentFlag.AlignCenter, label)


class StreakCalendar(QWidget):
    """One square per day, green when you studied — a year at a glance."""

    MAX_WEEKS = 53
    CELL = 13
    GAP = 3
    LEFT = 30
    TOP = 16

    def __init__(self):
        super().__init__()
        self.activity = {}
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setFixedHeight(self.TOP + 7 * (self.CELL + self.GAP) + 6)

    def set_activity(self, activity):
        self.activity = activity
        self.update()

    def weeks(self):
        return max(10, min(self.MAX_WEEKS,
                           (self.width() - self.LEFT) // (self.CELL + self.GAP)))

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        today = datetime.now().date()
        weeks = self.weeks()
        days_since_monday = today.weekday()
        peak = max(self.activity.values(), default=1) or 1
        shades = [QColor(SURFACE), QColor("#0e4429"), QColor("#006d32"),
                  QColor("#26a641"), QColor(SUCCESS)]
        last_month = None
        for week in range(weeks):
            for weekday in range(7):
                offset = (weeks - 1 - week) * 7 + (days_since_monday - weekday)
                day = today - timedelta(days=offset)
                if day > today:
                    continue
                count = self.activity.get(day.strftime("%Y-%m-%d"), 0)
                color = shades[0] if not count else shades[min(4, 1 + int(count / peak * 3))]
                x = self.LEFT + week * (self.CELL + self.GAP)
                y = self.TOP + weekday * (self.CELL + self.GAP)
                painter.setBrush(color)
                painter.drawRoundedRect(QRectF(x, y, self.CELL, self.CELL), 3, 3)
                if weekday == 0 and day.month != last_month:
                    if last_month is not None:
                        painter.setPen(QColor(TEXT_MUTED))
                        painter.drawText(QRectF(x, 0, 40, self.TOP - 2),
                                         Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                                         MONTHS[day.month - 1])
                        painter.setPen(Qt.PenStyle.NoPen)
                    last_month = day.month
        painter.setPen(QColor(TEXT_MUTED))
        for weekday, label in [(0, "Mon"), (3, "Thu"), (6, "Sun")]:
            y = self.TOP + weekday * (self.CELL + self.GAP)
            painter.drawText(QRectF(0, y, 26, self.CELL),
                             Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, label)


def _card(title=None):
    frame = QFrame()
    frame.setObjectName("card")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(22, 18, 22, 18)
    layout.setSpacing(10)
    if title:
        label = QLabel(title)
        label.setStyleSheet("font-weight: 700; font-size: 12pt;")
        layout.addWidget(label)
    return frame, layout


def _tile(title, color):
    frame = QFrame()
    frame.setObjectName("statCard")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(20, 16, 20, 16)
    layout.setSpacing(4)
    value = QLabel("—")
    value.setStyleSheet(f"font-size: 24pt; font-weight: 700; color: {color};")
    head = QLabel(title)
    head.setStyleSheet(f"color: {TEXT_SECONDARY}; font-weight: 600;")
    note = wrapping(QLabel(""))
    note.setStyleSheet(f"color: {TEXT_MUTED}; font-size: 9pt;")
    layout.addWidget(value)
    layout.addWidget(head)
    layout.addWidget(note)
    return frame, value, note


class StatsScreen(QWidget):
    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)

        header = QLabel("Your progress")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(header)

        # ---- one sentence
        summary_card, summary_layout = _card()
        self.summary = wrapping(QLabel(""))
        self.summary.setTextFormat(Qt.TextFormat.RichText)
        self.summary.setStyleSheet("font-size: 13pt; line-height: 140%;")
        summary_layout.addWidget(self.summary)
        layout.addWidget(summary_card)

        # ---- three numbers
        tiles = QHBoxLayout()
        tiles.setSpacing(14)
        streak_tile, self.streak_value, self.streak_note = _tile("Day streak", WARNING)
        mastered_tile, self.mastered_value, self.mastered_note = _tile("Words mastered", SUCCESS)
        week_tile, self.week_value, self.week_note = _tile("Reviews this week", ACCENT)
        self.mastery_bar = QProgressBar()
        self.mastery_bar.setFixedHeight(8)
        self.mastery_bar.setRange(0, 100)
        self.mastery_bar.setTextVisible(False)
        mastered_tile.layout().insertWidget(2, self.mastery_bar)
        for tile in (streak_tile, mastered_tile, week_tile):
            tiles.addWidget(tile, 1)          # equal thirds, whatever the text
        layout.addLayout(tiles)

        # ---- badges: what was earned, and the next one of each kind
        badges_card, badges_layout = _card()
        head = QHBoxLayout()
        title = QLabel("Your badges")
        title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        head.addWidget(title)
        self.badge_count = QLabel("")
        self.badge_count.setStyleSheet(f"color: {TEXT_SECONDARY}; font-size: 11pt;")
        head.addWidget(self.badge_count)
        head.addStretch()
        badges_layout.addLayout(head)
        self.badge_shelf = BadgeShelf()
        badges_layout.addWidget(self.badge_shelf)
        self.badge_hint = wrapping(QLabel(""))
        self.badge_hint.setStyleSheet(f"color: {TEXT_MUTED}; font-size: 9pt;")
        badges_layout.addWidget(self.badge_hint)
        layout.addWidget(badges_card)

        # ---- the long view
        months_card, months_layout = _card("Cards reviewed, month by month")
        self.month_chart = MonthChart()
        months_layout.addWidget(self.month_chart)
        layout.addWidget(months_card)

        # ---- the calendar
        calendar_card, calendar_layout = _card("Days you studied — the last year")
        hint = QLabel("Each square is a day. Green means you reviewed cards; brighter means more.")
        hint.setStyleSheet(f"color: {TEXT_MUTED}; font-size: 9pt;")
        calendar_layout.addWidget(hint)
        self.calendar = StreakCalendar()
        calendar_layout.addWidget(self.calendar)
        layout.addWidget(calendar_card)

        # ---- what is waiting, in words
        coming_card, coming_layout = _card("Coming up")
        self.coming = wrapping(QLabel(""))
        self.coming.setTextFormat(Qt.TextFormat.RichText)
        self.coming.setStyleSheet("font-size: 11pt;")
        coming_layout.addWidget(self.coming)
        layout.addWidget(coming_card)

        layout.addStretch()

    # ------------------------------------------------------------ refresh

    def _reviews_between(self, start, end):
        return self.db.conn.execute(
            "SELECT COALESCE(SUM(cards_reviewed), 0) FROM sessions "
            "WHERE date >= ? AND date <= ?", (start, end)).fetchone()[0]

    def refresh(self):
        totals = self.db.totals()
        counts = self.db.counts()
        today = datetime.now().date()
        first = self.db.first_study_date()
        streak = self.db.current_streak()
        best = self.db.longest_streak()

        # the sentence
        if first:
            start = datetime.strptime(first, "%Y-%m-%d").date()
            span = (today - start).days + 1
            studied = len(self.db.study_dates())
            accuracy = f" {totals['accuracy']:.0f}% of your answers were Good or Easy." \
                if totals["reviewed"] else ""
            self.summary.setText(
                f"You started on <b>{start:%d %B %Y}</b>. Since then you have studied on "
                f"<b>{studied}</b> of {span} days and reviewed <b>{totals['reviewed']:,}</b> "
                f"cards.{accuracy}")
        else:
            self.summary.setText("Nothing here yet — your first review starts the story.")

        # the three numbers
        self.streak_value.setText(f"🔥 {streak}")
        self.streak_note.setText(
            f"Days in a row with at least one review. Your best: {best}."
            if best else "Days in a row with at least one review.")
        pct = round(counts["mastered"] / counts["total"] * 100) if counts["total"] else 0
        self.mastered_value.setText(f"{counts['mastered']:,}")
        self.mastery_bar.setValue(pct)
        self.mastered_note.setText(
            f"{pct}% of your {counts['total']:,} words. A word counts as mastered when it "
            f"can wait {MASTERED_INTERVAL}+ days between reviews.")
        monday = today - timedelta(days=today.weekday())
        this_week = self._reviews_between(monday.isoformat(), today.isoformat())
        last_week = self._reviews_between((monday - timedelta(days=7)).isoformat(),
                                          (monday - timedelta(days=1)).isoformat())
        self.week_value.setText(f"{this_week:,}")
        if last_week:
            self.week_note.setText(f"Since Monday. Last week: {last_week:,}.")
        else:
            self.week_note.setText("Since Monday.")

        # badges
        rows = badges.shelf(self.db)
        earned = sum(1 for row in rows for item in row["items"] if item["earned"])
        self.badge_count.setText(f"·  {earned} earned" if earned else "")
        self.badge_shelf.set_rows(rows)
        special = any(row["family"] == "special" for row in rows)
        if not earned:
            self.badge_hint.setText("Your first badge comes with your first word studied.")
        else:
            self.badge_hint.setText(
                "Grey medals are the next ones — hover over a medal to see what it is for. "
                + ("There are more special badges to discover." if special else
                   "Special badges appear here too: a perfect round, your first story, your "
                   "first conversation — and a few surprises."))

        # the long view
        self.month_chart.set_data([
            (f"{MONTHS[int(key[5:7]) - 1]} {key[:4]}" if key.endswith("-01") or i == 0
             else MONTHS[int(key[5:7]) - 1], count)
            for i, (key, count) in enumerate(self.db.reviews_per_month())])

        # the calendar
        activity = {}
        for date_str, count in self.db.conn.execute(
                "SELECT date, SUM(cards_reviewed) FROM sessions "
                "WHERE cards_reviewed > 0 GROUP BY date").fetchall():
            activity[date_str] = count or 0
        self.calendar.set_activity(activity)

        # coming up, in words
        upcoming = self.db.due_next_days(7)
        due_today = upcoming[0][1] if upcoming else 0
        later = [(label, n) for label, n in upcoming[1:] if n]
        if counts["total"] == 0:
            text = "Add some words and the schedule starts here."
        elif due_today:
            text = f"<b>{due_today:,}</b> card{'s' if due_today != 1 else ''} waiting for you today."
        else:
            text = "Nothing is due today — you are all caught up."
        if later:
            full = {name[:3]: name for name in DAYS}
            names = [f"{n} on {full.get(label, label)}" for label, n in later]
            text += " Then " + ", ".join(names[:-1]) + (" and " if len(names) > 1 else "") \
                + names[-1] + "."
        elif counts["total"]:
            text += " Nothing more is scheduled for the rest of the week."
        text += ("<br><span style='color:%s'>Words you review come back later; the better "
                 "you know one, the longer it waits.</span>" % TEXT_MUTED)
        self.coming.setText(text)

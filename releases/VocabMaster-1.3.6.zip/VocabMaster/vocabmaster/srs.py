"""SM-2 spaced repetition algorithm and session queue logic."""

AGAIN, HARD, GOOD, EASY = 0, 1, 2, 3

RATING_NAMES = {AGAIN: "Again", HARD: "Hard", GOOD: "Good", EASY: "Easy"}


def sm2_update(interval, ease_factor, repetitions, rating):
    """Return (new_interval, new_ease_factor, new_repetitions).

    rating: 0=Again, 1=Hard, 2=Good, 3=Easy
    """
    if rating == 0:
        return 1, max(1.3, ease_factor - 0.2), 0
    new_ef = max(1.3, ease_factor + 0.1 - (3 - rating) * (0.08 + (3 - rating) * 0.02))
    if repetitions == 0:
        new_interval = 1
    elif repetitions == 1:
        new_interval = 3 if rating == HARD else 6
    elif rating == HARD:
        # Hard: a little longer than last time, always sooner than Good.
        # (Classic SM-2 gave Hard the same jump as Good: a word you had just
        # found hard came back in "6 months", like one you knew well.)
        new_interval = max(interval + 1, round(interval * 1.2))
    else:
        new_interval = round(interval * ease_factor)
    if rating == 3:
        # Easy on a brand-new card jumps to 4 days (Anki-style); otherwise +30%.
        new_interval = 4 if repetitions == 0 else round(new_interval * 1.3)
    return max(1, new_interval), new_ef, repetitions + 1


def span(days):
    """A stretch of time in words: "3 days", "2 weeks", "5 months", "1 year"."""
    days = max(1, int(days))
    if days < 7:
        return f"{days} day{'s' if days != 1 else ''}"
    if days < 30:
        weeks = max(1, round(days / 7))
        return f"{weeks} week{'s' if weeks != 1 else ''}"
    if days < 335:                       # from about 11 months: "1 year"
        months = max(1, round(days / 30))
        return f"{months} month{'s' if months != 1 else ''}"
    years = max(1, round(days / 365))
    return f"{years} year{'s' if years != 1 else ''}"


def when(days):
    """When a card comes back, in words anyone reads at a glance:
    "today", "tomorrow", "in 3 days", "in 2 weeks", "in 5 months"."""
    days = int(days)
    if days <= 0:
        return "today"
    if days == 1:
        return "tomorrow"
    return f"in {span(days)}"


def preview_interval(interval, ease_factor, repetitions, rating):
    """What a rating would do, in words: Again = "soon" (later in this
    round), the others "tomorrow", "in 3 days", "in 5 months"…"""
    new_interval, _, _ = sm2_update(interval, ease_factor, repetitions, rating)
    if rating == AGAIN:
        return "soon"
    return when(new_interval)


class StudySession:
    """Holds the queue for one study session.

    Cards rated Again are re-queued at the end of the current session so the
    user must answer them correctly before finishing.
    """

    def __init__(self, cards):
        self.queue = list(cards)
        self.total = len(cards)
        self.position = 0  # unique cards completed (Again does not advance)
        self.tally = {AGAIN: 0, HARD: 0, GOOD: 0, EASY: 0}

    def current(self):
        return self.queue[0] if self.queue else None

    def is_finished(self):
        return not self.queue

    def rate(self, rating, updated_card=None):
        """Apply a rating to the current card and advance the queue."""
        card = self.queue.pop(0)
        self.tally[rating] += 1
        if rating == AGAIN:
            requeued = dict(updated_card or card)
            self.queue.append(requeued)
        else:
            self.position += 1

    def progress_label(self):
        done = min(self.position + 1, self.total) if self.queue else self.total
        return f"Card {done} of {self.total}"

    def progress_fraction(self):
        if self.total == 0:
            return 1.0
        return self.position / self.total

"""SQLite persistence layer for VocabMaster.

All reads and writes go through the Database class. Progress is committed
immediately after every mutation so a crash never loses a rating.
"""

import glob
import hashlib
import os
import shutil
import sqlite3
import uuid
from datetime import datetime, timedelta

DEFAULT_DB_NAME = "vocabmaster.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS words (
    id TEXT PRIMARY KEY,
    word TEXT NOT NULL,
    definition TEXT NOT NULL,
    pos TEXT,
    greek TEXT,
    swedish TEXT,
    synonyms TEXT,
    example TEXT,
    hook TEXT
);

CREATE TABLE IF NOT EXISTS progress (
    word_id TEXT PRIMARY KEY,
    interval INTEGER DEFAULT 1,
    ease_factor REAL DEFAULT 2.5,
    repetitions INTEGER DEFAULT 0,
    due_date TEXT DEFAULT (datetime('now')),
    last_studied TEXT,
    FOREIGN KEY (word_id) REFERENCES words(id)
);

CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    cards_reviewed INTEGER DEFAULT 0,
    again_count INTEGER DEFAULT 0,
    hard_count INTEGER DEFAULT 0,
    good_count INTEGER DEFAULT 0,
    easy_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

def utc_stamp():
    """UTC ISO timestamp, comparable with the cloud's updated_at."""
    from datetime import timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


DEFAULT_SETTINGS = {
    "daily_goal": "20",
    "max_new_per_day": "20",
    "session_cap": "20",
    "font_size": "medium",
}

MASTERED_INTERVAL = 21

CARD_FIELDS = ("word", "definition", "pos", "greek", "swedish",
               "synonyms", "example", "hook", "reading", "example_tr", "example_reading",
               "rescue")


def insert_card(conn, entry):
    """One new word plus its progress row, stamped for sync. The single
    insert path shared by import, the hub API and AI-written cards; the
    caller handles duplicates and commits. Returns the new id."""
    word_id = uuid.uuid4().hex
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    stamp = utc_stamp()
    conn.execute(
        f"INSERT INTO words (id, {', '.join(CARD_FIELDS)}, updated_at) "
        f"VALUES (?, {', '.join('?' * len(CARD_FIELDS))}, ?)",
        (word_id, *[(entry.get(field) or "").strip() for field in CARD_FIELDS], stamp))
    conn.execute(
        "INSERT INTO progress (word_id, interval, ease_factor, repetitions, "
        "due_date, updated_at) VALUES (?, 1, 2.5, 0, ?, ?)", (word_id, now, stamp))
    return word_id


def due_today_parts(conn, max_new):
    """(reviews, new) — today's study split: reviews due today, and the new
    words still allowed today."""
    now = datetime.now()
    today_end = now.strftime("%Y-%m-%d 23:59:59")
    reviews = conn.execute(
        "SELECT COUNT(*) FROM progress WHERE repetitions > 0 AND due_date <= ?",
        (today_end,)).fetchone()[0]
    waiting = conn.execute(
        "SELECT COUNT(*) FROM progress WHERE repetitions = 0 AND due_date <= ?",
        (today_end,)).fetchone()[0]
    started = conn.execute(
        "SELECT COUNT(*) FROM progress WHERE repetitions = 1 AND last_studied LIKE ?",
        (now.strftime("%Y-%m-%d") + "%",)).fetchone()[0]
    return reviews, min(waiting, max(0, max_new - started))


def due_today(conn, max_new):
    """What today's study will actually show: every review that is due, plus
    the new words still allowed today (Settings -> Max new cards per day).
    The one definition behind the dashboard, status bar, reminder and Hub —
    counting every never-seen word as "due" said 1,251 on a day with 63."""
    now = datetime.now()
    today_end = now.strftime("%Y-%m-%d 23:59:59")
    reviews = conn.execute(
        "SELECT COUNT(*) FROM progress WHERE repetitions > 0 AND due_date <= ?",
        (today_end,)).fetchone()[0]
    waiting = conn.execute(
        "SELECT COUNT(*) FROM progress WHERE repetitions = 0 AND due_date <= ?",
        (today_end,)).fetchone()[0]
    started = conn.execute(
        "SELECT COUNT(*) FROM progress WHERE repetitions = 1 AND last_studied LIKE ?",
        (now.strftime("%Y-%m-%d") + "%",)).fetchone()[0]
    return reviews + min(waiting, max(0, max_new - started))


def _readonly(path):
    """A read-only connection (never creates or changes the file)."""
    from pathlib import Path
    return sqlite3.connect(Path(os.path.abspath(path)).as_uri() + "?mode=ro", uri=True, timeout=5)


def healthy(path):
    """True when SQLite's own quick check passes. A damaged deck never does —
    and is then never backed up over a good copy."""
    try:
        conn = _readonly(path)
        try:
            return conn.execute("PRAGMA quick_check").fetchone()[0] == "ok"
        finally:
            conn.close()
    except sqlite3.Error:
        return False


def healthy_backups(path):
    """The deck's daily backups that pass the check, newest first."""
    folder = os.path.join(os.path.dirname(os.path.abspath(path)), "backups")
    found = sorted(glob.glob(os.path.join(folder, "vocabmaster-*.db")), reverse=True)
    return [copy for copy in found if healthy(copy)]


def restore_copy(path, backup):
    """Put a healthy backup in place of a damaged deck — or, with `backup`
    None, set the damaged deck aside so an empty one can start. The damaged
    file is kept in the backups folder as damaged-<stamp>.db (nothing is
    deleted). Returns where it was kept."""
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    kept = os.path.join(os.path.dirname(os.path.abspath(path)), "backups", f"damaged-{stamp}.db")
    os.makedirs(os.path.dirname(kept), exist_ok=True)
    if os.path.exists(path):
        os.replace(path, kept)
    for suffix in ("-journal", "-wal", "-shm"):       # they belong to the damaged file
        if os.path.exists(path + suffix):
            os.replace(path + suffix, kept + suffix)
    if backup:
        shutil.copy2(backup, path + ".part")
        os.replace(path + ".part", path)
    return kept


# Settings a deck started afresh must NOT inherit from its damaged file: with
# them, sync would think it already has everything (cursor) or skip its own
# earlier logs (device id).
FRESH_SYNC = ("sync_cursor", "sync_last_push", "sync_last_ok", "sync_device",
              "gdrive_deck_info_sent", "reminder_last")


def salvage_settings(path):
    """Best effort: the settings a damaged deck still holds ({} when none)."""
    try:
        conn = _readonly(path)
        try:
            return dict(conn.execute("SELECT key, value FROM settings").fetchall())
        finally:
            conn.close()
    except sqlite3.Error:
        return {}


def default_db_path():
    """The user's data folder (paths.py), moving a legacy deck in first."""
    import paths
    return paths.db_path()


BACKUP_KEEP = 7


class Database:
    def __init__(self, path=None):
        self.path = path or default_db_path()
        self._backup()
        self.conn = sqlite3.connect(self.path)
        # A damaged deck is refused here, with the file closed, so main.py
        # can offer the newest healthy backup (and move the damaged file).
        try:
            verdict = self.conn.execute("PRAGMA quick_check").fetchone()[0]
            if verdict != "ok":
                raise sqlite3.DatabaseError(f"the deck failed its check: {verdict}")
        except sqlite3.DatabaseError:
            self.conn.close()
            self.conn = None
            raise
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        # Additive sync support: change-tracking columns + deletion tombstones.
        # Nullable columns and a new table — existing behavior untouched.
        wcols = {r[1] for r in self.conn.execute("PRAGMA table_info(words)")}
        if "hook" not in wcols:
            self.conn.execute("ALTER TABLE words ADD COLUMN hook TEXT")
        # For learners of another script: how the word is read (romanisation,
        # pinyin, kana), and the example sentence in their own language.
        # example_reading: the example in Latin letters, for scripts that
        # cannot be sounded out (kanji, hanzi) — since 1.0.7.
        # rescue: the word doctor's "new way to remember" (JSON) — since 1.1.0.
        for column in ("reading", "example_tr", "example_reading", "rescue"):
            if column not in wcols:
                self.conn.execute(f"ALTER TABLE words ADD COLUMN {column} TEXT")
        # lapses: how often a card was rated Again — the word doctor steps in
        # at 3 (since 1.1.0).
        pcols = {r[1] for r in self.conn.execute("PRAGMA table_info(progress)")}
        if "lapses" not in pcols:
            self.conn.execute("ALTER TABLE progress ADD COLUMN lapses INTEGER DEFAULT 0")
        for table in ("words", "progress"):
            cols = {r[1] for r in self.conn.execute(f"PRAGMA table_info({table})")}
            if "updated_at" not in cols:
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN updated_at TEXT")
            # backfill so pre-existing rows count as changed for first sync
            self.conn.execute(
                f"UPDATE {table} SET updated_at=? WHERE updated_at IS NULL",
                (utc_stamp(),))
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS sync_tombstones ("
            "word_id TEXT PRIMARY KEY, at TEXT NOT NULL)")
        # Study history travels too (today's count, streak, stats), so every
        # session needs an id that means the same on every device. Rows that
        # predate this get one derived from their content: two machines that
        # started from the same backup derive the same id and merge into one.
        scols = {r[1] for r in self.conn.execute("PRAGMA table_info(sessions)")}
        if "uid" not in scols:
            self.conn.execute("ALTER TABLE sessions ADD COLUMN uid TEXT")
        if "updated_at" not in scols:
            self.conn.execute("ALTER TABLE sessions ADD COLUMN updated_at TEXT")
        for row in self.conn.execute(
                "SELECT id, date, cards_reviewed, again_count, hard_count, "
                "good_count, easy_count FROM sessions WHERE uid IS NULL").fetchall():
            digest = hashlib.sha1("|".join(str(v) for v in row).encode()).hexdigest()
            self.conn.execute("UPDATE sessions SET uid=?, updated_at=? WHERE id=?",
                              (digest[:32], utc_stamp(), row[0]))
        # Practice stories (practice.py): device-local, like the alphabet drill.
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS stories (id TEXT PRIMARY KEY, lang TEXT, "
            "made_on TEXT, body TEXT, created_at TEXT)")
        # Letters of a non-Latin alphabet the user has drilled (ui/alphabet.py).
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS alphabet_progress (lang TEXT, symbol TEXT, "
            "streak INTEGER DEFAULT 0, seen INTEGER DEFAULT 0, updated_at TEXT, "
            "PRIMARY KEY (lang, symbol))")
        # Badges earned (badges.py): kept forever, synced, never taken away.
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS badges (id TEXT PRIMARY KEY, earned_on TEXT, "
            "celebrated INTEGER DEFAULT 0, updated_at TEXT)")
        self.conn.commit()
        # Card illustrations live in their own tables and their own folder —
        # never as blobs in here, which _backup() copies whole every day.
        import images
        images.ensure_schema(self.conn, self.path)
        # Which languages this deck is about (legacy decks: English learned,
        # Greek + Swedish translations; fresh decks: English, no translations).
        import languages
        languages.ensure_defaults(self.conn)
        # Everyday sentences (sentences.py): their own table, never in stats.
        import sentences
        sentences.ensure_schema(self.conn)
        self.conn.commit()

    def _backup(self):
        """Copy the database to backups/ once per day; keep the last 7.

        Only a deck that passes SQLite's check is copied, and old copies are
        pruned only after a new good one exists — so a damaged deck can never
        push the good backups out, however often it is opened. The copy is
        taken with SQLite's backup API (consistent even while the app has
        the deck open)."""
        if not os.path.exists(self.path) or os.path.getsize(self.path) == 0:
            return
        backup_dir = os.path.join(os.path.dirname(self.path), "backups")
        try:
            os.makedirs(backup_dir, exist_ok=True)
            today = datetime.now().strftime("%Y-%m-%d")
            target = os.path.join(backup_dir, f"vocabmaster-{today}.db")
            if os.path.exists(target):
                return
            if not healthy(self.path):
                import logging
                logging.getLogger("database").warning(
                    "%s failed its check: no backup taken, the old ones are kept", self.path)
                return
            source = _readonly(self.path)
            copy = sqlite3.connect(target + ".part")
            try:
                source.backup(copy)
            finally:
                copy.close()
                source.close()
            os.replace(target + ".part", target)
            backups = sorted(glob.glob(os.path.join(backup_dir, "vocabmaster-*.db")))
            for old in backups[:-BACKUP_KEEP]:
                os.remove(old)
        except (OSError, sqlite3.Error):
            pass  # a failed backup must never block the app

    def daily_backup(self):
        """The once-a-day copy, also for an app that lives in the tray for
        days without being restarted (the window calls this every minute;
        it does nothing once today's copy exists)."""
        self._backup()

    def close(self):
        """Idempotent: a restore closes the connection before the app's own
        shutdown gets to it."""
        if self.conn is not None:
            self.conn.close()
            self.conn = None

    # ------------------------------------------------------------- settings

    def get_setting(self, key, default=None):
        row = self.conn.execute(
            "SELECT value FROM settings WHERE key=?", (key,)
        ).fetchone()
        if row is not None:
            return row["value"]
        return DEFAULT_SETTINGS.get(key, default)

    def set_setting(self, key, value):
        self.conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )
        self.conn.commit()

    def get_int_setting(self, key, default):
        try:
            return int(self.get_setting(key, default))
        except (TypeError, ValueError):
            return default

    # ---------------------------------------------------------------- words

    def word_count(self):
        return self.conn.execute("SELECT COUNT(*) FROM words").fetchone()[0]

    def add_words(self, entries, replace=False):
        """Insert parsed word dicts. Returns number of words inserted."""
        if replace:
            self.conn.execute("DELETE FROM progress")
            self.conn.execute("DELETE FROM words")
        existing = {
            row["word"].strip().lower()
            for row in self.conn.execute("SELECT word FROM words")
        }
        inserted = 0
        for entry in entries:
            key = entry["word"].strip().lower()
            if key in existing:
                continue
            existing.add(key)
            insert_card(self.conn, entry)
            inserted += 1
        self.conn.commit()
        return inserted

    def update_word(self, word_id, fields):
        allowed = set(CARD_FIELDS)
        sets, values = [], []
        for key, value in fields.items():
            if key in allowed:
                sets.append(f"{key}=?")
                values.append(value)
        if not sets:
            return
        sets.append("updated_at=?")
        values.append(utc_stamp())
        values.append(word_id)
        self.conn.execute(f"UPDATE words SET {', '.join(sets)} WHERE id=?", values)
        self.conn.commit()

    def delete_word(self, word_id):
        import images

        self.conn.execute("DELETE FROM progress WHERE word_id=?", (word_id,))
        self.conn.execute("DELETE FROM words WHERE id=?", (word_id,))
        self.conn.execute("DELETE FROM word_images WHERE word_id=?", (word_id,))
        self.conn.execute(
            "INSERT OR REPLACE INTO sync_tombstones (word_id, at) VALUES (?, ?)",
            (word_id, utc_stamp()))
        self.conn.commit()
        # The picture goes too, so images/ does not keep files no card shows.
        try:
            path = images.image_file(self.path, word_id)
            if path:
                os.remove(path)
        except OSError:
            pass

    def delete_all_words(self):
        """Start over: every word, its progress and its picture go; settings,
        keys, languages, the ledger and the study history (streak) stay.
        Deletes travel as tombstones, so a synced computer starts over too.
        The deck and its pictures are first set aside in
        backups/start-over-<stamp>/ — copying them back undoes it.
        Returns how many words were deleted."""
        import images

        ids = [row["id"] for row in self.conn.execute("SELECT id FROM words")]
        if not ids:
            return 0
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        keep = os.path.join(os.path.dirname(os.path.abspath(self.path)),
                            "backups", f"start-over-{stamp}")
        os.makedirs(keep, exist_ok=True)
        self.conn.commit()
        snapshot = sqlite3.connect(os.path.join(keep, DEFAULT_DB_NAME))
        try:
            self.conn.backup(snapshot)          # fails loudly: nothing deleted yet
        finally:
            snapshot.close()
        now = utc_stamp()
        with self.conn:                          # one transaction, all or nothing
            self.conn.executemany(
                "INSERT OR REPLACE INTO sync_tombstones (word_id, at) VALUES (?, ?)",
                [(word_id, now) for word_id in ids])
            self.conn.execute("DELETE FROM progress")
            self.conn.execute("DELETE FROM word_images")
            self.conn.execute("DELETE FROM words")
        pictures = os.path.join(keep, "images")
        for word_id in ids:
            path = images.image_file(self.path, word_id)
            if path:
                try:
                    os.makedirs(pictures, exist_ok=True)
                    shutil.move(path, os.path.join(pictures, os.path.basename(path)))
                except OSError:
                    pass
        return len(ids)

    def reset_progress(self, word_id):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.conn.execute(
            "UPDATE progress SET interval=1, ease_factor=2.5, repetitions=0, "
            "due_date=?, last_studied=NULL, updated_at=? WHERE word_id=?",
            (now, utc_stamp(), word_id),
        )
        self.conn.commit()

    def get_words(self, search="", status_filter="all"):
        """Return joined word+progress rows, optionally filtered."""
        query = (
            "SELECT w.*, p.interval, p.ease_factor, p.repetitions, p.due_date, p.last_studied, "
            "COALESCE(p.lapses, 0) AS lapses "
            "FROM words w JOIN progress p ON p.word_id = w.id"
        )
        clauses, params = [], []
        if search:
            # Any face of the card: the word, its meaning, its translations.
            clauses.append("(w.word LIKE ? OR w.definition LIKE ? OR w.greek LIKE ? "
                           "OR w.swedish LIKE ? OR w.synonyms LIKE ?)")
            like = f"%{search}%"
            params.extend([like] * 5)
        due_ids = None
        if status_filter == "due":
            # The same cards today's study shows (reviews + today's new words);
            # filtered below, not in SQL (a long-neglected deck can have more
            # due ids than SQLite takes as parameters).
            due_ids = {r["id"] for r in self.get_due_words(
                max_new=self.get_int_setting("max_new_per_day", 20))}
        elif status_filter == "new":
            clauses.append("p.repetitions = 0 AND p.last_studied IS NULL")
        elif status_filter == "learning":
            clauses.append("((p.repetitions > 0 AND p.interval < ?) "
                           "OR (p.repetitions = 0 AND p.last_studied IS NOT NULL))")
            params.append(MASTERED_INTERVAL)
        elif status_filter == "mastered":
            clauses.append("p.repetitions > 0 AND p.interval >= ?")
            params.append(MASTERED_INTERVAL)
        elif status_filter == "difficult":
            # Cards repeatedly rated Again/Hard drift toward the 1.3 ease floor.
            clauses.append("p.repetitions > 0 AND p.ease_factor <= 1.8")
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY w.word COLLATE NOCASE"
        rows = [dict(row) for row in self.conn.execute(query, params)]
        return rows if due_ids is None else [r for r in rows if r["id"] in due_ids]

    def get_word(self, word_id):
        row = self.conn.execute(
            "SELECT w.*, p.interval, p.ease_factor, p.repetitions, p.due_date, p.last_studied, "
            "COALESCE(p.lapses, 0) AS lapses "
            "FROM words w JOIN progress p ON p.word_id = w.id WHERE w.id=?",
            (word_id,),
        ).fetchone()
        return dict(row) if row else None

    # ------------------------------------------------------------ SRS queue

    def get_due_words(self, limit=None, max_new=None):
        """Cards due now: seen cards first (oldest due first), then new cards."""
        today_end = datetime.now().strftime("%Y-%m-%d 23:59:59")
        seen = [
            dict(row)
            for row in self.conn.execute(
                "SELECT w.*, p.interval, p.ease_factor, p.repetitions, p.due_date, "
                "p.last_studied, COALESCE(p.lapses, 0) AS lapses "
                "FROM words w JOIN progress p ON p.word_id = w.id "
                "WHERE p.repetitions > 0 AND p.due_date <= ? ORDER BY p.due_date",
                (today_end,),
            )
        ]
        new = [
            dict(row)
            for row in self.conn.execute(
                # The due filter matters: a card rated Again mid-session goes
                # back to repetitions=0 with due_date tomorrow — without the
                # filter it would jump into the SAME day's next session.
                "SELECT w.*, p.interval, p.ease_factor, p.repetitions, p.due_date, "
                "p.last_studied, COALESCE(p.lapses, 0) AS lapses "
                "FROM words w JOIN progress p ON p.word_id = w.id "
                "WHERE p.repetitions = 0 AND p.due_date <= ? ORDER BY w.rowid",
                (today_end,),
            )
        ]
        if max_new is not None:
            new_today = self.new_cards_studied_today()
            remaining = max(0, max_new - new_today)
            new = new[:remaining]
        queue = seen + new
        if limit is not None:
            queue = queue[:limit]
        return queue

    def reviewed_today(self):
        today = datetime.now().strftime("%Y-%m-%d")
        row = self.conn.execute(
            "SELECT COALESCE(SUM(cards_reviewed),0) FROM sessions WHERE date=?",
            (today,),
        ).fetchone()
        return row[0]

    def new_cards_studied_today(self):
        today = datetime.now().strftime("%Y-%m-%d")
        row = self.conn.execute(
            "SELECT COUNT(*) FROM progress WHERE repetitions = 1 "
            "AND last_studied LIKE ?",
            (today + "%",),
        ).fetchone()
        return row[0]

    def due_count(self):
        """Cards today's study will show (reviews + today's new words)."""
        return due_today(self.conn, self.get_int_setting("max_new_per_day", 20))

    def next_due_datetime(self):
        row = self.conn.execute(
            "SELECT MIN(due_date) FROM progress"
        ).fetchone()
        if row and row[0]:
            try:
                return datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S")
            except ValueError:
                pass
        return None

    def progress_of(self, word_id):
        """The raw progress row, for an undo snapshot."""
        row = self.conn.execute(
            "SELECT interval, ease_factor, repetitions, due_date, last_studied, "
            "COALESCE(lapses, 0) AS lapses FROM progress WHERE word_id=?", (word_id,)).fetchone()
        return dict(row) if row else None

    def restore_progress(self, word_id, snapshot):
        """Put a progress row back exactly as it was (undo of a rating).
        Stamped as a change so the other computer follows."""
        self.conn.execute(
            "UPDATE progress SET interval=?, ease_factor=?, repetitions=?, "
            "due_date=?, last_studied=?, lapses=?, updated_at=? WHERE word_id=?",
            (snapshot["interval"], snapshot["ease_factor"], snapshot["repetitions"],
             snapshot["due_date"], snapshot["last_studied"], snapshot.get("lapses", 0),
             utc_stamp(), word_id))
        self.conn.commit()

    def apply_review(self, word_id, interval, ease_factor, repetitions, again=False):
        """Store a rating's result; `again` counts a lapse (word doctor)."""
        due = (datetime.now() + timedelta(days=interval)).strftime("%Y-%m-%d %H:%M:%S")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.conn.execute(
            "UPDATE progress SET interval=?, ease_factor=?, repetitions=?, "
            "due_date=?, last_studied=?, lapses=COALESCE(lapses, 0) + ?, updated_at=? "
            "WHERE word_id=?",
            (interval, ease_factor, repetitions, due, now, 1 if again else 0,
             utc_stamp(), word_id),
        )
        self.conn.commit()

    # -------------------------------------------------------------- sessions

    def start_session(self):
        today = datetime.now().strftime("%Y-%m-%d")
        cursor = self.conn.execute(
            "INSERT INTO sessions (date, uid, updated_at) VALUES (?, ?, ?)",
            (today, uuid.uuid4().hex, utc_stamp()),
        )
        self.conn.commit()
        return cursor.lastrowid

    def record_rating(self, session_id, rating):
        column = ["again_count", "hard_count", "good_count", "easy_count"][rating]
        self.conn.execute(
            f"UPDATE sessions SET cards_reviewed = cards_reviewed + 1, "
            f"{column} = {column} + 1, updated_at=? WHERE id=?",
            (utc_stamp(), session_id),
        )
        self.conn.commit()

    def unrecord_rating(self, session_id, rating):
        """The opposite of record_rating, for undo."""
        column = ["again_count", "hard_count", "good_count", "easy_count"][rating]
        self.conn.execute(
            f"UPDATE sessions SET cards_reviewed = MAX(0, cards_reviewed - 1), "
            f"{column} = MAX(0, {column} - 1), updated_at=? WHERE id=?",
            (utc_stamp(), session_id),
        )
        self.conn.commit()

    def delete_empty_session(self, session_id):
        self.conn.execute(
            "DELETE FROM sessions WHERE id=? AND cards_reviewed=0", (session_id,)
        )
        self.conn.commit()

    # -------------------------------------------------------------- alphabet

    def alphabet_progress(self, lang):
        """symbol -> right answers in a row."""
        return dict(self.conn.execute(
            "SELECT symbol, streak FROM alphabet_progress WHERE lang=?", (lang,)).fetchall())

    def alphabet_introduce(self, lang, symbol):
        """The drill has shown this symbol (with its sound) for the first
        time; a row with streak 0 marks it as met. Returns its streak."""
        self.conn.execute(
            "INSERT OR IGNORE INTO alphabet_progress (lang, symbol, streak, seen, updated_at) "
            "VALUES (?, ?, 0, 0, ?)", (lang, symbol, utc_stamp()))
        self.conn.commit()
        row = self.conn.execute(
            "SELECT streak FROM alphabet_progress WHERE lang=? AND symbol=?",
            (lang, symbol)).fetchone()
        return row["streak"] if row else 0

    def alphabet_record(self, lang, symbol, correct):
        """One answer; returns the new streak (0 after a miss)."""
        row = self.conn.execute(
            "SELECT streak FROM alphabet_progress WHERE lang=? AND symbol=?",
            (lang, symbol)).fetchone()
        streak = (row["streak"] + 1) if (row and correct) else (1 if correct else 0)
        self.conn.execute(
            "INSERT INTO alphabet_progress (lang, symbol, streak, seen, updated_at) "
            "VALUES (?, ?, ?, 1, ?) ON CONFLICT(lang, symbol) DO UPDATE SET "
            "streak=excluded.streak, seen=seen+1, updated_at=excluded.updated_at",
            (lang, symbol, streak, utc_stamp()))
        self.conn.commit()
        return streak

    # ----------------------------------------------------------------- stats

    def counts(self):
        total = self.word_count()
        # New = never studied. A card rated Again also has repetitions 0, but
        # it has been seen: it is Learning, not New / Unseen.
        new = self.conn.execute(
            "SELECT COUNT(*) FROM progress WHERE repetitions = 0 AND last_studied IS NULL"
        ).fetchone()[0]
        mastered = self.conn.execute(
            "SELECT COUNT(*) FROM progress WHERE repetitions > 0 AND interval >= ?",
            (MASTERED_INTERVAL,),
        ).fetchone()[0]
        learning = total - new - mastered
        return {
            "total": total,
            "new": new,
            "mastered": mastered,
            "learning": learning,
            "due": self.due_count(),
        }

    def reviews_per_day(self, days=30):
        """List of (date_str, count) for the last `days` days, oldest first."""
        result = []
        today = datetime.now().date()
        rows = dict(
            self.conn.execute(
                "SELECT date, SUM(cards_reviewed) FROM sessions "
                "WHERE cards_reviewed > 0 GROUP BY date"
            ).fetchall()
        )
        for offset in range(days - 1, -1, -1):
            day = (today - timedelta(days=offset)).strftime("%Y-%m-%d")
            result.append((day, rows.get(day, 0) or 0))
        return result

    def reviews_per_month(self):
        """(YYYY-MM, reviews) for every month from the first session to this
        one, zeros included — the long view the 30-day chart cannot give."""
        rows = dict(self.conn.execute(
            "SELECT substr(date, 1, 7), SUM(cards_reviewed) FROM sessions "
            "WHERE cards_reviewed > 0 GROUP BY 1").fetchall())
        if not rows:
            return []
        year, month = (int(part) for part in min(rows).split("-"))
        today = datetime.now()
        result = []
        while (year, month) <= (today.year, today.month):
            key = f"{year:04d}-{month:02d}"
            result.append((key, rows.get(key, 0) or 0))
            month += 1
            if month > 12:
                year, month = year + 1, 1
        return result

    def first_study_date(self):
        row = self.conn.execute(
            "SELECT MIN(date) FROM sessions WHERE cards_reviewed > 0").fetchone()
        return row[0] if row and row[0] else None

    def due_next_days(self, days=7):
        result = []
        today = datetime.now().date()
        for offset in range(days):
            day = today + timedelta(days=offset)
            if offset == 0:
                count = self.due_count()
            else:
                start = day.strftime("%Y-%m-%d 00:00:00")
                end = day.strftime("%Y-%m-%d 23:59:59")
                count = self.conn.execute(
                    "SELECT COUNT(*) FROM progress WHERE due_date >= ? AND due_date <= ?",
                    (start, end),
                ).fetchone()[0]
            result.append((day.strftime("%a"), count))
        return result

    def totals(self):
        row = self.conn.execute(
            "SELECT COALESCE(SUM(cards_reviewed),0), COUNT(*), "
            "COALESCE(SUM(again_count),0), COALESCE(SUM(hard_count),0), "
            "COALESCE(SUM(good_count),0), COALESCE(SUM(easy_count),0) "
            "FROM sessions WHERE cards_reviewed > 0"
        ).fetchone()
        reviewed, sessions, again, hard, good, easy = row
        accuracy = 0.0
        if reviewed:
            accuracy = (good + easy) / reviewed * 100
        return {
            "reviewed": reviewed,
            "sessions": sessions,
            "accuracy": accuracy,
            "again": again,
            "hard": hard,
            "good": good,
            "easy": easy,
        }

    def study_dates(self):
        return {
            row[0]
            for row in self.conn.execute(
                "SELECT DISTINCT date FROM sessions WHERE cards_reviewed > 0"
            )
        }

    def current_streak(self):
        dates = self.study_dates()
        if not dates:
            return 0
        streak = 0
        day = datetime.now().date()
        # A streak survives if today has no session yet but yesterday does.
        if day.strftime("%Y-%m-%d") not in dates:
            day -= timedelta(days=1)
        while day.strftime("%Y-%m-%d") in dates:
            streak += 1
            day -= timedelta(days=1)
        return streak

    def longest_streak(self):
        dates = sorted(
            datetime.strptime(d, "%Y-%m-%d").date() for d in self.study_dates()
        )
        longest = current = 0
        previous = None
        for day in dates:
            if previous is not None and (day - previous).days == 1:
                current += 1
            else:
                current = 1
            longest = max(longest, current)
            previous = day
        return longest

    # ---------------------------------------------------------------- export

    def export_csv(self, filepath):
        import csv

        rows = self.get_words()
        with open(filepath, "w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(
                [
                    "Word", "Definition", "Part of Speech", "Greek", "Swedish",
                    "Synonyms", "Example", "Interval (days)", "Ease Factor",
                    "Repetitions", "Due Date", "Last Studied",
                ]
            )
            for row in rows:
                writer.writerow(
                    [
                        row["word"], row["definition"], row["pos"], row["greek"],
                        row["swedish"], row["synonyms"], row["example"],
                        row["interval"], round(row["ease_factor"], 2),
                        row["repetitions"], row["due_date"], row["last_studied"] or "",
                    ]
                )
        return len(rows)

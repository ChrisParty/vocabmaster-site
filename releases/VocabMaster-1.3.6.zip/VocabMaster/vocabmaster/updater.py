"""In-app updates, without a server of our own — all or nothing.

tools/publish_release.py puts two things on the public GitHub Pages site:
`latest.json` ({"version", "url", "sha256", "notes", "published"}) and the zip
it points to. At startup the app reads latest.json; a newer version shows a
banner. "Update & restart" then:

  1. downloads the zip and checks it against the published SHA-256 (a
     damaged or swapped download is refused before anything changes);
  2. checks the zip itself: readable, one VocabMaster release, no file name
     that could land outside the install folder, and the version inside is
     the one announced;
  3. copies every file it is about to replace into <install>/.update/old and
     writes a journal (.update/journal.json);
  4. installs the new files one by one (each written beside its target and
     renamed into place), version.py last;
  5. on any failure, puts the old files back: the app is as it was.

A power cut in the middle leaves the journal behind. The next start calls
recover_interrupted() before loading anything else and puts the old version
back, so the app starts, and the update is simply offered again.

Data never lives in the install folder (paths.py), and .venv is never touched.
The journal format is part of the contract between versions (an older
updater's journal is read by a newer recover_interrupted): keep its fields.
"""

import hashlib
import json
import logging
import os
import re
import shutil
import tempfile
import time
import urllib.request
import zipfile

import paths
from version import VERSION

LATEST_URL = "https://chrisparty.github.io/vocabmaster-site/latest.json"
KEEP = (".venv", ".update", ".git")    # never written by an update
STATE = ".update"                      # journal + copies of the replaced files
LAST = "vocabmaster/version.py"        # installed last: the version changes only at the very end

log = logging.getLogger("updater")


def parse(version):
    try:
        return tuple(int(part) for part in version.strip().split("."))
    except ValueError:
        return (0,)


def check(timeout=10):
    """The latest release if it is newer than this one, else None. Any
    network trouble is None too: an update check must never bother anyone."""
    try:
        with urllib.request.urlopen(LATEST_URL, timeout=timeout) as response:
            info = json.loads(response.read().decode())
    except Exception:
        return None
    if parse(info.get("version", "0")) > parse(VERSION):
        return info
    return None


def _release_root(bundle):
    """The top folder inside the zip that holds vocabmaster/main.py."""
    for name in bundle.namelist():
        parts = name.split("/")
        if len(parts) == 3 and parts[1] == "vocabmaster" and parts[2] == "main.py":
            return parts[0]
    raise ValueError("that zip is not a VocabMaster release")


def _members(bundle, root):
    """The files to install, as paths relative to the install folder. A name
    that could escape it (.., an absolute path, a drive letter, a
    backslash) means the zip is refused as a whole."""
    out = []
    for name in bundle.namelist():
        if name.endswith("/") or not name.startswith(root + "/"):
            continue
        rel = name[len(root) + 1:]
        parts = rel.split("/")
        if (not rel or "\\" in rel or ":" in rel or rel.startswith("/")
                or any(part in ("", ".", "..") for part in parts)):
            raise ValueError(f"that zip holds an unsafe file name ({name!r})")
        if parts[0] in KEEP:
            continue
        out.append(rel)
    return out


def _zip_version(bundle, root):
    text = bundle.read(f"{root}/{LAST}").decode("utf-8", "replace")
    match = re.search(r'VERSION\s*=\s*["\']([0-9.]+)["\']', text)
    return match.group(1) if match else ""


def _sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _put(src, dst):
    """One file into place: written beside the target, then renamed. An
    antivirus often holds a freshly written file for a moment ("Access is
    denied"): a few short retries before it counts as a failure."""
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copyfile(src, dst + ".part")
    shutil.copymode(src, dst + ".part")
    for attempt in range(6):
        try:
            os.replace(dst + ".part", dst)
            return
        except PermissionError:
            if attempt == 5:
                raise
            time.sleep(0.25 * (attempt + 1))


def _write_journal(state_dir, journal):
    path = os.path.join(state_dir, "journal.json")
    with open(path + ".part", "w", encoding="utf-8") as handle:
        json.dump(journal, handle)
    os.replace(path + ".part", path)


def recover_interrupted(root=None):
    """Undo an update that did not finish (power cut, crash). Returns the
    version put back, or None when there was nothing to undo. Safe to call
    at every start, and again if it was itself interrupted."""
    root = root or paths.install_root()
    state_dir = os.path.join(root, STATE)
    if not os.path.isdir(state_dir):
        return None
    try:
        with open(os.path.join(state_dir, "journal.json"), encoding="utf-8") as handle:
            journal = json.load(handle)
    except (OSError, ValueError):
        journal = None                    # stopped before the first new file: nothing changed
    if not journal or journal.get("state") == "done":
        shutil.rmtree(state_dir, ignore_errors=True)
        return None
    old = os.path.join(state_dir, "old")
    stuck = []
    for rel in journal.get("replaced", []):
        saved = os.path.join(old, *rel.split("/"))
        if os.path.exists(saved):
            try:
                _put(saved, os.path.join(root, *rel.split("/")))
            except OSError:
                stuck.append(rel)              # still locked: try again next start
    for rel in journal.get("created", []):
        try:
            os.remove(os.path.join(root, *rel.split("/")))
        except FileNotFoundError:
            pass
        except OSError:
            stuck.append(rel)
    if stuck:
        log.error("undoing the update to %s: %d files still locked, retrying at next start",
                  journal.get("version"), len(stuck))
        return None                           # the journal stays, so nothing is forgotten
    shutil.rmtree(state_dir, ignore_errors=True)
    log.warning("an unfinished update to %s was undone; back on %s",
                journal.get("version"), journal.get("from"))
    return journal.get("from")


def apply(info, progress=None):
    """Download, verify and install. Returns the new version string. Raises
    on any problem — with the installed copy exactly as it was."""
    target = paths.install_root()
    recover_interrupted(target)                 # leftovers of an earlier attempt
    handle, archive = tempfile.mkstemp(suffix=".zip")
    os.close(handle)
    staging = None
    state_dir = os.path.join(target, STATE)
    try:
        if progress:
            progress("downloading…")
        with urllib.request.urlopen(info["url"], timeout=60) as response, open(archive, "wb") as out:
            shutil.copyfileobj(response, out)
        expected = str(info.get("sha256") or "").strip().lower()
        if expected and _sha256(archive) != expected:
            raise ValueError("the download is damaged (it does not match the published "
                             "fingerprint) — nothing was changed; try again later")
        try:
            bundle = zipfile.ZipFile(archive)
        except zipfile.BadZipFile:
            raise ValueError("the download is damaged — nothing was changed; try again later")
        with bundle:
            if bundle.testzip() is not None:
                raise ValueError("the download is damaged — nothing was changed; try again later")
            root = _release_root(bundle)
            members = _members(bundle, root)
            version = _zip_version(bundle, root)
            if info.get("version") and version != info["version"]:
                raise ValueError("that zip is not the release it was announced as")
            if parse(version) <= parse(VERSION):
                raise ValueError("that release is not newer than this one")
            staging = tempfile.mkdtemp(prefix="vocabmaster-update-")
            for rel in members:
                dest = os.path.join(staging, *rel.split("/"))
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with bundle.open(f"{root}/{rel}") as src, open(dest, "wb") as out:
                    shutil.copyfileobj(src, out)
        if progress:
            progress("installing…")
        order = sorted(members, key=lambda rel: rel == LAST)          # version.py last
        shutil.rmtree(state_dir, ignore_errors=True)
        old = os.path.join(state_dir, "old")
        journal = {"version": version, "from": VERSION, "state": "copying",
                   "replaced": [], "created": []}
        for rel in order:                     # keep a copy of everything about to change
            current = os.path.join(target, *rel.split("/"))
            if os.path.exists(current):
                saved = os.path.join(old, *rel.split("/"))
                os.makedirs(os.path.dirname(saved), exist_ok=True)
                shutil.copy2(current, saved)
                journal["replaced"].append(rel)
            else:
                journal["created"].append(rel)
        _write_journal(state_dir, journal)    # from here on, a power cut is undone at start
        try:
            for rel in order:
                _put(os.path.join(staging, *rel.split("/")), os.path.join(target, *rel.split("/")))
        except Exception as exc:
            recover_interrupted(target)
            raise RuntimeError(f"the update could not be written ({exc}) — "
                               "the old version was put back") from exc
        journal["state"] = "done"
        _write_journal(state_dir, journal)
        shutil.rmtree(state_dir, ignore_errors=True)
        return version
    finally:
        if staging:
            shutil.rmtree(staging, ignore_errors=True)
        try:
            os.remove(archive)
        except OSError:
            pass

"""Sample decks: 20 beginner words with full cards — readings, examples,
memory hooks — shipped with the app (data/samples/<target>-<definition>.json,
written once by the app's own card writer). A new learner sees real cards in
the first minute, before getting an OpenAI key.

Offered only for an EMPTY deck whose languages match a sample, so no
existing deck ever changes. The sample's translations are kept only when
they are in the deck's own translation language.
"""

import json
import os

import database

FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "samples")


def path_for(langs):
    """The sample for this deck's learning + explaining language, or None."""
    name = f"{langs.target.strip().lower()}-{langs.definition.strip().lower()}.json"
    path = os.path.join(FOLDER, name)
    return path if os.path.exists(path) else None


def offer(db, langs):
    """The sample to offer this deck — only while it has no words at all."""
    return path_for(langs) if db.word_count() == 0 else None


def add_to(db, langs, path):
    """Put the sample's cards in the deck (they become ordinary new cards).
    Returns how many were added."""
    with open(path, encoding="utf-8") as handle:
        data = json.load(handle)
    keep_translation = (langs.native or "").strip().lower() == str(data.get("translation", "")).lower()
    have = {row[0].strip().lower() for row in db.conn.execute("SELECT word FROM words")}
    added = 0
    for card in data.get("cards", []):
        word = (card.get("word") or "").strip()
        if not word or word.lower() in have:
            continue
        entry = {k: v for k, v in card.items() if k in database.CARD_FIELDS}
        if not keep_translation:
            entry["greek"] = ""
        database.insert_card(db.conn, entry)
        have.add(word.lower())
        added += 1
    db.conn.commit()
    return added

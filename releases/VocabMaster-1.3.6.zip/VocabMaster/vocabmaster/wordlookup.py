"""Find a word from a story, a conversation or a sentence among the deck's
own cards — no AI, no cost. Used by the double-click card (ui/wordlabel.py).

A word in running text often carries an ending: 물을 (물 + object particle),
kaffet (kaffe + "the"), dricker (dricka), 飲みます (飲む). `find` accepts the
card's word with an ending from a short list for its language — never just
any longer word (물건 "thing" is not 물 "water"). Japanese has no spaces, so
a double-click selects the whole sentence: `in_sentence` lists the deck's
words that occur in it instead.
"""

import unicodedata

PUNCTUATION = " \t\r\n.,!?;:\"'“”‘’„«»()[]{}…—–-·。、！？「」『』（）"

KOREAN_PARTICLES = {
    "은", "는", "이", "가", "을", "를", "에", "에서", "에게", "의", "도", "와", "과", "로",
    "으로", "만", "까지", "부터", "한테", "께", "요", "이에요", "예요", "이야", "야", "랑",
    "이랑", "하고", "처럼", "보다", "들", "들이", "들은", "들을", "들도", "에는", "에서는",
    "에게는", "은요", "는요", "이요", "도요", "입니다", "이다",
}
# How a Korean verb or adjective (dictionary form ending in 다) continues
# after its stem: 먹다 → 먹어요, 먹었어요, 먹고, 먹는, 먹습니다…
KOREAN_VERB_STARTS = ("아", "어", "았", "었", "요", "고", "는", "니", "면", "세", "습",
                      "지", "게", "기", "겠", "러", "려", "서", "자", "시", "으", "을", "은")
JAPANESE_PARTICLES = {"は", "が", "を", "に", "で", "と", "の", "へ", "も", "や", "から",
                      "まで", "より", "です", "だ", "でした", "じゃ", "ね", "よ"}
JAPANESE_VERB_ENDS = set("うくぐすつぬぶむるい")
SWEDISH_ENDINGS = {"en", "et", "n", "t", "na", "er", "ar", "or", "erna", "arna", "orna",
                   "s", "r", "de", "te", "dde", "tt", "a", "e", "ade", "at", "ande"}
ENGLISH_ENDINGS = {"s", "es", "ed", "d", "ing", "er", "est", "ly", "ies", "ied"}
GREEK_ENDINGS = {"ς", "ν", "α", "ες", "ου", "ων", "ι", "οι", "η", "ης", "ο", "ος", "ας",
                 "ει", "εις", "ουμε", "ετε", "ουν", "ω"}


def _clean(text):
    return unicodedata.normalize("NFC", (text or "").strip(PUNCTUATION)).casefold()


def _forms(card):
    """The written forms of a card: the word and, for kana languages, the kana
    part of its reading ("たべる · taberu")."""
    word = _clean((card["word"] or "").split("[")[0])
    out = [word] if word else []
    for part in (card.get("reading") or "").split("·"):
        part = _clean(part)
        if part and part not in out and not part.isascii():
            out.append(part)
    return out


def _fits(clicked, form, language):
    """Is `clicked` the card's form with an ending of its language?"""
    if not form or not clicked.startswith(form):
        return False
    rest = clicked[len(form):]
    if not rest:
        return True
    if language == "korean":
        return rest in KOREAN_PARTICLES
    if language == "swedish":
        return rest in SWEDISH_ENDINGS
    if language == "english":
        return rest in ENGLISH_ENDINGS
    if language == "greek":
        return rest in GREEK_ENDINGS
    if language == "japanese":
        return rest in JAPANESE_PARTICLES
    return False


def _stems(form, language):
    """Forms a word takes before an ending: 먹다 → 먹, dricka → drick,
    make → mak, 飲む → 飲, φίλος → φίλ."""
    if language == "korean" and form.endswith("다") and len(form) >= 2:
        stem = form[:-1]
        out = [stem]
        if stem.endswith("하"):                     # 공부하다 → 공부해요, 공부했어요
            out.append(stem[:-1] + "해")
            out.append(stem[:-1] + "했")
        return out
    if language in ("swedish", "english") and len(form) >= 4 and form[-1] in "ae":
        return [form[:-1]]
    if language == "greek" and len(form) >= 4 and form[-2:] in ("ος", "ας", "ης", "ει", "ώ"):
        return [form[:-2]]
    if language == "japanese" and len(form) >= 2 and form[-1] in JAPANESE_VERB_ENDS:
        return [form[:-1]]
    return []


def _stem_fits(clicked, stem, language):
    if not stem or not clicked.startswith(stem) or clicked == stem:
        return False
    rest = clicked[len(stem):]
    if language == "korean":
        return len(rest) <= 5 and rest.startswith(KOREAN_VERB_STARTS)
    if language in ("swedish", "english", "greek"):
        endings = {"swedish": SWEDISH_ENDINGS, "english": ENGLISH_ENDINGS,
                   "greek": GREEK_ENDINGS}[language]
        return rest in endings
    if language == "japanese":
        return len(rest) <= 6
    return False


def _cards(conn):
    return [dict(r) for r in conn.execute(
        "SELECT id, word, reading, definition, greek, example, example_tr FROM words")]


def find(conn, text, target):
    """The deck's card for a word as it appears in text, or None."""
    clicked = _clean(text)
    language = (target or "").strip().lower()
    if not clicked:
        return None
    best, best_len = None, 0
    for card in _cards(conn):
        for form in _forms(card):
            if form == clicked:
                return card
            if _fits(clicked, form, language) and len(form) > best_len:
                best, best_len = card, len(form)
            for stem in _stems(form, language):
                if _stem_fits(clicked, stem, language) and len(stem) > best_len:
                    best, best_len = card, len(stem)
    return best


def in_sentence(conn, text, target, limit=6):
    """The deck's cards whose words occur in a sentence without spaces
    (Japanese), in the order they appear."""
    sentence = _clean(text)
    language = (target or "").strip().lower()
    found = []
    for card in _cards(conn):
        where = None
        for form in _forms(card):
            if len(form) >= 1 and form in sentence:
                where = sentence.index(form)
                break
            for stem in _stems(form, language):
                # a verb's stem must be more than one kana long to count
                if (len(stem) >= 2 or not stem.isascii() and any("一" <= ch <= "鿿" for ch in stem)) \
                        and stem in sentence:
                    where = sentence.index(stem)
                    break
            if where is not None:
                break
        if where is not None:
            found.append((where, card))
    found.sort(key=lambda pair: pair[0])
    return [card for _, card in found][:limit]

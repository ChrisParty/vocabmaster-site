"""The daily nudge: once a day, at the chosen time, if there is something
due and the goal is not met yet — "12 cards due — five minutes?". Clicking
it opens a session. Windows and Linux use the tray balloon; macOS gets a
Notification Center message through osascript, which works unbundled.
"""

import platform
import subprocess
from datetime import datetime

DEFAULT_TIME = "19:00"


def due_message(db):
    """The reminder text if one is owed right now, else None. Owed means:
    enabled, past the chosen time, not yet shown today, cards due, goal
    not reached. Marks today as done either way once past the time."""
    if db.get_setting("reminder_enabled") != "1":
        return None
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    if db.get_setting("reminder_last") == today:
        return None
    if now.strftime("%H:%M") < (db.get_setting("reminder_time") or DEFAULT_TIME):
        return None
    db.set_setting("reminder_last", today)
    due = db.due_count()
    if due == 0 or db.reviewed_today() >= db.get_int_setting("daily_goal", 20):
        return None
    return f"{due} card{'s' if due != 1 else ''} due — five minutes?"


def notify(tray, title, text):
    if platform.system() == "Darwin":
        safe = text.replace('"', "'")
        subprocess.Popen(["osascript", "-e",
                          f'display notification "{safe}" with title "{title}"'])
    elif tray is not None:
        tray.showMessage(title, text, tray.icon(), 15000)

"""The writing systems a learner may have to acquire before the words make
sense: Hangul, kana, the Greek alphabet. Data only — the screen that
teaches them is ui/alphabet.py.

Each alphabet: an intro a beginner can read in a minute, groups of
symbols with a reading and an optional note, and (for Hangul) a way to
build syllables so practice is not limited to isolated letters.
"""

HANGUL_INTRO = (
    "Hangul has only 24 basic letters and you can read it in a few days. "
    "Letters are stacked into syllable blocks: a consonant, then a vowel, "
    "sometimes a final consonant underneath. 한 = ㅎ + ㅏ + ㄴ (han); "
    "물 = ㅁ + ㅜ + ㄹ (mul); 가 = ㄱ + ㅏ (ga). The circle ㅇ is silent at the "
    "start of a block and 'ng' at the end. Learn the sounds below, then let "
    "the practice drill show you blocks until they read themselves."
)

KANA_INTRO = (
    "Japanese writes native words in hiragana and borrowed words in "
    "katakana: two sets of 46 symbols with the same sounds. Each symbol is "
    "one syllable (ka, ki, ku…), so once you know them you can read any "
    "word aloud. Start with hiragana; katakana follows the same table."
)

GREEK_INTRO = (
    "Twenty-four letters, most with a sound close to the Latin one you "
    "already know. The traps are few: Β is v, Η is i, Ρ is r, Χ is a throaty "
    "h, and Υ sounds like i. Learn those and you can read Greek aloud today."
)

# (symbol, reading, note)
HANGUL_CONSONANTS = [
    ("ㄱ", "g / k", ""), ("ㄴ", "n", ""), ("ㄷ", "d / t", ""), ("ㄹ", "r / l", ""),
    ("ㅁ", "m", ""), ("ㅂ", "b / p", ""), ("ㅅ", "s", "sh before i"),
    ("ㅇ", "– / ng", "silent at the start, ng at the end"), ("ㅈ", "j", ""),
    ("ㅊ", "ch", ""), ("ㅋ", "k", "strong"), ("ㅌ", "t", "strong"),
    ("ㅍ", "p", "strong"), ("ㅎ", "h", ""),
]
HANGUL_DOUBLE = [
    ("ㄲ", "kk", "tense"), ("ㄸ", "tt", "tense"), ("ㅃ", "pp", "tense"),
    ("ㅆ", "ss", "tense"), ("ㅉ", "jj", "tense"),
]
HANGUL_VOWELS = [
    ("ㅏ", "a", ""), ("ㅑ", "ya", ""), ("ㅓ", "eo", "like 'u' in 'but'"),
    ("ㅕ", "yeo", ""), ("ㅗ", "o", ""), ("ㅛ", "yo", ""), ("ㅜ", "u", ""),
    ("ㅠ", "yu", ""), ("ㅡ", "eu", "lips flat"), ("ㅣ", "i", ""),
]
HANGUL_COMPOUND = [
    ("ㅐ", "ae", ""), ("ㅒ", "yae", ""), ("ㅔ", "e", ""), ("ㅖ", "ye", ""),
    ("ㅘ", "wa", ""), ("ㅙ", "wae", ""), ("ㅚ", "oe", ""), ("ㅝ", "wo", ""),
    ("ㅞ", "we", ""), ("ㅟ", "wi", ""), ("ㅢ", "ui", ""),
]

# Unicode syllable composition: 0xAC00 + (initial * 21 + vowel) * 28 + final
_INITIALS = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
_INITIAL_ROM = ["g", "kk", "n", "d", "tt", "r", "m", "b", "pp", "s", "ss", "",
                "j", "jj", "ch", "k", "t", "p", "h"]
_VOWELS = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ"
_VOWEL_ROM = ["a", "ae", "ya", "yae", "eo", "e", "yeo", "ye", "o", "wa", "wae", "oe",
              "yo", "u", "wo", "we", "wi", "yu", "eu", "ui", "i"]


def hangul_syllables(simple=True):
    """(syllable, reading) for consonant + vowel blocks — the simple ones
    (basic consonants, basic vowels) when `simple`, else all of them."""
    out = []
    for ci, consonant in enumerate(_INITIALS):
        if simple and consonant in "ㄲㄸㅃㅆㅉ":
            continue
        for vi, vowel in enumerate(_VOWELS):
            if simple and vowel not in "ㅏㅑㅓㅕㅗㅛㅜㅠㅡㅣ":
                continue
            code = 0xAC00 + (ci * 21 + vi) * 28
            out.append((chr(code), _INITIAL_ROM[ci] + _VOWEL_ROM[vi]))
    return out


_HIRA = ("あa いi うu えe おo かka きki くku けke こko さsa しshi すsu せse そso "
         "たta ちchi つtsu てte とto なna にni ぬnu ねne のno はha ひhi ふfu へhe ほho "
         "まma みmi むmu めme もmo やya ゆyu よyo らra りri るru れre ろro わwa をwo んn")
_KATA = ("アa イi ウu エe オo カka キki クku ケke コko サsa シshi スsu セse ソso "
         "タta チchi ツtsu テte トto ナna ニni ヌnu ネne ノno ハha ヒhi フfu ヘhe ホho "
         "マma ミmi ムmu メme モmo ヤya ユyu ヨyo ラra リri ルru レre ロro ワwa ヲwo ンn")


def _kana(spec):
    return [(item[0], item[1:], "") for item in spec.split()]


GREEK = [
    ("Α α", "a", "alpha"), ("Β β", "v", "vita — not b"), ("Γ γ", "gh / y", "gamma, soft"),
    ("Δ δ", "th", "delta, as in 'this'"), ("Ε ε", "e", "epsilon"), ("Ζ ζ", "z", "zita"),
    ("Η η", "i", "ita — sounds like i"), ("Θ θ", "th", "thita, as in 'thin'"),
    ("Ι ι", "i", "iota"), ("Κ κ", "k", "kappa"), ("Λ λ", "l", "lamda"), ("Μ μ", "m", "mi"),
    ("Ν ν", "n", "ni"), ("Ξ ξ", "ks", "xi"), ("Ο ο", "o", "omikron"), ("Π π", "p", "pi"),
    ("Ρ ρ", "r", "ro — not p"), ("Σ σ ς", "s", "sigma; ς at the end of a word"),
    ("Τ τ", "t", "taf"), ("Υ υ", "i", "ipsilon — sounds like i"), ("Φ φ", "f", "fi"),
    ("Χ χ", "ch", "chi, throaty h"), ("Ψ ψ", "ps", "psi"), ("Ω ω", "o", "omega"),
]

ALPHABETS = {
    "korean": {
        "title": "Hangul — the Korean alphabet",
        "intro": HANGUL_INTRO,
        "groups": [("Consonants", HANGUL_CONSONANTS), ("Tense consonants", HANGUL_DOUBLE),
                   ("Vowels", HANGUL_VOWELS), ("Compound vowels", HANGUL_COMPOUND)],
        "syllables": True,
    },
    "japanese": {
        "title": "Kana — the Japanese syllabaries",
        "intro": KANA_INTRO,
        "groups": [("Hiragana", _kana(_HIRA)), ("Katakana", _kana(_KATA))],
        "syllables": False,
    },
    "greek": {
        "title": "The Greek alphabet",
        "intro": GREEK_INTRO,
        "groups": [("Letters", GREEK)],
        "syllables": False,
    },
}


def for_language(name):
    """The alphabet for a learning language, or None (Latin scripts)."""
    return ALPHABETS.get((name or "").strip().lower())


def all_symbols(alphabet):
    """Every (symbol, reading) the practice can ask about."""
    items = [(symbol, reading) for _, group in alphabet["groups"] for symbol, reading, _ in group]
    if alphabet.get("syllables"):
        items += hangul_syllables(simple=True)
    return items


def speakable(symbol):
    """What to hand the voice: a full symbol, or for a Greek pair its
    lower-case letter."""
    return symbol.split()[-1] if " " in symbol else symbol

"""Browse screen: searchable word table, filters, detail panel, context menu."""

import html

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QAbstractItemView, QDialog, QDialogButtonBox, QFormLayout, QFrame,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMenu, QMessageBox,
    QPushButton, QScrollArea, QTableWidget, QTableWidgetItem, QTextEdit,
    QVBoxLayout, QWidget,
)

import flags
import languages
from database import MASTERED_INTERVAL
from styles import ACCENT, SUCCESS, TEXT_MUTED, TEXT_SECONDARY

FILTERS = [
    ("all", "All"),
    ("due", "Due Today"),
    ("new", "New"),
    ("learning", "Learning"),
    ("mastered", "Mastered"),
    ("difficult", "Difficult"),
]

STATUS_COLORS = {
    "New": TEXT_SECONDARY,
    "Learning": ACCENT,
    "Mastered": SUCCESS,
}


def word_status(row):
    if row["repetitions"] == 0:
        return "New"
    if row["interval"] >= MASTERED_INTERVAL:
        return "Mastered"
    return "Learning"


class EditWordDialog(QDialog):
    def __init__(self, word, langs, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Edit “{word['word']}”")
        self.setMinimumWidth(460)
        layout = QFormLayout(self)
        self.fields = {}
        for field, label in [
            ("word", "Word"), ("pos", "Part of speech"),
            ("greek", langs.native or "Translation"),
            ("swedish", langs.second or "Translation 2"), ("synonyms", "Similar words"),
            ("reading", "Reading (pronunciation)"),
        ]:
            edit = QLineEdit(word.get(field) or "")
            self.fields[field] = edit
            layout.addRow(label, edit)
        for field, label in [("definition", "Definition"), ("example", "Example"),
                             ("example_tr", "Example translated"), ("hook", "Memory hook")]:
            edit = QTextEdit(word.get(field) or "")
            edit.setMaximumHeight(70)
            self.fields[field] = edit
            layout.addRow(label, edit)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def values(self):
        result = {}
        for field, widget in self.fields.items():
            if isinstance(widget, QTextEdit):
                result[field] = widget.toPlainText().strip()
            else:
                result[field] = widget.text().strip()
        return result


class BrowseScreen(QWidget):
    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self.current_filter = "all"
        self.rows = []
        self.langs = languages.load(db.get_setting)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(14)

        header = QLabel("Browse Words")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(header)

        # ------------------------------------------------ search + filters
        controls_row = QHBoxLayout()
        controls_row.setSpacing(8)
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("🔍  Search words, meanings or translations…")
        self.search_box.textChanged.connect(self.reload)
        controls_row.addWidget(self.search_box, 1)

        self.filter_buttons = {}
        for key, label in FILTERS:
            button = QPushButton(label)
            button.setCheckable(True)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _, k=key: self.set_filter(k))
            controls_row.addWidget(button)
            self.filter_buttons[key] = button
        layout.addLayout(controls_row)

        # ------------------------------------------------ table + detail
        body_row = QHBoxLayout()
        body_row.setSpacing(14)

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(
            ["Word", "Definition", "POS", "Interval", "Due Date", "Status"]
        )
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(44)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        self.table.itemSelectionChanged.connect(self.show_detail)
        # A click on the row that is already selected changes no selection,
        # so it must show the detail on its own.
        self.table.cellClicked.connect(lambda *_: self.show_detail())
        body_row.addWidget(self.table, 1)

        self.detail_panel = QFrame()
        self.detail_panel.setObjectName("card")
        self.detail_panel.setFixedWidth(280)
        detail_layout = QVBoxLayout(self.detail_panel)
        detail_layout.setContentsMargins(18, 16, 18, 16)
        self.detail_label = QLabel("Select a word to see details.")
        self.detail_label.setWordWrap(True)
        self.detail_label.setTextFormat(Qt.TextFormat.RichText)
        self.detail_label.setAlignment(Qt.AlignmentFlag.AlignTop)
        # A long card (hook + both translations) scrolls inside the panel
        # instead of pushing the buttons out of sight.
        detail_scroll = QScrollArea()
        detail_scroll.setWidgetResizable(True)
        detail_scroll.setFrameShape(QFrame.Shape.NoFrame)
        detail_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        detail_scroll.setStyleSheet("background: transparent;")
        detail_scroll.setWidget(self.detail_label)
        detail_layout.addWidget(detail_scroll, 1)
        # The right-click menu is invisible to most people: the same three
        # actions as buttons, enabled once a word is selected.
        self.action_buttons = []
        for text, tip, handler in [
            ("✏️  Edit", "Change any field of this card", self.edit_selected),
            ("🔄  Reset progress", "Forget how well you know it; it becomes new again",
             self.reset_selected),
            ("🗑️  Delete", "Remove the word and its progress for good  (Delete key)",
             self.delete_selected),
        ]:
            button = QPushButton(text)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setToolTip(tip)
            button.setEnabled(False)
            button.clicked.connect(handler)
            detail_layout.addWidget(button)
            self.action_buttons.append(button)
        body_row.addWidget(self.detail_panel)

        layout.addLayout(body_row, 1)

        self.count_label = QLabel("")
        self.count_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        layout.addWidget(self.count_label)

        self.set_filter("all")

    def refresh(self):
        self.langs = languages.load(self.db.get_setting)
        self.reload()

    def set_filter(self, key):
        self.current_filter = key
        for name, button in self.filter_buttons.items():
            button.setChecked(name == key)
        self.reload()

    def reload(self):
        search = self.search_box.text().strip()
        self.rows = self.db.get_words(search=search, status_filter=self.current_filter)
        self.table.clearSelection()
        self.table.setRowCount(len(self.rows))
        for r, row in enumerate(self.rows):
            definition = row["definition"]
            if len(definition) > 60:
                definition = definition[:57] + "…"
            status = word_status(row)
            due = (row["due_date"] or "")[:10]
            cells = [
                row["word"], definition, row["pos"] or "",
                f"{row['interval']}d" if row["repetitions"] else "—",
                due if row["repetitions"] else "new",
                status,
            ]
            for c, text in enumerate(cells):
                item = QTableWidgetItem(text)
                if c == 0:
                    item.setData(Qt.ItemDataRole.UserRole, row["id"])
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                if c == 5:
                    item.setForeground(QColor(STATUS_COLORS[status]))
                if c in (3, 4):
                    item.setForeground(QColor(TEXT_MUTED))
                self.table.setItem(r, c, item)
        self.count_label.setText(f"{len(self.rows)} words shown")
        self.detail_label.setText("Select a word to see details.")
        for button in self.action_buttons:
            button.setEnabled(False)
        # A search that narrows to a few words: show the first one right away.
        if search and 0 < len(self.rows) <= 3:
            self.table.selectRow(0)
            self.show_detail()

    # --------------------------------------------------------------- detail

    def _selected_row(self):
        indexes = self.table.selectionModel().selectedRows()
        if not indexes:
            return None
        return self.rows[indexes[0].row()]

    def show_detail(self):
        row = self._selected_row()
        for button in self.action_buttons:
            button.setEnabled(row is not None)
        if not row:
            return
        status = word_status(row)
        row = {k: (html.escape(v) if isinstance(v, str) else v) for k, v in row.items()}
        parts = [
            f"<h2 style='margin:0'>{row['word']}</h2>",
            f"<p style='color:{STATUS_COLORS[status]};font-weight:600;margin:4px 0'>{status}</p>",
        ]
        if row.get("reading"):
            parts.append(f"<p style='color:{TEXT_SECONDARY};margin:0'>{row['reading']}</p>")
        if row["pos"]:
            parts.append(f"<p style='color:{TEXT_SECONDARY};margin:2px 0'><i>{row['pos']}</i></p>")
        parts.append(f"<p>{row['definition']}</p>")
        if row["example"]:
            parts.append(f"<p style='color:{TEXT_SECONDARY}'><i>“{row['example']}”</i>"
                         + (f"<br>{row['example_tr']}" if row.get("example_tr") else "") + "</p>")
        if row["greek"] and self.langs.native_label:
            parts.append(f"<p>{flags.tag(self.langs.native, self.langs.native_label)}{row['greek']}</p>")
        if row["swedish"] and self.langs.second_label:
            parts.append(f"<p>{flags.tag(self.langs.second, self.langs.second_label)}{row['swedish']}</p>")
        if row["synonyms"]:
            parts.append(f"<p style='color:{TEXT_SECONDARY}'>Similar words: {row['synonyms']}</p>")
        if row.get("hook") and self.db.get_setting("show_hook", "1") != "0":
            hook = "<br>".join(line.strip() for line in row["hook"].splitlines() if line.strip())
            parts.append(f"<p style='color:{TEXT_SECONDARY};font-size:8pt;font-weight:700;margin-bottom:0'>"
                         f"MEMORY HOOK</p><p style='color:{ACCENT};margin-top:2px'>{hook}</p>")
        parts.append(
            f"<hr><p style='color:{TEXT_MUTED};font-size:9pt'>"
            + (f"Comes back every {row['interval']} day{'s' if row['interval'] != 1 else ''}<br>"
               f"Reviewed {row['repetitions']} time{'s' if row['repetitions'] != 1 else ''}<br>"
               f"Next: {(row['due_date'] or '')[:10]}</p>" if row['repetitions'] else
               "Not studied yet</p>")
        )
        self.detail_label.setText("".join(parts))

    # --------------------------------------------------------- context menu

    def show_context_menu(self, position):
        row = self._selected_row()
        if not row:
            return
        menu = QMenu(self)
        edit_action = menu.addAction("✏️  Edit word")
        reset_action = menu.addAction("🔄  Reset progress")
        menu.addSeparator()
        delete_action = menu.addAction("🗑️  Delete word")
        action = menu.exec(self.table.viewport().mapToGlobal(position))
        if action is edit_action:
            self.edit_word(row)
        elif action is reset_action:
            self.reset_word(row)
        elif action is delete_action:
            self.delete_word(row)

    def edit_selected(self):
        row = self._selected_row()
        if row:
            self.edit_word(row)

    def reset_selected(self):
        row = self._selected_row()
        if row:
            self.reset_word(row)

    def delete_selected(self):
        row = self._selected_row()
        if row:
            self.delete_word(row)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Delete and self._selected_row():
            self.delete_selected()
            return
        super().keyPressEvent(event)

    def edit_word(self, row):
        dialog = EditWordDialog(row, self.langs, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            values = dialog.values()
            if values["word"] and values["definition"]:
                self.db.update_word(row["id"], values)
                self.reload()

    def reset_word(self, row):
        confirm = QMessageBox.question(
            self, "Reset progress",
            f"Reset all learning progress for “{row['word']}”?",
        )
        if confirm == QMessageBox.StandardButton.Yes:
            self.db.reset_progress(row["id"])
            self.reload()
            self.main_window.update_status()

    def delete_word(self, row):
        confirm = QMessageBox.question(
            self, "Delete word",
            f"Permanently delete “{row['word']}” and its progress?",
        )
        if confirm == QMessageBox.StandardButton.Yes:
            self.db.delete_word(row["id"])
            self.reload()
            self.main_window.update_status()
            self.main_window.start_sync()          # the other computer drops it too

"""Input widgets that ignore the mouse wheel unless they have focus.

A page that scrolls is full of spin boxes and combos; a wheel that lands
on one while scrolling changes a setting — the daily budget, the language —
without anyone noticing. These only react to the wheel after a click.
"""

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QComboBox, QDoubleSpinBox, QSpinBox, QTimeEdit


class _NoWheelUnlessFocused:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def wheelEvent(self, event):
        if self.hasFocus():
            super().wheelEvent(event)
        else:
            event.ignore()          # let the page scroll instead


class SpinBox(_NoWheelUnlessFocused, QSpinBox):
    pass


class DoubleSpinBox(_NoWheelUnlessFocused, QDoubleSpinBox):
    pass


class ComboBox(_NoWheelUnlessFocused, QComboBox):
    pass


class TimeEdit(_NoWheelUnlessFocused, QTimeEdit):
    pass

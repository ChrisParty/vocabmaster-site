"""Dashboard: the "get started" checklist for a new deck, then stat cards,
mastery progress, streak, and the start buttons."""

from datetime import datetime

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QFrame, QGridLayout, QHBoxLayout, QLabel, QProgressBar, QPushButton,
    QVBoxLayout, QWidget,
)

import alphabets
import cloud
import images
import languages
from styles import ACCENT, SUCCESS, TEXT, TEXT_MUTED, TEXT_SECONDARY, WARNING, wrapping

MOTIVATION = [
    "Every review makes the memory stronger. 💪",
    "Consistency beats intensity — see you at the next review!",
    "Your future self will thank you for today's session. ✨",
    "Small daily steps, massive vocabulary. Keep going!",
]

STAT_TIPS = {
    "total": "Every word in your deck.",
    "due": "Cards the schedule wants you to see today — new ones and ones you are about to forget.",
    "mastered": "Words with an interval of 21 days or more: you know them.",
    "learning": "Seen at least once, not yet mastered.",
    "new": "Never studied. They enter at the daily limit set in Settings.",
}

# The three things a fresh deck needs, plus the optional fourth. Each step
# knows whether it is done and where its button leads.
STEPS = [
    ("languages", "Choose your languages",
     "What you are learning, and what to translate into.", "settings"),
    ("key", "Add your OpenAI key",
     "It writes the cards and draws the pictures — a few cents a day at most.", "settings"),
    ("words", "Get your first words",
     "A starter deck of the most useful words, or add one word at a time.", "import"),
    ("sync", "Optional: connect Google Drive",
     "Only if you use two computers. Your deck stays in your own Drive.", "settings"),
]


def _stat_card(title, color, tip):
    card = QFrame()
    card.setObjectName("statCard")
    card.setToolTip(tip)
    layout = QVBoxLayout(card)
    layout.setContentsMargins(18, 14, 18, 14)
    value = QLabel("0")
    value.setStyleSheet(f"font-size: 22pt; font-weight: 700; color: {color};")
    label = QLabel(title)
    label.setStyleSheet(f"color: {TEXT_SECONDARY};")
    layout.addWidget(value)
    layout.addWidget(label)
    return card, value


class DashboardScreen(QWidget):
    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(20)

        header = QLabel("Dashboard")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(header)

        # ------------------------------------------------- get started
        self.start_card = QFrame()
        self.start_card.setObjectName("card")
        start_layout = QVBoxLayout(self.start_card)
        start_layout.setContentsMargins(24, 18, 24, 18)
        start_layout.setSpacing(10)
        start_title = QLabel("Get started — three small steps")
        start_title.setStyleSheet("font-weight: 700; font-size: 13pt;")
        start_layout.addWidget(start_title)
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(8)
        grid.setColumnStretch(1, 1)
        self.step_widgets = {}
        for row, (key, title, hint, target) in enumerate(STEPS):
            mark = QLabel("○")
            mark.setStyleSheet(f"font-size: 15pt; color: {TEXT_MUTED};")
            mark.setFixedWidth(26)
            text = QLabel(f"<b>{title}</b><br><span style='color:{TEXT_SECONDARY}'>{hint}</span>")
            text.setTextFormat(Qt.TextFormat.RichText)
            wrapping(text)
            button = QPushButton("Open")
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setFixedWidth(110)
            button.clicked.connect(lambda _, t=target: self.main_window.navigate(t))
            grid.addWidget(mark, row, 0, Qt.AlignmentFlag.AlignTop)
            grid.addWidget(text, row, 1)
            grid.addWidget(button, row, 2, Qt.AlignmentFlag.AlignTop)
            self.step_widgets[key] = (mark, text, button)
        start_layout.addLayout(grid)
        layout.addWidget(self.start_card)

        # --------------------------------------------------- stat cards
        cards_row = QHBoxLayout()
        cards_row.setSpacing(14)
        self.stat_values = {}
        for key, title, color in [
            ("total", "Total Words", TEXT),
            ("due", "Due Today", WARNING),
            ("mastered", "Mastered", SUCCESS),
            ("learning", "Learning", ACCENT),
            ("new", "New / Unseen", TEXT_SECONDARY),
        ]:
            card, value = _stat_card(title, color, STAT_TIPS[key])
            self.stat_values[key] = value
            cards_row.addWidget(card)
        layout.addLayout(cards_row)
        caption = wrapping(QLabel(
            "Due: what the schedule wants today  ·  Mastered: interval of 21+ days  ·  "
            "Learning: seen, not yet mastered  ·  New: never studied, they enter at your "
            "daily limit"))
        caption.setStyleSheet(f"color: {TEXT_MUTED}; font-size: 9pt;")
        layout.addWidget(caption)

        # ----------------------------------------------- mastery + streak
        progress_card = QFrame()
        progress_card.setObjectName("card")
        progress_layout = QVBoxLayout(progress_card)
        progress_layout.setContentsMargins(20, 16, 20, 16)
        progress_layout.setSpacing(10)

        top_row = QHBoxLayout()
        self.mastery_label = QLabel("Mastery: 0%")
        self.mastery_label.setStyleSheet("font-weight: 600; font-size: 12pt;")
        self.mastery_label.setToolTip("Share of the deck with an interval of 21 days or more.")
        self.today_label = QLabel("")
        self.today_label.setStyleSheet(f"font-weight: 600; font-size: 12pt; color: {ACCENT};")
        self.today_label.setToolTip("Cards reviewed today against your daily goal (Settings).")
        self.streak_label = QLabel("🔥 0 day streak")
        self.streak_label.setStyleSheet(f"font-weight: 600; font-size: 12pt; color: {WARNING};")
        self.streak_label.setToolTip("Days in a row with at least one card reviewed. Skipping a day resets it.")
        top_row.addWidget(self.mastery_label)
        top_row.addStretch()
        top_row.addWidget(self.today_label)
        top_row.addSpacing(20)
        top_row.addWidget(self.streak_label)
        progress_layout.addLayout(top_row)

        self.mastery_bar = QProgressBar()
        self.mastery_bar.setFixedHeight(10)
        self.mastery_bar.setRange(0, 100)
        progress_layout.addWidget(self.mastery_bar)
        layout.addWidget(progress_card)

        # ------------------------------------------------- action buttons
        actions_row = QHBoxLayout()
        actions_row.setSpacing(14)

        self.review_button = QPushButton("📖  Start Flashcard Review")
        self.review_button.setObjectName("primary")
        self.review_button.setMinimumHeight(64)
        self.review_button.setStyleSheet("font-size: 13pt;")
        self.review_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.review_button.setToolTip(
            "See the word, recall the meaning, reveal, rate yourself. The app picks the cards.  (Ctrl+R)")
        self.review_button.clicked.connect(lambda: self.main_window.navigate("study"))

        self.quiz_button = QPushButton("❓  Multiple Choice Quiz")
        self.quiz_button.setObjectName("success")
        self.quiz_button.setMinimumHeight(64)
        self.quiz_button.setStyleSheet("font-size: 13pt;")
        self.quiz_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.quiz_button.setToolTip(
            "Pick the right answer out of four, then rate yourself. Practises random words when nothing is due.")
        self.quiz_button.clicked.connect(lambda: self.main_window.navigate("quiz"))

        actions_row.addWidget(self.review_button)
        actions_row.addWidget(self.quiz_button)
        layout.addLayout(actions_row)

        self.alphabet_tip = QPushButton("")
        self.alphabet_tip.setCursor(Qt.CursorShape.PointingHandCursor)
        self.alphabet_tip.setStyleSheet(
            f"text-align: left; padding: 12px 16px; color: {TEXT}; background: rgba(59,130,246,0.08);"
            f" border: 1px solid {ACCENT}; border-radius: 10px;")
        self.alphabet_tip.clicked.connect(lambda: self.main_window.navigate("alphabet"))
        self.alphabet_tip.hide()
        layout.addWidget(self.alphabet_tip)

        self.message_label = QLabel("")
        self.message_label.setStyleSheet(f"color: {TEXT_SECONDARY}; font-size: 11pt;")
        self.message_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wrapping(self.message_label)
        layout.addWidget(self.message_label)

        layout.addStretch()

    # ------------------------------------------------------------ refresh

    def _step_states(self):
        total = self.db.word_count()
        engine = images.ImageEngine(self.db.path)
        try:
            has_key = bool(engine.api_key())
        finally:
            engine.close()
        return {
            "languages": total > 0 or self.db.get_setting("lang_confirmed") == "1",
            "key": has_key,
            "words": total > 0,
            "sync": cloud.active_backend(self.db.get_setting) == "gdrive",
        }

    def refresh(self):
        counts = self.db.counts()
        for key, value in self.stat_values.items():
            value.setText(str(counts[key]))

        states = self._step_states()
        essentials_done = all(states[k] for k in ("languages", "key", "words"))
        self.start_card.setVisible(not essentials_done)
        if not essentials_done:
            langs = languages.load(self.db.get_setting)
            for key, (mark, text, button) in self.step_widgets.items():
                done = states[key]
                mark.setText("✓" if done else "○")
                mark.setStyleSheet(f"font-size: 15pt; color: {SUCCESS if done else TEXT_MUTED};")
                button.setText("Done" if done else "Open")
                button.setEnabled(not done)
                if key == "languages":
                    text.setText(
                        f"<b>Choose your languages</b><br><span style='color:{TEXT_SECONDARY}'>"
                        f"Now: {langs.describe()}. Change it in Settings if that is not right.</span>")

        total = counts["total"]
        pct = round(counts["mastered"] / total * 100) if total else 0
        self.mastery_label.setText(f"Mastery: {pct}%  ({counts['mastered']} of {total} words)")
        self.mastery_bar.setValue(pct)

        streak = self.db.current_streak()
        self.streak_label.setText(f"🔥 {streak} day streak")

        goal = self.db.get_int_setting("daily_goal", 20)
        reviewed = self.db.reviewed_today()
        check = " ✅" if reviewed >= goal else ""
        self.today_label.setText(f"Today: {reviewed} / {goal}{check}")

        due = counts["due"]
        self.review_button.setText(f"📖  Start Flashcard Review  ({due} due)")
        self.review_button.setEnabled(total > 0)
        self.quiz_button.setEnabled(total >= 4)

        langs = languages.load(self.db.get_setting)
        alphabet = alphabets.for_language(langs.target)
        self.alphabet_tip.setVisible(False)
        if alphabet is not None:
            letters = [s for _, group in alphabet["groups"] for s, _, _ in group]
            progress = self.db.alphabet_progress(langs.target)
            known = sum(1 for s in letters if progress.get(s, 0) >= 3)
            if known < len(letters):
                self.alphabet_tip.setText(
                    f"ㄱ  {alphabet['title'].split(' — ')[0]}: you know {known} of {len(letters)} "
                    f"letters. Ten minutes in Alphabet makes every card easier — click here.")
                self.alphabet_tip.setVisible(True)
        if total == 0:
            self.message_label.setText("")
        elif due == 0:
            message = self._next_review_message()
            index = datetime.now().day % len(MOTIVATION)
            self.message_label.setText(f"✅ All caught up! {message}  {MOTIVATION[index]}")
        else:
            self.message_label.setText("")

    def _next_review_message(self):
        next_due = self.db.next_due_datetime()
        if not next_due:
            return ""
        delta = next_due - datetime.now()
        hours = max(1, round(delta.total_seconds() / 3600))
        if hours < 24:
            return f"Next review in ~{hours} hour{'s' if hours != 1 else ''}."
        days = round(hours / 24)
        return f"Next review in ~{days} day{'s' if days != 1 else ''}."

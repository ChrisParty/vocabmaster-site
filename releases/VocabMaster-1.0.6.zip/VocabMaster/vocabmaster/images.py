"""Card illustrations — generated on a hard daily budget.

Cost safety architecture. The rule is that the daily cap can never be
exceeded, not that it is usually respected:

  known price   every image costs a fixed, published number of output
                tokens for its quality and size, so the price of the NEXT
                call is known exactly before making it — never estimated.
  debit first   the ledger row is written BEFORE the request goes out, so
                a crash mid-call leaves money debited rather than silently
                spent. Calls that produce nothing are refunded.
  one gate      every call goes through _debit(), which re-reads today's
                total under a lock. Two threads cannot both pass on the
                same remaining cent.

Images are files in images/, never BLOBs: database.py copies the whole db
daily and keeps 7, and sync.py pushes append-only JSON logs — a blob would
be duplicated into both, forever.

The model draws the scene only. Callout text is stored separately and
painted by Qt (ui/image_card.py), because image models misspell baked-in
text, and a card that teaches a misspelling is worse than one with no
picture at all.
"""

import base64
import json
import os
import sqlite3
import urllib.request
from datetime import datetime, timezone

import ledger
from ledger import BudgetExhausted, Ledger   # re-exported: images.BudgetExhausted

IMAGES_URL = "https://api.openai.com/v1/images/generations"
CHAT_URL = "https://api.openai.com/v1/chat/completions"

IMAGE_MODEL = "gpt-image-1-mini"
PLAN_MODEL = "gpt-4o-mini"
QUALITY = "medium"
SIZE = "1024x1024"

# USD per 1M tokens, from OpenAI's published pricing.
OUTPUT_RATE = {"gpt-image-1-mini": 8.00, "gpt-image-1.5": 32.00, "gpt-image-1": 40.00}
INPUT_RATE = {"gpt-image-1-mini": 2.00, "gpt-image-1.5": 5.00, "gpt-image-1": 5.00}
PLAN_IN_RATE, PLAN_OUT_RATE = 0.15, 0.60

# Images are metered as a FIXED output-token count per quality — this is what
# makes the pre-flight gate exact instead of a guess.
IMAGE_TOKENS = {"low": 272, "medium": 1056, "high": 4160}
TALL_MULTIPLIER = 1.5          # 1024x1536 / 1536x1024 cost ~1.5x

DEFAULT_CAP = 0.10             # USD per day
PROMPT_TOKEN_ALLOWANCE = 160   # short briefs only; charged at the input rate

PLAN_BATCH = 5
CALLOUT_MAX = 45

SYSTEM = """You write image briefs for vocabulary flashcards. Return JSON:
{"items":[{"word":str,"skip":bool,"prompt":str,"callouts":[str]}]}

The picture must make the MEANING obvious to someone who does not know the
word. A pretty object merely associated with the word is a failure. Pick the
moment that demonstrates the concept:
  saturated -> a sponge so full that water runs off it onto the counter
  brittle   -> a dry twig snapped clean in two between two fingers

prompt: ONE photographic scene, max 40 words. Literal, everyday, one clear
subject, plain uncluttered background, bright even lighting. Describe what is
HAPPENING, not colours, mood or style. It MUST contain no text, letters,
numbers, signs, labels or writing of any kind.
callouts: 1-2 phrases, max 45 characters, each saying what the scene shows
about the MEANING ("It cannot hold any more"), never how it looks ("bright
red tomato"). Plain sentences, no markdown, no quotes.
skip: true only when no photograph could show the meaning (abstract
connectives, grammatical words); then prompt is "" and callouts is []."""


SCHEMA = """
CREATE TABLE IF NOT EXISTS word_images (
    word_id TEXT PRIMARY KEY,
    filename TEXT,
    prompt TEXT,
    callouts TEXT,
    model TEXT,
    quality TEXT,
    status TEXT,
    created_at TEXT,
    updated_at TEXT,      -- travels in the sync log; most recent wins
    synced_at TEXT        -- when the picture itself reached the cloud
);
"""


def ensure_schema(conn, db_path):
    """Idempotent; called by both Database and ImageEngine so whichever
    connection opens first, the tables are there."""
    conn.executescript(SCHEMA)
    conn.executescript(ledger.SCHEMA)
    # Additive, for tables created before image sync existed.
    columns = {row[1] for row in conn.execute("PRAGMA table_info(word_images)")}
    for column in ("updated_at", "synced_at"):
        if column not in columns:
            conn.execute(f"ALTER TABLE word_images ADD COLUMN {column} TEXT")
    conn.execute("UPDATE word_images SET updated_at=COALESCE(created_at, ?) "
                 "WHERE updated_at IS NULL", (_stamp(),))
    conn.commit()
    os.makedirs(images_dir(db_path), exist_ok=True)


def image_cost(model=IMAGE_MODEL, quality=QUALITY, size=SIZE):
    """Exact USD for one image, known before the call is made."""
    tokens = IMAGE_TOKENS[quality]
    if size != "1024x1024":
        tokens = int(tokens * TALL_MULTIPLIER)
    out = tokens * OUTPUT_RATE[model] / 1e6
    prompt_in = PROMPT_TOKEN_ALLOWANCE * INPUT_RATE[model] / 1e6
    return out + prompt_in


def images_dir(db_path):
    return os.path.join(os.path.dirname(os.path.abspath(db_path)), "images")


def image_file(db_path, word_id):
    """Absolute path to a word's illustration, or None if it has none."""
    path = os.path.join(images_dir(db_path), f"{word_id}.webp")
    return path if os.path.exists(path) else None


def _today():
    return datetime.now().strftime("%Y-%m-%d")


def _stamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def utc_stamp():
    """Same shape as database.utc_stamp and sync.utcnow, so the sync layer's
    'most recent wins' comparison works across all three tables."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


class ImageEngine:
    """Owns its own sqlite connection so it can run off the UI thread,
    matching the pattern SyncEngine uses."""

    def __init__(self, db_path):
        self.path = db_path
        # Autocommit (ledger.open_connection), so the gate can hold its own
        # IMMEDIATE transaction. Every other statement commits itself.
        self.conn = ledger.open_connection(db_path)
        self.ensure_schema()
        self.ledger = Ledger(self.conn, "image_daily_cap", DEFAULT_CAP, ("image", "plan"))

    def close(self):
        self.conn.close()

    def ensure_schema(self):
        ensure_schema(self.conn, self.path)

    # ------------------------------------------------------------- settings

    def setting(self, key, default=None):
        row = self.conn.execute(
            "SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row and row["value"] not in (None, "") else default

    def cap(self):
        return self.ledger.cap()

    def quality(self):
        q = self.setting("image_quality", QUALITY)
        return q if q in IMAGE_TOKENS else QUALITY

    def model(self):
        m = self.setting("image_model", IMAGE_MODEL)
        return m if m in OUTPUT_RATE else IMAGE_MODEL

    def api_key(self):
        """Vocabmaster's own key if set, else the shared ecosystem key that
        tools/enrich_deck.py already reads from Lexi."""
        own = self.setting("openai_api_key")
        if own:
            return own
        lexi = os.path.join(os.environ.get("APPDATA", ""), "Lexi", "lexi.db")
        if not os.path.exists(lexi):
            return None
        try:
            conn = sqlite3.connect(f"file:{lexi}?mode=ro", uri=True, timeout=3)
            row = conn.execute(
                "SELECT value FROM settings WHERE key='api_key'").fetchone()
            conn.close()
            return row[0] if row and row[0] else None
        except sqlite3.Error:
            return None

    # --------------------------------------------------------------- budget

    def spent_today(self):
        return self.ledger.spent_today()

    def remaining_today(self):
        return self.ledger.remaining_today()

    def affordable_images(self):
        """How many more images today's remaining budget allows."""
        each = image_cost(self.model(), self.quality(), SIZE)
        return int(self.remaining_today() // each) if each > 0 else 0

    # The gate itself lives in ledger.py (shared with AI-written cards).
    def _debit(self, word_id, kind, cost, model):
        return self.ledger.debit(word_id, kind, cost, model)

    def _settle(self, ledger_id, status, usage=None, cost=None):
        self.ledger.settle(ledger_id, status, usage, cost)

    def _refund(self, ledger_id, reason):
        self.ledger.refund(ledger_id, reason)

    # ------------------------------------------------------------------ http

    def _post(self, url, payload, key, timeout=180):
        body = json.dumps(payload).encode()
        request = urllib.request.Request(
            url, data=body,
            headers={"Content-Type": "application/json",
                     "Authorization": f"Bearer {key}"})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode())

    # -------------------------------------------------------------- planning

    def plan(self, words, key):
        """One short batched call that turns words into image briefs."""
        payload = {
            "model": PLAN_MODEL,
            "messages": [
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": json.dumps(
                    [{"word": w["word"], "pos": w["pos"] or "",
                      "definition": w["definition"]} for w in words],
                    ensure_ascii=False)},
            ],
            "temperature": 0.5,
            "response_format": {"type": "json_object"},
        }
        estimate = (400 * len(words) * PLAN_IN_RATE
                    + 120 * len(words) * PLAN_OUT_RATE) / 1e6
        ledger_id = self._debit(None, "plan", estimate, PLAN_MODEL)
        try:
            data = self._post(CHAT_URL, payload, key, timeout=90)
        except Exception as exc:
            self._refund(ledger_id, "failed")
            raise RuntimeError(f"planning call failed: {exc}") from exc
        usage = data.get("usage", {})
        actual = (usage.get("prompt_tokens", 0) * PLAN_IN_RATE
                  + usage.get("completion_tokens", 0) * PLAN_OUT_RATE) / 1e6
        self._settle(ledger_id, "ok", usage, cost=actual)
        items = json.loads(
            data["choices"][0]["message"]["content"]).get("items", [])
        return {(i.get("word") or "").strip().lower(): i for i in items}

    def save_plan(self, word_id, brief):
        callouts = [str(c).strip()[:CALLOUT_MAX]
                    for c in (brief.get("callouts") or []) if str(c).strip()][:2]
        # REPLACE rewrites the whole row, so carry over what belongs to the
        # picture rather than to the brief — otherwise re-planning a word
        # would forget that its image is already in the cloud.
        existing = self.conn.execute(
            "SELECT filename, synced_at FROM word_images WHERE word_id=?",
            (word_id,)).fetchone()
        self.conn.execute(
            "INSERT OR REPLACE INTO word_images (word_id, filename, prompt, "
            "callouts, model, quality, status, created_at, updated_at, "
            "synced_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (word_id, existing["filename"] if existing else None,
             (brief.get("prompt") or "").strip(),
             json.dumps(callouts, ensure_ascii=False), self.model(),
             self.quality(), "skipped" if brief.get("skip") else "planned",
             _stamp(), utc_stamp(),
             existing["synced_at"] if existing else None))
        self.conn.commit()

    # --------------------------------------------------------------- drawing

    def draw(self, word_id, prompt, key):
        """Generate and store one illustration. Debits before it spends."""
        model, quality = self.model(), self.quality()
        cost = image_cost(model, quality, SIZE)
        ledger_id = self._debit(word_id, "image", cost, model)
        payload = {"model": model, "prompt": prompt, "size": SIZE,
                   "quality": quality, "n": 1,
                   "output_format": "webp", "output_compression": 80}
        try:
            data = self._post(IMAGES_URL, payload, key)
            encoded = data["data"][0]["b64_json"]
        except Exception as exc:
            self._refund(ledger_id, "failed")
            raise RuntimeError(f"image call failed: {exc}") from exc

        target = os.path.join(images_dir(self.path), f"{word_id}.webp")
        partial = target + ".part"
        with open(partial, "wb") as handle:
            handle.write(base64.b64decode(encoded))
        os.replace(partial, target)      # never leave a half-written image

        self._settle(ledger_id, "ok", data.get("usage"))
        # synced_at back to NULL: a freshly drawn picture still owes the cloud.
        self.conn.execute(
            "UPDATE word_images SET filename=?, status='ok', model=?, "
            "quality=?, updated_at=?, synced_at=NULL WHERE word_id=?",
            (f"{word_id}.webp", model, quality, utc_stamp(), word_id))
        self.conn.commit()
        return target

    # ------------------------------------------------------------ the cycle

    def candidates(self, word_ids):
        """Words from the given ids that have no image and were not skipped."""
        if not word_ids:
            return []
        marks = ",".join("?" * len(word_ids))
        return [dict(row) for row in self.conn.execute(
            f"SELECT w.id, w.word, w.definition, w.pos FROM words w "
            f"LEFT JOIN word_images i ON i.word_id = w.id "
            f"WHERE w.id IN ({marks}) "
            f"AND (i.word_id IS NULL OR (i.filename IS NULL "
            f"     AND i.status NOT IN ('skipped', 'failed'))) "
            f"ORDER BY w.rowid", word_ids)]

    def brief_for(self, word, key):
        """The stored brief for one word, planning it if we have none."""
        row = self.conn.execute(
            "SELECT prompt, status FROM word_images WHERE word_id=?",
            (word["id"],)).fetchone()
        if row and row["status"] == "skipped":
            return None
        if row and (row["prompt"] or "").strip():
            return row["prompt"]
        brief = self.plan([word], key).get(word["word"].strip().lower())
        if not brief:
            return None
        self.save_plan(word["id"], brief)
        return None if brief.get("skip") else (brief.get("prompt") or "").strip()

    def generate_for(self, word, key=None):
        """Plan (if needed) and draw one word. Returns the file path, or None
        when no photograph could show the meaning."""
        if has_picture(self.conn, word["id"]):
            return image_file(self.path, word["id"])   # already bought
        key = key or self.api_key()
        if not key:
            raise RuntimeError("no OpenAI API key available")
        prompt = self.brief_for(word, key)
        if not prompt:
            return None
        return self.draw(word["id"], prompt, key)

    def top_up(self, word_ids, limit=None):
        """Fill in missing images for the given words, stopping at the cap.
        Returns (generated, skipped, reason)."""
        key = self.api_key()
        if not key:
            return 0, 0, "no OpenAI API key"
        todo = self.candidates(word_ids)
        if not todo:
            return 0, 0, "every due word already has an image"
        budget_allows = self.affordable_images()
        if limit is not None:
            budget_allows = min(budget_allows, limit)
        if budget_allows <= 0:
            return 0, 0, f"daily cap ${self.cap():.2f} reached"

        # Only consider as many words as today's budget could actually draw.
        # Planning every due word to draw eleven of them spends the budget on
        # briefs instead of pictures — with a backlog of a thousand cards that
        # is most of the day's money gone before a single image is made.
        # Doubled, so words that turn out to be unpicturable still leave room
        # to reach the cap.
        working = todo[:budget_allows * 2 + PLAN_BATCH]

        # Plan first: skipped words cost nothing to draw, so knowing about
        # them early keeps the budget for the words that can use it.
        unplanned = [w for w in working if not self.conn.execute(
            "SELECT 1 FROM word_images WHERE word_id=? AND prompt IS NOT NULL "
            "AND prompt != ''", (w["id"],)).fetchone()]
        for start in range(0, len(unplanned), PLAN_BATCH):
            batch = unplanned[start:start + PLAN_BATCH]
            try:
                briefs = self.plan(batch, key)
            except (RuntimeError, BudgetExhausted):
                break
            for word in batch:
                brief = briefs.get(word["word"].strip().lower())
                if brief:
                    self.save_plan(word["id"], brief)

        generated = skipped = 0
        for word in working:
            if generated >= budget_allows:
                break
            row = self.conn.execute(
                "SELECT prompt, status FROM word_images WHERE word_id=?",
                (word["id"],)).fetchone()
            if (not row or row["status"] == "skipped"
                    or not (row["prompt"] or "").strip()):
                skipped += 1
                continue
            try:
                self.draw(word["id"], row["prompt"], key)
                generated += 1
            except BudgetExhausted:
                break
            except RuntimeError:
                skipped += 1
        return generated, skipped, None

    def due_today_ids(self):
        """Words the user will actually meet today, new ones first — a brand
        new word is the one a picture helps most."""
        today_end = datetime.now().strftime("%Y-%m-%d 23:59:59")
        return [row[0] for row in self.conn.execute(
            "SELECT w.id FROM words w JOIN progress p ON p.word_id = w.id "
            "WHERE p.due_date <= ? "
            "ORDER BY (p.repetitions = 0) DESC, p.due_date",
            (today_end,))]

    def top_up_due(self, limit=None):
        """What the app calls at startup: fill today's words, stop at the cap."""
        return self.top_up(self.due_today_ids(), limit=limit)

    # ---------------------------------------------------------------- report

    def summary(self):
        return {
            "spent_today": self.spent_today(),
            "cap": self.cap(),
            "remaining": self.remaining_today(),
            "affordable": self.affordable_images(),
            "lifetime": self.ledger.spent_total(),
            "images": self.conn.execute(
                "SELECT COUNT(*) FROM word_images "
                "WHERE filename IS NOT NULL").fetchone()[0],
            "skipped": self.conn.execute(
                "SELECT COUNT(*) FROM word_images "
                "WHERE status='skipped'").fetchone()[0],
            "words": self.conn.execute("SELECT COUNT(*) FROM words").fetchone()[0],
            "each": image_cost(self.model(), self.quality()),
        }


def has_picture(conn, word_id):
    """True when a picture for this word exists ANYWHERE — on this disk, or
    in the cloud still on its way down. The filesystem alone is not enough:
    a second device syncs the brief before the bytes arrive, and treating
    that gap as 'no picture' is how you pay for the same image twice."""
    row = conn.execute(
        "SELECT filename FROM word_images WHERE word_id=?", (word_id,)).fetchone()
    return bool(row and row["filename"])


def load_callouts(conn, word_id):
    row = conn.execute(
        "SELECT callouts FROM word_images WHERE word_id=?", (word_id,)).fetchone()
    if not row or not row[0]:
        return []
    try:
        return json.loads(row[0])
    except (TypeError, ValueError):
        return []

# 🎓 VocabMaster

A beautiful, fully offline desktop app for mastering vocabulary with **spaced repetition** (the SM-2 algorithm — the same science behind Anki). Import your word list straight from Google Sheets and study with flashcards or multiple-choice quizzes.

## Installation

Requires **Python 3.11+**.

```bash
pip install PyQt6
```

That's the only dependency — SQLite is built into Python.

## Running

**Windows:** double-click the **VocabMaster** shortcut on the Desktop, or run:

```bash
cd vocabmaster
python main.py
```

**Mac:** clone the repo, double-click `setup-mac.command` once (it creates a
private Python environment with PyQt6 and puts **VocabMaster.app** on the
Desktop), then open the app. Pronunciation uses the Mac's built-in voice.

Your data lives in your user folder — Windows `%APPDATA%\VocabMaster`, Mac `~/Library/Application Support/VocabMaster` (Settings → *Open folder*). A backup copy is saved there automatically once per day (the last 7 are kept), and updating the app never touches it. Studying never needs the internet; two optional features use it — card pictures (OpenAI, hard-capped spend) and cloud sync (off until configured).

## Keeping two computers in step (cloud sync)

Settings → **Cloud sync → Connect Google Drive…** signs you in with Google;
the deck is mirrored into a hidden folder of *your own* Drive that only this
app can see. Do the same on the other computer with the same account and
they stay in step — after every study session, every 10 minutes, and when
the app closes. For every card the most recently studied version wins, so
nothing done on either side is lost. The one-time Google registration is in
[docs/GOOGLE-DRIVE-SETUP.md](../docs/GOOGLE-DRIVE-SETUP.md).

## Moving to another computer

Settings → **Export everything (.zip)** packs the whole deck — words, progress,
pictures, settings and keys — into one file. On the other machine, **Restore
from a backup…** (Settings, or the Import screen on a fresh install) replaces
whatever is there with it, keeps the old database in `backups/pre-restore-*.db`,
and restarts the app. The file contains your keys: move it privately and
delete it afterwards.

While open, the app also serves a tiny status API on `127.0.0.1:7843` (`/health` and `/api/today`) so the Hub dashboard (`Desktop\Hub`) can show whether it's running and how many words are due — see `hub_server.py` and the convention in `Desktop\Hub\STANDARD.md`.

## Languages

Settings → **Languages**: pick what you are learning (English, Swedish,
Greek, Korean or Japanese), the language definitions are written in, and up to two
languages every card is translated into. Labels on the cards and what the
AI writes follow from this; existing cards keep their text.

## Learning the alphabet

For Korean, Japanese or Greek the menu shows **Alphabet**: a one-minute
explanation, a practice drill (unknown letters first; three right answers in
a row and a letter is yours; Hangul syllable blocks join once the letters are
known) and the full chart. On any card, **A** opens the chart beside it.

## Getting words

- **Import → Build a starter deck**: the 100–2,000 most common words of your
  language for a beginner / intermediate / advanced learner. The AI writes a
  full card for each (definition, translations, example, memory hook) in
  batches of 20, saving as it goes — about **$0.60 per 1,000 words** on your
  own OpenAI key with the default model (gpt-6-luna), never more than the
  daily AI budget in Settings ($1.00 by default). Settings shows what the AI
  has cost today, this month and all time. Stop any time; Generate again continues.
- **Import → Add one word**: type a word, get its card.
- Cards for languages in another script carry a **reading** (si-won-ha-da) under the word, and every example sentence its **translation** — a beginner is never shown text they cannot read. Older cards get these from **Complete your existing cards**.
- **Settings → Start over** deletes every word (settings, key, languages,
  sentences and streak stay; the old deck and its pictures are set aside in
  the backups folder) — for replacing cards made by an older version.
- **Settings → Memory hook** hides the hook block on cards, tree, quiz and
  Browse; the cards keep their hooks.

## Sentences

**Sentences** in the menu is a phrasebook beside the deck: the 20–200 most
useful everyday sentences of the language you learn, each with its reading,
its meaning and the meaning of every piece. Space shows the meaning, K marks
it learned, N shows it again later; the list marks ✓ learned, ◐ seen, ○ new
and opens any of them again. Written by the AI on the same key and daily
budget as the cards (about a cent for 50). Deliberately separate: sentences
never change the streak, goal, due count or stats. They sync like the cards.
- **Paste a spreadsheet instead…** (collapsed at the bottom): tab- or
  comma-separated text with a header row, or a dropped `.csv`. Duplicates
  are skipped; existing progress is never lost unless you choose *Replace all*.

## Updates

The app checks for a newer version at startup and offers **Update & restart**; only the code is replaced. To publish one: bump `vocabmaster/version.py`, commit, `python tools/publish_release.py "what changed"`.

## Giving it to a friend

`python tools/make_release.py` builds a zip; [docs/GIVE-TO-A-FRIEND.md](../docs/GIVE-TO-A-FRIEND.md) has their five steps (Python, setup script, languages + key, starter deck, optional Drive sync).

## How studying works

- **Study (flashcards)** — see the word, recall the meaning, press Space to reveal, then rate yourself:
  - **Again** (1) — you blanked; the card comes back later in this session and again tomorrow
  - **Hard** (2) — you struggled; short interval
  - **Good** (3) — solid recall; interval grows
  - **Easy** (4) — instant recall; interval grows fast
- **Quiz (multiple choice)** — pick the right definition out of 4 options, then rate yourself the same way.

Each card gets its own schedule. Words with an interval of **21+ days count as Mastered**. Review what's due every day and the app handles the rest.

## Card pictures

Words can carry an illustration, shown on the back of the card with one or
two labels pointing into it. A picture reaches the meaning faster than a
definition does, so the deck fills itself in gradually: on startup the app
quietly draws pictures for the words due today, and `I` (or the **Image**
button) draws one for the word in front of you right now.

**Spending is capped and cannot run away.** Set the daily budget in
Settings — $0.10 by default, which buys 11 pictures a day. The cost of each
picture is known exactly before it is requested, and it is written to a
ledger *before* the request goes out, so the cap is a gate rather than a
hope. Set the budget to **$0.00** to switch generation off entirely.

At the default settings a picture costs about **$0.0088**, so illustrating
all 1,600-odd words works out to roughly **$14 once**, spread over as many
days as you like. Settings shows what has been spent today and in total.

The model draws the scene only — never the text. Labels are stored as data
and drawn by the app, because image models misspell words, and a misspelt
headword on a flashcard teaches the wrong thing. Words no photograph can
show (grammatical words, abstract connectives) are detected and skipped
before any image is paid for.

Pictures are WebP files in `images/`, about 50 KB each, kept out of the
database so the daily backup stays small.

## Keyboard shortcuts

| Shortcut | Action |
|---|---|
| `Space` | Show answer (flashcards) |
| `P` | Pronounce the word (flashcards) |
| `T` | Toggle the word-tree view |
| `I` | Draw a picture for this word |
| `1` `2` `3` `4` | Rate card / choose quiz answer |
| `Ctrl+I` | Import screen |
| `Ctrl+R` | Start review |
| `Ctrl+Q` | Quit |
| `Esc` | Back to dashboard |

## Screens

- **Dashboard** — due counts, mastery %, streak, quick-start buttons
- **Study** — flashcard review of due cards
- **Quiz** — multiple-choice mode (practices random words when nothing is due)
- **Browse** — search, filter, edit, delete, or reset any word
- **Stats** — 30-day review chart, GitHub-style activity calendar, upcoming due load
- **Settings** — session size, new-cards-per-day limit, languages, OpenAI key and budgets, font size, move between computers, cloud sync, CSV export

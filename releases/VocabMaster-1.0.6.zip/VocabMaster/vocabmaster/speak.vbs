' Speaks the first argument with the built-in Windows voice (offline).
' The optional second argument is a language id (hex LCID, e.g. 412 for
' Korean): when a voice for that language is installed it is used, otherwise
' the default voice reads the text as best it can.
If WScript.Arguments.Count > 0 Then
    Set voice = CreateObject("SAPI.SpVoice")
    If WScript.Arguments.Count > 1 Then
        Set voices = voice.GetVoices("Language=" & WScript.Arguments(1))
        If voices.Count > 0 Then Set voice.Voice = voices.Item(0)
    End If
    voice.Speak WScript.Arguments(0)
End If

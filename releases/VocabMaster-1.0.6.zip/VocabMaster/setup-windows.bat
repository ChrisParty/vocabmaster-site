@echo off
rem VocabMaster - one-shot Windows setup. Double-click this file.
rem Gives the app a private Python environment with PyQt6 and puts a
rem VocabMaster shortcut on the Desktop. Safe to run again.
rem Needs Python 3.11+ from https://www.python.org/downloads/windows/
rem (tick "Add python.exe to PATH" in the installer).
setlocal
cd /d "%~dp0"

set "PY="
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>nul && set "PY=python"
if not defined PY (
  echo Python 3.11 or newer was not found.
  echo Install it from https://www.python.org/downloads/windows/ - tick "Add python.exe to PATH" - then run this again.
  pause
  exit /b 1
)
echo Using: & %PY% --version

echo Creating the app's private environment (.venv) and installing PyQt6...
if not exist ".venv\Scripts\python.exe" %PY% -m venv .venv
".venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
".venv\Scripts\python.exe" -m pip install --quiet "PyQt6>=6.6"
".venv\Scripts\python.exe" -c "import PyQt6.QtCore as q; print('PyQt6', q.PYQT_VERSION_STR, 'ready')" || (echo PyQt6 failed to install. & pause & exit /b 1)

echo Creating the Desktop shortcut...
rem Full path: some shells (and some locked-down PCs) lack it on PATH.
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
rem An optional first argument puts the shortcut elsewhere (used by tests).
set "DESK=%~1"
rem usebackq, and %PS% unquoted (its path has no spaces): cmd strips the
rem outer quotes of a command that starts with one, which broke this line.
if not defined DESK for /f "usebackq delims=" %%d in (`%PS% -NoProfile -Command "[Environment]::GetFolderPath([Environment+SpecialFolder]::Desktop)"`) do set "DESK=%%d"
if not defined DESK set "DESK=%USERPROFILE%\Desktop"
"%PS%" -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d='%DESK%';" ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\VocabMaster.lnk');" ^
  "$s.TargetPath='%CD%\.venv\Scripts\pythonw.exe';" ^
  "$s.Arguments='\"%CD%\vocabmaster\main.py\"';" ^
  "$s.WorkingDirectory='%CD%\vocabmaster';" ^
  "$s.IconLocation='%CD%\vocabmaster\vocabmaster.ico,0';" ^
  "$s.Save()"

echo.
echo Done. Open VocabMaster from the Desktop shortcut.
echo First time: Settings - Languages, your OpenAI key, then Import - Build a starter deck.
echo Your data lives in %CD%\vocabmaster\vocabmaster.db
pause

"""How a card's word is shown: the headline and the small line under it.

Every language: the word as the headline, its reading (if any) under it —
exactly what the cards always showed.

Japanese adds one choice (Settings -> Languages -> Japanese words), because
a learner who reads only kana cannot read 友達 yet:
  kana first  (default)  ともだち     with  友達 · tomodachi  under it
  kanji first            友達         with  ともだち · tomodachi  under it
A word already written in kana (おいしい) looks the same either way.
Nothing here changes what is stored; it is display only.
"""


def _get(card, key):
    try:
        return (card[key] or "").strip()
    except (KeyError, IndexError, TypeError):
        return ""


def split_reading(reading):
    """'ともだち · tomodachi' -> ('ともだち', 'tomodachi'); 'mizu' -> ('', 'mizu')."""
    if "·" in (reading or ""):
        kana, _, latin = (part.strip() for part in reading.partition("·"))
        return kana, latin
    return "", (reading or "").strip()


def kana_first(target, get_setting):
    return ((target or "").strip().lower() == "japanese"
            and (get_setting("ja_words", "kana") or "kana") != "kanji")


def headline(card, target, get_setting):
    """(headline, the line under it) for this card."""
    word, reading = _get(card, "word"), _get(card, "reading")
    if not kana_first(target, get_setting):
        return word, reading
    kana, latin = split_reading(reading)
    if not kana or kana == word:
        return word, reading
    return kana, " · ".join(part for part in (word, latin) if part)


def one_line(card, target, get_setting):
    """Headline plus reading on one line — for quiz answers and lists:
    '友達  (ともだち · tomodachi)', or the plain word when it has no reading."""
    head, under = headline(card, target, get_setting)
    return f"{head}  ({under})" if under else head


def for_display(card, target, get_setting):
    """A copy of the card whose word / reading are the displayed ones (for
    the word map, which draws card['word'] and card['reading'] itself)."""
    head, under = headline(card, target, get_setting)
    shown = dict(card)
    shown["word"], shown["reading"] = head, under
    return shown

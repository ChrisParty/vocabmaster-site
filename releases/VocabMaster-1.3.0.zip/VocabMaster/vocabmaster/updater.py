"""In-app updates, without a server of our own.

tools/publish_release.py puts two things on the public GitHub Pages site:
`latest.json` ({"version", "url", "notes", "published"}) and the zip it
points to. At startup the app reads latest.json; a newer version shows a
banner. "Update & restart" downloads the zip, checks it is a VocabMaster
release, and copies its files over the installed code. Data never lives in
the install folder (paths.py), and .venv is never touched, so an update
cannot lose anything; a half-written file is impossible because every file
is written next to its target and renamed into place.
"""

import json
import os
import shutil
import tempfile
import urllib.request
import zipfile

import paths
from version import VERSION

LATEST_URL = "https://chrisparty.github.io/vocabmaster-site/latest.json"
KEEP = (".venv",)              # never overwritten by an update


def parse(version):
    try:
        return tuple(int(part) for part in version.strip().split("."))
    except ValueError:
        return (0,)


def check(timeout=10):
    """The latest release if it is newer than this one, else None. Any
    network trouble is None too: an update check must never bother anyone."""
    try:
        with urllib.request.urlopen(LATEST_URL, timeout=timeout) as response:
            info = json.loads(response.read().decode())
    except Exception:
        return None
    if parse(info.get("version", "0")) > parse(VERSION):
        return info
    return None


def _release_root(bundle):
    """The top folder inside the zip that holds vocabmaster/main.py."""
    for name in bundle.namelist():
        parts = name.split("/")
        if len(parts) == 3 and parts[1] == "vocabmaster" and parts[2] == "main.py":
            return parts[0]
    raise ValueError("that zip is not a VocabMaster release")


def apply(info, progress=None):
    """Download and install. Returns the new version string. Raises on any
    problem, with the installed copy untouched up to the first file write
    and consistent per file after it."""
    url = info["url"]
    handle, archive = tempfile.mkstemp(suffix=".zip")
    os.close(handle)
    try:
        if progress:
            progress("downloading…")
        with urllib.request.urlopen(url, timeout=60) as response, open(archive, "wb") as out:
            shutil.copyfileobj(response, out)
        with zipfile.ZipFile(archive) as bundle:
            root = _release_root(bundle)
            if parse(info["version"]) <= parse(VERSION):
                raise ValueError("that release is not newer than this one")
            staging = tempfile.mkdtemp(prefix="vocabmaster-update-")
            bundle.extractall(staging)
        if progress:
            progress("installing…")
        source = os.path.join(staging, root)
        target = paths.install_root()
        for folder, _dirs, files in os.walk(source):
            rel = os.path.relpath(folder, source)
            if rel.split(os.sep)[0] in KEEP:
                continue
            dest_dir = os.path.join(target, rel) if rel != "." else target
            os.makedirs(dest_dir, exist_ok=True)
            for name in files:
                src = os.path.join(folder, name)
                dst = os.path.join(dest_dir, name)
                shutil.copyfile(src, dst + ".part")
                shutil.copymode(src, dst + ".part")
                os.replace(dst + ".part", dst)
        shutil.rmtree(staging, ignore_errors=True)
        return info["version"]
    finally:
        try:
            os.remove(archive)
        except OSError:
            pass

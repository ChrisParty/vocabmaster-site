"""Practice with the words you know: a short story, a guided conversation,
and the word doctor for words that keep slipping.

All three run on the learner's own OpenAI key through cards_ai.CardWriter's
one spending gate (kinds "story", "talk", "doctor" — the same daily AI-text
cap as cards and sentences, $0.50 by default), only when the learner presses a button, and
every field that comes back is language-checked like the cards: a line in
the learning language must be in its script, carry a reading where the
script needs one, and a translation; explanations must be in the learner's
language. Nothing here changes the cards' schedule, sessions, streak or
stats.

Stories are kept on this computer (table `stories`, not synced — cheap to
write again). A rescue from the word doctor is stored on the card itself
(`words.rescue`, JSON) and syncs with it.
"""

import json
import re
import uuid
from datetime import datetime

import cards_ai
import database
import languages

STUCK_LAPSES = 3          # rated Again this often -> the word doctor offers help
STUCK_EASE = 1.7          # or an ease this low (older cards had no lapse count)
STORIES_PER_DAY = 3       # a soft limit on top of the daily AI budget
TALK_TURNS = 12           # the learner's turns in one conversation
LEVELS = ("beginner", "intermediate", "advanced")

SCENES = [
    ("At a café", "ordering a drink and something to eat at a café"),
    ("In a shop", "buying something in a small shop and asking the price"),
    ("Meeting someone", "meeting a friendly new neighbour for the first time"),
    ("Asking the way", "asking a stranger the way to the station"),
    ("At the doctor", "telling a doctor what hurts"),
    ("At a hotel", "checking in at a small hotel"),
    ("Small talk", "chatting with a colleague about the weekend"),
]


# ------------------------------------------------------------------ helpers

def known_words(conn, limit=40):
    """The words the learner has studied, most recent first, for prompts."""
    rows = conn.execute(
        "SELECT w.word, w.reading, w.definition, w.greek FROM words w "
        "JOIN progress p ON p.word_id = w.id WHERE p.last_studied IS NOT NULL "
        "ORDER BY p.last_studied DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for word, reading, definition, translation in rows:
        meaning = (translation or "").strip() or (definition or "").strip()[:60]
        out.append({"word": word, "reading": reading or "", "meaning": meaning})
    return out


def studied_count(conn):
    return conn.execute(
        "SELECT COUNT(*) FROM progress WHERE last_studied IS NOT NULL").fetchone()[0]


def level_for(conn):
    """A sensible default level from how many words have been studied."""
    studied = studied_count(conn)
    return "beginner" if studied < 100 else "intermediate" if studied < 600 else "advanced"


def is_stuck(card):
    """A word that keeps slipping: rated Again 3+ times, or worn down."""
    try:
        lapses = int(card["lapses"] or 0)
    except (KeyError, IndexError, TypeError, ValueError):
        lapses = 0
    try:
        ease = float(card["ease_factor"])
        seen = card["repetitions"] > 0 or bool(card["last_studied"])
    except (KeyError, IndexError, TypeError, ValueError):
        ease, seen = 2.5, False
    return lapses >= STUCK_LAPSES or (seen and ease <= STUCK_EASE)


def rescue_of(card):
    """The stored rescue as a dict, or None."""
    try:
        raw = card["rescue"]
    except (KeyError, IndexError, TypeError):
        return None
    try:
        data = json.loads(raw) if raw else None
    except (TypeError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def sentence_reading_rule(target):
    if not languages.needs_reading(target):
        return 'always ""'
    return ("how it is pronounced, in Latin letters a learner can read: Revised "
            f"Romanization for Korean, {cards_ai.JA_ROMAJI} for Japanese, pinyin with "
            "tones for Chinese, a simple transliteration otherwise")


def words_in(text, words):
    """Which of `words` (dicts with word / reading) appear in `text`."""
    found = []
    for w in words:
        forms = [w["word"]]
        kana = (w.get("reading") or "").split("·")[0].strip()
        if kana and kana != w["word"] and any(0x3040 <= ord(c) <= 0x30FF for c in kana):
            forms.append(kana)
        for form in forms:
            if form and _contains(text, form):
                found.append(w["word"])
                break
    return found


def _contains(text, form):
    if any(0x3040 <= ord(c) <= 0x9FFF or 0xAC00 <= ord(c) <= 0xD7A3 for c in form):
        # Unspaced or agglutinating scripts: the stem may carry an ending.
        stem = form[:-1] if len(form) >= 3 and form.endswith(("る", "う", "く", "む", "다")) else form
        return stem in text
    return re.search(rf"(?<!\w){re.escape(form.lower())}", text.lower()) is not None


class _Writer(cards_ai.CardWriter):
    """Shared checks for every line the model writes."""

    def _line(self, raw):
        """{"text", "reading", "translation"} checked, or None when a beginner
        could not read or understand it."""
        if not isinstance(raw, dict):
            return None
        L = self.langs
        text = (raw.get("text") or "").strip()
        if not text:
            return None
        if L.target.lower() in cards_ai.SCRIPTS and cards_ai.script_share(text, L.target) < 0.5:
            return None
        same = L.target.lower() == L.definition.lower()
        translation = "" if same else cards_ai._in_language(
            (raw.get("translation") or "").strip(), L.target, L.definition)
        if not same and not translation:
            return None
        reading = cards_ai.latin_reading(raw.get("reading"), L.target)
        if languages.needs_reading(L.target) and not reading:
            return None
        return {"text": text, "reading": reading, "translation": translation}

    def _mine(self, text):
        """Text that must be in the learner's language ('' if it is not)."""
        text = (text or "").strip()
        L = self.langs
        if L.target.lower() != L.definition.lower() and cards_ai.wrong_language(
                text, L.target, L.definition):
            return ""
        return text

    def _length(self, level):
        return {"beginner": "3 to 7 words per sentence, present tense where possible",
                "intermediate": "up to 12 words per sentence, everyday grammar",
                "advanced": "natural sentences of any length"}.get(level, "3 to 7 words")


# ------------------------------------------------------------------ the story

STORY_SYSTEM = """You write a very short story for a {level} learner of {target}
whose own language is {definition}. It is made mostly from the learner's own
words (given), so reading it revises them in a new context.

Return JSON: {{"title": str, "sentences": [{{"text": str, "reading": str,
"translation": str}}], "new_words": [{{"word": str, "reading": str, "meaning": str}}],
"questions": [{{"question": str, "options": [str, str, str, str], "answer": int}}]}}

- title (in {definition}): 2-5 words.
- sentences: 5 to 8 sentences in {target} ONLY that tell one small everyday story:
  someone, somewhere, something happens, a small ending. {length}.
  Use at least 8 of the learner's words (all of them if there are fewer); apart
  from them only very common words a {level} learner already knows.
  reading: {reading_rule}. translation: the sentence in {definition}.
- new_words: at most 2 words in the story the learner does not know yet, each
  with its reading ({word_reading_rule}) and its meaning in {definition}; [] if none.
- questions: exactly 3, in {definition}, about what happens in the story,
  each with 4 short options in {definition} and the index (0-3) of the right one.
No markdown anywhere."""


class StoryWriter(_Writer):

    def write(self, level=None, key=None):
        """One new story (dict) from the learner's words; raises RuntimeError
        or cards_ai.BudgetExhausted when it cannot."""
        key = key or self.api_key()
        if not key:
            raise RuntimeError("no OpenAI API key — add one in Settings")
        level = level if level in LEVELS else level_for(self.conn)
        words = known_words(self.conn, 40)
        if len(words) < 5:
            raise RuntimeError("study at least 5 words first — the story is made from them")
        L = self.langs
        system = STORY_SYSTEM.format(
            level=level, target=L.target, definition=L.definition, length=self._length(level),
            reading_rule=sentence_reading_rule(L.target),
            word_reading_rule=cards_ai.reading_rules(L.target)["reading_rule"])
        user = json.dumps({"learner_words": [{"word": w["word"], "meaning": w["meaning"]}
                                             for w in words]}, ensure_ascii=False)
        data = self._chat("story", system, user, 1100, 1, key)
        story = self.clean(data, words)
        story["level"] = level
        return story

    def clean(self, data, words):
        if not isinstance(data, dict):
            raise RuntimeError("the story came back empty — press New story to try again")
        lines = [line for line in (self._line(s) for s in data.get("sentences") or []) if line]
        if len(lines) < 4:
            raise RuntimeError("the story came back incomplete — press New story to try again")
        L = self.langs
        new_words = []
        for item in data.get("new_words") or []:
            if not isinstance(item, dict):
                continue
            word = (item.get("word") or "").strip()
            meaning = self._mine(item.get("meaning"))
            reading = cards_ai.latin_reading(item.get("reading"), L.target)
            if word and meaning and (reading or not languages.needs_reading(L.target)):
                new_words.append({"word": word, "reading": reading, "meaning": meaning})
        questions = []
        for item in data.get("questions") or []:
            if not isinstance(item, dict):
                continue
            question = self._mine(item.get("question"))
            options = [self._mine(str(o)) for o in item.get("options") or []]
            answer = item.get("answer")
            if (question and len(options) == 4 and all(options)
                    and isinstance(answer, int) and 0 <= answer <= 3):
                questions.append({"question": question, "options": options, "answer": answer})
        text = " ".join(line["text"] for line in lines)
        return {"title": self._mine(data.get("title")) or "Today's story",
                "sentences": lines, "new_words": new_words[:2], "questions": questions[:3],
                "words_used": words_in(text, words)}


def save_story(conn, lang, story):
    story_id = uuid.uuid4().hex
    conn.execute("INSERT INTO stories (id, lang, made_on, body, created_at) VALUES (?, ?, ?, ?, ?)",
                 (story_id, lang, datetime.now().strftime("%Y-%m-%d"),
                  json.dumps(story, ensure_ascii=False), database.utc_stamp()))
    conn.commit()
    return story_id


def stories(conn, lang, limit=20):
    """[(id, made_on, story dict)] newest first."""
    out = []
    for story_id, made_on, body in conn.execute(
            "SELECT id, made_on, body FROM stories WHERE lang=? ORDER BY created_at DESC LIMIT ?",
            (lang, limit)).fetchall():
        try:
            out.append((story_id, made_on, json.loads(body)))
        except (TypeError, ValueError):
            continue
    return out


def stories_today(conn, lang):
    return conn.execute("SELECT COUNT(*) FROM stories WHERE lang=? AND made_on=?",
                        (lang, datetime.now().strftime("%Y-%m-%d"))).fetchone()[0]


# ------------------------------------------------------------------ the conversation

TALK_SYSTEM = """You are a friendly conversation partner for a {level} learner of
{target} whose own language is {definition}. Scene: {scene}. You play the other
person; the learner plays themself. Use mostly the learner's own words (given);
apart from them only very common words a {level} learner knows. Each of your
turns: one or two short sentences in {target}, {length}, then let the learner answer.

Return JSON: {{"feedback": null or {{"ok": bool, "better": str, "better_reading": str,
"why": str}}, "reply": {{"text": str, "reading": str, "translation": str}},
"suggestions": [{{"text": str, "reading": str, "translation": str}}], "finished": bool}}

- feedback: about the learner's last message only; null when there is none.
  ok = true when it is understandable and fits the scene. When it is not quite
  right: better = how a native speaker would say it ({target}), better_reading =
  its reading ({reading_rule}), why = one short, kind sentence in {definition}.
  When ok, better and why are "".
  A message in {definition} means the learner did not know how to say it:
  ok = false, better = how to say it in {target}, why = a short encouragement.
- reply: your next line in {target} ONLY; reading: {reading_rule}; translation:
  in {definition}. Stay in the scene.
- suggestions: exactly 3 different short answers the learner could give next,
  each in {target} with reading and translation, simple enough for the level.
- finished: true when the scene has reached a natural end (your reply then
  closes it kindly); otherwise false.
No markdown anywhere."""


HELP_SYSTEM = """A {level} learner of {target} whose own language is {definition}
is in a conversation (scene: {scene}) and does not know how to say something.
They tell you in {definition} (or a mix) what they want to say.

Return JSON: {{"text": str, "reading": str, "translation": str}}
- text: how a native speaker would say it here, in {target} ONLY, as simple as
  the level allows ({length}).
- reading: {reading_rule}.
- translation: what text means, in {definition}.
No markdown anywhere."""


class TalkPartner(_Writer):

    def turn(self, scene, level, history, said="", key=None):
        """The partner's next turn. `history` is [{"who": "partner"|"learner",
        "text": str}]; `said` the learner's newest message ('' to open)."""
        key = key or self.api_key()
        if not key:
            raise RuntimeError("no OpenAI API key — add one in Settings")
        L = self.langs
        level = level if level in LEVELS else level_for(self.conn)
        system = TALK_SYSTEM.format(level=level, target=L.target, definition=L.definition,
                                    scene=scene, length=self._length(level),
                                    reading_rule=sentence_reading_rule(L.target))
        user = json.dumps({
            "learner_words": [w["word"] for w in known_words(self.conn, 40)],
            "conversation": history[-10:],
            "learner_now": said,
        }, ensure_ascii=False)
        data = self._chat("talk", system, user, 750, 1, key)
        return self.clean(data, said)

    def how_to_say(self, scene, level, history, meaning, key=None):
        """The learner said (or typed) in their own language what they want
        to say; return it as a line in the learning language to say next."""
        key = key or self.api_key()
        if not key:
            raise RuntimeError("no OpenAI API key — add one in Settings")
        L = self.langs
        level = level if level in LEVELS else level_for(self.conn)
        system = HELP_SYSTEM.format(level=level, target=L.target, definition=L.definition,
                                    scene=scene, length=self._length(level),
                                    reading_rule=sentence_reading_rule(L.target))
        user = json.dumps({"conversation": history[-6:], "wants_to_say": meaning},
                          ensure_ascii=False)
        line = self._line(self._chat("talk", system, user, 300, 1, key))
        if line is None:
            raise RuntimeError("the answer came back unreadable — try again")
        return line

    def clean(self, data, said):
        if not isinstance(data, dict):
            raise RuntimeError("no answer came back — try again")
        reply = self._line(data.get("reply"))
        if reply is None:
            raise RuntimeError("the answer came back unreadable — try again")
        suggestions = [s for s in (self._line(x) for x in data.get("suggestions") or []) if s][:3]
        feedback = None
        raw = data.get("feedback")
        if said and isinstance(raw, dict):
            L = self.langs
            better = (raw.get("better") or "").strip()
            if better and L.target.lower() in cards_ai.SCRIPTS and \
                    cards_ai.script_share(better, L.target) < 0.5:
                better = ""
            feedback = {"ok": bool(raw.get("ok")) or not better,
                        "better": better,
                        "better_reading": cards_ai.latin_reading(raw.get("better_reading"), L.target)
                        if better else "",
                        "why": self._mine(raw.get("why")) if better else ""}
        return {"reply": reply, "suggestions": suggestions, "feedback": feedback,
                "finished": bool(data.get("finished"))}


# ------------------------------------------------------------------ the word doctor

DOCTOR_SYSTEM = """A learner of {target} whose own language is {definition}
keeps forgetting one word. Give them new ways to remember it.

Return JSON: {{"hook": {{"image": str, "bridge": str, "line": str, "line_tr": str,
"line_reading": str}}, "contrast": str, "story": [{{"text": str, "reading": str,
"translation": str}}]}}

- hook: a NEW memory hook, clearly different from the old one (given).
  image (in {definition}, max 160 characters): the word's real parts with their
  meanings, or one vivid, concrete, slightly surprising scene; a sound-alike cue
  in {definition} is welcome when marked as one ("sounds like …").{family_rule}
  bridge (in {definition}): only a documented link to {definition}; else "".
  line (in {target} ONLY): a short first-person sentence using the word.
  line_tr: that line in {definition}. line_reading: {line_reading_rule}.
- contrast (in {definition}, max 200 characters): when the word is easily
  confused with another {target} word (similar sound, look or meaning), name it
  with its reading and meaning and say how to tell them apart; else "".
- story: exactly 2 short connected sentences in {target} that use the word in
  a memorable little situation, each with reading ({reading_rule}) and
  translation ({definition}).
No markdown anywhere."""


class Doctor(_Writer):

    def rescue(self, card, key=None):
        """A new way to remember `card` (dict with word, reading, definition,
        greek, example, hook, id); saved on the card and returned."""
        key = key or self.api_key()
        if not key:
            raise RuntimeError("no OpenAI API key — add one in Settings")
        L = self.langs
        rules = cards_ai.reading_rules(L.target)
        line_rule = rules["line_reading_rule"]
        if line_rule == 'always ""' and languages.needs_reading(L.target):
            line_rule = sentence_reading_rule(L.target)
        system = DOCTOR_SYSTEM.format(target=L.target, definition=L.definition,
                                      family_rule=rules["family_rule"],
                                      line_reading_rule=line_rule,
                                      reading_rule=sentence_reading_rule(L.target))
        user = json.dumps({k: (card[k] or "") for k in
                           ("word", "reading", "definition", "greek", "example", "hook")},
                          ensure_ascii=False)
        data = self._chat("doctor", system, user, 450, 1, key)
        result = self.clean(data)
        self.conn.execute("UPDATE words SET rescue=?, updated_at=? WHERE id=?",
                          (json.dumps(result, ensure_ascii=False), database.utc_stamp(),
                           card["id"]))
        return result

    def clean(self, data):
        if not isinstance(data, dict):
            raise RuntimeError("no answer came back — try again")
        L = self.langs
        raw_hook = data.get("hook")
        hook = cards_ai.assemble_hook(raw_hook, L.target, L.definition)
        if isinstance(raw_hook, dict) and languages.needs_reading(L.target) \
                and not languages.needs_sentence_reading(L.target):
            # assemble_hook adds the line's reading for kanji scripts only; a
            # Korean or Greek beginner needs one for the hook line too.
            reading = cards_ai.latin_reading(raw_hook.get("line_reading"), L.target)
            line = (raw_hook.get("line") or "").strip()
            if reading and line and line in hook:
                hook = hook.replace(line, f"{line} ({reading})", 1)
        story = [s for s in (self._line(x) for x in data.get("story") or []) if s][:2]
        contrast = self._mine(data.get("contrast"))[:240]
        if not (hook or story or contrast):
            raise RuntimeError("nothing usable came back — try again")
        return {"hook": hook, "contrast": contrast, "story": story}

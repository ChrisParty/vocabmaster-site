"""TSV/CSV parser with fuzzy header-based column detection.

Google Sheets copy-paste arrives tab-separated; .csv files are comma-separated.
"""

import csv
import io
import re
from html.parser import HTMLParser

# Part-of-speech tags embedded in the word cell, e.g. "Pursue [ v ]"
POS_TOKENS = {
    "n", "v", "adj", "adv", "prep", "phr", "phrase", "idiom", "pron",
    "conj", "interj", "noun", "verb", "adjective", "adverb",
}


def _extract_pos(word):
    """Pull recognized POS tags out of the word: "Pursue [ v ]" -> ("Pursue", "v").

    Unrecognized bracket groups like "[ to ]" or "[ sth ]" stay in the word.
    """
    found = []

    def repl(match):
        token = match.group(1).strip().lower()
        if token in POS_TOKENS:
            found.append(token)
            return ""
        return match.group(0)

    cleaned = re.sub(r"\[\s*([^\[\]]*?)\s*\]", repl, word)
    return " ".join(cleaned.split()), ", ".join(found)

def column_matchers(langs=None):
    """Header needles per field. The deck's own language names join the
    generic ones, so "Korean | Meaning" is recognised for a Korean deck and
    "Greek" still lands in the first translation column for Mike's."""
    word = ["word", "term", "vocab", "headword"]
    native = ["translation", "native"]
    second = ["translation 2", "second"]
    if langs:
        word.append(langs.target.lower())
        if langs.native:
            native.insert(0, langs.native.lower())
        if langs.second:
            second.insert(0, langs.second.lower())
    else:
        word.append("english")
        native += ["greek", "ελλ"]
        second += ["swed", "svenska"]
    return [
        ("word", word),
        ("definition", ["defin", "meaning", "desc"]),
        ("pos", ["part of speech", "pos", "speech", "type"]),
        ("greek", native),
        ("swedish", second),
        ("synonyms", ["syn"]),
        ("example", ["example", "sentence", "usage"]),
        ("hook", ["hook", "mnemonic", "memory"]),
    ]


class _TableExtractor(HTMLParser):
    """Pulls <table> rows out of clipboard HTML (Excel/Sheets copy format)."""

    def __init__(self):
        super().__init__()
        self.rows = []
        self._row = None
        self._cell = None

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self._row = []
        elif tag in ("td", "th") and self._row is not None:
            self._cell = []
        elif tag == "br" and self._cell is not None:
            self._cell.append(" ")

    def handle_endtag(self, tag):
        if tag == "tr" and self._row is not None:
            self.rows.append(self._row)
            self._row = None
        elif tag in ("td", "th") and self._cell is not None:
            text = "".join(self._cell)
            self._row.append(" ".join(text.split()))
            self._cell = None

    def handle_data(self, data):
        if self._cell is not None:
            self._cell.append(data)


def html_table_to_tsv(html):
    """Convert clipboard HTML with a table into TSV text. Returns "" if no table."""
    extractor = _TableExtractor()
    try:
        extractor.feed(html)
    except Exception:
        return ""
    rows = [row for row in extractor.rows if any(cell.strip() for cell in row)]
    if not rows or max(len(row) for row in rows) < 2:
        return ""
    return "\n".join(
        "\t".join(cell.replace("\t", " ") for cell in row) for row in rows
    )


def detect_delimiter(text):
    lines = [line for line in text.splitlines() if line.strip()][:20]
    if not lines:
        return "\t"
    # Google Sheets pastes are tab-separated, and cells routinely contain
    # commas (synonym lists, example sentences) — so tabs win whenever most
    # lines contain at least one. Only fall back to comma for real CSVs.
    tab_lines = sum(1 for line in lines if "\t" in line)
    if tab_lines >= max(1, len(lines) // 2):
        return "\t"
    return ","


def _match_columns(header, langs=None):
    """Map field name -> column index using fuzzy header matching."""
    mapping = {}
    lowered = [cell.strip().lower() for cell in header]
    for field, needles in column_matchers(langs):
        for index, cell in enumerate(lowered):
            if index in mapping.values():
                continue
            if any(needle in cell for needle in needles):
                mapping[field] = index
                break
    return mapping


def parse_text(text, langs=None):
    """Parse pasted TSV/CSV text.

    Returns (entries, detected_columns, error_message).
    entries: list of dicts with keys word/definition/pos/greek/swedish/synonyms/example/hook
    detected_columns: dict of field -> header label (for the UI badges)
    langs: the deck's languages.Languages, for header detection
    """
    text = text.strip()
    if not text:
        return [], {}, ""

    delimiter = detect_delimiter(text)
    try:
        rows = list(csv.reader(io.StringIO(text), delimiter=delimiter))
    except csv.Error as exc:
        return [], {}, f"Could not parse data: {exc}"

    rows = [row for row in rows if any(cell.strip() for cell in row)]
    if not rows:
        return [], {}, "No data rows found."

    mapping = _match_columns(rows[0], langs)
    header_labels = {}
    if "word" in mapping and "definition" in mapping:
        header = rows[0]
        for field, index in mapping.items():
            header_labels[field] = header[index].strip() if index < len(header) else field
        data_rows = rows[1:]
    else:
        # No recognizable header. If the text also has no tabs, this is almost
        # certainly a broken paste where every spreadsheet cell landed on its
        # own line — importing it would create garbage rows, so refuse.
        if delimiter != "\t" and len(rows) > 20:
            return [], {}, (
                "This paste lost its column structure (each cell arrived on "
                "its own line), so it can't be imported safely. Copy the sheet "
                "again and paste directly here — or use the “Choose CSV file” "
                "button instead."
            )
        mapping = {"word": 0, "definition": 1}
        header_labels = {"word": "Column 1", "definition": "Column 2"}
        data_rows = rows

    if not data_rows:
        return [], header_labels, "Found a header but no word rows underneath it."

    entries = []
    for row in data_rows:
        def cell(field):
            index = mapping.get(field)
            if index is None or index >= len(row):
                return ""
            # Strip stray quote marks left behind by imperfect CSV quoting.
            return row[index].strip().strip('"').strip()

        word = cell("word")
        definition = cell("definition")
        greek = cell("greek")
        synonyms = cell("synonyms").replace("|", ", ")
        pos = cell("pos")
        if not pos:
            word, pos = _extract_pos(word)
        # Rows without a definition are still usable — fall back to synonyms
        # or the Greek translation so the card back is never empty.
        if not definition:
            definition = synonyms or greek
        if not word or not definition:
            continue
        entries.append(
            {
                "word": word,
                "definition": definition,
                "pos": pos,
                "greek": greek,
                "swedish": cell("swedish"),
                "synonyms": synonyms,
                "example": cell("example"),
                "hook": cell("hook"),
            }
        )

    if not entries:
        return [], header_labels, (
            "No valid rows found. Each row needs at least a word and a definition."
        )
    return entries, header_labels, ""


def parse_file(filepath, langs=None):
    """Parse a .csv (or .tsv/.txt) file from disk."""
    try:
        with open(filepath, "r", encoding="utf-8-sig") as handle:
            return parse_text(handle.read(), langs)
    except OSError as exc:
        return [], {}, f"Could not read file: {exc}"
    except UnicodeDecodeError:
        try:
            with open(filepath, "r", encoding="latin-1") as handle:
                return parse_text(handle.read(), langs)
        except OSError as exc:
            return [], {}, f"Could not read file: {exc}"

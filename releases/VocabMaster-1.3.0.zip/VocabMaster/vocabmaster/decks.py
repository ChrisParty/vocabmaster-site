"""Several decks side by side — one per language you learn (or per person on
a shared computer), each with its own words, progress, streak, stats and
sentences, so learning Korean never mixes Korean cards into an English deck.

  main deck     the data folder itself (paths.data_dir()) — where the one
                deck has always lived; nothing about it moves or changes
  other decks   <data folder>/decks/<id>/vocabmaster.db (+ images, backups)
  decks.json    which decks exist on this computer, their order, and which
                one is open

A deck's name ("Mike") and languages live in its own settings, so they
travel with backups. One deck is open at a time: switching saves, closes the
app and opens it again on the other deck (main.py reads `current()`).

Cloud sync keeps decks apart: the main deck syncs at the top of the user's
Drive app folder, as it always did; every other deck in its own sub-folder
named by `gdrive_space` ("deck-<id>"), with a small `deck.info` there so
another computer can find it and open it too (`join()`).

The daily AI budget is shared: ledger.OTHER_DBS lets each deck's ledger count
what the other decks spent today.
"""

import json
import os
import secrets
import sqlite3

import paths

MAIN = "main"
REGISTRY = "decks.json"

# Settings that belong to the person, not to a deck: a new deck starts with
# them so the key, the budget and the Drive connection need no second setup.
PERSONAL = (
    "openai_api_key", "card_model", "text_daily_cap", "image_daily_cap", "image_quality",
    "font_size", "daily_goal", "max_new_per_day", "session_cap", "study_direction",
    "quiz_mode", "show_hook", "reminder_enabled", "reminder_time", "autostart",
    "tray_hint_shown", "talk_read_aloud",
    "sync_backend", "gdrive_client_id", "gdrive_client_secret", "gdrive_refresh_token",
    "gdrive_account",
)


# ------------------------------------------------------------------ registry

def _registry_path():
    return os.path.join(paths.data_dir(), REGISTRY)


def _load():
    try:
        with open(_registry_path(), encoding="utf-8") as handle:
            data = json.load(handle)
        if isinstance(data, dict):
            return data
    except (OSError, ValueError):
        pass
    return {}


def _save(data):
    target = _registry_path()
    with open(target + ".part", "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=1)
    os.replace(target + ".part", target)


def folder(deck_id):
    if deck_id == MAIN:
        return paths.data_dir()
    return os.path.join(paths.data_dir(), "decks", deck_id)


def db_path(deck_id):
    """Where a deck's database is (a plain path: opening the main deck — and
    moving a legacy one in — stays paths.db_path()'s job at startup)."""
    return os.path.join(folder(deck_id), paths.DB_NAME)


def deck_of(path):
    """The id of the deck whose database is at `path` ('' when none is)."""
    here = os.path.normcase(os.path.abspath(path))
    for deck in ids():
        if os.path.normcase(os.path.abspath(db_path(deck))) == here:
            return deck
    return ""


def ids():
    """The decks on this computer, the main one first."""
    order = [d for d in _load().get("order", []) if d != MAIN]
    return [MAIN] + [d for d in order if os.path.exists(db_path(d))]


def current():
    deck = _load().get("current") or MAIN
    return deck if deck in ids() else MAIN


def set_current(deck_id):
    data = _load()
    data["current"] = deck_id
    _save(data)


def other_db_paths(open_path):
    """Every deck's database except the one open (for the shared budget)."""
    here = os.path.normcase(os.path.abspath(open_path))
    out = []
    for deck in ids():
        path = db_path(deck)
        if os.path.normcase(os.path.abspath(path)) != here and os.path.exists(path):
            out.append(path)
    return out


# ------------------------------------------------------------------ reading a deck

def info(deck_id, path=None):
    """{"id", "name", "target", "words", "space"} read without changing the deck."""
    path = path or db_path(deck_id)
    out = {"id": deck_id, "name": "", "target": "", "words": 0, "space": ""}
    try:
        conn = sqlite3.connect(f"file:{os.path.abspath(path)}?mode=ro", uri=True)
        try:
            settings = dict(conn.execute(
                "SELECT key, value FROM settings WHERE key IN "
                "('deck_name', 'lang_target', 'gdrive_space')").fetchall())
            out["words"] = conn.execute("SELECT COUNT(*) FROM words").fetchone()[0]
        finally:
            conn.close()
    except sqlite3.Error:
        return out
    import languages
    out["name"] = (settings.get("deck_name") or "").strip()
    out["target"] = settings.get("lang_target") or languages.LEGACY.get("lang_target", "English")
    out["space"] = settings.get("gdrive_space") or ""
    return out


def label(deck):
    """'Korean · Mike' — the language first, the name when there is one."""
    return f"{deck['target']} · {deck['name']}" if deck.get("name") else deck["target"]


def all_info():
    return [info(d) for d in ids()]


# ------------------------------------------------------------------ making one

def create(name, langs, copy_from=None, space=None):
    """A new deck with these languages ({"lang_target": …, "lang_definition": …,
    "lang_native": …, "lang_second": …}), the person's settings copied from
    `copy_from` (a database path), syncing into its own Drive folder —
    `space` to join a deck another computer made. Returns the new id."""
    from database import Database
    deck_id = secrets.token_hex(3)
    while os.path.exists(folder(deck_id)):
        deck_id = secrets.token_hex(3)
    os.makedirs(folder(deck_id))
    db = Database(db_path(deck_id))
    try:
        if copy_from and os.path.exists(copy_from):
            source = sqlite3.connect(f"file:{os.path.abspath(copy_from)}?mode=ro", uri=True)
            try:
                marks = ",".join("?" * len(PERSONAL))
                for key, value in source.execute(
                        f"SELECT key, value FROM settings WHERE key IN ({marks})", PERSONAL):
                    if value not in (None, ""):
                        db.set_setting(key, value)
            finally:
                source.close()
        for key, value in langs.items():
            db.set_setting(key, value or "")
        db.set_setting("deck_name", (name or "").strip())
        db.set_setting("lang_confirmed", "1")
        # Never the top of the Drive folder: that is the main deck's.
        db.set_setting("gdrive_space", space or f"deck-{deck_id}")
    finally:
        db.close()
    data = _load()
    data["order"] = [d for d in data.get("order", []) if d != MAIN] + [deck_id]
    _save(data)
    return deck_id


def rename(deck_id, name):
    conn = sqlite3.connect(db_path(deck_id))
    try:
        conn.execute("INSERT INTO settings (key, value) VALUES ('deck_name', ?) "
                     "ON CONFLICT(key) DO UPDATE SET value=excluded.value", ((name or "").strip(),))
        conn.commit()
    finally:
        conn.close()


def remote_only(open_db):
    """Decks another computer put in this Google Drive that are not on this
    one yet (the open deck's last sync noted them in `drive_decks`)."""
    try:
        conn = sqlite3.connect(f"file:{os.path.abspath(open_db)}?mode=ro", uri=True)
        try:
            row = conn.execute("SELECT value FROM settings WHERE key='drive_decks'").fetchone()
        finally:
            conn.close()
        seen = json.loads(row[0]) if row and row[0] else []
    except (sqlite3.Error, ValueError):
        return []
    here = {d["space"] for d in all_info() if d["space"]}
    return [d for d in seen if isinstance(d, dict) and d.get("space") and d["space"] not in here
            and d.get("lang_target")]

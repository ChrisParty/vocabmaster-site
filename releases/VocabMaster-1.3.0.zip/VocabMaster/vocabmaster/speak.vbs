' Speaks the first argument with a Windows voice (offline).
'
' The optional second argument is a language id (hex LCID, e.g. 41D for
' Swedish). The first installed voice for that language is used: the
' classic voices first, then the newer ones Windows adds from Settings ->
' Speech (Speech_OneCore). Greek and Swedish exist only there. Language
' ids are compared as numbers, because Windows writes some as "041d":
' an exact match first, then the same language from another country
' (409 English US -> 809 English UK). Without a voice for the language the
' default voice reads the text as best it can.
'
' A third argument writes the speech to that .wav file instead of the
' speakers (used by the tests, so they make no sound).

Function LangNumber(code)
    LangNumber = -1
    On Error Resume Next
    LangNumber = CLng("&H" & Trim(code))
    On Error Goto 0
End Function

Function FindVoice(lcid)
    Set FindVoice = Nothing
    want = LangNumber(lcid)
    If want < 0 Then Exit Function
    places = Array("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices", _
                   "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Speech\Voices", _
                   "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech_OneCore\Voices")
    For pass = 1 To 2
        For Each place In places
            Set category = CreateObject("SAPI.SpObjectTokenCategory")
            On Error Resume Next
            category.SetId place, False
            missing = (Err.Number <> 0)
            Err.Clear
            On Error Goto 0
            If Not missing Then
                For Each token In category.EnumerateTokens()
                    For Each part In Split(token.GetAttribute("Language"), ";")
                        have = LangNumber(part)
                        If have >= 0 Then
                            If (pass = 1 And have = want) Or _
                               (pass = 2 And (have And &H3FF) = (want And &H3FF)) Then
                                Set FindVoice = token
                                Exit Function
                            End If
                        End If
                    Next
                Next
            End If
        Next
    Next
End Function

If WScript.Arguments.Count > 0 Then
    Set voice = CreateObject("SAPI.SpVoice")
    If WScript.Arguments.Count > 1 Then
        Set chosen = FindVoice(WScript.Arguments(1))
        If Not chosen Is Nothing Then Set voice.Voice = chosen
    End If
    If WScript.Arguments.Count > 2 Then
        Set stream = CreateObject("SAPI.SpFileStream")
        stream.Open WScript.Arguments(2), 3, False
        Set voice.AudioOutputStream = stream
        voice.Speak WScript.Arguments(0)
        stream.Close
    Else
        voice.Speak WScript.Arguments(0)
    End If
End If

"""Start VocabMaster with the computer, hidden in the tray, so the daily
reminder can fire. Windows: a shortcut in the user's Startup folder.
macOS: a LaunchAgent. Nothing needs admin rights; disable removes the file.
"""

import os
import platform
import plistlib
import subprocess
import sys

import paths

LABEL = "local.vocabmaster"


def _python():
    """The interpreter running us, windowless on Windows."""
    exe = sys.executable
    if platform.system() == "Windows" and exe.lower().endswith("python.exe"):
        quiet = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(quiet):
            exe = quiet
    return exe


def _target():
    system = platform.system()
    if system == "Windows":
        return os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows",
                            "Start Menu", "Programs", "Startup", "VocabMaster.lnk")
    if system == "Darwin":
        return os.path.expanduser(f"~/Library/LaunchAgents/{LABEL}.plist")
    return os.path.expanduser("~/.config/autostart/vocabmaster.desktop")


def enabled():
    return os.path.exists(_target())


def enable():
    system = platform.system()
    target = _target()
    main = os.path.join(paths.app_dir(), "main.py")
    os.makedirs(os.path.dirname(target), exist_ok=True)
    if system == "Windows":
        powershell = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                                  "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
        script = (f"$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{target}');"
                  f"$s.TargetPath='{_python()}';$s.Arguments='\"{main}\" --tray';"
                  f"$s.WorkingDirectory='{paths.app_dir()}';"
                  f"$s.IconLocation='{os.path.join(paths.app_dir(), 'vocabmaster.ico')},0';"
                  "$s.Save()")
        subprocess.run([powershell, "-NoProfile", "-Command", script], check=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    elif system == "Darwin":
        with open(target, "wb") as handle:
            plistlib.dump({"Label": LABEL, "RunAtLoad": True,
                           "ProgramArguments": [_python(), main, "--tray"],
                           "WorkingDirectory": paths.app_dir()}, handle)
        subprocess.run(["launchctl", "load", target], check=False)
    else:
        with open(target, "w", encoding="utf-8") as handle:
            handle.write("[Desktop Entry]\nType=Application\nName=VocabMaster\n"
                         f"Exec={_python()} {main} --tray\nX-GNOME-Autostart-enabled=true\n")


def disable():
    target = _target()
    if platform.system() == "Darwin" and os.path.exists(target):
        subprocess.run(["launchctl", "unload", target], check=False)
    try:
        os.remove(target)
    except OSError:
        pass

"""The daily nudge: once a day, at the chosen time, if there is something
due and the goal is not met yet — "12 cards due — five minutes?". Clicking
it opens a session. Windows and Linux use the tray balloon; macOS gets a
Notification Center message through osascript, which works unbundled.
"""

import platform
import subprocess
from datetime import datetime

DEFAULT_TIME = "19:00"


def due_message(db):
    """The reminder text if one is owed right now, else None. Owed means:
    enabled, past the chosen time, not yet shown today, cards due, goal
    not reached. Marks today as done either way once past the time."""
    if db.get_setting("reminder_enabled") != "1":
        return None
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    if db.get_setting("reminder_last") == today:
        return None
    if now.strftime("%H:%M") < (db.get_setting("reminder_time") or DEFAULT_TIME):
        return None
    db.set_setting("reminder_last", today)
    due = db.due_count()
    if due == 0 or db.reviewed_today() >= db.get_int_setting("daily_goal", 20):
        return None
    return f"{due} card{'s' if due != 1 else ''} due — five minutes?"


def today_status(db):
    """One plain sentence for Settings: what the reminder will do today, so a
    quiet day never looks like a broken reminder."""
    if db.get_setting("reminder_enabled") != "1":
        return ""
    at = db.get_setting("reminder_time") or DEFAULT_TIME
    goal = db.get_int_setting("daily_goal", 20)
    done = db.reviewed_today()
    if done >= goal:
        return (f"Today's goal is done ({done} of {goal} cards) ✓ — so no reminder today. "
                f"The next one comes tomorrow at {at}, if your goal is not reached by then.")
    if db.due_count() == 0:
        return f"Nothing to study today — no reminder. The next one: tomorrow at {at}."
    if db.get_setting("reminder_last") == datetime.now().strftime("%Y-%m-%d"):
        return f"Today's reminder has been shown. The next one: tomorrow at {at}."
    if datetime.now().strftime("%H:%M") < at:
        return f"Today at {at}, unless you reach your goal ({goal} cards) before then."
    return "Any moment now — the reminder checks once a minute."


def notify(tray, title, text):
    if platform.system() == "Darwin":
        safe = text.replace('"', "'")
        subprocess.Popen(["osascript", "-e",
                          f'display notification "{safe}" with title "{title}"'])
    elif tray is not None:
        tray.showMessage(title, text, tray.icon(), 15000)

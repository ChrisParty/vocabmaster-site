"""Tiny localhost status server so the Hub dashboard can see VocabMaster.

Serves the Hub standard (Desktop\\Hub\\STANDARD.md) on a daemon thread:
GET /health and GET /api/today, plus POST /api/words so other apps (Lexi)
can add vocabulary cards. Reads use fresh mode=ro connections; the single
write endpoint uses its own short-lived connection with a busy timeout, so
it can never block or corrupt the main app. Bound to 127.0.0.1 only.
"""

import json
import sqlite3
import threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import database

HOST, PORT = "127.0.0.1", 7843


def _due_count(db_path):
    """Same definition as Database.due_count(): today's reviews plus the new
    words still allowed today (database.due_today)."""
    uri = f"file:{Path(db_path).as_posix()}?mode=ro"
    with sqlite3.connect(uri, uri=True, timeout=1.0) as conn:
        row = conn.execute(
            "SELECT value FROM settings WHERE key='max_new_per_day'").fetchone()
        try:
            max_new = int(row[0]) if row else 20
        except (TypeError, ValueError):
            max_new = 20
        return database.due_today(conn, max_new)


def _add_word(db_path, entry: dict) -> dict:
    """Insert one word + its progress row (mirrors Database.add_words).
    Dedupes case-insensitively; commits immediately."""
    word = (entry.get("word") or "").strip()
    definition = (entry.get("definition") or "").strip()
    if not word or not definition:
        return {"error": "word and definition are required"}
    conn = sqlite3.connect(db_path, timeout=3.0)
    try:
        existing = conn.execute(
            "SELECT 1 FROM words WHERE lower(word) = lower(?)", (word,)).fetchone()
        if existing:
            return {"added": False, "reason": "already in the deck"}
        # Shared insert path — it stamps updated_at, without which a card
        # added by Lexi would never travel to the other computer.
        word_id = database.insert_card(conn, dict(entry, word=word, definition=definition))
        conn.commit()
        return {"added": True, "id": word_id}
    finally:
        conn.close()


class _Handler(BaseHTTPRequestHandler):
    db_path = None
    on_show = None          # a second launch asks the running instance to show itself

    def do_POST(self):
        if self.path == "/api/show":
            if _Handler.on_show:
                _Handler.on_show()
            self._json({"ok": True})
            return
        if self.path != "/api/words":
            self._json({"error": "not found"}, 404)
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            entry = json.loads(self.rfile.read(length).decode())
            result = _add_word(self.db_path, entry)
        except (json.JSONDecodeError, ValueError):
            result = {"error": "invalid JSON"}
        except sqlite3.Error as e:
            result = {"error": f"database busy: {e}"}
        self._json(result, 400 if "error" in result else 200)

    def do_GET(self):
        if self.path == "/health":
            self._json({"ok": True})
        elif self.path == "/api/today":
            try:
                count = _due_count(self.db_path)
            except sqlite3.Error:
                count = 0
            self._json({"app": "VocabMaster", "label": "words due", "count": count})
        else:
            self._json({"error": "not found"}, 404)

    def _json(self, payload, status=200):
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass  # stay silent; this runs inside a windowed app


def start(db_path, on_show=None):
    """Start the status server. Never lets a failure break the main app —
    if the port is taken (e.g. another instance won the race), just skip."""
    try:
        server = ThreadingHTTPServer((HOST, PORT), _Handler)
    except OSError:
        return
    _Handler.db_path = db_path
    _Handler.on_show = on_show
    threading.Thread(target=server.serve_forever, daemon=True).start()

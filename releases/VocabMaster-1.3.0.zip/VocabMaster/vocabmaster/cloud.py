"""Cloud transports for sync.py — where the append-only logs and the picture
files live. The transport moves named blobs and knows nothing about words.

Two backends, one shape:

  GoogleDrive      the user's OWN Google Drive, in the hidden appDataFolder
                   that only this app can see. OAuth sign-in, no server of
                   ours, nothing that pauses or expires. One Google account
                   is one user, so pairing two machines is: sign in on both.
                   This is also the model for other people using the app —
                   their data stays in their Drive, there is nothing to host.
  SupabaseStorage  the original private bucket. Kept so an old install still
                   syncs; the free tier pauses after a week idle, which is
                   why it is no longer the default.

Interface (all raise CloudError; NotFound for a missing blob; NotConnected
when the user has to sign in again):
  label                       short name for the status bar
  list_logs() -> [name]       every log file, name-sorted
  put_log(name, bytes)        logs are immutable: a name is written once
  get_log(name) -> bytes
  put_image(filename, bytes)  idempotent (same name overwrites)
  get_image(filename) -> bytes
"""

import base64
import hashlib
import http.server
import json
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

DRIVE = "https://www.googleapis.com/drive/v3"
UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"
AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
# The narrowest Drive scope there is: a hidden folder this app alone can see.
# No access to the user's real files, so Google asks for no verification.
SCOPE = "https://www.googleapis.com/auth/drive.appdata"
FOLDER = "application/vnd.google-apps.folder"
IMAGES_FOLDER = "images"
DECK_INFO = "deck.info"           # a deck folder's description (JSON; not *.json, so never read as a log)

BUCKET = "vocab-sync"          # Supabase
IMAGE_PREFIX = "images"


class CloudError(Exception):
    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code


class NotFound(CloudError):
    pass


class NotConnected(CloudError):
    pass


def _http(method, url, body=None, headers=None, timeout=30):
    request = urllib.request.Request(url, data=body, method=method,
                                     headers=headers or {})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.read()
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode()[:200]
        except Exception:
            pass
        if exc.code == 404:
            raise NotFound(f"not found: {detail}", 404) from exc
        raise CloudError(f"cloud error {exc.code}: {detail}", exc.code) from exc


# --------------------------------------------------------------- selection

def active_backend(get_setting):
    """'gdrive', 'supabase' or '' — which transport the settings describe."""
    backend = get_setting("sync_backend") or ""
    if backend == "gdrive" and get_setting("gdrive_refresh_token"):
        return "gdrive"
    if backend in ("", "supabase") and get_setting("sync_url") \
            and get_setting("sync_secret") and get_setting("sync_enabled") == "1":
        return "supabase"
    return ""


def open_store(get_setting, set_setting, ensure_key):
    """The configured transport, or None when sync is off."""
    backend = active_backend(get_setting)
    if backend == "gdrive":
        return GoogleDrive(get_setting, set_setting)
    if backend == "supabase":
        return SupabaseStorage(get_setting("sync_url"), get_setting("sync_secret"),
                               ensure_key())
    return None


# ---------------------------------------------------------------- Supabase

class SupabaseStorage:
    label = "Supabase"

    def __init__(self, url, secret, key):
        self.base = url.rstrip("/")
        self.secret = secret
        self.key = key

    def _req(self, method, path, body=None, content_type="application/json"):
        return _http(method, self.base + path, body, {
            "Authorization": f"Bearer {self.secret}", "apikey": self.secret,
            "Content-Type": content_type, "x-upsert": "true"})

    def list_logs(self):
        body = json.dumps({"prefix": self.key, "limit": 1000, "offset": 0,
                           "sortBy": {"column": "name", "order": "asc"}}).encode()
        out = json.loads(self._req("POST", f"/storage/v1/object/list/{BUCKET}", body))
        return sorted(o["name"] for o in out if o.get("name", "").endswith(".json"))

    def put_log(self, name, data):
        self._req("POST", f"/storage/v1/object/{BUCKET}/{self.key}/{name}", data)

    def get_log(self, name):
        return self._req("GET", f"/storage/v1/object/{BUCKET}/{self.key}/{name}")

    def _image(self, filename):
        return f"/storage/v1/object/{BUCKET}/{IMAGE_PREFIX}/{self.key}/{filename}"

    def put_image(self, filename, data):
        self._req("POST", self._image(filename), data, "image/webp")

    def get_image(self, filename):
        return self._req("GET", self._image(filename))


# ------------------------------------------------------------ Google Drive

def _form(url, fields):
    body = urllib.parse.urlencode(fields).encode()
    return json.loads(_http("POST", url, body,
                            {"Content-Type": "application/x-www-form-urlencoded"}))


def _quote(value):
    return value.replace("\\", "\\\\").replace("'", "\\'")


class GoogleDrive:
    """Settings-backed: tokens live in the settings table, so the engine's
    own connection (any thread) can refresh them."""

    label = "Google Drive"

    def __init__(self, get_setting, set_setting):
        self.get = get_setting
        self.set = set_setting

    # ---- auth

    def _token(self):
        token = self.get("gdrive_access_token")
        try:
            expiry = float(self.get("gdrive_token_expiry") or 0)
        except ValueError:
            expiry = 0
        if token and time.time() < expiry - 60:
            return token
        refresh = self.get("gdrive_refresh_token")
        if not refresh:
            raise NotConnected("Google Drive is not connected")
        try:
            data = _form(TOKEN_URL, {
                "client_id": self.get("gdrive_client_id"),
                "client_secret": self.get("gdrive_client_secret"),
                "refresh_token": refresh, "grant_type": "refresh_token"})
        except CloudError as exc:
            if "invalid_grant" in str(exc):
                # Revoked or expired: the only fix is a fresh sign-in.
                self.set("gdrive_refresh_token", "")
                raise NotConnected("Google Drive sign-in expired — connect again "
                                   "in Settings") from exc
            raise
        self.set("gdrive_access_token", data["access_token"])
        self.set("gdrive_token_expiry", time.time() + float(data.get("expires_in", 3600)))
        return data["access_token"]

    def _request(self, method, url, body=None, content_type=None, timeout=60):
        for attempt in range(2):
            headers = {"Authorization": f"Bearer {self._token()}"}
            if content_type:
                headers["Content-Type"] = content_type
            try:
                return _http(method, url, body, headers, timeout)
            except CloudError as exc:
                if exc.code == 401 and attempt == 0:
                    self.set("gdrive_token_expiry", "0")   # force a refresh
                    continue
                raise

    # ---- files

    def _list(self, query):
        files, page = [], None
        while True:
            params = {"spaces": "appDataFolder", "q": query, "pageSize": 1000,
                      "orderBy": "name", "fields": "nextPageToken,files(id,name)"}
            if page:
                params["pageToken"] = page
            out = json.loads(self._request(
                "GET", f"{DRIVE}/files?{urllib.parse.urlencode(params)}"))
            files.extend(out.get("files", []))
            page = out.get("nextPageToken")
            if not page:
                return files

    def _find(self, name, parent):
        found = self._list(f"name = '{_quote(name)}' and '{parent}' in parents "
                           f"and trashed = false")
        return found[0]["id"] if found else None

    def _create(self, name, data, content_type, parent):
        boundary = "vocabmaster" + secrets.token_hex(8)
        meta = json.dumps({"name": name, "parents": [parent]})
        body = (f"--{boundary}\r\nContent-Type: application/json; charset=UTF-8"
                f"\r\n\r\n{meta}\r\n--{boundary}\r\nContent-Type: {content_type}"
                f"\r\n\r\n").encode() + data + f"\r\n--{boundary}--".encode()
        out = self._request("POST", f"{UPLOAD}?uploadType=multipart&fields=id", body,
                            f"multipart/related; boundary={boundary}")
        return json.loads(out)["id"]

    def _put(self, name, data, content_type, parent, overwrite):
        existing = self._find(name, parent) if overwrite else None
        if existing:
            self._request("PATCH", f"{UPLOAD}/{existing}?uploadType=media", data,
                          content_type)
        else:
            self._create(name, data, content_type, parent)

    def _get(self, name, parent):
        file_id = self._find(name, parent)
        if not file_id:
            raise NotFound(f"{name} is not in the cloud yet", 404)
        return self._request("GET", f"{DRIVE}/files/{file_id}?alt=media")

    def _folder(self, name, parent, cache_key):
        """A sub-folder's id: remembered in a setting, found, or made."""
        folder = self.get(cache_key)
        if folder:
            return folder
        found = self._list(f"name = '{_quote(name)}' and mimeType = '{FOLDER}' "
                           f"and '{parent}' in parents and trashed = false")
        if found:
            folder = found[0]["id"]
        else:
            body = json.dumps({"name": name, "mimeType": FOLDER, "parents": [parent]}).encode()
            folder = json.loads(self._request(
                "POST", f"{DRIVE}/files?fields=id", body, "application/json"))["id"]
        self.set(cache_key, folder)
        return folder

    def _root(self):
        """Where this deck's logs live: the top of the app folder for the main
        deck (as always), its own sub-folder for every other deck."""
        space = self.get("gdrive_space") or ""
        if not space:
            return "appDataFolder"
        return self._folder(space, "appDataFolder", "gdrive_space_folder")

    def _images_folder(self):
        return self._folder(IMAGES_FOLDER, self._root(), "gdrive_images_folder")

    # ---- interface

    def list_logs(self):
        files = self._list(f"'{self._root()}' in parents and trashed = false "
                           f"and mimeType != '{FOLDER}'")
        return sorted(f["name"] for f in files if f["name"].endswith(".json"))

    def put_log(self, name, data):
        # Names carry a timestamp and the device id, so they never collide:
        # no lookup needed, one request per push.
        self._create(name, data, "application/json", self._root())

    def get_log(self, name):
        return self._get(name, self._root())

    # ---- decks (decks.py): a deck's folder carries a small description so
    # another computer signed in to the same Drive can find and open it.

    def put_deck_info(self, data):
        if self.get("gdrive_space"):
            self._put(DECK_INFO, data, "application/json", self._root(), overwrite=True)

    def list_decks(self, known=()):
        """[{"space", "name", "lang_target", …}] for every deck folder in this
        Drive; descriptions of `known` spaces (a dict space → entry) are reused."""
        known = dict(known)
        out = []
        for entry in self._list(f"mimeType = '{FOLDER}' and 'appDataFolder' in parents "
                                f"and trashed = false"):
            space = entry["name"]
            if not space.startswith("deck-"):
                continue
            if space in known:
                out.append(known[space])
                continue
            try:
                about = json.loads(self._get(DECK_INFO, entry["id"]).decode())
            except (NotFound, ValueError):
                continue
            if isinstance(about, dict):
                about["space"] = space
                out.append(about)
        return out

    def put_image(self, filename, data):
        self._put(filename, data, "image/webp", self._images_folder(), overwrite=True)

    def get_image(self, filename):
        return self._get(filename, self._images_folder())


# --------------------------------------------------------- Google sign-in

def read_client_file(path):
    """(client_id, client_secret) from the JSON Google Cloud lets you download
    for a 'Desktop app' OAuth client."""
    with open(path, encoding="utf-8") as handle:
        data = json.load(handle)
    client = data.get("installed") or data.get("web") or {}
    if not client.get("client_id") or not client.get("client_secret"):
        raise ValueError("this is not a Google OAuth client file "
                         "(expected client_secret_….json with an 'installed' entry)")
    return client["client_id"], client["client_secret"]


_DONE_PAGE = """<!doctype html><html><body style="font-family:sans-serif;
background:#0d1117;color:#f0f6fc;text-align:center;padding-top:18vh">
<h2>{title}</h2><p style="color:#8b949e">{text}</p></body></html>"""


def connect(get_setting, set_setting, client_id, client_secret, timeout=180):
    """Sign the user in with Google and store the tokens. Blocks until the
    browser comes back to us (or `timeout` seconds). Returns the account's
    e-mail when Google tells us, else ''.

    Loopback flow with PKCE: a throwaway server on 127.0.0.1 receives the
    redirect, so no secret ever travels through a third party."""
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    state = secrets.token_urlsafe(16)
    result = {}

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path != "/":                 # favicon and friends
                self.send_response(404)
                self.end_headers()
                return
            query = urllib.parse.parse_qs(parsed.query)
            if query.get("state", [""])[0] == state and "code" in query:
                result["code"] = query["code"][0]
                page = _DONE_PAGE.format(
                    title="VocabMaster is connected to your Google Drive",
                    text="You can close this tab and go back to the app.")
            else:
                result["error"] = query.get("error", ["no code returned"])[0]
                page = _DONE_PAGE.format(title="Sign-in did not finish",
                                         text=result["error"])
            body = page.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
    server.timeout = 5
    redirect = f"http://127.0.0.1:{server.server_port}"
    params = {"client_id": client_id, "redirect_uri": redirect,
              "response_type": "code", "scope": SCOPE, "state": state,
              "code_challenge": challenge, "code_challenge_method": "S256",
              "access_type": "offline", "prompt": "consent"}
    webbrowser.open(f"{AUTH_URL}?{urllib.parse.urlencode(params)}")
    deadline = time.time() + timeout
    try:
        while not result and time.time() < deadline:
            server.handle_request()
    finally:
        server.server_close()
    if "code" not in result:
        raise CloudError(result.get("error", "sign-in timed out — try again"))

    data = _form(TOKEN_URL, {
        "code": result["code"], "client_id": client_id,
        "client_secret": client_secret, "redirect_uri": redirect,
        "grant_type": "authorization_code", "code_verifier": verifier})
    if not data.get("refresh_token"):
        raise CloudError("Google returned no refresh token — try again and "
                         "allow the access it asks for")

    set_setting("gdrive_client_id", client_id)
    set_setting("gdrive_client_secret", client_secret)
    set_setting("gdrive_refresh_token", data["refresh_token"])
    set_setting("gdrive_access_token", data["access_token"])
    set_setting("gdrive_token_expiry", time.time() + float(data.get("expires_in", 3600)))
    set_setting("gdrive_images_folder", "")
    set_setting("gdrive_space_folder", "")
    set_setting("sync_backend", "gdrive")
    set_setting("sync_enabled", "1")

    account = ""
    try:
        about = json.loads(_http("GET", f"{DRIVE}/about?fields=user", headers={
            "Authorization": f"Bearer {data['access_token']}"}))
        account = about.get("user", {}).get("emailAddress", "")
    except Exception:
        pass                       # cosmetic; the connection itself is made
    set_setting("gdrive_account", account)
    return account


def disconnect(set_setting):
    """Forget the sign-in. The deck stays; so does everything in the Drive."""
    for key in ("gdrive_refresh_token", "gdrive_access_token",
                "gdrive_token_expiry", "gdrive_account", "gdrive_images_folder",
                "gdrive_space_folder"):
        set_setting(key, "")
    set_setting("sync_backend", "none")

"""How the word doctor's answer looks on a card (Study and Browse): a new
memory hook, the word it is confused with, and a two-sentence story with
readings and translations. Everything is escaped; only the layout is markup."""

import html

from styles import TEXT, TEXT_MUTED, TEXT_SECONDARY, WARNING


def rescue_html(rescue):
    parts = [f'<div style="color:{TEXT_SECONDARY}; font-size:8pt; font-weight:700; '
             f'letter-spacing:1px">🩺 A NEW WAY TO REMEMBER</div>']
    for index, line in enumerate(l.strip() for l in (rescue.get("hook") or "").splitlines()):
        if line:
            color = WARNING if index == 0 else TEXT_SECONDARY
            parts.append(f'<div style="color:{color}; font-size:11pt; margin-top:4px">'
                         f'{html.escape(line)}</div>')
    if rescue.get("contrast"):
        parts.append(f'<div style="color:{TEXT}; font-size:10.5pt; margin-top:8px">'
                     f'↔ {html.escape(rescue["contrast"])}</div>')
    for sentence in rescue.get("story") or []:
        parts.append(f'<div style="color:{TEXT}; font-size:11pt; margin-top:8px">'
                     f'{html.escape(sentence.get("text", ""))}</div>')
        if sentence.get("reading"):
            parts.append(f'<div style="color:{TEXT_SECONDARY}; font-size:10pt">'
                         f'{html.escape(sentence["reading"])}</div>')
        if sentence.get("translation"):
            parts.append(f'<div style="color:{TEXT_MUTED}; font-size:10pt; font-style:italic">'
                         f'{html.escape(sentence["translation"])}</div>')
    return "".join(parts)

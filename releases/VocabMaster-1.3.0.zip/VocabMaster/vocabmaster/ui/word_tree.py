"""Fan-right tree view of one word.

No new data: exactly the fields already on the card, re-arranged so the eye
grabs the structure instead of reading top to bottom. Every word puts the
same branch in the same place — after enough cards the position itself
becomes a way back to the meaning.
"""

from PyQt6.QtCore import QPointF, QRectF, QSize, Qt
from PyQt6.QtGui import QColor, QFont, QFontMetricsF, QPainter, QPen
from PyQt6.QtWidgets import QSizePolicy, QWidget

import flags
from styles import ACCENT, BORDER, TEXT, TEXT_MUTED, TEXT_SECONDARY

# Hooks are written as prose ("A vivid image: ..."). The branch is already
# labelled PICTURE, so that prefix is noise here.
_IMAGE_PREFIXES = ("a vivid image:", "vivid image:", "an image:", "image:", "picture:")

WRAP = int(Qt.TextFlag.TextWordWrap)
TOP_LEFT = int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
LEFT_MID = int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

PAD = 10
WORD_GAP = 30      # word block -> spine
STUB = 22          # spine -> label
LABEL_GAP = 18     # label -> content
BRANCH_GAP = 15    # between branches
SEGMENT_GAP = 3    # between lines inside one branch
MIN_CONTENT = 150


def _strip_prefix(line):
    low = line.lower()
    for prefix in _IMAGE_PREFIXES:
        if low.startswith(prefix):
            return line[len(prefix):].strip()
    return line


def _bullets(raw, sep):
    parts = [p.strip() for p in (raw or "").split(sep) if p.strip()]
    return "  ·  ".join(parts)


def build_branches(card, langs=None, show_hook=True):
    """(label, [(text, style)]) in a fixed order — the same shape every word.
    `langs` names the translation columns; without it the legacy labels.
    `show_hook` False leaves the HOOK branch out (Settings → Memory hooks)."""
    native_label = langs.native_label if langs else "ΕΛΛΗΝΙΚΑ"
    second_label = langs.second_label if langs else "SVENSKA"
    branches = []

    definition = (card.get("definition") or "").strip()
    if definition:
        branches.append(("MEANS", [(definition, "lead")]))

    reading = (card.get("reading") or "").strip()
    if reading:
        branches.append(("READ", [(reading, "muted")]))

    example = (card.get("example") or "").strip()
    if example:
        segments = [("“" + example + "”", "quote")]
        for extra in ("example_reading", "example_tr"):
            text = (card.get(extra) or "").strip()
            if text:
                segments.append((text, "muted"))
        branches.append(("SAID", segments))

    synonyms = _bullets(card.get("synonyms"), "|")
    if synonyms:
        branches.append(("SIMILAR", [(synonyms, "muted")]))

    tongues = []
    greek = _bullets(card.get("greek"), ",") if native_label else ""
    if greek:
        tongues.append((greek, "native"))
    swedish = _bullets(card.get("swedish"), ",") if second_label else ""
    if swedish:
        # Under the native label the second language needs its own tag.
        tongues.append((swedish, "muted"))
    if tongues:
        branches.append((native_label if greek else second_label, tongues))
        branches[-1] = branches[-1] + (langs.native if (langs and greek) else (langs.second if langs else None),)

    hook = (card.get("hook") or "").strip() if show_hook else ""
    if hook:
        lines = [line.strip() for line in hook.splitlines() if line.strip()]
        segments = [(_strip_prefix(lines[0]), "accent")]
        segments += [(line, "muted") for line in lines[1:]]
        branches.append(("HOOK", segments))

    return branches


class WordTreeWidget(QWidget):
    """Draws the fan. A pure renderer — it holds no state but the card."""

    _COLORS = {"lead": TEXT, "quote": TEXT_SECONDARY, "muted": TEXT_SECONDARY,
               "accent": ACCENT, "native": TEXT}

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("background: transparent;")
        self._card = None
        self._branches = []
        policy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        policy.setHeightForWidth(True)
        self.setSizePolicy(policy)

    def set_card(self, card, langs=None, show_hook=True):
        self._card = card
        self._branches = build_branches(card, langs, show_hook) if card else []
        self.updateGeometry()
        self.update()

    # ---------------------------------------------------------------- fonts

    def _fonts(self):
        base = self.font()
        size = base.pointSizeF()

        word = QFont(base)
        word.setPointSizeF(size + 15)
        word.setBold(True)

        pos = QFont(base)
        pos.setPointSizeF(size + 4)

        label = QFont(base)
        label.setPointSizeF(max(7.0, size - 1.5))
        label.setBold(True)
        label.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.4)

        lead = QFont(base)
        lead.setPointSizeF(size + 1.5)

        body = QFont(base)
        body.setPointSizeF(size + 0.5)

        quote = QFont(body)
        quote.setItalic(True)

        native = QFont(base)
        native.setPointSizeF(size + 2)

        return {"word": word, "pos": pos, "label": label, "lead": lead,
                "muted": body, "quote": quote, "accent": body, "native": native}

    # --------------------------------------------------------------- layout

    def _geometry(self, width):
        """Everything the painter needs — so height and paint never disagree."""
        fonts = self._fonts()
        card = self._card or {}

        fm_word = QFontMetricsF(fonts["word"])
        fm_pos = QFontMetricsF(fonts["pos"])
        fm_label = QFontMetricsF(fonts["label"])

        word_text = (card.get("word") or "").strip()
        pos = (card.get("pos") or "").strip()
        pos_text = "  [ " + pos + " ]" if pos else ""
        word_only_w = fm_word.horizontalAdvance(word_text)
        word_w = word_only_w + fm_pos.horizontalAdvance(pos_text)

        label_w = max([flags.W if len(b) > 2 and flags.pixmap(b[2]) else fm_label.horizontalAdvance(b[0])
                       for b in self._branches] or [0])

        spine_x = PAD + word_w + WORD_GAP
        label_x = spine_x + STUB
        content_x = label_x + label_w + LABEL_GAP
        content_w = width - content_x - PAD

        # Narrow window: take room from the word block rather than crush the text.
        if content_w < MIN_CONTENT:
            spine_x = max(PAD + 40.0, spine_x - (MIN_CONTENT - content_w))
            label_x = spine_x + STUB
            content_x = label_x + label_w + LABEL_GAP
            content_w = max(80.0, width - content_x - PAD)

        rows = []
        y = float(PAD)
        for branch in self._branches:
            name, segments = branch[0], branch[1]
            top = y
            drawn = []
            for text, style in segments:
                fm = QFontMetricsF(fonts[style])
                height = fm.boundingRect(QRectF(0, 0, content_w, 10000), WRAP, text).height()
                drawn.append((text, style, y, height))
                y += height + SEGMENT_GAP
            y -= SEGMENT_GAP
            rows.append({"label": name, "top": top, "segments": drawn,
                         "flag": branch[2] if len(branch) > 2 else None})
            y += BRANCH_GAP
        content_h = (y - BRANCH_GAP) - PAD if rows else 0.0

        return {"fonts": fonts, "word_text": word_text, "pos_text": pos_text,
                "word_only_w": word_only_w, "word_w": word_w,
                "spine_x": spine_x, "label_x": label_x, "content_x": content_x,
                "content_w": content_w, "rows": rows, "content_h": content_h,
                "word_h": fm_word.height(), "label_h": fm_label.height()}

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        if not self._branches:
            return 0
        geo = self._geometry(max(float(width), 200.0))
        return int(max(geo["content_h"], geo["word_h"]) + PAD * 2)

    def sizeHint(self):
        width = max(self.width(), 600)
        return QSize(width, self.heightForWidth(width))

    def minimumSizeHint(self):
        return QSize(320, self.heightForWidth(max(self.width(), 320)))

    # ---------------------------------------------------------------- paint

    def paintEvent(self, event):
        if not self._branches:
            return
        geo = self._geometry(float(self.width()))
        rows = geo["rows"]
        fonts = geo["fonts"]
        half_label = geo["label_h"] / 2

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        # Centre the whole fan in whatever height the layout gave us.
        offset = max(0.0, (self.height() - geo["content_h"] - PAD * 2) / 2)

        spine_x = geo["spine_x"]
        spine_top = rows[0]["top"] + offset + half_label
        spine_bottom = rows[-1]["top"] + offset + half_label

        pen = QPen(QColor(BORDER))
        pen.setWidthF(1.4)
        painter.setPen(pen)
        painter.drawLine(QPointF(spine_x, spine_top), QPointF(spine_x, spine_bottom))

        # The word sits centred against the spine, joined by one connector.
        word_mid = (spine_top + spine_bottom) / 2
        painter.drawLine(QPointF(PAD + geo["word_w"] + 8, word_mid), QPointF(spine_x, word_mid))

        word_rect = QRectF(PAD, word_mid - geo["word_h"] / 2, geo["word_w"], geo["word_h"])
        painter.setFont(fonts["word"])
        painter.setPen(QColor(TEXT))
        painter.drawText(word_rect, LEFT_MID, geo["word_text"])
        if geo["pos_text"]:
            painter.setFont(fonts["pos"])
            painter.setPen(QColor(TEXT_MUTED))
            painter.drawText(word_rect.adjusted(geo["word_only_w"], 0, 0, 0),
                             LEFT_MID, geo["pos_text"])

        for row in rows:
            label_mid = row["top"] + offset + half_label

            painter.setPen(pen)
            painter.drawLine(QPointF(spine_x, label_mid),
                             QPointF(geo["label_x"] - 8, label_mid))

            label_x = geo["label_x"]
            flag = flags.pixmap(row["flag"]) if row.get("flag") else None
            if flag:
                painter.drawPixmap(QPointF(label_x, row["top"] + offset + (geo["label_h"] - flags.H) / 2), flag)
            else:
                painter.setFont(fonts["label"])
                painter.setPen(QColor(ACCENT))
                painter.drawText(QRectF(label_x, row["top"] + offset,
                                        geo["content_x"] - label_x, geo["label_h"]),
                                 TOP_LEFT, row["label"])

            for text, style, y, height in row["segments"]:
                painter.setFont(fonts[style])
                painter.setPen(QColor(self._COLORS[style]))
                painter.drawText(QRectF(geo["content_x"], y + offset,
                                        geo["content_w"], height),
                                 WRAP | TOP_LEFT, text)

        painter.end()

"""The microphone, through Qt Multimedia (part of PyQt6 — no extra package).

Recorder.start() records the default microphone as 16-bit mono (or the
device's own format, converted); stop() — or voice.MAX_SECONDS — ends it
and emits `finished(pcm, rate)`. Nothing is written to disk. `failed(text)`
says in plain words what to do when there is no microphone or the system
does not allow it.
"""

import os
import platform

from PyQt6.QtCore import QObject, QTimer, pyqtSignal

import voice

try:
    from PyQt6.QtMultimedia import QAudioFormat, QAudioSource, QMediaDevices
except ImportError:          # a Qt without multimedia: the 🎤 button stays hidden
    QAudioFormat = QAudioSource = QMediaDevices = None

FORMATS = {"Int16": "int16", "Int32": "int32", "Float": "float", "UInt8": "uint8"}


def privacy_hint():
    if platform.system() == "Darwin":
        return ("System Settings → Privacy & Security → Microphone → switch on "
                "VocabMaster")
    if platform.system() == "Windows":
        return ("Windows Settings → Privacy & security → Microphone → switch on "
                "“Let desktop apps access your microphone”")
    return "your system's sound settings"


def mac_bundle_ready():
    """macOS ends an app that opens the microphone without saying why in its
    Info.plist. The .app made by setup-mac.command before 1.1.0 did not, so
    it must be made again; started from a terminal, the terminal asks."""
    bundle = os.environ.get("VOCABMASTER_APP")
    if bundle:
        try:
            with open(os.path.join(bundle, "Contents", "Info.plist"), "rb") as plist:
                return b"NSMicrophoneUsageDescription" in plist.read()
        except OSError:
            return False
    return bool(os.environ.get("TERM_PROGRAM"))


def available():
    """(True, '') when a microphone can be used, else (False, why)."""
    if QAudioSource is None:
        return False, "this copy of Qt has no sound recording"
    if QMediaDevices.defaultAudioInput().isNull():
        return False, "no microphone found — plug one in (a headset works best)"
    return True, ""


class Recorder(QObject):
    tick = pyqtSignal(float)                 # seconds recorded so far
    finished = pyqtSignal(bytes, int)        # 16-bit mono PCM, sample rate
    failed = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.source = None
        self.device = None
        self.chunks = []
        self.format = None
        self.elapsed = 0.0
        self.timer = QTimer(self)
        self.timer.setInterval(100)
        self.timer.timeout.connect(self._on_tick)

    def recording(self):
        return self.source is not None

    def start(self):
        ok, why = available()
        if not ok:
            self.failed.emit(why)
            return
        if platform.system() == "Darwin":
            if not mac_bundle_ready():
                self.failed.emit("on the Mac, double-click setup-mac.command once more — it "
                                 "lets VocabMaster use the microphone")
                return
            if not self._mac_allowed():
                return
        device = QMediaDevices.defaultAudioInput()
        fmt = QAudioFormat()
        fmt.setSampleRate(16000)
        fmt.setChannelCount(1)
        fmt.setSampleFormat(QAudioFormat.SampleFormat.Int16)
        if not device.isFormatSupported(fmt):
            fmt = device.preferredFormat()
        if fmt.sampleFormat().name not in FORMATS:
            self.failed.emit("the microphone uses a sound format VocabMaster cannot read")
            return
        self.format = fmt
        self.chunks = []
        self.elapsed = 0.0
        self.source = QAudioSource(device, fmt, self)
        self.device = self.source.start()
        if self.device is None or self._error():
            self._abandon()
            self.failed.emit(f"the microphone could not be opened — {privacy_hint()}")
            return
        self.device.readyRead.connect(self._read)
        self.timer.start()

    def _error(self):
        error = self.source.error()
        return getattr(error, "name", "NoError") != "NoError"

    def _read(self):
        if self.device is not None:
            self.chunks.append(bytes(self.device.readAll()))

    def _on_tick(self):
        self.elapsed += 0.1
        if self.source is not None and self._error():
            self._abandon()
            self.failed.emit(f"the microphone stopped — {privacy_hint()}")
            return
        self.tick.emit(self.elapsed)
        if self.elapsed >= voice.MAX_SECONDS:
            self.stop()

    def stop(self):
        """End the recording and hand over what was said."""
        if self.source is None:
            return
        self._read()
        fmt = self.format
        raw = b"".join(self.chunks)
        self._abandon()
        pcm = voice.to_mono16(raw, FORMATS[fmt.sampleFormat().name], fmt.channelCount())
        self.finished.emit(pcm, fmt.sampleRate())

    def cancel(self):
        self._abandon()

    def _abandon(self):
        self.timer.stop()
        if self.source is not None:
            try:
                self.source.stop()
            except RuntimeError:
                pass
            self.source.deleteLater()
        self.source = None
        self.device = None
        self.chunks = []

    def _mac_allowed(self):
        """macOS asks the user once; until they answer, nothing records."""
        try:
            from PyQt6.QtCore import QCoreApplication, QMicrophonePermission, Qt
            app = QCoreApplication.instance()
            permission = QMicrophonePermission()
            status = app.checkPermission(permission)
            if status == Qt.PermissionStatus.Granted:
                return True
            if status == Qt.PermissionStatus.Undetermined:
                app.requestPermission(permission, lambda *_: None)
                self.failed.emit("allow the microphone in the box macOS shows, then press 🎤 again")
                return False
            self.failed.emit(f"macOS does not allow the microphone — {privacy_hint()}")
            return False
        except Exception:
            return True               # older Qt: macOS asks by itself

"""The deck switcher at the top of the sidebar, and the New deck dialog.

The button shows the open deck — flag, language, name ("Korean · Mike").
Its menu lists every deck on this computer with its word count, offers the
decks another computer put in this Google Drive ("open here"), a new deck
and renaming this one. Choosing a deck saves, closes and reopens the app on
it (MainWindow.switch_deck).
"""

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QDialog, QDialogButtonBox, QFormLayout, QInputDialog, QLabel, QLineEdit, QMenu,
    QPushButton, QVBoxLayout,
)

import decks
import flags
import languages
from styles import TEXT_SECONDARY, wrapping
from ui.widgets import ComboBox


def _words(count):
    return "no words yet" if not count else f"{count:,} word{'s' if count != 1 else ''}"


class DeckButton(QPushButton):
    """The open deck; click for the menu."""

    def __init__(self, window):
        super().__init__()
        self.window = window
        self.setObjectName("deckButton")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("Your decks — one per language. Click to switch or start a new one.")
        self.setStyleSheet("QPushButton#deckButton { text-align: left; padding: 8px 12px; "
                           "font-weight: 600; }")
        self.clicked.connect(self.open_menu)
        self.refresh()

    def here(self):
        """The deck the window has open."""
        path = self.window.db.path
        return decks.info(decks.deck_of(path), path)

    def refresh(self):
        here = self.here()
        self.setIcon(flags.icon(here["target"]))
        self.setText(f"{decks.label(here)}  ▾")

    def build_menu(self):
        menu = QMenu(self)
        open_id = decks.deck_of(self.window.db.path)
        for deck in decks.all_info():
            here = deck["id"] == open_id
            action = menu.addAction(flags.icon(deck["target"]),
                                    f"{decks.label(deck)}   ({_words(deck['words'])})"
                                    + ("   ✓" if here else ""))
            if not here:
                action.triggered.connect(lambda _, d=deck["id"]: self.window.switch_deck(d))
        remote = decks.remote_only(self.window.db.path)
        if remote:
            menu.addSeparator()
            note = menu.addAction("In your Google Drive, from another computer:")
            note.setEnabled(False)
            for about in remote:
                name = (about.get("deck_name") or "").strip()
                text = about["lang_target"] + (f" · {name}" if name else "")
                action = menu.addAction(flags.icon(about["lang_target"]), f"{text}   — open here")
                action.triggered.connect(lambda _, a=about: self.window.join_deck(a))
        menu.addSeparator()
        menu.addAction("＋  New deck…", lambda: self.window.new_deck())
        menu.addAction("✎  Rename this deck…", self.rename)
        return menu

    def open_menu(self):
        self.build_menu().exec(self.mapToGlobal(self.rect().bottomLeft()))

    def rename(self):
        here = self.here()
        name, ok = QInputDialog.getText(
            self, "Rename this deck",
            f"A name for your {here['target']} deck — who learns with it, e.g. your first name:",
            text=here["name"])
        if ok:
            self.window.db.set_setting("deck_name", name.strip())
            self.refresh()
            self.window.update_title()


class NewDeckDialog(QDialog):
    """Name (optional) and languages for a new deck."""

    def __init__(self, parent, db, target=None):
        super().__init__(parent)
        self.setWindowTitle("New deck")
        self.setMinimumWidth(460)
        current = languages.load(db.get_setting)
        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        intro = wrapping(QLabel(
            "A deck is one language you learn, with its own words, progress, streak and "
            "stats. Your other decks stay exactly as they are — switch between them at "
            "the top left."))
        intro.setStyleSheet(f"color: {TEXT_SECONDARY};")
        layout.addWidget(intro)
        form = QFormLayout()
        form.setSpacing(10)
        self.name = QLineEdit(db.get_setting("deck_name", "") or "")
        self.name.setPlaceholderText("optional — e.g. your first name")
        form.addRow("Name", self.name)
        self.target = self._combo()
        start = target or next((c for c in languages.CHOICES if c != current.target), "English")
        self.target.setCurrentText(start)
        form.addRow("I want to learn", self.target)
        self.definition = self._combo()
        form.addRow("Explain the words in", self.definition)
        self.native = self._combo(optional=True)
        form.addRow("Translation into", self.native)
        layout.addLayout(form)
        self.note = wrapping(QLabel(""))
        self.note.setStyleSheet(f"color: {TEXT_SECONDARY};")
        layout.addWidget(self.note)
        buttons = QDialogButtonBox()
        self.create_button = buttons.addButton("Create and open", QDialogButtonBox.ButtonRole.AcceptRole)
        self.create_button.setObjectName("primary")
        buttons.addButton("Cancel", QDialogButtonBox.ButtonRole.RejectRole)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self._current = current
        self.target.currentTextChanged.connect(self._suggest)
        self._suggest()

    def _combo(self, optional=False):
        box = ComboBox()
        if optional:
            box.addItem(languages.NONE)
        for choice in languages.CHOICES:
            box.addItem(flags.icon(choice), choice)
        return box

    def _suggest(self):
        """Explain in the language the person reads best (this deck's), with a
        translation into their own — never into the language being learned."""
        target = self.target.currentText()
        own = self._current.native or self._current.definition or "English"
        explain = self._current.definition if self._current.definition != target else own
        if explain == target:
            explain = next(c for c in languages.CHOICES if c != target)
        self.definition.setCurrentText(explain)
        native = own if own not in (target, explain) else languages.NONE
        self.native.setCurrentText(native)
        self.note.setText(
            f"Next: Add Words → build a {target} starter deck. "
            + (f"The {target} alphabet is in the menu too." if target.lower() in
               ("korean", "japanese", "greek") else ""))

    def values(self):
        native = self.native.currentText()
        target = self.target.currentText()
        second = self._current.second
        if second in (target, native, ""):
            second = ""
        return self.name.text().strip(), {
            "lang_target": target,
            "lang_definition": self.definition.currentText(),
            "lang_native": "" if native in (languages.NONE, target) else native,
            "lang_second": second or "",
        }

"""The card illustration, with its callouts drawn by Qt.

The generated picture carries no text — image models misspell it, and a
misspelled headword on a vocabulary card teaches the wrong thing. So the
model supplies a clean scene and the labels arrive as data, painted here.

That keeps every label correctly spelled, themed with the rest of the app,
and re-editable without paying to regenerate the picture.
"""

from PyQt6.QtCore import QPointF, QRectF, QSize, Qt
from PyQt6.QtGui import (
    QColor, QFont, QFontMetricsF, QPainter, QPainterPath, QPen, QPixmap,
)
from PyQt6.QtWidgets import QSizePolicy, QWidget

from styles import ACCENT, BG, BORDER, TEXT

IMAGE_HEIGHT = 330      # tall enough to read, short enough to keep the card whole
IMAGE_MIN_HEIGHT = 150  # a short window shrinks the picture, never overlaps text
RADIUS = 10
BUBBLE_PAD = 9
BUBBLE_RADIUS = 7
BUBBLE_MAX_W = 230
MARGIN = 14             # bubble inset from the image edge
ARROW = 6.0

# Where each callout sits, and the point in the picture it reaches toward.
# Fractions of the image rect, so they hold at any size.
ANCHORS = [
    {"corner": "top-left", "target": (0.46, 0.42)},
    {"corner": "bottom-right", "target": (0.56, 0.62)},
]


class ImageCard(QWidget):
    """One illustration plus up to two callouts pointing into it."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pixmap = None
        self._callouts = []
        self._max_height = IMAGE_HEIGHT
        # Preferred, not Fixed: the picture gives up height before it is
        # allowed to overlap the words underneath it.
        self.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Preferred)
        self.setStyleSheet("background: transparent;")

    def set_image(self, path, callouts=None):
        """Point the widget at an image file. A missing or unreadable file
        hides the widget rather than leaving a broken frame on the card."""
        self._callouts = [c for c in (callouts or []) if c][:2]
        pixmap = QPixmap(path) if path else QPixmap()
        self._pixmap = None if pixmap.isNull() else pixmap
        # A height range rather than a fixed height: the callouts are placed
        # against whatever rect is actually painted, so both stay together
        # however much room the card ends up with.
        self.setMinimumHeight(min(IMAGE_MIN_HEIGHT, self._max_height) if self._pixmap else 0)
        self.setMaximumHeight(self._max_height if self._pixmap else 0)
        self.setVisible(self._pixmap is not None)
        self.updateGeometry()
        self.update()

    def set_max_height(self, height):
        """The screen tells the picture how much it may take (window height)."""
        self._max_height = max(60, min(IMAGE_HEIGHT, height))
        if self._pixmap:
            self.setMinimumHeight(min(IMAGE_MIN_HEIGHT, self._max_height))
            self.setMaximumHeight(self._max_height)
            self.updateGeometry()

    def clear(self):
        self._pixmap = None
        self._callouts = []
        self.setMinimumHeight(0)
        self.setMaximumHeight(0)
        self.setVisible(False)

    def has_image(self):
        return self._pixmap is not None

    def sizeHint(self):
        return QSize(self.width() or 600, self._max_height if self._pixmap else 0)

    def minimumSizeHint(self):
        return QSize(240, IMAGE_MIN_HEIGHT if self._pixmap else 0)

    # ------------------------------------------------------------------ paint

    def _image_rect(self):
        """The picture, centred and aspect-preserved inside the widget."""
        size = self._pixmap.size()
        scale = min(self.width() / size.width(), self.height() / size.height())
        width, height = size.width() * scale, size.height() * scale
        return QRectF((self.width() - width) / 2, (self.height() - height) / 2,
                      width, height)

    def _bubble_font(self):
        font = QFont(self.font())
        font.setPointSizeF(max(8.5, font.pointSizeF() - 0.5))
        return font

    def paintEvent(self, event):
        if not self._pixmap:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        image_rect = self._image_rect()

        # Rounded corners: clip to the path rather than masking the pixmap,
        # so the scaling stays smooth at any widget width.
        clip = QPainterPath()
        clip.addRoundedRect(image_rect, RADIUS, RADIUS)
        painter.save()
        painter.setClipPath(clip)
        painter.drawPixmap(image_rect, self._pixmap,
                           QRectF(self._pixmap.rect()))
        painter.restore()

        painter.setPen(QPen(QColor(BORDER), 1))
        painter.drawRoundedRect(image_rect, RADIUS, RADIUS)

        font = self._bubble_font()
        painter.setFont(font)
        metrics = QFontMetricsF(font)
        for callout, anchor in zip(self._callouts, ANCHORS):
            self._draw_callout(painter, metrics, image_rect, callout, anchor)
        painter.end()

    def _draw_callout(self, painter, metrics, image_rect, text, anchor):
        max_text = min(BUBBLE_MAX_W, image_rect.width() / 2 - MARGIN * 2)
        if max_text < 60:
            return                      # too narrow to label without covering it
        bounds = metrics.boundingRect(
            QRectF(0, 0, max_text, 1000),
            int(Qt.TextFlag.TextWordWrap), text)
        width = bounds.width() + BUBBLE_PAD * 2
        height = bounds.height() + BUBBLE_PAD * 2

        if anchor["corner"] == "top-left":
            left = image_rect.left() + MARGIN
            top = image_rect.top() + MARGIN
        else:
            left = image_rect.right() - MARGIN - width
            top = image_rect.bottom() - MARGIN - height
        bubble = QRectF(left, top, width, height)

        target = QPointF(
            image_rect.left() + image_rect.width() * anchor["target"][0],
            image_rect.top() + image_rect.height() * anchor["target"][1])

        # Leader first, so the bubble paints over its own tail.
        start = QPointF(bubble.center().x(),
                        bubble.bottom() if anchor["corner"] == "top-left"
                        else bubble.top())
        self._draw_leader(painter, start, target)

        painter.setPen(QPen(QColor(ACCENT), 1))
        painter.setBrush(QColor(BG).darker(105))
        painter.setOpacity(0.93)
        painter.drawRoundedRect(bubble, BUBBLE_RADIUS, BUBBLE_RADIUS)
        painter.setOpacity(1.0)

        painter.setPen(QColor(TEXT))
        painter.drawText(bubble.adjusted(BUBBLE_PAD, BUBBLE_PAD,
                                         -BUBBLE_PAD, -BUBBLE_PAD),
                         int(Qt.TextFlag.TextWordWrap), text)

    def _draw_leader(self, painter, start, end):
        """A thin line from the bubble to the thing it is talking about."""
        pen = QPen(QColor(ACCENT))
        pen.setWidthF(1.3)
        painter.setPen(pen)
        painter.setBrush(QColor(ACCENT))
        painter.drawLine(start, end)

        # A small solid head, built from the line's own direction so it always
        # points at the target whatever the bubble size worked out to be.
        dx, dy = end.x() - start.x(), end.y() - start.y()
        length = (dx * dx + dy * dy) ** 0.5
        if length < 1:
            return
        ux, uy = dx / length, dy / length
        base = QPointF(end.x() - ux * ARROW, end.y() - uy * ARROW)
        painter.drawPolygon(
            end,
            QPointF(base.x() - uy * ARROW * 0.5, base.y() + ux * ARROW * 0.5),
            QPointF(base.x() + uy * ARROW * 0.5, base.y() - ux * ARROW * 0.5))

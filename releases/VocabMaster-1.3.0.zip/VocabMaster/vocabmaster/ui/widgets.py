"""Input widgets that ignore the mouse wheel unless they have focus.

A page that scrolls is full of spin boxes and combos; a wheel that lands
on one while scrolling changes a setting — the daily budget, the language —
without anyone noticing. These only react to the wheel after a click.
"""

import time

from PyQt6.QtCore import QRectF, Qt, QTimer
from PyQt6.QtGui import QColor, QPainter, QPen
from PyQt6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QHBoxLayout, QLabel, QSpinBox, QTimeEdit, QWidget,
)

from styles import ACCENT, BORDER, TEXT_SECONDARY


class _NoWheelUnlessFocused:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def wheelEvent(self, event):
        if self.hasFocus():
            super().wheelEvent(event)
        else:
            event.ignore()          # let the page scroll instead


class SpinBox(_NoWheelUnlessFocused, QSpinBox):
    pass


class DoubleSpinBox(_NoWheelUnlessFocused, QDoubleSpinBox):
    pass


class ComboBox(_NoWheelUnlessFocused, QComboBox):
    pass


class TimeEdit(_NoWheelUnlessFocused, QTimeEdit):
    pass


class Spinner(QWidget):
    """A small turning arc: "working on it". Hidden until start()."""

    def __init__(self, size=18, parent=None):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self._angle = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._turn)
        self.hide()

    def start(self):
        self._angle = 0
        self.show()
        self._timer.start(30)

    def stop(self):
        self._timer.stop()
        self.hide()

    def is_spinning(self):
        return self._timer.isActive()

    def _turn(self):
        self._angle = (self._angle + 10) % 360
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        box = QRectF(2.5, 2.5, self.width() - 5, self.height() - 5)
        track = QPen(QColor(BORDER), 2.5)
        painter.setPen(track)
        painter.drawEllipse(box)
        arc = QPen(QColor(ACCENT), 2.5)
        arc.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(arc)
        painter.drawArc(box, -self._angle * 16, 100 * 16)


class WorkingLine(QWidget):
    """Spinner + a sentence + the seconds so far: what a long AI job shows
    while it runs, so nobody wonders whether anything is happening.
    `start(text)`, `set_text(text)` as it progresses, `stop()` when done."""

    def __init__(self, parent=None):
        super().__init__(parent)
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 2, 0, 2)
        row.setSpacing(10)
        self.spinner = Spinner()
        row.addWidget(self.spinner)
        self.label = QLabel("")
        self.label.setTextFormat(Qt.TextFormat.PlainText)
        self.label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        self.label.setWordWrap(True)
        row.addWidget(self.label, 1)
        self._text = ""
        self._started = 0.0
        self._clock = QTimer(self)
        self._clock.timeout.connect(self._show)
        self.hide()

    def start(self, text):
        self._text = text
        self._started = time.monotonic()
        self._show()
        self.spinner.start()
        self._clock.start(1000)
        self.show()

    def set_text(self, text):
        self._text = text
        self._show()

    def stop(self):
        self._clock.stop()
        self.spinner.stop()
        self.hide()

    def running(self):
        return self._clock.isActive()

    def _show(self):
        seconds = int(time.monotonic() - self._started)
        self.label.setText(f"{self._text}   {seconds} s" if seconds else self._text)

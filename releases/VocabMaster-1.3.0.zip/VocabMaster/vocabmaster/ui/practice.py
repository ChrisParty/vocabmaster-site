"""Practice screen: use the words you know.

Today's story — a few sentences made from the learner's own words, each
with its reading and (on request) its translation, the learner's words
highlighted, up to two new words that can be added to the deck, and three
questions. Talk — a short guided conversation in a chosen scene: the
partner's lines with reading and translation, three suggested answers a
beginner can click, gentle corrections, at most practice.TALK_TURNS turns.
Talk can be spoken: 🎤 records the answer (voice.py writes it down, the
learner checks it, then Send), "Say it in <own language>" turns what they
want to say into a line to say, and the partner's replies are read aloud by
the computer's own voice.

Every AI call starts from a button, runs off the UI thread with a
WorkingLine, and goes through the one spending gate. Nothing here touches
the cards' schedule, sessions, streak or stats.
"""

import html
import random
import re
import threading

from PyQt6.QtCore import QEasingCurve, Qt, QTimer, QVariantAnimation, pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QFrame, QGraphicsDropShadowEffect, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

import cards_ai
import languages
import practice
import voice
from styles import ACCENT, DANGER, SUCCESS, TEXT, TEXT_MUTED, TEXT_SECONDARY, WARNING, wrapping
from ui.flashcard import has_voice, listen_button_tip, speak
from ui.recorder import Recorder, available as mic_available
from ui.widgets import ComboBox, WorkingLine
from ui.wordlabel import WordAdder, WordLabel, addable as addable_word

LEVEL_CHOICES = [("Level: automatic", None), ("Beginner", "beginner"),
                 ("Intermediate", "intermediate"), ("Advanced", "advanced")]


def _plain():
    """A container that does not paint the page background over a card."""
    widget = QWidget()
    widget.setObjectName("plain")
    widget.setStyleSheet("QWidget#plain { background: transparent; }")
    return widget


def _clear(layout):
    while layout.count():
        item = layout.takeAt(0)
        if item.widget() is not None:
            item.widget().deleteLater()
        elif item.layout() is not None:
            _clear(item.layout())


def _label(text="", style="", rich=False, target=False):
    """Every label here can be selected and copied; `target` marks text in the
    learning language, where a selected word can be added to the deck."""
    label = WordLabel(text, addable=target)
    label.setTextFormat(Qt.TextFormat.RichText if rich else Qt.TextFormat.PlainText)
    if style:
        label.setStyleSheet(style)
    wrapping(label)
    return label


def _card(title=None):
    frame = QFrame()
    frame.setObjectName("card")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(24, 18, 24, 18)
    layout.setSpacing(10)
    if title:
        heading = QLabel(title)
        heading.setStyleSheet("font-weight: 700; font-size: 12pt;")
        layout.addWidget(heading)
    return frame, layout


def highlight(text, words):
    """The sentence as rich text with the learner's own words in the accent
    colour. Everything is escaped; only the spans are markup."""
    forms = set()
    for w in words:
        forms.add(w["word"])
        kana = (w.get("reading") or "").split("·")[0].strip()
        if kana and any(0x3040 <= ord(c) <= 0x30FF for c in kana):
            forms.add(kana)
    forms = sorted((f for f in forms if f and len(f) >= 1), key=len, reverse=True)
    if not forms:
        return html.escape(text)
    pattern = re.compile("|".join(re.escape(f) for f in forms), re.IGNORECASE)
    out, last = [], 0
    for match in pattern.finditer(text):
        before = text[last:match.start()]
        # Latin words only on word boundaries ("art" is not inside "start").
        latin = match.group(0).isascii()
        if latin and ((match.start() > 0 and text[match.start() - 1].isalnum())
                      or (match.end() < len(text) and text[match.end()].isalnum())):
            continue
        out.append(html.escape(before))
        out.append(f"<span style='color:{ACCENT}; font-weight:600'>"
                   f"{html.escape(match.group(0))}</span>")
        last = match.end()
    out.append(html.escape(text[last:]))
    return "".join(out)


class PracticeScreen(QWidget):
    story_done = pyqtSignal(object, str)      # story dict or None, error text
    talk_done = pyqtSignal(object, str)       # turn dict or None, error text
    heard = pyqtSignal(str, str, str)         # mode ("say" / "help"), text, error
    helped = pyqtSignal(object, str)          # line to say or None, error

    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self.langs = languages.load(db.get_setting)
        self.story = None
        self.show_translations = False
        self._story_busy = False
        self._talk_busy = False
        self.history = []                     # [{"who": "partner"|"learner", "text": str}]
        self.scene = ""
        self.turns = 0
        self.talk_over = True
        self._pending = None                  # the last talk request, for "Try again"
        self.story_done.connect(self._on_story)
        self.talk_done.connect(self._on_turn)
        self.adder = WordAdder(db.path, self)
        self.adder.done.connect(self._on_word_added)
        self._adding_on_talk = False
        self.heard.connect(self._on_heard)
        self.helped.connect(self._on_helped)
        self.recorder = Recorder(self)
        self.recorder.tick.connect(self._on_record_tick)
        self.recorder.finished.connect(self._on_recorded)
        self.recorder.failed.connect(self._on_record_failed)
        self._record_mode = None              # "say" / "help" while the microphone is on
        self._last_lines = []                 # the partner's line + ideas: hints for transcription
        self._send_glow = None                # the pulse on Send while a spoken answer waits

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(self.scroll)
        content = QWidget()
        self.scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)

        header = QLabel("Practice")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(header)
        intro = _label("Use the words you know: read a short story made from them, or "
                       "have a short conversation. Separate from your cards — nothing "
                       "here changes your streak or stats. A word you want to learn: "
                       "select it, right-click, Add to my deck.", f"color: {TEXT_SECONDARY};")
        layout.addWidget(intro)

        modes = QHBoxLayout()
        modes.setSpacing(10)
        self.mode_group = QButtonGroup(self)
        self.mode_buttons = []
        for index, text in enumerate(("📜  Today's story", "🗣  Talk")):
            button = QPushButton(text)
            button.setCheckable(True)
            button.setMinimumHeight(44)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setStyleSheet(
                f"QPushButton:checked {{ background-color: rgba(59,130,246,0.18); "
                f"border: 1px solid {ACCENT}; color: {TEXT}; font-weight: 600; }}")
            self.mode_group.addButton(button, index)
            modes.addWidget(button)
            self.mode_buttons.append(button)
        modes.addStretch()
        self.level = ComboBox()
        for label, _ in LEVEL_CHOICES:
            self.level.addItem(label)
        self.level.setToolTip("How hard the story and the conversation are. Automatic "
                              "follows how many words you have studied.")
        self.level.currentIndexChanged.connect(
            lambda i: self.db.set_setting("practice_level", LEVEL_CHOICES[i][1] or ""))
        modes.addWidget(self.level)
        layout.addLayout(modes)

        # Story and Talk sit one under the other and only the chosen one is
        # shown: a hidden page takes no room (a QStackedWidget is as tall as
        # its tallest page, which stretched the Talk boxes after a story).
        self.pages = [self._build_story(), self._build_talk()]
        for page in self.pages:
            layout.addWidget(page)
        layout.addStretch()
        self.mode_group.idClicked.connect(self.show_page)
        self.show_page(0)
        self.mode_buttons[0].setChecked(True)

    def show_page(self, index):
        for i, page in enumerate(self.pages):
            page.setVisible(i == index)

    # ================================================================ story

    def _build_story(self):
        page = _plain()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(16)

        top, top_layout = _card()
        row = QHBoxLayout()
        self.story_info = _label("", f"color: {TEXT_SECONDARY};")
        row.addWidget(self.story_info, 1)
        self.new_story = QPushButton("✨  New story")
        self.new_story.setObjectName("primary")
        self.new_story.setMinimumHeight(40)
        self.new_story.setCursor(Qt.CursorShape.PointingHandCursor)
        self.new_story.clicked.connect(self.write_story)
        row.addWidget(self.new_story)
        top_layout.addLayout(row)
        self.story_working = WorkingLine()
        top_layout.addWidget(self.story_working)
        self.story_status = _label("", f"color: {TEXT_SECONDARY};")
        top_layout.addWidget(self.story_status)
        earlier = QHBoxLayout()
        self.earlier = ComboBox()
        self.earlier.setToolTip("Read one of your earlier stories again")
        self.earlier.activated.connect(self.open_earlier)
        earlier.addWidget(QLabel("Earlier stories"))
        earlier.addWidget(self.earlier, 1)
        self.earlier_row = earlier
        top_layout.addLayout(earlier)
        column.addWidget(top)

        self.story_card, story_layout = _card()
        head = QHBoxLayout()
        self.story_title = _label("", "font-size: 15pt; font-weight: 700;")
        head.addWidget(self.story_title, 1)
        self.listen_story = QPushButton("🔊  Listen")
        self.listen_story.setCursor(Qt.CursorShape.PointingHandCursor)
        self.listen_story.clicked.connect(self.listen_all)
        head.addWidget(self.listen_story)
        self.toggle_tr = QPushButton("Show translations")
        self.toggle_tr.setCursor(Qt.CursorShape.PointingHandCursor)
        self.toggle_tr.setToolTip("Try to understand each sentence first, then check")
        self.toggle_tr.clicked.connect(self.flip_translations)
        head.addWidget(self.toggle_tr)
        story_layout.addLayout(head)
        self.used_label = _label("", f"color: {TEXT_SECONDARY};")
        story_layout.addWidget(self.used_label)
        self.sentence_box = QVBoxLayout()
        self.sentence_box.setSpacing(12)
        story_layout.addLayout(self.sentence_box)
        column.addWidget(self.story_card)

        self.words_card, words_layout = _card("New words in this story")
        self.words_box = QVBoxLayout()
        self.words_box.setSpacing(8)
        words_layout.addLayout(self.words_box)
        self.word_working = WorkingLine()
        words_layout.addWidget(self.word_working)
        column.addWidget(self.words_card)

        self.questions_card, questions_layout = _card("Did you understand it?")
        self.questions_box = QVBoxLayout()
        self.questions_box.setSpacing(10)
        questions_layout.addLayout(self.questions_box)
        self.score_label = _label("", f"color: {TEXT_SECONDARY}; font-weight: 600;")
        questions_layout.addWidget(self.score_label)
        column.addWidget(self.questions_card)
        column.addStretch()
        return page

    def refresh(self):
        self.langs = languages.load(self.db.get_setting)
        saved = self.db.get_setting("practice_level", "") or None
        self.level.blockSignals(True)
        self.level.setCurrentIndex(next((i for i, (_, v) in enumerate(LEVEL_CHOICES)
                                         if v == saved), 0))
        self.level.blockSignals(False)
        self._refresh_story_info()
        self._refresh_talk_info()
        if self.story is None or self.story.get("_lang") != self.langs.target:
            kept = practice.stories(self.db.conn, self.langs.target, 1)
            self.story = dict(kept[0][2], _lang=self.langs.target) if kept else None
            self.show_translations = False
            self.render_story()

    def _level(self):
        return LEVEL_CHOICES[max(0, self.level.currentIndex())][1]

    def _has_key(self):
        writer = cards_ai.CardWriter(self.db.path)
        try:
            return bool(writer.api_key())
        finally:
            writer.close()

    def _refresh_story_info(self):
        studied = practice.studied_count(self.db.conn)
        today = practice.stories_today(self.db.conn, self.langs.target)
        if studied < 5:
            text = (f"The story is made from words you have studied — study at least 5 "
                    f"first (so far: {studied}).")
        elif not self._has_key():
            text = "⚠ No OpenAI key — add one in Settings first."
        elif today >= practice.STORIES_PER_DAY:
            text = f"That's {today} stories today — the next one tomorrow."
        else:
            text = ("A short story from the words you have studied — about a third of "
                    f"a cent. Up to {practice.STORIES_PER_DAY} a day.")
        self.story_info.setText(text)
        self.new_story.setEnabled(studied >= 5 and today < practice.STORIES_PER_DAY
                                  and self._has_key() and not self._story_busy)
        kept = practice.stories(self.db.conn, self.langs.target, 20)
        self.earlier.blockSignals(True)
        self.earlier.clear()
        self._earlier_ids = []
        for story_id, made_on, story in kept:
            self.earlier.addItem(f"{made_on} — {story.get('title', '')}")
            self._earlier_ids.append(story_id)
        self.earlier.blockSignals(False)
        for i in range(self.earlier_row.count()):
            widget = self.earlier_row.itemAt(i).widget()
            if widget is not None:
                widget.setVisible(len(kept) > 1)

    def write_story(self):
        if self._story_busy:
            return
        self._story_busy = True
        self.new_story.setEnabled(False)
        self.story_status.setText("")
        self.story_working.start("Writing a story from your words…")
        level = self._level()

        def work():
            writer = practice.StoryWriter(self.db.path)
            try:
                story = writer.write(level)
                practice.save_story(writer.conn, writer.langs.target, story)
                self.story_done.emit(story, "")
            except Exception as exc:
                self.story_done.emit(None, str(exc))
            finally:
                writer.close()

        threading.Thread(target=work, daemon=True).start()

    def _on_story(self, story, error):
        self._story_busy = False
        self.story_working.stop()
        if story is None:
            self.story_status.setText(f"No story this time: {error}")
        else:
            self.story = dict(story, _lang=self.langs.target)
            self.show_translations = False
            self.render_story()
            self.scroll.verticalScrollBar().setValue(0)
        self._refresh_story_info()

    def open_earlier(self, index):
        if 0 <= index < len(self._earlier_ids):
            for story_id, _, story in practice.stories(self.db.conn, self.langs.target, 20):
                if story_id == self._earlier_ids[index]:
                    self.story = dict(story, _lang=self.langs.target)
                    self.show_translations = False
                    self.render_story()

    def render_story(self):
        story = self.story
        for card in (self.story_card, self.words_card, self.questions_card):
            card.setVisible(story is not None)
        if story is None:
            return
        words = practice.known_words(self.db.conn, 200)
        scale = languages.script_scale(self.langs.target)
        voice = has_voice(self.langs.target)
        self.story_title.setText(story.get("title", ""))
        used = story.get("words_used") or []
        self.used_label.setText(
            f"{len(used)} of your words in it: {', '.join(used)}" if used else "")
        self.used_label.setVisible(bool(used))
        self.listen_story.setVisible(voice)
        self.toggle_tr.setVisible(any(s.get("translation") for s in story["sentences"]))
        self.toggle_tr.setText("Hide translations" if self.show_translations else "Show translations")
        _clear(self.sentence_box)
        for sentence in story["sentences"]:
            row = QHBoxLayout()
            row.setSpacing(10)
            text_col = QVBoxLayout()
            text_col.setSpacing(2)
            line = _label(highlight(sentence["text"], words),
                          f"font-size: {15 * scale:.0f}pt;", rich=True, target=True)
            text_col.addWidget(line)
            if sentence.get("reading"):
                text_col.addWidget(_label(sentence["reading"], f"color: {TEXT_SECONDARY};"))
            if sentence.get("translation") and self.show_translations:
                text_col.addWidget(_label(sentence["translation"],
                                          f"color: {TEXT_MUTED}; font-style: italic;"))
            row.addLayout(text_col, 1)
            if voice:
                listen = QPushButton("🔊")
                listen.setFixedSize(36, 32)
                listen.setCursor(Qt.CursorShape.PointingHandCursor)
                listen.setToolTip("Hear this sentence")
                listen.clicked.connect(lambda _, t=sentence["text"]: speak(t, self.langs.target))
                row.addWidget(listen, 0, Qt.AlignmentFlag.AlignTop)
            self.sentence_box.addLayout(row)
        # new words, each with a way into the deck
        _clear(self.words_box)
        new_words = story.get("new_words") or []
        self.words_card.setVisible(bool(new_words))
        have = {w.lower() for (w,) in self.db.conn.execute("SELECT word FROM words")}
        for item in new_words:
            row = QHBoxLayout()
            reading = f"  ({item['reading']})" if item.get("reading") else ""
            row.addWidget(_label(f"{item['word']}{reading} — {item['meaning']}",
                                 f"font-size: {11.5 * scale:.1f}pt;"), 1)
            add = QPushButton("✓  In your deck" if item["word"].lower() in have else "＋  Add to my deck")
            add.setEnabled(item["word"].lower() not in have)
            add.setCursor(Qt.CursorShape.PointingHandCursor)
            add.setToolTip("Writes a full card for this word (about a tenth of a cent)")
            add.clicked.connect(lambda _, w=item["word"], b=add: self.add_word(w, b))
            row.addWidget(add)
            self.words_box.addLayout(row)
        # questions
        _clear(self.questions_box)
        questions = story.get("questions") or []
        self.questions_card.setVisible(bool(questions))
        self._answers = {}
        for number, item in enumerate(questions):
            self.questions_box.addWidget(_label(f"{number + 1}.  {item['question']}",
                                                "font-weight: 600;"))
            buttons = []
            for option_index, option in enumerate(item["options"]):
                button = QPushButton(option)
                button.setCursor(Qt.CursorShape.PointingHandCursor)
                button.setStyleSheet("text-align: left; padding: 8px 14px;")
                button.clicked.connect(lambda _, q=number, o=option_index: self.answer(q, o))
                self.questions_box.addWidget(button)
                buttons.append(button)
            item["_buttons"] = buttons
        self.score_label.setText("")

    def flip_translations(self):
        self.show_translations = not self.show_translations
        self.render_story()

    def listen_all(self):
        if self.story and has_voice(self.langs.target):
            speak(" ".join(s["text"] for s in self.story["sentences"]), self.langs.target)

    def answer(self, question, option):
        item = self.story["questions"][question]
        if question in self._answers:
            return
        self._answers[question] = option == item["answer"]
        for index, button in enumerate(item["_buttons"]):
            button.setEnabled(False)
            if index == item["answer"]:
                button.setStyleSheet(f"text-align: left; padding: 8px 14px; color: {SUCCESS}; "
                                     f"border: 2px solid {SUCCESS};")
                button.setText("✓  " + button.text())
            elif index == option:
                button.setStyleSheet(f"text-align: left; padding: 8px 14px; color: {DANGER}; "
                                     f"border: 2px solid {DANGER};")
                button.setText("✗  " + button.text())
        total = len(self.story["questions"])
        if len(self._answers) == total:
            right = sum(self._answers.values())
            self.score_label.setText(f"You got {right} of {total} right" +
                                     (" ✓" if right == total else "."))

    def word_to_add(self, text):
        """WordLabel asks: the selected text as a word worth a card, or ''."""
        return addable_word(text, self.langs.target)

    def add_selected_word(self, word):
        self.add_word(word)

    def add_word(self, word, button=None):
        """A card for `word`: the story's ＋ buttons and right-click → Add."""
        if not self.adder.add(word):
            return
        if button is not None:
            button.setEnabled(False)
        self._adding_on_talk = not self.pages[1].isHidden()
        working = self.talk_word_working if self._adding_on_talk else self.word_working
        working.start(f"Writing the card for “{word}”…")

    def _on_word_added(self, word, message):
        self.word_working.stop()
        self.talk_word_working.stop()
        status = self.talk_word_status if self._adding_on_talk else self.story_status
        status.setText(f"“{word}” — {message}")
        status.show()
        self.main_window.update_status()
        if "✓" in message:
            self.main_window.start_sync()
        self.render_story()

    # ================================================================ talk

    def _build_talk(self):
        page = _plain()
        column = QVBoxLayout(page)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(16)

        setup, setup_layout = _card()
        self.talk_info = _label("", f"color: {TEXT_SECONDARY};")
        setup_layout.addWidget(self.talk_info)
        row = QHBoxLayout()
        row.addWidget(QLabel("Scene"))
        self.scene_box = ComboBox()
        for title, _ in practice.SCENES:
            self.scene_box.addItem(title)
        self.scene_box.addItem("Surprise me")
        row.addWidget(self.scene_box, 1)
        self.start_talk = QPushButton("▶  Start")
        self.start_talk.setObjectName("primary")
        self.start_talk.setMinimumHeight(40)
        self.start_talk.setCursor(Qt.CursorShape.PointingHandCursor)
        self.start_talk.clicked.connect(self.begin)
        row.addWidget(self.start_talk)
        setup_layout.addLayout(row)
        column.addWidget(setup)

        self.chat_card, chat_layout = _card()
        top = QHBoxLayout()
        self.scene_label = _label("", "font-weight: 700; font-size: 12pt;")
        top.addWidget(self.scene_label, 1)
        self.read_aloud = QCheckBox("🔊  Read the replies aloud")
        self.read_aloud.setToolTip("The other person's lines are spoken by your computer's voice.")
        self.read_aloud.toggled.connect(
            lambda on: self.db.set_setting("talk_read_aloud", "1" if on else "0"))
        top.addWidget(self.read_aloud)
        self.turn_label = QLabel("")
        self.turn_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        top.addWidget(self.turn_label)
        chat_layout.addLayout(top)
        self.bubbles = QVBoxLayout()
        self.bubbles.setSpacing(10)
        chat_layout.addLayout(self.bubbles)
        self.talk_working = WorkingLine()
        chat_layout.addWidget(self.talk_working)
        self.talk_status = _label("", f"color: {WARNING};")
        chat_layout.addWidget(self.talk_status)
        self.retry = QPushButton("↻  Try again")
        self.retry.setCursor(Qt.CursorShape.PointingHandCursor)
        self.retry.clicked.connect(self.try_again)
        self.retry.hide()
        chat_layout.addWidget(self.retry, 0, Qt.AlignmentFlag.AlignLeft)

        ideas_row = QHBoxLayout()
        self.ideas_label = QLabel("Ideas — click one to say it:")
        self.ideas_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        ideas_row.addWidget(self.ideas_label)
        ideas_row.addStretch()
        self.help_button = QPushButton("")
        self.help_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.help_button.clicked.connect(lambda: self.toggle_mic("help"))
        ideas_row.addWidget(self.help_button)
        chat_layout.addLayout(ideas_row)
        self.ideas = QVBoxLayout()
        self.ideas.setSpacing(6)
        chat_layout.addLayout(self.ideas)

        entry = QHBoxLayout()
        entry.setSpacing(8)
        self.say_box = QLineEdit()
        self.say_box.setMinimumHeight(42)
        self.say_box.setPlaceholderText("or write your own answer, then Enter")
        self.say_box.returnPressed.connect(self.send_typed)
        self.say_box.textChanged.connect(lambda text: text.strip() or self._nudge_send(False))
        entry.addWidget(self.say_box, 1)
        self.letters = QHBoxLayout()
        self.letters.setSpacing(6)
        entry.addLayout(self.letters)
        self.mic_button = QPushButton("🎤  Speak")
        self.mic_button.setMinimumHeight(42)
        self.mic_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.mic_button.clicked.connect(lambda: self.toggle_mic("say"))
        entry.addWidget(self.mic_button)
        self.send_button = QPushButton("Send")
        self.send_button.setMinimumHeight(42)
        self.send_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send_button.clicked.connect(self.send_typed)
        entry.addWidget(self.send_button)
        chat_layout.addLayout(entry)
        self.voice_note = _label("", f"color: {TEXT_SECONDARY};")
        self.voice_note.hide()
        chat_layout.addWidget(self.voice_note)
        self.talk_word_working = WorkingLine()
        chat_layout.addWidget(self.talk_word_working)
        self.talk_word_status = _label("", f"color: {TEXT_SECONDARY};")
        self.talk_word_status.hide()
        chat_layout.addWidget(self.talk_word_status)
        self.summary = _label("", f"color: {SUCCESS}; font-weight: 600;")
        chat_layout.addWidget(self.summary)
        self.chat_card.hide()
        column.addWidget(self.chat_card)
        column.addStretch()
        return page

    def _refresh_talk_info(self):
        studied = practice.studied_count(self.db.conn)
        if studied < 5:
            text = (f"The conversation uses the words you have studied — study at least 5 "
                    f"first (so far: {studied}).")
        elif not self._has_key():
            text = "⚠ No OpenAI key — add one in Settings first."
        else:
            text = (f"Pick a scene: the other person speaks with your words, you answer — "
                    f"click an idea, write your own or 🎤 say it. Up to {practice.TALK_TURNS} "
                    f"turns, about a cent per conversation (speaking adds a fraction of a "
                    f"cent per answer).")
        self.talk_info.setText(text)
        mic_ok, why = mic_available()
        self.mic_button.setVisible(mic_ok)
        self.mic_button.setToolTip(
            f"Say your answer in {self.langs.target} — up to {voice.MAX_SECONDS} seconds. "
            f"Click again to stop. You see what was heard before it is sent.")
        own = self.langs.definition
        self.help_button.setText(f"🆘  Say it in {own}")
        self.help_button.setToolTip(
            f"Don't know how to say it? Say it in {own} and you get it in {self.langs.target}.")
        self.help_button.setVisible(
            mic_ok and own.strip().lower() != self.langs.target.strip().lower())
        speaks = has_voice(self.langs.target)
        self.read_aloud.setVisible(speaks)
        self.read_aloud.blockSignals(True)
        self.read_aloud.setChecked(speaks and self.db.get_setting("talk_read_aloud", "1") != "0")
        self.read_aloud.blockSignals(False)
        self.start_talk.setEnabled(studied >= 5 and self._has_key() and not self._talk_busy)
        # Letters a keyboard may lack (Swedish å ä ö), as in the quiz.
        _clear(self.letters)
        for letter in languages.extra_letters(self.langs.target):
            button = QPushButton(letter)
            button.setFixedSize(42, 42)
            button.setStyleSheet("font-size: 14pt; padding: 0;")
            button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _, l=letter: self._type(l))
            self.letters.addWidget(button)

    def _type(self, letter):
        shift = QApplication.keyboardModifiers() & Qt.KeyboardModifier.ShiftModifier
        self.say_box.insert(letter.upper() if shift else letter)
        self.say_box.setFocus()

    def begin(self):
        if self._talk_busy:
            return
        index = self.scene_box.currentIndex()
        if index >= len(practice.SCENES):
            title, scene = random.choice(practice.SCENES)
        else:
            title, scene = practice.SCENES[index]
        self.scene = scene
        self.history = []
        self.turns = 0
        self.talk_over = False
        _clear(self.bubbles)
        _clear(self.ideas)
        self.summary.setText("")
        self.voice_note.hide()
        self.talk_word_status.hide()
        self._nudge_send(False)
        self.recorder.cancel()
        self._record_mode = None
        self._last_lines = []
        self.scene_label.setText(title)
        self.chat_card.show()
        self._ask("")

    def send_typed(self):
        self.send(self.say_box.text().strip())

    def send(self, text):
        if not text or self._talk_busy or self.talk_over:
            return
        self.say_box.clear()
        self.voice_note.hide()
        self._nudge_send(False)
        self.history.append({"who": "learner", "text": text})
        self.turns += 1
        self._learner_bubble(text)
        self._ask(text)

    def _ask(self, said):
        self._talk_busy = True
        self._pending = said
        self._set_talk_enabled(False)
        self.talk_status.setText("")
        self.retry.hide()
        self.talk_working.start("Thinking of an answer…" if said else "Setting the scene…")
        scene, level = self.scene, self._level()
        history = [h for h in self.history]
        if said:
            history = history[:-1]

        def work():
            partner = practice.TalkPartner(self.db.path)
            try:
                result = partner.turn(scene, level, history, said)
                self.talk_done.emit(result, "")
            except Exception as exc:
                self.talk_done.emit(None, str(exc))
            finally:
                partner.close()

        threading.Thread(target=work, daemon=True).start()

    def try_again(self):
        if self._pending is not None and not self._talk_busy:
            self._ask(self._pending)

    def _on_turn(self, result, error):
        self._talk_busy = False
        self.talk_working.stop()
        if result is None:
            self.talk_status.setText(f"No answer this time: {error}")
            self.retry.show()
            self._set_talk_enabled(not self.talk_over)
            return
        if result.get("feedback") and result["feedback"].get("better"):
            self._feedback_bubble(result["feedback"])
        self.history.append({"who": "partner", "text": result["reply"]["text"]})
        self._partner_bubble(result["reply"])
        self._say_aloud(result["reply"]["text"])
        self._last_lines = [result["reply"]["text"]] + [
            idea["text"] for idea in result.get("suggestions") or []]
        _clear(self.ideas)
        if result.get("finished") or self.turns >= practice.TALK_TURNS:
            self.finish()
        else:
            for idea in result.get("suggestions") or []:
                button = QPushButton(idea["text"] + (f"\n{idea['reading']}" if idea.get("reading") else ""))
                button.setToolTip(idea.get("translation") or "")
                button.setCursor(Qt.CursorShape.PointingHandCursor)
                button.setStyleSheet("text-align: left; padding: 8px 14px;")
                button.clicked.connect(lambda _, t=idea["text"]: self.send(t))
                self.ideas.addWidget(button)
                if idea.get("translation"):
                    hint = _label(f"   {idea['translation']}", f"color: {TEXT_MUTED}; font-size: 9pt;")
                    self.ideas.addWidget(hint)
            self._set_talk_enabled(True)
            self.say_box.setFocus()
        self.turn_label.setText(f"turn {self.turns} of {practice.TALK_TURNS}")
        QTimer.singleShot(50, lambda: self.scroll.verticalScrollBar().setValue(
            self.scroll.verticalScrollBar().maximum()))

    def _set_talk_enabled(self, on):
        self.say_box.setEnabled(on)
        self.send_button.setEnabled(on)
        self.mic_button.setEnabled(on)
        self.help_button.setEnabled(on)
        self.ideas_label.setVisible(on)
        for i in range(self.ideas.count()):
            widget = self.ideas.itemAt(i).widget()
            if widget is not None:
                widget.setEnabled(on)

    # ---------------------------------------------------------------- speaking

    def _say_aloud(self, text):
        if not self.read_aloud.isHidden() and self.read_aloud.isChecked():
            speak(text, self.langs.target)

    def toggle_mic(self, mode):
        """🎤 / 🆘: start recording, or stop and write down what was said."""
        if self._record_mode:
            if self._record_mode == mode:
                self.recorder.stop()
            return
        if self._talk_busy or self.talk_over:
            return
        self._record_mode = mode
        self.talk_status.setText("")
        self.voice_note.hide()
        self._nudge_send(False)
        self._set_talk_enabled(False)
        button = self.mic_button if mode == "say" else self.help_button
        button.setEnabled(True)
        button.setText("■  Stop · 0 s")
        button.setStyleSheet(f"color: {DANGER}; font-weight: 600;")
        self.recorder.start()

    def _nudge_send(self, on):
        """After 🎤 the answer waits in the box: Send turns blue, gains an
        arrow and breathes a soft glow until it is pressed (or the answer is
        cleared, re-recorded, or a new scene starts)."""
        if bool(on) == (self._send_glow is not None):
            return
        button = self.send_button
        if on:
            button.setStyleSheet(
                f"QPushButton {{ background-color: {ACCENT}; color: white; font-weight: 600; "
                f"border: none; border-radius: 8px; padding: 8px 16px; }} "
                f"QPushButton:hover {{ background-color: #2563eb; }}")
            button.setText("Send  ➤")
            glow = QGraphicsDropShadowEffect(button)
            glow.setOffset(0, 0)
            glow.setColor(QColor(ACCENT))
            glow.setBlurRadius(6)
            button.setGraphicsEffect(glow)
            pulse = QVariantAnimation(self)
            pulse.setStartValue(6.0)
            pulse.setKeyValueAt(0.5, 30.0)
            pulse.setEndValue(6.0)
            pulse.setDuration(1600)
            pulse.setLoopCount(-1)
            pulse.setEasingCurve(QEasingCurve.Type.InOutSine)
            pulse.valueChanged.connect(glow.setBlurRadius)
            pulse.start()
            self._send_glow = pulse
        else:
            self._send_glow.stop()
            self._send_glow.deleteLater()
            self._send_glow = None
            button.setGraphicsEffect(None)
            button.setStyleSheet("")
            button.setText("Send")

    def _restore_mic_buttons(self):
        self.mic_button.setText("🎤  Speak")
        self.help_button.setText(f"🆘  Say it in {self.langs.definition}")
        self.mic_button.setStyleSheet("")
        self.help_button.setStyleSheet("")

    def _on_record_tick(self, seconds):
        button = self.mic_button if self._record_mode == "say" else self.help_button
        button.setText(f"■  Stop · {int(seconds)} s")

    def _on_record_failed(self, text):
        self._record_mode = None
        self._restore_mic_buttons()
        self._set_talk_enabled(not self.talk_over)
        self.talk_status.setText(f"🎤 {text[:1].upper()}{text[1:]}.")

    def _on_recorded(self, pcm, rate):
        mode, self._record_mode = self._record_mode, None
        self._restore_mic_buttons()
        if mode is None:
            return
        self._talk_busy = True
        self.talk_working.start("Writing down what you said…")
        language = self.langs.target if mode == "say" else self.langs.definition
        hints = list(self._last_lines) if mode == "say" else []

        def work():
            listener = voice.Transcriber(self.db.path)
            try:
                self.heard.emit(mode, listener.transcribe(pcm, rate, language, hints), "")
            except Exception as exc:
                self.heard.emit(mode, "", str(exc))
            finally:
                listener.close()

        threading.Thread(target=work, daemon=True).start()

    def _on_heard(self, mode, text, error):
        self._talk_busy = False
        self.talk_working.stop()
        if error:
            self._set_talk_enabled(not self.talk_over)
            self.talk_status.setText(f"🎤 {error[:1].upper()}{error[1:]}.")
            return
        if mode == "say":
            self._set_talk_enabled(not self.talk_over)
            self.say_box.setText(text)
            self.say_box.setFocus()
            self.voice_note.setText("I heard this — fix it if you need to, then press Send "
                                    "(or 🎤 to say it again).")
            self.voice_note.show()
            self._nudge_send(True)
            return
        self._talk_busy = True
        self.talk_working.start("Finding how to say it…")
        scene, level, history = self.scene, self._level(), list(self.history)

        def work():
            partner = practice.TalkPartner(self.db.path)
            try:
                self.helped.emit(partner.how_to_say(scene, level, history, text), "")
            except Exception as exc:
                self.helped.emit(None, str(exc))
            finally:
                partner.close()

        threading.Thread(target=work, daemon=True).start()

    def _on_helped(self, line, error):
        self._talk_busy = False
        self.talk_working.stop()
        self._set_talk_enabled(not self.talk_over)
        if line is None:
            self.talk_status.setText(f"No answer this time: {error}")
            return
        box = QFrame()
        box.setObjectName("sayit")
        box.setStyleSheet(f"QFrame#sayit {{ border: 1px solid {ACCENT}; border-radius: 10px; }}"
                          f"QFrame#sayit QLabel {{ background: transparent; }}")
        inner = QVBoxLayout(box)
        inner.setContentsMargins(14, 10, 14, 10)
        inner.setSpacing(4)
        inner.addWidget(_label("Say it like this:", f"color: {TEXT_SECONDARY};"))
        say = QPushButton(line["text"] + (f"\n{line['reading']}" if line.get("reading") else ""))
        say.setCursor(Qt.CursorShape.PointingHandCursor)
        say.setStyleSheet("text-align: left; padding: 8px 14px; font-weight: 600;")
        say.setToolTip("Click to send it as your answer")
        say.clicked.connect(lambda _, t=line["text"]: self.send(t))
        inner.addWidget(say)
        if line.get("translation"):
            inner.addWidget(_label(line["translation"], f"color: {TEXT_MUTED}; font-style: italic;"))
        self.ideas.insertWidget(0, box)
        self._last_lines = [line["text"]] + self._last_lines
        self._say_aloud(line["text"])
        self.voice_note.setText("Now say it yourself with 🎤 — or click it to send it.")
        self.voice_note.show()

    def hideEvent(self, event):
        if self._record_mode:
            self.recorder.cancel()
            self._record_mode = None
            self._restore_mic_buttons()
            self._set_talk_enabled(not self.talk_over)
        super().hideEvent(event)

    def finish(self):
        self.talk_over = True
        self._set_talk_enabled(False)
        learner = " ".join(h["text"] for h in self.history if h["who"] == "learner")
        used = practice.words_in(learner, practice.known_words(self.db.conn, 200))
        self.summary.setText(
            "Well done — conversation finished ✓" +
            (f"  You used {len(used)} of your words: {', '.join(used[:12])}." if used else "") +
            "  Press Start for another.")

    def _bubble(self, name, color):
        frame = QFrame()
        frame.setObjectName(name)
        frame.setStyleSheet(f"QFrame#{name} {{ background-color: {color}; border-radius: 10px; }}"
                            f"QFrame#{name} QLabel {{ background: transparent; }}")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(2)
        return frame, layout

    def _partner_bubble(self, line):
        frame, layout = self._bubble("partner", "rgba(59,130,246,0.10)")
        scale = languages.script_scale(self.langs.target)
        row = QHBoxLayout()
        row.addWidget(_label(line["text"], f"font-size: {13.5 * scale:.1f}pt;", target=True), 1)
        if has_voice(self.langs.target):
            listen = QPushButton("🔊")
            listen.setFixedSize(36, 30)
            listen.setCursor(Qt.CursorShape.PointingHandCursor)
            listen.clicked.connect(lambda _, t=line["text"]: speak(t, self.langs.target))
            row.addWidget(listen, 0, Qt.AlignmentFlag.AlignTop)
        layout.addLayout(row)
        if line.get("reading"):
            layout.addWidget(_label(line["reading"], f"color: {TEXT_SECONDARY};"))
        if line.get("translation"):
            layout.addWidget(_label(line["translation"], f"color: {TEXT_MUTED}; font-style: italic;"))
        holder = QHBoxLayout()
        holder.addWidget(frame, 4)
        holder.addStretch(1)
        self.bubbles.addLayout(holder)

    def _learner_bubble(self, text):
        frame, layout = self._bubble("learner", "rgba(34,197,94,0.10)")
        scale = languages.script_scale(self.langs.target)
        layout.addWidget(_label(text, f"font-size: {13.5 * scale:.1f}pt;", target=True))
        holder = QHBoxLayout()
        holder.addStretch(1)
        holder.addWidget(frame, 4)
        self.bubbles.addLayout(holder)

    def _feedback_bubble(self, feedback):
        frame, layout = self._bubble("feedback", "rgba(245,158,11,0.10)")
        better = feedback["better"] + (f"  ({feedback['better_reading']})"
                                       if feedback.get("better_reading") else "")
        layout.addWidget(_label(f"Better: {better}", f"color: {WARNING};", target=True))
        if feedback.get("why"):
            layout.addWidget(_label(feedback["why"], f"color: {TEXT_SECONDARY};"))
        holder = QHBoxLayout()
        holder.addStretch(1)
        holder.addWidget(frame, 4)
        self.bubbles.addLayout(holder)

    # ================================================================ from Study

    def show_story(self):
        """Opened from the end of a study session: the story page."""
        self.mode_buttons[0].setChecked(True)
        self.show_page(0)

"""Main window: sidebar navigation + stacked content area + status bar.

Also home to the things more than one screen needs: the background sync
worker, the update banner, and the two whole-deck moves (export / restore
a backup bundle).
"""

import logging
import os
import sqlite3
import threading
import zipfile
from datetime import datetime

from PyQt6.QtCore import QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QIcon, QKeySequence, QPixmap, QShortcut
from PyQt6.QtWidgets import (
    QApplication, QDialog, QFileDialog, QFrame, QHBoxLayout, QLabel, QMainWindow, QMenu,
    QMessageBox, QPushButton, QStackedWidget, QSystemTrayIcon, QVBoxLayout, QWidget,
)

import decks
import images
import paths
import reminder
import transfer
import updater
from styles import ACCENT, TEXT_SECONDARY
from sync import SyncEngine
from ui.dashboard import DashboardScreen
from ui.flashcard import FlashcardScreen
from ui.quiz import QuizScreen
from ui.browse import BrowseScreen
from ui.import_screen import ImportScreen
from ui.stats import StatsScreen
from ui.settings_screen import SettingsScreen
from ui.help import HelpScreen
from ui.alphabet import AlphabetDialog, AlphabetScreen
from ui.sentences import SentencesScreen
from ui.practice import PracticeScreen
from ui.decks import DeckButton, NewDeckDialog
import alphabets
import languages
from version import VERSION

NAV_ITEMS = [
    ("dashboard", "🏠  Dashboard", "Today's numbers and the start button"),
    ("study", "📖  Study", "Flashcards: the cards due today  (Ctrl+R)"),
    ("quiz", "❓  Quiz", "Multiple choice on the same cards — or practice when nothing is due"),
    ("practice", "✨  Practice", "A short story and a conversation made from the words you know"),
    ("sentences", "💬  Sentences", "Everyday sentences with every word explained — separate from your cards and stats"),
    ("alphabet", "ㄱ  Alphabet", "Learn the letters of your language, and look them up  (A on a card)"),
    ("browse", "🔍  Browse", "Search, edit, reset or delete any word"),
    ("import", "➕  Add Words", "Starter decks, single words, or a pasted spreadsheet  (Ctrl+I)"),
    ("stats", "📊  Stats", "Reviews per day, streak calendar, what is coming up"),
    ("settings", "⚙️  Settings", "Daily limits, languages, OpenAI key, cloud sync, backups"),
    ("help", "❔  Help", "How it works, the keys, your data  (F1)"),
]

STUDY_SCREENS = ("study", "quiz")
log = logging.getLogger("app")


class MainWindow(QMainWindow):
    # Workers (sync, update check, update install) report back through
    # signals: the UI thread is the only place widgets may be touched.
    sync_finished = pyqtSignal(dict)
    update_available = pyqtSignal(dict)
    update_result = pyqtSignal(bool, str)        # ok, message
    show_requested = pyqtSignal()                # from a second launch / the tray

    def __init__(self, db):
        super().__init__()
        self.db = db
        self.current_key = None
        self._syncing = False
        self._sync_note = ""
        self._update_info = None
        self.relaunch_requested = False
        self._quitting = False
        self.show_requested.connect(self.show_from_tray)
        self.sync_finished.connect(self._on_sync_finished)
        self.update_available.connect(self.offer_update)
        self.update_result.connect(self._on_update_result)
        self.setWindowTitle("VocabMaster")
        QTimer.singleShot(0, self.update_title)
        self.setMinimumSize(960, 680)

        central = QWidget()
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        self.setCentralWidget(central)

        # ------------------------------------------------------- sidebar
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(220)
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(0, 20, 0, 20)
        side_layout.setSpacing(2)

        logo_row = QHBoxLayout()
        logo_row.setContentsMargins(18, 0, 18, 16)
        logo_row.setSpacing(10)
        icon = QLabel()
        icon_path = os.path.join(paths.app_dir(), "vocabmaster.png")
        if os.path.exists(icon_path):
            icon.setPixmap(QPixmap(icon_path).scaled(
                30, 30, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation))
        logo_row.addWidget(icon)
        logo = QLabel("VocabMaster")
        logo.setStyleSheet("font-size: 15pt; font-weight: 700;")
        logo_row.addWidget(logo)
        logo_row.addStretch()
        side_layout.addLayout(logo_row)
        # Which deck is open (one per language); click to switch or add one.
        deck_row = QHBoxLayout()
        deck_row.setContentsMargins(10, 0, 10, 12)
        self.deck_button = DeckButton(self)
        deck_row.addWidget(self.deck_button)
        side_layout.addLayout(deck_row)

        self.nav_buttons = {}
        for key, label, tip in NAV_ITEMS:
            button = QPushButton(label)
            button.setObjectName("navButton")
            button.setCheckable(True)
            button.setToolTip(tip)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _, k=key: self.navigate(k))
            side_layout.addWidget(button)
            self.nav_buttons[key] = button
        side_layout.addStretch()
        version = QLabel(f"v{VERSION}")
        version.setStyleSheet(f"color: {TEXT_SECONDARY}; padding: 0 18px; font-size: 8pt;")
        side_layout.addWidget(version)
        root.addWidget(sidebar)

        # -------------------------------------------------------- content
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        root.addWidget(content, 1)

        # Update banner: hidden until a newer release is found.
        self.update_banner = QFrame()
        self.update_banner.setStyleSheet(
            f"background: rgba(59,130,246,0.12); border-bottom: 1px solid {ACCENT};")
        banner_layout = QHBoxLayout(self.update_banner)
        banner_layout.setContentsMargins(20, 8, 20, 8)
        self.update_label = QLabel("")
        self.update_label.setWordWrap(True)
        banner_layout.addWidget(self.update_label, 1)
        self.update_button = QPushButton("Update & restart")
        self.update_button.setObjectName("primary")
        self.update_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.update_button.setToolTip(
            "Downloads the new version and replaces the app's code. Your words, "
            "progress and settings live elsewhere and are never touched.")
        self.update_button.clicked.connect(self.apply_update)
        banner_layout.addWidget(self.update_button)
        later = QPushButton("Later")
        later.setCursor(Qt.CursorShape.PointingHandCursor)
        later.clicked.connect(self.update_banner.hide)
        banner_layout.addWidget(later)
        self.update_banner.hide()
        content_layout.addWidget(self.update_banner)

        self.stack = QStackedWidget()
        content_layout.addWidget(self.stack, 1)

        self.screens = {
            "dashboard": DashboardScreen(db, self),
            "study": FlashcardScreen(db, self),
            "quiz": QuizScreen(db, self),
            "browse": BrowseScreen(db, self),
            "import": ImportScreen(db, self),
            "stats": StatsScreen(db, self),
            "settings": SettingsScreen(db, self),
            "help": HelpScreen(db, self),
            "alphabet": AlphabetScreen(db, self),
            "sentences": SentencesScreen(db, self),
            "practice": PracticeScreen(db, self),
        }
        self.alphabet_dialog = None
        for key, _, _ in NAV_ITEMS:
            self.stack.addWidget(self.screens[key])

        # ------------------------------------------------------ statusbar
        self.status_label = QLabel()
        self.statusBar().addPermanentWidget(self.status_label)
        self.statusBar().setSizeGripEnabled(False)

        # ------------------------------------------------------ shortcuts
        QShortcut(QKeySequence("Ctrl+I"), self, activated=lambda: self.navigate("import"))
        QShortcut(QKeySequence("Ctrl+R"), self, activated=self.start_review)
        QShortcut(QKeySequence("Ctrl+Q"), self, activated=self.quit_for_real)
        QShortcut(QKeySequence("F1"), self, activated=lambda: self.navigate("help"))
        QShortcut(QKeySequence(Qt.Key.Key_Escape), self, activated=self.escape_pressed)

        # The dashboard greets everyone: a new deck gets its "get started"
        # checklist there, an old one its numbers.
        self.refresh_nav()
        self.navigate("dashboard")

        # ----------------------------------------------- tray + reminder
        self.tray = None
        if QSystemTrayIcon.isSystemTrayAvailable() and os.path.exists(icon_path):
            self.tray = QSystemTrayIcon(QIcon(icon_path), self)
            self.tray.setToolTip("VocabMaster")
            tray_menu = QMenu()
            tray_menu.addAction("Open VocabMaster", self.show_from_tray)
            tray_menu.addAction("Study now", self.study_from_tray)
            tray_menu.addSeparator()
            tray_menu.addAction("Quit", self.quit_for_real)
            self.tray.setContextMenu(tray_menu)
            self.tray.activated.connect(
                lambda reason: self.show_from_tray()
                if reason != QSystemTrayIcon.ActivationReason.Context else None)
            self.tray.messageClicked.connect(self.study_from_tray)
            self.tray.show()
        self.reminder_timer = QTimer(self)
        self.reminder_timer.setInterval(60 * 1000)
        self.reminder_timer.timeout.connect(self.check_reminder)
        self.reminder_timer.start()
        QTimer.singleShot(15 * 1000, self.check_reminder)

    # ------------------------------------------------------------ routing

    # --------------------------------------------------------------- decks

    def update_title(self):
        """The open deck in the title bar once there is more than one."""
        base = "VocabMaster" + (f" — {paths.PROFILE} profile" if paths.PROFILE else "")
        if len(decks.ids()) > 1:
            base += f" — {decks.label(self.deck_button.here())}"
        self.setWindowTitle(base)
        self.deck_button.refresh()

    def switch_deck(self, deck_id):
        """One deck is open at a time: remember the choice, close, and open
        again on it (main.py syncs the deck being left on the way out)."""
        importer = self.screens.get("import")
        if importer is not None and getattr(importer, "_busy", False):
            QMessageBox.information(
                self, "Switch deck",
                "New cards are being written right now. Wait until that finishes, "
                "then switch.")
            return False
        decks.set_current(deck_id)
        self.relaunch_requested = True
        QApplication.quit()
        return True

    def new_deck(self, target=None):
        """Ask for a name and languages, make the deck, open it."""
        dialog = NewDeckDialog(self, self.db, target)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return False
        name, langs = dialog.values()
        deck_id = decks.create(name, langs, copy_from=self.db.path)
        return self.switch_deck(deck_id)

    def join_deck(self, about):
        """Open on this computer a deck another computer keeps in Drive."""
        name = (about.get("deck_name") or "").strip()
        title = about["lang_target"] + (f" · {name}" if name else "")
        answer = QMessageBox.question(
            self, "Open here",
            f"Open your {title} deck on this computer too? Its words and progress "
            "arrive from Google Drive in the first minute.")
        if answer != QMessageBox.StandardButton.Yes:
            return False
        langs = {key: about.get(key, "") or "" for key in languages.KEYS}
        deck_id = decks.create(name, langs, copy_from=self.db.path, space=about["space"])
        return self.switch_deck(deck_id)

    def refresh_nav(self):
        """The Alphabet entry exists only for languages that have one to learn."""
        target = languages.load(self.db.get_setting).target
        alphabet = alphabets.for_language(target)
        self.nav_buttons["alphabet"].setVisible(alphabet is not None)
        if alphabet is not None:          # あ for Japanese, ㄱ for Korean, Ω for Greek
            self.nav_buttons["alphabet"].setText(f"{alphabet['icon']}  Alphabet")

    def show_alphabet(self):
        """The chart beside the card (A on the Study and Quiz screens)."""
        if self.alphabet_dialog is None:
            self.alphabet_dialog = AlphabetDialog(self.db, self)
        if self.alphabet_dialog.refresh():
            self.alphabet_dialog.show()
            self.alphabet_dialog.raise_()

    def navigate(self, key):
        leaving = self.current_key
        self.current_key = key
        if key == "settings" or leaving == "settings":
            self.refresh_nav()
        for name, button in self.nav_buttons.items():
            button.setChecked(name == key)
        screen = self.screens[key]
        screen.refresh()
        self.stack.setCurrentWidget(screen)
        self.update_status()
        # Ratings just made should reach the other computer before you get
        # there — leaving a study screen is the moment to send them.
        if leaving in STUDY_SCREENS and key not in STUDY_SCREENS:
            self.start_sync()

    def start_review(self):
        self.navigate("study")

    def escape_pressed(self):
        current = self.stack.currentWidget()
        if current in (self.screens["study"], self.screens["quiz"]):
            self.navigate("dashboard")

    def update_status(self):
        streak = self.db.current_streak()
        due = self.db.due_count()
        text = (f"🔥 Streak: {streak} day{'s' if streak != 1 else ''}    •    "
                f"📌 {due} card{'s' if due != 1 else ''} due    ")
        if self._sync_note:
            text = f"{self._sync_note}    •    " + text
        self.status_label.setText(text)

    # ------------------------------------------------------ tray / quit

    def show_from_tray(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def study_from_tray(self):
        self.show_from_tray()
        self.navigate("study")

    def keep_in_tray(self):
        """Closing hides instead of quitting once the reminder or autostart
        is on — the app has a job to do while the window is away."""
        return self.tray is not None and (
            self.db.get_setting("reminder_enabled") == "1"
            or self.db.get_setting("autostart") == "1")

    def quit_for_real(self):
        self._quitting = True
        QApplication.quit()

    def closeEvent(self, event):
        if self.keep_in_tray() and not self._quitting:
            event.ignore()
            self.hide()
            if self.db.get_setting("tray_hint_shown") != "1":
                self.db.set_setting("tray_hint_shown", "1")
                reminder.notify(self.tray, "Still here, in the tray",
                                "VocabMaster keeps running for your daily reminder. "
                                "Right-click the icon to quit.")
            return
        super().closeEvent(event)

    def check_reminder(self):
        message = reminder.due_message(self.db)
        if message:
            reminder.notify(self.tray, "VocabMaster", message)

    # --------------------------------------------------------- cloud sync

    def start_sync(self):
        """One background sync cycle; silent no-op when nothing is
        configured, and never two at once."""
        if self._syncing:
            return
        self._syncing = True

        def work():
            engine = SyncEngine(self.db)
            try:
                result = engine.sync()
            finally:
                engine.close()
            try:
                self.sync_finished.emit(result)
            except RuntimeError:
                pass                  # the window closed while the sync ran

        threading.Thread(target=work, daemon=True).start()

    def _on_sync_finished(self, result):
        self._syncing = False
        self.deck_button.refresh()
        if result.get("ok"):
            self._sync_note = f"☁ synced {datetime.now():%H:%M}"
            # Something arrived from the other computer: screens that merely
            # display the deck pick it up; a study session in progress is
            # never disturbed.
            if result.get("pulled") and self.current_key in ("dashboard", "browse", "stats"):
                self.screens[self.current_key].refresh()
        elif result.get("reason") == "sync not configured":
            self._sync_note = ""
        else:
            self._sync_note = "☁ sync failed"
            log.warning("sync failed: %s", result.get("reason"))
        self.update_status()

    # ------------------------------------------------------------ updates

    def offer_update(self, info):
        self._update_info = info
        notes = (info.get("notes") or "").strip()
        self.update_label.setText(
            f"<b>VocabMaster {info['version']}</b> is available"
            + (f" — {notes}" if notes else "") + ".")
        self.update_button.setEnabled(True)
        self.update_button.setText("Update & restart")
        self.update_banner.show()

    def check_updates_now(self):
        """From Help: the same check, but it answers either way."""
        def work():
            info = updater.check()
            if info:
                self.update_available.emit(info)
            else:
                self.update_result.emit(True, f"You have the latest version ({VERSION}).")

        threading.Thread(target=work, daemon=True).start()

    def apply_update(self):
        info = self._update_info
        if not info:
            return
        self.update_button.setEnabled(False)
        self.update_button.setText("Downloading…")

        def work():
            try:
                version = updater.apply(info, progress=None)
                self.update_result.emit(True, f"Updated to {version}. VocabMaster will restart.")
            except Exception as exc:
                log.exception("update failed")
                self.update_result.emit(False, f"The update could not be installed: {exc}")

        threading.Thread(target=work, daemon=True).start()

    def _on_update_result(self, ok, message):
        if ok and message.startswith("Updated to"):
            QMessageBox.information(self, "Updated", message)
            self.relaunch_requested = True
            QApplication.quit()
            return
        self.update_button.setEnabled(True)
        self.update_button.setText("Update & restart")
        (QMessageBox.information if ok else QMessageBox.warning)(
            self, "Updates", message)

    # ------------------------------------------- moving between computers

    def export_backup(self):
        """Everything — deck, progress, pictures, settings — as one .zip."""
        default = f"vocabmaster-backup-{datetime.now():%Y-%m-%d}.zip"
        path, _ = QFileDialog.getSaveFileName(
            self, "Export everything", default, "VocabMaster backup (*.zip)")
        if not path:
            return
        # The other machine has no Lexi to borrow a key from, so the bundle
        # carries whichever key the pictures use here.
        engine = images.ImageEngine(self.db.path)
        try:
            key = engine.api_key()
        finally:
            engine.close()
        try:
            info = transfer.export_bundle(
                self.db.path, path, {"openai_api_key": key} if key else None)
        except (OSError, sqlite3.Error) as exc:
            QMessageBox.warning(self, "Export failed", str(exc))
            return
        QMessageBox.information(
            self, "Backup exported",
            f"{info['words']} words, {info['images']} pictures "
            f"({info['bytes'] / 1e6:.1f} MB)\n{path}\n\n"
            "The file contains your sync secret and OpenAI key — move it "
            "privately (AirDrop, USB) and delete it once restored.")

    def restore_backup(self):
        """Replace this computer's data with a bundle, then quit so the next
        launch opens the restored database cleanly."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Restore from a VocabMaster backup", "",
            "VocabMaster backup (*.zip)")
        if not path:
            return
        try:
            info = transfer.inspect_bundle(path)
        except (ValueError, OSError, zipfile.BadZipFile) as exc:
            QMessageBox.warning(self, "Not a VocabMaster backup", str(exc))
            return
        here = self.db.word_count()
        kept = (f"The {here} words here are kept in backups/pre-restore-….db.\n"
                if here else "")
        confirm = QMessageBox.question(
            self, "Restore everything?",
            f"Backup: {info['words']} words, {info['images']} pictures.\n{kept}\n"
            "VocabMaster closes when it is done — open it again to continue.")
        if confirm != QMessageBox.StandardButton.Yes:
            return
        self.db.close()                 # no open handle may survive the swap
        try:
            transfer.restore_bundle(self.db.path, path)
        except Exception as exc:
            QMessageBox.critical(
                self, "Restore failed", f"{exc}\n\nOpen VocabMaster again and retry.")
            QApplication.quit()
            return
        QMessageBox.information(
            self, "Restored",
            f"{info['words']} words and {info['images']} pictures are on this "
            "computer now. Open VocabMaster again.")
        QApplication.quit()

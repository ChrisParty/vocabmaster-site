"""Stroke order for kana: strokes appear one by one, in writing order, over a
faint guide of the whole character; click to see it again.

Data: data/kana_strokes.json, made by tools/fetch_kana_strokes.py from
KanjiVG (c) Ulrich Apel, CC BY-SA 3.0, https://kanjivg.tagaini.net —
credited in Help. Each character: SVG paths in a 109 x 109 box, in order,
with the place of each stroke number.
"""

import json
import os

from PyQt6.QtCore import QByteArray, QRectF, Qt, QTimer
from PyQt6.QtGui import QPainter
from PyQt6.QtSvg import QSvgRenderer
from PyQt6.QtWidgets import QWidget

from styles import ACCENT, BORDER, TEXT_SECONDARY

_DATA = None


def _data():
    global _DATA
    if _DATA is None:
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "data", "kana_strokes.json")
        try:
            with open(path, encoding="utf-8") as f:
                _DATA = json.load(f)
        except (OSError, ValueError):
            _DATA = {}
    return _DATA


def has_strokes(symbol):
    """True when every character of `symbol` (あ, きゃ) has stroke data."""
    chars = [ch for ch in symbol if not ch.isspace()]
    return bool(chars) and all(ch in _data() for ch in chars)


class StrokeOrder(QWidget):
    """One or two kana side by side, drawn stroke by stroke."""

    STEP_MS = 550

    def __init__(self, size=140, parent=None):
        super().__init__(parent)
        self.box = size
        self.setFixedHeight(size)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("Stroke order — click to see it again")
        self._chars = []
        self._shown = 0
        self._total = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._step)
        self.hide()

    def set_symbol(self, symbol):
        data = _data()
        self._chars = [data[ch] for ch in symbol if ch in data] if has_strokes(symbol) else []
        self._total = sum(len(c["strokes"]) for c in self._chars)
        self.setVisible(bool(self._chars))
        self.replay()

    def clear(self):
        self._timer.stop()
        self._chars = []
        self.hide()

    def replay(self):
        self._shown = 0
        self.update()
        if self._chars:
            self._timer.start(self.STEP_MS)

    def mousePressEvent(self, event):
        self.replay()

    def _step(self):
        self._shown += 1
        if self._shown >= self._total:
            self._timer.stop()
        self.update()

    def _svg(self, char, first, shown):
        """SVG for one character: the whole thing faint, the strokes written
        so far in the accent colour, with their numbers."""
        guide = "".join(f'<path d="{d}"/>' for d in char["strokes"])
        done = char["strokes"][:max(0, shown - first)]
        drawn = "".join(f'<path d="{d}"/>' for d in done)
        numbers = "".join(
            f'<text x="{x}" y="{y}">{i + 1}</text>'
            for i, (x, y) in enumerate(char.get("numbers", [])[:len(done)]))
        return (
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 109 109">'
            f'<g fill="none" stroke="{BORDER}" stroke-width="3" stroke-linecap="round" '
            f'stroke-linejoin="round">{guide}</g>'
            f'<g fill="none" stroke="{ACCENT}" stroke-width="4" stroke-linecap="round" '
            f'stroke-linejoin="round">{drawn}</g>'
            f'<g fill="{TEXT_SECONDARY}" font-size="9" font-family="sans-serif">{numbers}</g>'
            '</svg>')

    def paintEvent(self, event):
        if not self._chars:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        size = self.box
        left = (self.width() - size * len(self._chars)) / 2
        first = 0
        for index, char in enumerate(self._chars):
            renderer = QSvgRenderer(QByteArray(self._svg(char, first, self._shown).encode()))
            renderer.render(painter, QRectF(left + index * size, 0, size, size))
            first += len(char["strokes"])

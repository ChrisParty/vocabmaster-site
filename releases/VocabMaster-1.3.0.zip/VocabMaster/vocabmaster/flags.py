"""Small painted flags for the languages the app knows.

Emoji flags are not an option: Windows draws them as two letters. These are
simplified designs painted by Qt at 18×12, recognisable at a glance and
quiet enough to sit next to a label. `html()` gives an <img> tag for rich
text labels (the PNG is cached in the data folder); `icon()` a QIcon for
combo boxes; `pixmap()` for painters.
"""

import os

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap

import paths
from styles import BORDER

W, H = 18, 12
_cache = {}


def _paint(name, painter, w, h):
    name = name.lower()
    if name == "english":
        painter.fillRect(0, 0, w, h, QColor("#1e40af"))
        for color, width in ((QColor("white"), 3.0), (QColor("#dc2626"), 1.2)):
            pen = QPen(color, width)
            painter.setPen(pen)
            painter.drawLine(QPointF(0, 0), QPointF(w, h))
            painter.drawLine(QPointF(w, 0), QPointF(0, h))
        for color, width in ((QColor("white"), 4.0), (QColor("#dc2626"), 2.2)):
            painter.setPen(QPen(color, width))
            painter.drawLine(QPointF(w / 2, 0), QPointF(w / 2, h))
            painter.drawLine(QPointF(0, h / 2), QPointF(w, h / 2))
    elif name == "greek":
        stripe = h / 9
        for i in range(9):
            painter.fillRect(QRectF(0, i * stripe, w, stripe + 0.5),
                             QColor("#1d4ed8") if i % 2 == 0 else QColor("white"))
        canton = stripe * 5
        painter.fillRect(QRectF(0, 0, canton, canton), QColor("#1d4ed8"))
        painter.setPen(QPen(QColor("white"), stripe))
        painter.drawLine(QPointF(canton / 2, 0), QPointF(canton / 2, canton))
        painter.drawLine(QPointF(0, canton / 2), QPointF(canton, canton / 2))
    elif name == "swedish":
        painter.fillRect(0, 0, w, h, QColor("#1d4ed8"))
        painter.setPen(QPen(QColor("#facc15"), h / 5))
        painter.drawLine(QPointF(w * 0.38, 0), QPointF(w * 0.38, h))
        painter.drawLine(QPointF(0, h / 2), QPointF(w, h / 2))
    elif name == "korean":
        painter.fillRect(0, 0, w, h, QColor("white"))
        r = h * 0.32
        centre = QRectF(w / 2 - r, h / 2 - r, 2 * r, 2 * r)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#dc2626"))
        painter.drawPie(centre, 0, 180 * 16)
        painter.setBrush(QColor("#1d4ed8"))
        painter.drawPie(centre, 180 * 16, 180 * 16)
    elif name == "japanese":
        painter.fillRect(0, 0, w, h, QColor("white"))
        r = h * 0.3
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#dc2626"))
        painter.drawEllipse(QRectF(w / 2 - r, h / 2 - r, 2 * r, 2 * r))
    else:
        return False
    return True


def pixmap(name, w=W, h=H):
    """A flag pixmap, or None for a language without one."""
    key = ((name or "").lower(), w, h)
    if key in _cache:
        return _cache[key]
    pm = QPixmap(w, h)
    pm.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pm)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    clip = QPainterPath()
    clip.addRoundedRect(QRectF(0, 0, w, h), 2, 2)
    painter.setClipPath(clip)
    known = _paint(name or "", painter, w, h)
    painter.setClipping(False)
    if known:
        painter.setPen(QPen(QColor(BORDER), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(QRectF(0.5, 0.5, w - 1, h - 1), 2, 2)
    painter.end()
    result = pm if known else None
    _cache[key] = result
    return result


def tag(name, label):
    """What to put before a translation in rich text: the flag when the
    language has one (it says enough on its own), else the text label."""
    img = html(name)
    return img if img else f"<b>{label}</b> "


def icon(name):
    pm = pixmap(name)
    return QIcon(pm) if pm else QIcon()


def html(name):
    """An <img> tag for rich-text labels, '' when there is no flag. The PNG
    is written once to the data folder (rich text needs a file)."""
    pm = pixmap(name, W * 2, H * 2)          # 2× so it stays crisp on HiDPI
    if pm is None:
        return ""
    folder = os.path.join(paths.data_dir(), "flags")
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"{name.lower()}.png")
    if not os.path.exists(path):
        pm.save(path, "PNG")
    return f'<img src="{path.replace(os.sep, "/")}" width="{W}" height="{H}"> '

"""Central color palette and application-wide QSS stylesheet."""

import platform

BG = "#0d1117"
SURFACE = "#161b22"
SURFACE_HOVER = "#1f2937"
SIDEBAR_BG = "#090d13"
ACCENT = "#3b82f6"
SUCCESS = "#22c55e"
WARNING = "#f59e0b"
DANGER = "#ef4444"
TEXT = "#f0f6fc"
TEXT_SECONDARY = "#8b949e"
TEXT_MUTED = "#484f58"
BORDER = "#30363d"


def app_font_family():
    system = platform.system()
    if system == "Windows":
        return "Segoe UI"
    if system == "Darwin":
        # The San Francisco system font is not installed under a public name;
        # this alias is how Qt reaches it. Falls back to the default if absent.
        return ".AppleSystemUIFont"
    return "Ubuntu"


FONT_SIZES = {"small": 9, "medium": 10, "large": 12}


def wrapping(label):
    """A QLabel that wraps to whatever width the layout gives it. Without
    the Ignored policy a wrapped label still asks for its full one-line
    width as a minimum, which pushes a scrolling page wider than the window
    and grows a horizontal scrollbar."""
    from PyQt6.QtWidgets import QSizePolicy
    label.setWordWrap(True)
    label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
    return label


def breakable_path(path):
    """A file path the label may wrap after any separator (zero-width
    spaces), so a long path never widens the page."""
    return path.replace("\\", "\\​").replace("/", "/​")


def build_stylesheet(font_size="medium"):
    base_pt = FONT_SIZES.get(font_size, 10)
    family = app_font_family()
    return f"""
QWidget {{
    background-color: {BG};
    color: {TEXT};
    font-family: "{family}";
    font-size: {base_pt}pt;
}}

QMainWindow, QDialog {{
    background-color: {BG};
}}

/* ------------------------------------------------------------- buttons */
QPushButton {{
    background-color: {SURFACE};
    color: {TEXT};
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 8px 16px;
}}
QPushButton:hover {{
    background-color: {SURFACE_HOVER};
    border-color: {TEXT_MUTED};
}}
QPushButton:pressed {{
    background-color: {BG};
}}
QPushButton:focus {{
    outline: none;
    border-color: {ACCENT};
}}
QPushButton:disabled {{
    color: {TEXT_MUTED};
    background-color: {BG};
}}

QPushButton#primary {{
    background-color: {ACCENT};
    color: white;
    border: none;
    font-weight: 600;
}}
QPushButton#primary:hover {{ background-color: #2563eb; }}
QPushButton#primary:disabled {{ background-color: {SURFACE}; color: {TEXT_MUTED}; }}

QPushButton#success {{
    background-color: {SUCCESS}; color: #052e12; border: none; font-weight: 600;
}}
QPushButton#success:hover {{ background-color: #16a34a; }}

QPushButton#rateAgain {{
    background-color: rgba(239, 68, 68, 0.15); color: {DANGER};
    border: 1px solid {DANGER}; font-weight: 600;
}}
QPushButton#rateAgain:hover {{ background-color: rgba(239, 68, 68, 0.3); }}
QPushButton#rateHard {{
    background-color: rgba(245, 158, 11, 0.15); color: {WARNING};
    border: 1px solid {WARNING}; font-weight: 600;
}}
QPushButton#rateHard:hover {{ background-color: rgba(245, 158, 11, 0.3); }}
QPushButton#rateGood {{
    background-color: rgba(34, 197, 94, 0.15); color: {SUCCESS};
    border: 1px solid {SUCCESS}; font-weight: 600;
}}
QPushButton#rateGood:hover {{ background-color: rgba(34, 197, 94, 0.3); }}
QPushButton#rateEasy {{
    background-color: rgba(59, 130, 246, 0.15); color: {ACCENT};
    border: 1px solid {ACCENT}; font-weight: 600;
}}
QPushButton#rateEasy:hover {{ background-color: rgba(59, 130, 246, 0.3); }}

/* -------------------------------------------------------------- sidebar */
QFrame#sidebar {{
    background-color: {SIDEBAR_BG};
    border-right: 1px solid {BORDER};
}}
QFrame#sidebar QLabel {{ background: transparent; }}
QPushButton#navButton {{
    background-color: transparent;
    color: {TEXT_SECONDARY};
    border: none;
    border-left: 3px solid transparent;
    border-radius: 0;
    padding: 12px 18px;
    text-align: left;
    font-size: {base_pt + 1}pt;
}}
QPushButton#navButton:hover {{
    background-color: {SURFACE};
    color: {TEXT};
}}
QPushButton#navButton:checked {{
    background-color: {SURFACE};
    color: {TEXT};
    border-left: 3px solid {ACCENT};
    font-weight: 600;
}}

/* ---------------------------------------------------------------- cards */
QFrame#card {{
    background-color: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 12px;
}}
QFrame#card QLabel {{ background: transparent; }}
QFrame#statCard {{
    background-color: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 12px;
}}
QFrame#statCard QLabel {{ background: transparent; }}

/* --------------------------------------------------------------- inputs */
QTextEdit, QLineEdit, QSpinBox, QComboBox {{
    background-color: {SURFACE};
    color: {TEXT};
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 6px 10px;
    selection-background-color: {ACCENT};
}}
QTextEdit:focus, QLineEdit:focus, QSpinBox:focus, QComboBox:focus {{
    border-color: {ACCENT};
}}
QComboBox::drop-down {{ border: none; width: 24px; }}
QComboBox QAbstractItemView {{
    background-color: {SURFACE};
    border: 1px solid {BORDER};
    selection-background-color: {SURFACE_HOVER};
    color: {TEXT};
}}
QSpinBox::up-button, QSpinBox::down-button {{
    background-color: {SURFACE_HOVER};
    border: none;
    width: 18px;
}}

/* ------------------------------------------------------------ checkboxes */
QCheckBox {{ spacing: 8px; }}
QCheckBox::indicator {{
    width: 16px; height: 16px;
    border: 1px solid {TEXT_MUTED};
    border-radius: 4px;
    background-color: {SURFACE};
}}
QCheckBox::indicator:hover {{ border-color: {ACCENT}; }}
QCheckBox::indicator:checked {{
    background-color: {ACCENT};
    border-color: {ACCENT};
}}

/* ---------------------------------------------------------------- table */
QTableWidget {{
    background-color: {BG};
    alternate-background-color: {SURFACE};
    gridline-color: transparent;
    border: 1px solid {BORDER};
    border-radius: 8px;
    color: {TEXT};
}}
QTableWidget::item {{
    padding: 6px 10px;
    border: none;
}}
QTableWidget::item:selected {{
    background-color: rgba(59, 130, 246, 0.25);
    color: {TEXT};
}}
QHeaderView::section {{
    background-color: {SIDEBAR_BG};
    color: {TEXT_SECONDARY};
    border: none;
    border-bottom: 1px solid {BORDER};
    padding: 10px;
    font-weight: 600;
}}
QTableCornerButton::section {{ background-color: {SIDEBAR_BG}; border: none; }}

/* ------------------------------------------------------------- progress */
QProgressBar {{
    background-color: {SURFACE};
    border: none;
    border-radius: 4px;
    height: 8px;
    text-align: center;
    color: transparent;
}}
QProgressBar::chunk {{
    background-color: {ACCENT};
    border-radius: 4px;
}}

/* ----------------------------------------------------------- scrollbars */
QScrollBar:vertical {{
    background: {BG}; width: 6px; margin: 0; border-radius: 3px;
}}
QScrollBar::handle:vertical {{
    background: {BORDER}; border-radius: 3px; min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{ background: {TEXT_MUTED}; }}
QScrollBar:horizontal {{
    background: {BG}; height: 6px; margin: 0; border-radius: 3px;
}}
QScrollBar::handle:horizontal {{
    background: {BORDER}; border-radius: 3px; min-width: 30px;
}}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: none; }}

/* -------------------------------------------------------------- statusbar */
QStatusBar {{
    background-color: {SIDEBAR_BG};
    color: {TEXT_SECONDARY};
    border-top: 1px solid {BORDER};
}}
QStatusBar::item {{ border: none; }}

/* ----------------------------------------------------------------- menu */
QMenu {{
    background-color: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 4px;
}}
QMenu::item {{
    padding: 6px 24px;
    border-radius: 4px;
    color: {TEXT};
}}
QMenu::item:selected {{ background-color: {SURFACE_HOVER}; }}

QToolTip {{
    background-color: {SURFACE};
    color: {TEXT};
    border: 1px solid {BORDER};
    padding: 4px;
}}

QMessageBox QLabel {{ color: {TEXT}; }}
"""

"""Help screen: how the app works, in the order a new user needs it.

One page, no wizard. The same words are in the tooltips; this is where
they are all in one place, plus the version and the update check.
"""

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

import paths
from styles import ACCENT, TEXT_SECONDARY, wrapping
from version import VERSION

SECTIONS = [
    ("Your daily rhythm", """
<p>Open the app, press <b>Start Flashcard Review</b>, rate each card, done —
ten minutes. The app decides <i>which</i> words you see: ones you are about
to forget come back, ones you know well wait weeks. That is spaced
repetition; it only works if you show up most days, so the dashboard keeps
a streak and a daily goal.</p>"""),
    ("The four buttons", f"""
<p>After you reveal a card, say honestly how it went:</p>
<p><b style="color:#ef4444">Again</b> (1) — blank. The card returns later in this session and tomorrow.<br>
<b style="color:#f59e0b">Hard</b> (2) — you got there, slowly. Short interval.<br>
<b style="color:#22c55e">Good</b> (3) — solid recall. The interval grows.<br>
<b style="color:{ACCENT}">Easy</b> (4) — instant. The interval grows fast.</p>
<p>Settings → <b>Study direction</b> decides which side you see first: the word (recognition), the meaning (you produce the word — harder and worth more), or both mixed. The <b>memory hook</b> under a card (the 💡 block) is not another
example: it is a way to remember — the word's parts, a real link to a language you
know, a vivid line. Each button shows when the card would come back. A word with an interval
of 21+ days counts as <b>mastered</b>. "Again" is information, not failure —
it is how the app learns what you need. Pressed the wrong key? <b>U</b>
takes the last rating back.</p>"""),
    ("Getting words", """
<p><b>Add Words → Build a starter deck</b>: the most useful words of your
language for your level, written as full cards by the AI (definition,
translations, example, memory hook), in batches of 20, saved as they come.
<b>Add one word</b> writes a single card for any word you meet. The Quiz can also ask you to <b>type</b> the word (Settings → Quiz style). Both use your
own OpenAI key (Settings) and stop at the daily AI budget — well under a dollar
per 1,000 words with the default model; Settings shows what today, this month
and all time have cost. A spreadsheet can still be pasted, under the fold.</p>"""),
    ("Learning the alphabet", """
<p>For Korean, Japanese or Greek the menu shows <b>Alphabet</b>: a one-minute
explanation, a practice drill (unknown letters first; three right answers in
a row and a letter is yours), and the full chart. On any card, <b>A</b> opens
the chart beside it, so a forgotten letter costs one glance. Ten minutes a
day for a week and the words stop looking like drawings.</p>"""),
    ("Keyboard", """
<table cellspacing="0" cellpadding="3">
<tr><td><b>Space</b></td><td>show the answer</td></tr>
<tr><td><b>1 2 3 4</b></td><td>rate the card / pick a quiz answer</td></tr>
<tr><td><b>P</b></td><td>pronounce the word</td></tr>
<tr><td><b>H</b></td><td>a hint (the first line of the memory hook)</td></tr>
<tr><td><b>T</b></td><td>tree view of the card</td></tr>
<tr><td><b>I</b></td><td>draw a picture for this word</td></tr>
<tr><td><b>U</b></td><td>undo the last rating (also Ctrl+Z)</td></tr>
<tr><td><b>A</b></td><td>the alphabet chart beside the card</td></tr>
<tr><td><b>More</b></td><td>on the card: edit it, reset its progress, remove it</td></tr>
<tr><td><b>Ctrl+R</b></td><td>start a review</td></tr>
<tr><td><b>Ctrl+I</b></td><td>Add Words</td></tr>
<tr><td><b>Esc</b></td><td>back to the dashboard</td></tr>
<tr><td><b>F1</b></td><td>this page</td></tr>
</table>
<p style="color:#8b949e">On a Mac, Ctrl is ⌘.</p>"""),
    ("Pictures", """
<p>A picture reaches the meaning faster than a definition. With an OpenAI
key, the app quietly draws pictures for the day's words at startup, and
<b>I</b> draws one for the card in front of you. Spending is capped per
day in Settings (<b>$0.10</b> by default, about 11 pictures); set it to
$0.00 to turn pictures off. The model draws the scene only — the labels
are written by the app, so they are never misspelled.</p>"""),
    ("Two computers", """
<p>Settings → <b>Connect Google Drive</b> on each computer, same Google
account. Your deck is mirrored into a hidden folder of <i>your own</i>
Drive — nothing is hosted anywhere else — and the computers stay in step:
after every study session, every 10 minutes, and when the app closes. For
each card the most recently studied version wins, so nothing done on either
side is lost. No cloud? <b>Export everything</b> makes a .zip you can
restore on the other machine.</p>"""),
    ("Never forget to show up", """
<p>Settings → <b>Daily reminder</b>: at the time you choose, if cards are due
and today's goal is not met, a notification says so; click it and the session
opens. Turn on <b>Start with the computer</b> and the app waits quietly in the
tray (menu bar on a Mac) so the reminder reaches you even on days you did not
think of it. Closing the window then keeps it there; Quit from the tray icon.</p>"""),
    ("Your data", f"""
<p>Everything is in one file on this computer:<br>
<code>{paths.data_dir()}</code><br>
A copy is made there every day (the last 7 are kept). Updating the app
never touches this folder. If something ever goes wrong, the details are
in <code>vocabmaster.log</code> in the same place.</p>"""),
]


class HelpScreen(QWidget):
    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)

        header = QLabel("How VocabMaster works")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(header)

        for title, body in SECTIONS:
            card = QFrame()
            card.setObjectName("card")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(24, 18, 24, 18)
            card_layout.setSpacing(6)
            heading = QLabel(title)
            heading.setStyleSheet("font-weight: 700; font-size: 12pt;")
            card_layout.addWidget(heading)
            text = QLabel(body.strip())
            text.setTextFormat(Qt.TextFormat.RichText)
            wrapping(text)
            text.setOpenExternalLinks(True)
            card_layout.addWidget(text)
            layout.addWidget(card)

        # ----- version + updates -----
        version_card = QFrame()
        version_card.setObjectName("card")
        version_layout = QHBoxLayout(version_card)
        version_layout.setContentsMargins(24, 16, 24, 16)
        self.version_label = QLabel(f"VocabMaster {VERSION}")
        self.version_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        version_layout.addWidget(self.version_label)
        version_layout.addStretch()
        update_button = QPushButton("Check for updates")
        update_button.setCursor(Qt.CursorShape.PointingHandCursor)
        update_button.setToolTip("Looks for a newer version; updating never touches your data.")
        update_button.clicked.connect(self.main_window.check_updates_now)
        version_layout.addWidget(update_button)
        layout.addWidget(version_card)

        layout.addStretch()

    def refresh(self):
        pass

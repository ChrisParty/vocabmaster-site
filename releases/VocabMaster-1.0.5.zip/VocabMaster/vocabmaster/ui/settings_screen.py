"""Settings screen: study limits, font size, pictures (budget + key), moving
between computers, data location, CSV export, cloud sync status."""

import os
import platform
import threading

from PyQt6.QtCore import QTime, Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QCheckBox, QFileDialog, QFormLayout, QFrame, QHBoxLayout, QLabel, QLineEdit,
    QMessageBox, QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

import autostart
import cards_ai
import cloud
import flags
import images
import languages
import ledger
import paths
import reminder
from styles import TEXT, TEXT_SECONDARY, breakable_path, build_stylesheet, wrapping
from sync import SyncEngine
from ui.widgets import ComboBox, DoubleSpinBox, SpinBox, TimeEdit


class SettingsScreen(QWidget):
    # The Google sign-in waits on the browser from a worker thread; these
    # bring the outcome back to the UI thread.
    connected = pyqtSignal(str)
    connect_failed = pyqtSignal(str)

    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self._loading = True      # set before any widget can emit a change
        self.connected.connect(self._on_connected)
        self.connect_failed.connect(self._on_connect_failed)
        self.main_window.sync_finished.connect(self._on_sync_result)

        # Five cards no longer fit a small window at the large font; the page
        # scrolls (like Stats) instead of squeezing rows into each other.
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)

        header = QLabel("Settings")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(header)

        card = QFrame()
        card.setObjectName("card")
        form = QFormLayout(card)
        form.setContentsMargins(24, 20, 24, 20)
        form.setSpacing(14)

        self.daily_goal = SpinBox()
        self.daily_goal.setRange(1, 500)
        self.daily_goal.setToolTip(
            "How many cards (new or repeated) count as a finished day — the "
            "dashboard's Today: n / goal ✓. Reviews of old words are most of a "
            "day, so set this higher than the new-cards limit, e.g. 15–20.")
        self.daily_goal.valueChanged.connect(
            lambda value: self.db.set_setting("daily_goal", value)
        )
        form.addRow("Daily review goal", self.daily_goal)

        self.max_new = SpinBox()
        self.max_new.setRange(0, 500)
        self.max_new.setToolTip(
            "How many never-seen words enter your deck per day. The one knob "
            "that sets your pace: 5 is relaxed, 20 is ambitious.")
        self.max_new.valueChanged.connect(
            lambda value: self.db.set_setting("max_new_per_day", value)
        )
        form.addRow("Max new cards per day", self.max_new)

        self.session_cap = SpinBox()
        self.session_cap.setRange(5, 500)
        self.session_cap.setToolTip(
            "How many cards one sitting shows before 'Session complete'. "
            "Comfort only — the app offers the next session if more are due.")
        self.session_cap.valueChanged.connect(
            lambda value: self.db.set_setting("session_cap", value)
        )
        form.addRow("Cards per session", self.session_cap)

        self.direction = ComboBox()
        for label, _ in self.DIRECTIONS:
            self.direction.addItem(label)
        self.direction.setToolTip(
            "Word → meaning is recognition. Meaning → word is the harder, more "
            "useful skill: you produce the word. Mixed alternates per card.")
        self.direction.currentIndexChanged.connect(self.change_direction)
        form.addRow("Study direction", self.direction)

        self.quiz_style = ComboBox()
        for label, _ in self.QUIZ_STYLES:
            self.quiz_style.addItem(label)
        self.quiz_style.setToolTip(
            "Multiple choice recognises; typing the word spells it out. Mixed does both.")
        self.quiz_style.currentIndexChanged.connect(self.change_quiz_style)
        form.addRow("Quiz style", self.quiz_style)

        self.font_size = ComboBox()
        self.font_size.addItems(["small", "medium", "large"])
        self.font_size.setToolTip("Text size across the app. Applies at once.")
        self.font_size.currentTextChanged.connect(self.change_font_size)
        form.addRow("Font size", self.font_size)

        self.db_label = wrapping(QLabel(breakable_path(os.path.abspath(self.db.path))))
        self.db_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        self.db_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        data_row = QHBoxLayout()
        data_row.setSpacing(10)
        data_row.addWidget(self.db_label, 1)
        open_button = QPushButton("Open folder")
        open_button.setCursor(Qt.CursorShape.PointingHandCursor)
        open_button.setToolTip("Your deck, its daily backups, pictures and the log live here.")
        open_button.clicked.connect(
            lambda: paths.open_folder(os.path.dirname(os.path.abspath(self.db.path))))
        data_row.addWidget(open_button)
        form.addRow("Your data", data_row)

        layout.addWidget(card)

        # ----- languages: what the deck is about (labels + what the AI writes) -----
        lang_card = QFrame()
        lang_card.setObjectName("card")
        lang_form = QFormLayout(lang_card)
        lang_form.setContentsMargins(24, 20, 24, 20)
        lang_form.setSpacing(14)
        lang_title = QLabel("Languages")
        lang_title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        lang_form.addRow(lang_title)
        self.lang_fields = {}
        for key, label, optional, tip in [
            ("lang_target", "Learning", False, "The language of the words."),
            ("lang_definition", "Definitions in", False,
             "The language definitions and memory hooks are written in — "
             "usually the one you are learning."),
            ("lang_native", "Translation", True,
             "Every card also carries a translation into this language."),
            ("lang_second", "Second translation", True, "Optional."),
        ]:
            field = ComboBox()
            if optional:
                field.addItem(languages.NONE)
            for choice in languages.CHOICES:
                field.addItem(flags.icon(choice), choice)
            field.setToolTip(tip)
            field.currentTextChanged.connect(lambda _, k=key: self.change_language(k))
            self.lang_fields[key] = field
            lang_form.addRow(label, field)
        if platform.system() == "Darwin":
            voice_hint = ("System Settings → Accessibility → Spoken Content → "
                          "System voice → Manage voices")
        else:
            voice_hint = "Windows Settings → Time & language → Speech → Add voices"
        lang_note = QLabel(
            "Pick up to three. Existing cards keep their text; this changes the "
            "labels on the cards and what the AI writes from now on.\n"
            f"The Say button uses your computer's voice for the language you are "
            f"learning — if it sounds wrong, install that language's voice under "
            f"{voice_hint}.")
        lang_note.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(lang_note)
        lang_form.addRow(lang_note)
        layout.addWidget(lang_card)

        # ----- the daily nudge -----
        remind_card = QFrame()
        remind_card.setObjectName("card")
        remind_form = QFormLayout(remind_card)
        remind_form.setContentsMargins(24, 20, 24, 20)
        remind_form.setSpacing(14)
        remind_title = QLabel("Daily reminder")
        remind_title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        remind_form.addRow(remind_title)
        remind_row = QHBoxLayout()
        self.remind_on = QCheckBox("Remind me every day at")
        self.remind_on.setToolTip(
            "A notification when cards are due and today's goal is not met yet. "
            "Click it to start the session.")
        self.remind_on.toggled.connect(self.change_reminder)
        self.remind_time = TimeEdit()
        self.remind_time.setDisplayFormat("HH:mm")
        self.remind_time.timeChanged.connect(self.change_reminder)
        remind_row.addWidget(self.remind_on)
        remind_row.addWidget(self.remind_time)
        remind_row.addStretch()
        remind_form.addRow(remind_row)
        self.autostart_on = QCheckBox("Start with the computer, quietly in the tray")
        self.autostart_on.setToolTip(
            "So the reminder can reach you even when you did not open the app. "
            "Closing the window then keeps it in the tray; Quit from the tray icon.")
        self.autostart_on.toggled.connect(self.change_autostart)
        remind_form.addRow(self.autostart_on)
        remind_note = wrapping(QLabel(
            "With either of these on, closing the window keeps VocabMaster in the "
            "tray (menu bar on a Mac). Right-click the icon to quit."))
        remind_note.setStyleSheet(f"color: {TEXT_SECONDARY};")
        remind_form.addRow(remind_note)
        layout.addWidget(remind_card)

        # ----- AI-written cards (starter decks, Add one word): own hard cap -----
        text_card = QFrame()
        text_card.setObjectName("card")
        text_form = QFormLayout(text_card)
        text_form.setContentsMargins(24, 20, 24, 20)
        text_form.setSpacing(14)
        self.text_cap = DoubleSpinBox()
        self.text_cap.setRange(0.00, 20.00)
        self.text_cap.setDecimals(2)
        self.text_cap.setSingleStep(0.25)
        self.text_cap.setPrefix("$ ")
        self.text_cap.setToolTip(
            "Starter decks and single cards stop for the day once this much "
            "has been spent. $0.00 turns them off.")
        self.text_cap.valueChanged.connect(self.change_text_cap)
        text_form.addRow("AI cards budget per day", self.text_cap)
        self.card_quality = ComboBox()
        for label, _ in self.CARD_MODELS:
            self.card_quality.addItem(label)
        self.card_quality.setToolTip(
            "Luna: the best memory hooks for the money, about $0.60 per 1,000 cards, "
            "a few seconds per card. Sol: the very best, about $5 per 1,000. gpt-4o: "
            "fast and plain, about $2 per 1,000. All obey the daily budget.")
        self.card_quality.currentIndexChanged.connect(self.change_card_quality)
        text_form.addRow("AI card quality", self.card_quality)
        self.text_status = QLabel("")
        self.text_status.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(self.text_status)
        text_form.addRow("Spending", self.text_status)
        layout.addWidget(text_card)

        # ----- what the AI has cost: three numbers, nothing to decode -----
        spend_card = QFrame()
        spend_card.setObjectName("card")
        spend_layout = QVBoxLayout(spend_card)
        spend_layout.setContentsMargins(24, 18, 24, 18)
        spend_layout.setSpacing(10)
        spend_title = QLabel("What the AI has cost")
        spend_title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        spend_layout.addWidget(spend_title)
        tiles = QHBoxLayout()
        tiles.setSpacing(14)
        self.spend_tiles = {}
        for key, title in (("today", "Today"), ("month", "This month"), ("all", "All time")):
            tile = QFrame()
            tile.setObjectName("statCard")
            tile_layout = QVBoxLayout(tile)
            tile_layout.setContentsMargins(18, 14, 18, 14)
            tile_layout.setSpacing(2)
            value = QLabel("$0.00")
            value.setStyleSheet(f"font-size: 20pt; font-weight: 700; color: {TEXT};")
            head = QLabel(title)
            head.setStyleSheet(f"color: {TEXT_SECONDARY};")
            tile_layout.addWidget(value)
            tile_layout.addWidget(head)
            tiles.addWidget(tile, 1)
            self.spend_tiles[key] = value
        spend_layout.addLayout(tiles)
        self.spend_note = wrapping(QLabel(""))
        self.spend_note.setStyleSheet(f"color: {TEXT_SECONDARY};")
        spend_layout.addWidget(self.spend_note)
        layout.addWidget(spend_card)

        # ----- card illustrations (hard daily spending cap) -----
        image_card = QFrame()
        image_card.setObjectName("card")
        image_form = QFormLayout(image_card)
        image_form.setContentsMargins(24, 20, 24, 20)
        image_form.setSpacing(14)

        self.image_cap = DoubleSpinBox()
        self.image_cap.setRange(0.00, 5.00)
        self.image_cap.setDecimals(2)
        self.image_cap.setSingleStep(0.05)
        self.image_cap.setPrefix("$ ")
        self.image_cap.setToolTip(
            "Images stop for the day once this much has been spent. "
            "Set it to $0.00 to turn generation off entirely.")
        self.image_cap.valueChanged.connect(self.change_image_cap)
        image_form.addRow("Image budget per day", self.image_cap)

        self.image_quality = ComboBox()
        self.image_quality.addItems(["low", "medium", "high"])
        self.image_quality.currentTextChanged.connect(self.change_image_quality)
        image_form.addRow("Image quality", self.image_quality)

        # Stored in this computer's database only. On Windows it may stay
        # blank: images.py then borrows the key Lexi already holds. A Mac has
        # no Lexi, so there the key has to be here (the backup bundle carries
        # it across, so usually nothing needs typing).
        self.api_key = QLineEdit()
        self.api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key.setPlaceholderText("sk-…   (blank on Windows = share Lexi's key)")
        self.api_key.setToolTip(
            "Needed to draw pictures. Saved only in this computer's database.")
        self.api_key.editingFinished.connect(self.change_api_key)
        image_form.addRow("OpenAI key", self.api_key)

        self.image_status = QLabel("")
        self.image_status.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(self.image_status)
        image_form.addRow("Spending", self.image_status)

        layout.addWidget(image_card)

        # ----- moving between computers (the cloud-free path) -----
        move_card = QFrame()
        move_card.setObjectName("card")
        move_layout = QVBoxLayout(move_card)
        move_layout.setContentsMargins(24, 20, 24, 20)
        move_layout.setSpacing(10)
        move_title = QLabel("Move to another computer")
        move_title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        move_layout.addWidget(move_title)
        move_note = QLabel(
            "Export packs the whole deck — words, progress, pictures, settings "
            "and keys — into one .zip. Restore it on the other machine from "
            "here or from the Import screen. The file contains your keys: move "
            "it privately and delete it afterwards.")
        move_note.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(move_note)
        move_layout.addWidget(move_note)
        move_row = QHBoxLayout()
        move_row.setSpacing(10)
        export_bundle_button = QPushButton("📦  Export everything (.zip)")
        export_bundle_button.setMinimumHeight(44)
        export_bundle_button.setCursor(Qt.CursorShape.PointingHandCursor)
        export_bundle_button.clicked.connect(self.main_window.export_backup)
        restore_button = QPushButton("📥  Restore from a backup…")
        restore_button.setMinimumHeight(44)
        restore_button.setCursor(Qt.CursorShape.PointingHandCursor)
        restore_button.clicked.connect(self.main_window.restore_backup)
        move_row.addWidget(export_bundle_button)
        move_row.addWidget(restore_button)
        move_layout.addLayout(move_row)
        layout.addWidget(move_card)

        export_button = QPushButton("📤  Export progress to CSV")
        export_button.setMinimumHeight(44)
        export_button.setCursor(Qt.CursorShape.PointingHandCursor)
        export_button.clicked.connect(self.export_csv)
        layout.addWidget(export_button)

        # ----- cloud sync: the user's own Google Drive, one sign-in per device -----
        sync_card = QFrame()
        sync_card.setObjectName("card")
        sync_layout = QVBoxLayout(sync_card)
        sync_layout.setContentsMargins(24, 20, 24, 20)
        sync_layout.setSpacing(10)
        sync_title = QLabel("Cloud sync")
        sync_title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        sync_layout.addWidget(sync_title)
        self.sync_status = QLabel("")
        self.sync_status.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(self.sync_status)
        self.sync_status.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        sync_layout.addWidget(self.sync_status)
        sync_row = QHBoxLayout()
        sync_row.setSpacing(10)
        self.connect_button = QPushButton("☁  Connect Google Drive…")
        self.connect_button.setObjectName("primary")
        self.connect_button.setMinimumHeight(44)
        self.connect_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.connect_button.clicked.connect(self.connect_gdrive)
        self.sync_button = QPushButton("🔄  Sync now")
        self.sync_button.setMinimumHeight(44)
        self.sync_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.sync_button.clicked.connect(self.sync_now)
        self.disconnect_button = QPushButton("Disconnect")
        self.disconnect_button.setMinimumHeight(44)
        self.disconnect_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.disconnect_button.clicked.connect(self.disconnect_gdrive)
        sync_row.addWidget(self.connect_button)
        sync_row.addWidget(self.sync_button)
        sync_row.addWidget(self.disconnect_button)
        sync_layout.addLayout(sync_row)
        sync_note = QLabel(
            "Your deck is mirrored into a hidden folder of your own Google "
            "Drive — nothing in between, nothing that pauses. Sign in with the "
            "same Google account on each computer and they stay in step: after "
            "every study session, every 10 minutes, and when the app closes. "
            "The local file above always remains the working copy."
        )
        sync_note.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(sync_note)
        sync_layout.addWidget(sync_note)
        layout.addWidget(sync_card)

        layout.addStretch()
        self._loading = False

    DIRECTIONS = [("Word → meaning", "forward"), ("Meaning → word", "reverse"),
                  ("Mixed — both ways", "mixed")]
    QUIZ_STYLES = [("Multiple choice", "choice"), ("Type the answer", "typing"),
                   ("Mixed", "mixed")]
    CARD_MODELS = [("Best value - gpt-6-luna (default)", "gpt-6-luna"),
                   ("Best - gpt-6-sol", "gpt-6-sol"),
                   ("Fast - gpt-4o", "gpt-4o")]

    def refresh(self):
        self._loading = True
        direction = self.db.get_setting("study_direction", "forward")
        self.direction.setCurrentIndex(
            next((i for i, (_, v) in enumerate(self.DIRECTIONS) if v == direction), 0))
        quiz_mode = self.db.get_setting("quiz_mode", "choice")
        self.quiz_style.setCurrentIndex(
            next((i for i, (_, v) in enumerate(self.QUIZ_STYLES) if v == quiz_mode), 0))
        self.remind_on.setChecked(self.db.get_setting("reminder_enabled") == "1")
        self.remind_time.setTime(QTime.fromString(
            self.db.get_setting("reminder_time") or reminder.DEFAULT_TIME, "HH:mm"))
        self.autostart_on.setChecked(autostart.enabled())
        model = self.db.get_setting("card_model", cards_ai.MODEL)
        self.card_quality.setCurrentIndex(
            next((i for i, (_, v) in enumerate(self.CARD_MODELS) if v == model), 0))
        self.daily_goal.setValue(self.db.get_int_setting("daily_goal", 20))
        self.max_new.setValue(self.db.get_int_setting("max_new_per_day", 20))
        self.session_cap.setValue(self.db.get_int_setting("session_cap", 20))
        self.font_size.setCurrentText(self.db.get_setting("font_size", "medium"))
        self.image_cap.setValue(float(
            self.db.get_setting("image_daily_cap", images.DEFAULT_CAP)))
        self.image_quality.setCurrentText(
            self.db.get_setting("image_quality", images.QUALITY))
        self.api_key.setText(self.db.get_setting("openai_api_key", "") or "")
        for key, field in self.lang_fields.items():
            value = self.db.get_setting(key, "") or ""
            if field.findText(value) < 0:       # a name typed before the dropdowns
                field.addItem(value)
            field.setCurrentText(value or languages.NONE)
        self.text_cap.setValue(float(
            self.db.get_setting("text_daily_cap", cards_ai.DEFAULT_CAP)))
        self._loading = False
        self.refresh_sync_status()
        self.refresh_image_status()
        self.refresh_text_status()
        self.refresh_spending()

    def change_direction(self, index):
        if not self._loading:
            self.db.set_setting("study_direction", self.DIRECTIONS[index][1])

    def change_quiz_style(self, index):
        if not self._loading:
            self.db.set_setting("quiz_mode", self.QUIZ_STYLES[index][1])

    def change_card_quality(self, index):
        if not self._loading:
            self.db.set_setting("card_model", self.CARD_MODELS[index][1])
            self.refresh_text_status()
            self.refresh_spending()

    def change_reminder(self, *_):
        if self._loading:
            return
        self.db.set_setting("reminder_enabled", "1" if self.remind_on.isChecked() else "0")
        self.db.set_setting("reminder_time", self.remind_time.time().toString("HH:mm"))
        self.db.set_setting("reminder_last", "")      # a changed time may fire today

    def change_autostart(self, on):
        if self._loading:
            return
        try:
            autostart.enable() if on else autostart.disable()
            self.db.set_setting("autostart", "1" if on else "0")
        except Exception as exc:
            QMessageBox.warning(self, "Could not change autostart", str(exc))
            self._loading = True
            self.autostart_on.setChecked(not on)
            self._loading = False

    def change_language(self, key):
        if self._loading:
            return
        value = self.lang_fields[key].currentText()
        if value == languages.NONE:
            value = ""
        # A translation into the language being learned is no translation.
        learning = self.lang_fields["lang_target"].currentText()
        if key in ("lang_native", "lang_second") and value == learning:
            self._loading = True
            self.lang_fields[key].setCurrentText(languages.NONE)
            self._loading = False
            value = ""
        self.db.set_setting(key, value)
        self.db.set_setting("lang_confirmed", "1")     # the dashboard's checklist

    def refresh_spending(self):
        state = ledger.spending(self.db.conn)
        for key in ("today", "month", "all"):
            self.spend_tiles[key].setText(f"${state[key]:.2f}")
        text_cap = float(self.db.get_setting("text_daily_cap", cards_ai.DEFAULT_CAP))
        image_cap = float(self.db.get_setting("image_daily_cap", images.DEFAULT_CAP))
        model = self.db.get_setting("card_model", cards_ai.MODEL)
        self.spend_note.setText(
            f"Today: ${state['today_cards']:.3f} on cards, ${state['today_pictures']:.3f} on "
            f"pictures. The app stops by itself at ${text_cap:.2f} for cards and "
            f"${image_cap:.2f} for pictures per day. With the current model a card costs "
            f"about ${cards_ai.cost_per_thousand(model) / 1000:.4f}; a picture "
            f"${images.image_cost():.4f}. Billed by OpenAI to your own key.")

    def refresh_text_status(self):
        writer = cards_ai.CardWriter(self.db.path)
        try:
            state = writer.summary()
        finally:
            writer.close()
        self.text_status.setText(
            f"${state['spent_today']:.3f} of ${state['cap']:.2f} today "
            f"— ${state['lifetime']:.2f} in total. About "
            f"${cards_ai.cost_per_thousand(self.db.get_setting('card_model', cards_ai.MODEL)):.2f} "
            f"per 1,000 cards with the chosen model.")

    def change_text_cap(self, value):
        if self._loading:
            return
        self.db.set_setting("text_daily_cap", f"{value:.2f}")
        self.refresh_text_status()
        self.refresh_spending()

    def refresh_image_status(self):
        engine = images.ImageEngine(self.db.path)
        try:
            state = engine.summary()
            key = engine.api_key()
        finally:
            engine.close()
        if not key:
            source = "No OpenAI key — pictures are off until one is pasted above."
        elif self.db.get_setting("openai_api_key"):
            source = f"Key set here (…{key[-4:]})."
        else:
            source = "Using Lexi's shared key."
        remaining = state["words"] - state["images"] - state["skipped"]
        self.image_status.setText(
            f"{source}\n"
            f"${state['spent_today']:.4f} of ${state['cap']:.2f} today "
            f"— room for {state['affordable']} more "
            f"(${state['each']:.4f} each)\n"
            f"{state['images']} words illustrated, {remaining} to go "
            f"— ${state['lifetime']:.2f} spent in total")

    def change_api_key(self):
        if self._loading:
            return
        self.db.set_setting("openai_api_key", self.api_key.text().strip())
        self.refresh_image_status()

    def change_image_cap(self, value):
        if self._loading:
            return
        self.db.set_setting("image_daily_cap", f"{value:.2f}")
        self.refresh_image_status()

    def change_image_quality(self, quality):
        if self._loading:
            return
        self.db.set_setting("image_quality", quality)
        self.refresh_image_status()

    # ------------------------------------------------------------ cloud sync

    def refresh_sync_status(self):
        backend = cloud.active_backend(self.db.get_setting)
        last = self.db.get_setting("sync_last_ok")
        when = (f"last synced {last[:16].replace('T', ' ')} UTC" if last
                else "not synced yet")
        if backend == "gdrive":
            account = self.db.get_setting("gdrive_account") or "your Google account"
            self.sync_status.setText(f"Connected to Google Drive as {account} · {when}")
            self.connect_button.setVisible(False)
            self.sync_button.setVisible(True)
            self.disconnect_button.setVisible(True)
        elif backend == "supabase":
            self.sync_status.setText(
                f"Still on the old Supabase sync · {when}\n"
                "Its free tier pauses after a week idle — switch to Google Drive.")
            self.connect_button.setText("☁  Switch to Google Drive…")
            self.connect_button.setVisible(True)
            self.sync_button.setVisible(True)
            self.disconnect_button.setVisible(False)
        else:
            self.sync_status.setText(
                "Not connected — this computer is on its own. Connect the same "
                "Google account here and on the other computer.")
            self.connect_button.setText("☁  Connect Google Drive…")
            self.connect_button.setVisible(True)
            self.sync_button.setVisible(False)
            self.disconnect_button.setVisible(False)
        self.connect_button.setEnabled(True)

    def connect_gdrive(self):
        """Sign in with Google. The first time on a machine the app needs the
        OAuth client file from Google Cloud (docs/GOOGLE-DRIVE-SETUP.md);
        a restored backup already carries it."""
        client_id = self.db.get_setting("gdrive_client_id")
        secret = self.db.get_setting("gdrive_client_secret")
        # A copy handed to a friend ships google_client.json next to main.py
        # (tools/make_release.py puts it there), so they never see a file dialog.
        bundled = os.path.join(os.path.dirname(os.path.abspath(self.db.path)),
                               "google_client.json")
        if not (client_id and secret) and os.path.exists(bundled):
            try:
                client_id, secret = cloud.read_client_file(bundled)
            except (OSError, ValueError):
                client_id = secret = None
        if not (client_id and secret):
            path, _ = QFileDialog.getOpenFileName(
                self, "Choose the Google client file (client_secret_….json)",
                "", "Google client file (*.json)")
            if not path:
                return
            try:
                client_id, secret = cloud.read_client_file(path)
            except (OSError, ValueError) as exc:
                QMessageBox.warning(self, "Not a Google client file", str(exc))
                return
        self.connect_button.setEnabled(False)
        self.sync_status.setText(
            "Finish signing in in your browser — this screen waits up to three minutes.")

        def work():
            engine = SyncEngine(self.db)      # own connection: safe off-thread
            try:
                account = cloud.connect(engine.setting, engine.set_setting,
                                        client_id, secret)
                engine.reset_for_new_backend()
                self.connected.emit(account)
            except Exception as exc:
                self.connect_failed.emit(str(exc))
            finally:
                engine.close()

        threading.Thread(target=work, daemon=True).start()

    def _on_connected(self, account):
        self.refresh_sync_status()
        self.main_window.start_sync()        # first push: the whole deck

    def _on_connect_failed(self, message):
        self.refresh_sync_status()
        self.sync_status.setText(f"Could not connect: {message}")

    def disconnect_gdrive(self):
        confirm = QMessageBox.question(
            self, "Disconnect Google Drive",
            "Stop syncing this computer? Your deck stays here, and everything "
            "already in your Drive stays there.")
        if confirm == QMessageBox.StandardButton.Yes:
            cloud.disconnect(self.db.set_setting)
            self.refresh_sync_status()

    def sync_now(self):
        self.sync_button.setEnabled(False)
        self.sync_button.setText("Syncing…")
        self.main_window.start_sync()

    def _on_sync_result(self, result):
        self.sync_button.setEnabled(True)
        self.sync_button.setText("🔄  Sync now")
        if not self.isVisible():
            return
        if result.get("ok"):
            self.refresh_sync_status()
            self.sync_status.setText(
                self.sync_status.text() + f"\nJust now: pulled {result['pulled']}, "
                f"pushed {result['pushed']}, pictures ↑{result['images_sent']} "
                f"↓{result['images_fetched']}.")
        elif result.get("reason") != "sync not configured":
            self.sync_status.setText(f"Sync failed: {result.get('reason')}")

    def change_font_size(self, size):
        if self._loading:
            return
        self.db.set_setting("font_size", size)
        app = self.main_window.parent() or self.main_window
        from PyQt6.QtWidgets import QApplication

        QApplication.instance().setStyleSheet(build_stylesheet(size))

    def export_csv(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Export progress", "vocabmaster_export.csv", "CSV files (*.csv)"
        )
        if not path:
            return
        try:
            count = self.db.export_csv(path)
            QMessageBox.information(
                self, "Export complete", f"Exported {count} words to:\n{path}"
            )
        except OSError as exc:
            QMessageBox.warning(self, "Export failed", str(exc))

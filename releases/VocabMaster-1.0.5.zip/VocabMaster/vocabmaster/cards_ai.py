"""AI-written cards: one word on demand, or a starter deck of the most
common words of a language — under the same hard daily budget as pictures.

Two calls, both gpt-4o-mini, both debited before they go out:

  common_words   "the next N most frequent <target> words, not in this list"
                 The model is an approximate frequency list, which is good
                 enough for a starter deck; duplicates are filtered here.
  write_cards    full cards for a batch of words: definition in the deck's
                 definition language, translations in its native/second
                 languages, part of speech, synonyms, example, memory hook.

The budget estimate for a call is deliberately generous and settled to the
real token count afterwards, so the gate can only ever be too strict.
"""

import json
import re
import sqlite3
import urllib.request
from datetime import datetime

import database
import languages
from ledger import BudgetExhausted, Ledger, open_connection

CHAT_URL = "https://api.openai.com/v1/chat/completions"
# Two qualities: the cheap one writes a good card most of the time; the
# expensive one is what Mike's own deck was written with.
# (USD per 1M input, per 1M output, accepts a temperature). Reasoning models
# (the gpt-5/6 families) refuse any temperature but the default, and their
# thinking is billed as output tokens — roughly 4x the visible answer.
MODELS = {
    "gpt-6-luna": (0.20, 1.00, False),
    "gpt-6-sol": (2.50, 10.00, False),
    "gpt-4o": (2.50, 10.00, True),
    "gpt-4o-mini": (0.15, 0.60, True),
}
# Measured on real Korean cards (2026-10-17): tokens in / out per card, the
# reasoning included. Used for the "about $x per 1,000 cards" lines.
TOKENS_PER_CARD = {"gpt-6-luna": (110, 540), "gpt-6-sol": (110, 500),
                   "gpt-4o": (100, 140), "gpt-4o-mini": (100, 145)}
MODEL = "gpt-6-luna"   # the default: Luna writes the best hooks per cent


def cost_per_thousand(model=MODEL):
    """Rough USD for 1,000 cards with this model."""
    in_rate, out_rate, _ = MODELS.get(model, MODELS[MODEL])
    tokens_in, tokens_out = TOKENS_PER_CARD.get(model, (110, 400))
    return (tokens_in * in_rate + tokens_out * out_rate) / 1e6 * 1000
DEFAULT_CAP = 1.00                    # USD per day for AI text
CARD_BATCH = 20                       # words per card-writing call
LIST_BATCH = 50                       # words per frequency-list call
KINDS = ("card", "deck")
LEVELS = ("beginner", "intermediate", "advanced")

CARD_SYSTEM = """You are a lexicographer and memory coach writing flashcards
for someone who speaks {native_or_def} and is learning {target}.

For each word return JSON: {{"cards": [{{
"word": str (exactly as given),
"definition": str (one clear sentence in {definition} that explains the meaning
  WITHOUT using, quoting or transliterating the word itself - never "X means...",
  never the word in quotes; write it as a dictionary would),
"pos": str (n/v/adj/adv/phrase),
"translation": str ({t1}),
"translation2": str ({t2}),
"synonyms": str (up to 3 {target} words of similar meaning that a learner at
  this level would already know, separated by |; "" when there are none),
"example": str (one natural {target} sentence using the word — for a beginner:
  short, 4-8 words, everyday vocabulary),
"example_tr": str (that sentence translated into {definition}),
"reading": str ({reading_rule}),
"hook": {{"image": str, "bridge": str, "line": str, "line_tr": str}} }}]}}

The hook is how the word is remembered. Every field has ONE language:
- image (in {definition}, max 160 characters): word surgery when it is real —
  the parts or roots with their meanings and 2-4 family words (the parts
  themselves may be quoted in {target}); otherwise one vivid, concrete,
  slightly surprising scene that shows the meaning. Never a restatement of
  the definition ("the word describes…" is forbidden). A sound-alike cue in
  {definition} is welcome when marked as one ("sounds like …").
- bridge (in {definition}): ONLY a documented link to {native_or_def} — a
  true cognate, a loanword in either direction, an identical construction.
  "Is similar to" is not a link. When there is none: "".
- line (in {target} ONLY): one short first-person sentence using the word,
  everyday life, concrete and slightly emotional, at most 12 words.
- line_tr (in {definition}): that sentence translated; "" when {target} is
  {definition}.
Never list the word itself among its synonyms. No markdown anywhere."""

LIST_SYSTEM = """You choose the vocabulary a learner of {target} should meet
first. Return JSON: {{"words": [str]}} — dictionary/base forms in {target}
only, most useful first.

Rules: content words only — nouns, verbs, adjectives, adverbs and everyday
expressions a learner needs to say real things (eat, water, friend, tired,
tomorrow, how much). NO grammar words: no articles, pronouns, prepositions,
conjunctions, particles or auxiliaries — those come from grammar, not from
flashcards. Mix the parts of speech (roughly half nouns, a third verbs, the
rest adjectives/adverbs/expressions). No proper nouns, no numerals, no
duplicates, nothing from the exclusion list. Level: beginner = the first
weeks of the language; intermediate = everyday fluency; advanced = precise,
expressive, less common words."""


FIX_SYSTEM = """Rewrite each definition so that it is written in {definition} (NOT in the
language of the word) and does NOT contain the word itself (nor a quoted or
transliterated form of it). Keep the meaning; one clear sentence, as a dictionary
would phrase it. Return JSON: {{"cards": [{{"word": str, "definition": str}}]}}."""


def mask_word(text, word):
    """Blank every occurrence of the word (and its first form) in a text:
    the last line of defence so a question can never show its own answer."""
    if not text or not word:
        return text or ""
    forms = {word.strip(), word.split("[")[0].strip()}
    forms |= {f.split()[0] for f in list(forms) if f.split()}
    out = text
    for form in sorted((f for f in forms if len(f) >= 2), key=len, reverse=True):
        out = re.sub(re.escape(form), "____", out, flags=re.IGNORECASE)
    return out


def wrong_language(text, target, definition):
    """True when a field that should be in the definition language came out
    mostly in the target's script (a model slip the card must not keep)."""
    if not text or target.lower() == definition.lower():
        return False
    return script_share(text, target) > 0.5


def _in_language(text, target, wanted):
    """A translation / example translation, or '' when it is not wanted or
    came out in the target's script instead of the wanted language."""
    if not wanted or not text:
        return ""
    return "" if wrong_language(text, target, wanted) else text


def _leaks(definition, word):
    """True when the definition gives the word away."""
    low = (definition or "").casefold()
    forms = {word.casefold().strip(), word.split("[")[0].casefold().strip()}
    return any(len(f) >= 2 and f in low for f in forms)


# Which Unicode block a learning language is written in — to check that a
# field the model was told to write in Greek did not come out in Korean.
SCRIPTS = {
    "korean": "\uac00-\ud7a3\u1100-\u11ff\u3130-\u318f",
    "japanese": "\u3040-\u30ff\u4e00-\u9fff",
    "chinese": "\u4e00-\u9fff",
    "greek": "\u0370-\u03ff\u1f00-\u1fff",
    "russian": "\u0400-\u04ff",
    "arabic": "\u0600-\u06ff",
    "hindi": "\u0900-\u097f",
}


def script_share(text, language):
    """Share of the letters in `text` that belong to `language`'s script;
    0.0 for Latin-script languages (no check possible there)."""
    block = SCRIPTS.get((language or "").lower())
    letters = [ch for ch in text or "" if ch.isalpha()]
    if not block or not letters:
        return 0.0
    own = re.findall(f"[{block}]", text)
    return len(own) / len(letters)


def assemble_hook(raw, target, definition):
    """Four typed fields -> the hook text the card shows, with each field
    kept only if it is in the language it was supposed to be in. A plain
    string (older models, old logs) passes through unchanged."""
    if not isinstance(raw, dict):
        return (raw or "").strip() if isinstance(raw, str) else ""
    image = (raw.get("image") or "").strip()
    bridge = (raw.get("bridge") or "").strip()
    line = (raw.get("line") or "").strip()
    line_tr = (raw.get("line_tr") or "").strip()
    foreign = target.lower() != definition.lower() and target.lower() in SCRIPTS
    if foreign:
        # Explanations must read in the learner's language (target parts may
        # be quoted, so a minority of target letters is fine).
        if script_share(image, target) > 0.5:
            image = ""
        if script_share(bridge, target) > 0.5:
            bridge = ""
        if script_share(line_tr, target) > 0.3:
            line_tr = ""
        if line and script_share(line, target) < 0.5:
            line = ""
    lines = [part for part in (image, bridge) if part]
    if line:
        lines.append(f"{line} — {line_tr}" if line_tr and target.lower() != definition.lower()
                     else line)
    return "\n".join(lines)


class CardWriter:
    """Owns its own connection (autocommit, for the ledger) so it can run
    off the UI thread, like ImageEngine and SyncEngine."""

    def __init__(self, db_path):
        self.path = db_path
        self.conn = open_connection(db_path)
        self.ledger = Ledger(self.conn, "text_daily_cap", DEFAULT_CAP, KINDS)
        self.langs = languages.load(self._setting)
        self.model = self._setting("card_model", MODEL)
        if self.model not in MODELS:
            self.model = MODEL

    def close(self):
        self.conn.close()

    def _setting(self, key, default=None):
        row = self.conn.execute(
            "SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row and row["value"] not in (None, "") else default

    def api_key(self):
        import images
        engine = images.ImageEngine(self.path)
        try:
            return engine.api_key()
        finally:
            engine.close()

    # ------------------------------------------------------------- http

    def _chat(self, kind, system, user, out_per_item, items, key):
        in_rate, out_rate, temperature_ok = MODELS[self.model]
        payload = {"model": self.model,
                   "response_format": {"type": "json_object"},
                   "messages": [{"role": "system", "content": system},
                                {"role": "user", "content": user}]}
        if temperature_ok:
            payload["temperature"] = 0.4
        # Generous: 4 chars per token for the prompt, a fixed allowance per
        # item for the answer (quadrupled for a model that thinks first).
        # Settled to the real usage below.
        thinking = 1 if temperature_ok else 4
        estimate = ((len(system) + len(user)) / 4 * in_rate
                    + out_per_item * thinking * items * out_rate) / 1e6
        ledger_id = self.ledger.debit(None, kind, estimate, self.model)
        try:
            request = urllib.request.Request(
                CHAT_URL, data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {key}"})
            # A thinking model takes longer: ~5 s per card.
            with urllib.request.urlopen(request, timeout=120 if temperature_ok else 300) as response:
                data = json.loads(response.read().decode())
        except Exception as exc:
            self.ledger.refund(ledger_id, "failed")
            raise RuntimeError(f"OpenAI call failed: {exc}") from exc
        usage = data.get("usage", {})
        actual = (usage.get("prompt_tokens", 0) * in_rate
                  + usage.get("completion_tokens", 0) * out_rate) / 1e6
        self.ledger.settle(ledger_id, "ok", usage, cost=actual)
        return json.loads(data["choices"][0]["message"]["content"])

    # ------------------------------------------------------------ cards

    def _card_system(self):
        L = self.langs
        who = L.native or L.definition
        t1 = (f"1-3 best {L.native} translations, comma-separated"
              if L.native else "always \"\"")
        t2 = (f"1-2 best {L.second} translations, comma-separated"
              if L.second else "always \"\"")
        reading_rule = ("how the word is pronounced, in Latin letters a learner can read: "
                        "Revised Romanization for Korean, romaji for Japanese, pinyin with "
                        "tones for Chinese, a simple transliteration otherwise"
                        if languages.needs_reading(L.target) else 'always ""')
        return CARD_SYSTEM.format(native_or_def=who, target=L.target,
                                  definition=L.definition, t1=t1, t2=t2,
                                  reading_rule=reading_rule)

    def write_cards(self, words, key):
        """Full cards for up to CARD_BATCH words. Returns entries in the
        shape database.insert_card expects; words the model dropped or
        renamed are left out."""
        user = json.dumps([{"word": w} for w in words], ensure_ascii=False)
        data = self._chat("card", self._card_system(), user, 320, len(words), key)
        wanted = {w.strip().lower(): w for w in words}
        entries = []
        cards = data.get("cards", [])
        L = self.langs

        def bad(c):
            return (_leaks(c.get("definition"), c.get("word") or "")
                    or wrong_language(c.get("definition"), L.target, L.definition))

        leaking = [c for c in cards if bad(c)]
        if leaking:
            # One repair round for definitions that quote the word or came out
            # in the wrong language; a leak that survives is blanked, a wrong
            # language that survives drops the card (better none than junk).
            try:
                fixed = self._chat("card", FIX_SYSTEM.format(definition=self.langs.definition),
                                   json.dumps([{"word": c["word"], "definition": c["definition"]}
                                               for c in leaking], ensure_ascii=False),
                                   80, len(leaking), key)
                better = {(c.get("word") or "").strip().lower(): (c.get("definition") or "").strip()
                          for c in fixed.get("cards", [])}
                for c in leaking:
                    new = better.get((c.get("word") or "").strip().lower())
                    if new and not _leaks(new, c["word"]) \
                            and not wrong_language(new, L.target, L.definition):
                        c["definition"] = new
            except (RuntimeError, BudgetExhausted):
                pass
            for c in leaking:
                if wrong_language(c.get("definition"), L.target, L.definition):
                    c["definition"] = ""                 # skipped below
                elif _leaks(c.get("definition"), c.get("word") or ""):
                    c["definition"] = mask_word(c["definition"], c["word"])
        for card in cards:
            word = (card.get("word") or "").strip()
            if word.lower() not in wanted or not (card.get("definition") or "").strip():
                continue
            # The word is not its own synonym, whatever the model thinks.
            synonyms = " | ".join(
                s.strip() for s in (card.get("synonyms") or "").split("|")
                if s.strip() and s.strip().lower() != word.lower())
            entries.append({
                "word": word, "definition": card["definition"].strip(),
                "pos": (card.get("pos") or "").strip(),
                "greek": _in_language((card.get("translation") or "").strip(), L.target, L.native),
                "swedish": _in_language((card.get("translation2") or "").strip(), L.target, L.second),
                "synonyms": synonyms,
                "example": (card.get("example") or "").strip(),
                "example_tr": _in_language((card.get("example_tr") or "").strip(), L.target,
                                           L.definition if L.target != L.definition else ""),
                "reading": (card.get("reading") or "").strip()
                if languages.needs_reading(self.langs.target) else "",
                "hook": assemble_hook(card.get("hook"), self.langs.target,
                                      self.langs.definition),
            })
        return entries

    def common_words(self, count, level, exclude, key):
        """The next `count` most frequent target-language words not in
        `exclude` (case-insensitive), most frequent first."""
        system = LIST_SYSTEM.format(target=self.langs.target)
        user = json.dumps({"language": self.langs.target, "level": level,
                           "count": count, "exclude": sorted(exclude)},
                          ensure_ascii=False)
        data = self._chat("deck", system, user, 8, count, key)
        seen = {w.lower() for w in exclude}
        fresh = []
        for word in data.get("words", []):
            word = str(word).strip()
            if word and word.lower() not in seen:
                seen.add(word.lower())
                fresh.append(word)
        return fresh[:count]

    # ------------------------------------------------------------ store

    def existing_words(self):
        return {row[0].strip().lower() for row in
                self.conn.execute("SELECT word FROM words")}

    def insert(self, entries):
        """Add cards that are not in the deck yet. Returns how many."""
        existing = self.existing_words()
        inserted = 0
        self.conn.execute("BEGIN")
        try:
            for entry in entries:
                key = entry["word"].strip().lower()
                if key in existing:
                    continue
                existing.add(key)
                database.insert_card(self.conn, entry)
                inserted += 1
        except BaseException:
            self.conn.execute("ROLLBACK")
            raise
        self.conn.execute("COMMIT")
        return inserted

    # ------------------------------------------------------------ flows

    def add_word(self, word, key=None):
        """One word → one full card in the deck. Returns the entry, or None
        when the word is already there / the model produced nothing."""
        key = key or self.api_key()
        if not key:
            raise RuntimeError("no OpenAI API key — add one in Settings")
        if word.strip().lower() in self.existing_words():
            return None
        entries = self.write_cards([word.strip()], key)
        if not entries:
            return None
        self.insert(entries)
        return entries[0]

    def build_starter(self, total, level, progress=None, key=None):
        """Grow the deck towards `total` common words, batch by batch, until
        done or the day's budget is spent. Every batch is saved as it lands,
        so stopping — by cap, by network, by the user — loses nothing and
        calling again continues. Returns (added, reason)."""
        key = key or self.api_key()
        if not key:
            return 0, "no OpenAI API key — add one in Settings"
        if level not in LEVELS:
            level = LEVELS[0]
        added = 0
        exclude = self.existing_words()
        try:
            while len(exclude) < total:
                want = min(LIST_BATCH, total - len(exclude))
                words = self.common_words(want, level, exclude, key)
                if not words:
                    return added, "the model ran out of new words"
                for start in range(0, len(words), CARD_BATCH):
                    batch = words[start:start + CARD_BATCH]
                    entries = self.write_cards(batch, key)
                    added += self.insert(entries)
                    exclude.update(w.lower() for w in words)
                    if progress:
                        progress(added, len(exclude), total)
        except BudgetExhausted as exc:
            return added, str(exc)
        except RuntimeError as exc:
            return added, str(exc)
        return added, None

    # ------------------------------------------------- completing old cards

    COMPLETE_SYSTEM = """For each {target} word with its example sentence, return JSON:
{{"cards": [{{"word": str, "reading": str ({reading_rule}),
"example_tr": str (the example sentence translated into {definition})}}]}}"""

    def incomplete(self):
        """Cards a beginner cannot read yet: no example translation while the
        definition language differs, or no reading for a non-Latin script."""
        L = self.langs
        clauses = []
        if L.target != L.definition:
            clauses.append("(COALESCE(example,'') <> '' AND COALESCE(example_tr,'') = '')")
        if languages.needs_reading(L.target):
            clauses.append("COALESCE(reading,'') = ''")
        if not clauses:
            return []
        return [dict(r) for r in self.conn.execute(
            f"SELECT id, word, example FROM words WHERE {' OR '.join(clauses)} ORDER BY rowid")]

    def complete_missing(self, progress=None, key=None):
        """Fill readings and example translations on existing cards, in
        batches, under the budget. Returns (done, reason)."""
        key = key or self.api_key()
        if not key:
            return 0, "no OpenAI API key - add one in Settings"
        L = self.langs
        reading_rule = ("Revised Romanization for Korean, romaji for Japanese, pinyin with tones "
                        "for Chinese, a simple transliteration otherwise"
                        if languages.needs_reading(L.target) else 'always ""')
        system = self.COMPLETE_SYSTEM.format(target=L.target, definition=L.definition,
                                             reading_rule=reading_rule)
        todo = self.incomplete()
        done = 0
        try:
            for start in range(0, len(todo), CARD_BATCH):
                batch = todo[start:start + CARD_BATCH]
                user = json.dumps([{"word": w["word"], "example": w["example"] or ""}
                                   for w in batch], ensure_ascii=False)
                data = self._chat("card", system, user, 90, len(batch), key)
                got = {(c.get("word") or "").strip().lower(): c for c in data.get("cards", [])}
                for w in batch:
                    c = got.get(w["word"].strip().lower())
                    if not c:
                        continue
                    self.conn.execute(
                        "UPDATE words SET reading=COALESCE(NULLIF(?, ''), reading), "
                        "example_tr=COALESCE(NULLIF(?, ''), example_tr), updated_at=? WHERE id=?",
                        ((c.get("reading") or "").strip() if languages.needs_reading(L.target) else "",
                         (c.get("example_tr") or "").strip(), database.utc_stamp(), w["id"]))
                    done += 1
                if progress:
                    progress(done, len(todo))
        except BudgetExhausted as exc:
            return done, str(exc)
        except RuntimeError as exc:
            return done, str(exc)
        return done, None

    def summary(self):
        return {"spent_today": self.ledger.spent_today(), "cap": self.ledger.cap(),
                "remaining": self.ledger.remaining_today(),
                "lifetime": self.ledger.spent_total()}

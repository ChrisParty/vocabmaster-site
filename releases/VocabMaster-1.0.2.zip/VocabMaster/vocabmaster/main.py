"""VocabMaster — spaced repetition vocabulary trainer.

Run with:  python main.py
"""

import ctypes
import logging
import logging.handlers
import os
import subprocess
import sys
import tempfile
import threading

from PyQt6.QtCore import QLockFile, QTimer
from PyQt6.QtGui import QFont, QIcon
from PyQt6.QtWidgets import QApplication, QMessageBox

import hub_server
import paths
import updater
from database import Database
from styles import FONT_SIZES, app_font_family, build_stylesheet
from sync import SyncEngine
from ui.main_window import MainWindow
from version import VERSION


def _install_logging():
    """A rolling log in the data folder, and an exception hook: under
    pythonw there is no console, and PyQt aborts the process on an
    unhandled exception unless a hook is installed. With one, the error is
    written down, shown once, and the app keeps running."""
    handler = logging.handlers.RotatingFileHandler(
        paths.log_path(), maxBytes=1_000_000, backupCount=2, encoding="utf-8")
    logging.basicConfig(level=logging.INFO, handlers=[handler],
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger().info("VocabMaster %s starting (python %s)", VERSION,
                             sys.version.split()[0])

    def hook(kind, value, trace):
        logging.getLogger().error("unhandled", exc_info=(kind, value, trace))
        if QApplication.instance() is not None:
            QMessageBox.warning(
                None, "VocabMaster hit a problem",
                f"{kind.__name__}: {value}\n\nThe details were saved to\n"
                f"{paths.log_path()}\n\nThe app keeps running. If something "
                "looks wrong, close and reopen it.")

    sys.excepthook = hook


def main():
    _install_logging()

    # Give the process its own taskbar identity — without this, Windows
    # groups the window under pythonw.exe and shows the Python icon.
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("VocabMaster")
    except (AttributeError, OSError):
        pass

    app = QApplication(sys.argv)
    app.setApplicationName("VocabMaster")
    base = paths.app_dir()
    for icon_file in ("vocabmaster.ico", "vocabmaster.png"):
        icon_path = os.path.join(base, icon_file)
        if os.path.exists(icon_path):
            app.setWindowIcon(QIcon(icon_path))
            break

    # Single-instance guard: a second launch shows a notice instead of
    # opening a conflicting duplicate window.
    lock = QLockFile(os.path.join(tempfile.gettempdir(), "vocabmaster.lock"))
    lock.setStaleLockTime(0)
    if not lock.tryLock(100):
        # Usually the copy that lives in the tray: ask it to come forward.
        try:
            import urllib.request
            urllib.request.urlopen(urllib.request.Request(
                f"http://{hub_server.HOST}:{hub_server.PORT}/api/show",
                data=b"{}", method="POST"), timeout=2)
        except Exception:
            QMessageBox.information(
                None, "VocabMaster",
                "VocabMaster is already running.\nCheck your taskbar for the open window.",
            )
        sys.exit(0)

    db = Database()
    font_size = db.get_setting("font_size", "medium")
    app.setFont(QFont(app_font_family(), FONT_SIZES.get(font_size, 10)))
    app.setStyleSheet(build_stylesheet(font_size))

    window = MainWindow(db)
    hub_server.start(db.path, on_show=window.show_requested.emit)
    # Started with the computer (--tray): stay in the tray until the
    # reminder or a click brings the window up.
    if "--tray" in sys.argv and window.tray is not None:
        pass
    else:
        window.show()
        # macOS launches us through a shell script inside the .app bundle, and
        # a window opened that way can come up behind the Finder.
        window.raise_()
        window.activateWindow()

    # Cloud sync: silent, background, additive. No config -> instant no-op.
    # At startup, every 10 minutes, after each study session (the window
    # triggers that one) and once more on quit.
    window.start_sync()
    sync_timer = QTimer()
    sync_timer.setInterval(10 * 60 * 1000)
    sync_timer.timeout.connect(window.start_sync)
    sync_timer.start()

    # Illustrations for today's words, drawn quietly in the background and
    # hard-capped by images.ImageEngine — it debits its ledger before it
    # spends, so this can never run up a bill while you study.
    def draw_todays_images():
        import images
        engine = images.ImageEngine(db.path)
        try:
            engine.top_up_due()
        except Exception:
            logging.getLogger("images").exception("startup top-up failed")
        finally:
            engine.close()

    threading.Thread(target=draw_todays_images, daemon=True).start()

    # A newer release? Checked a few seconds in, off the UI thread; the
    # window shows a banner if there is one. Never blocks, never nags.
    def check_updates():
        info = updater.check()
        if info:
            window.update_available.emit(info)

    threading.Timer(4, check_updates).start()

    exit_code = app.exec()
    # One last push so the cloud copy is current the moment the app closes.
    # Not after a restore (the connection is already closed): the restored
    # database syncs on its own next launch.
    if db.conn is not None:
        closer = threading.Thread(target=lambda: SyncEngine(db).sync(), daemon=True)
        closer.start()
        closer.join(timeout=8)
    db.close()
    if window.relaunch_requested:
        # The lock must go before the new process tries to take it.
        lock.unlock()
        subprocess.Popen([sys.executable, os.path.join(base, "main.py")], cwd=base)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()

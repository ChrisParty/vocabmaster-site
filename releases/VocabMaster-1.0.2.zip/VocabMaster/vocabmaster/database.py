"""SQLite persistence layer for VocabMaster.

All reads and writes go through the Database class. Progress is committed
immediately after every mutation so a crash never loses a rating.
"""

import glob
import hashlib
import os
import shutil
import sqlite3
import uuid
from datetime import datetime, timedelta

DEFAULT_DB_NAME = "vocabmaster.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS words (
    id TEXT PRIMARY KEY,
    word TEXT NOT NULL,
    definition TEXT NOT NULL,
    pos TEXT,
    greek TEXT,
    swedish TEXT,
    synonyms TEXT,
    example TEXT,
    hook TEXT
);

CREATE TABLE IF NOT EXISTS progress (
    word_id TEXT PRIMARY KEY,
    interval INTEGER DEFAULT 1,
    ease_factor REAL DEFAULT 2.5,
    repetitions INTEGER DEFAULT 0,
    due_date TEXT DEFAULT (datetime('now')),
    last_studied TEXT,
    FOREIGN KEY (word_id) REFERENCES words(id)
);

CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    cards_reviewed INTEGER DEFAULT 0,
    again_count INTEGER DEFAULT 0,
    hard_count INTEGER DEFAULT 0,
    good_count INTEGER DEFAULT 0,
    easy_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

def utc_stamp():
    """UTC ISO timestamp, comparable with the cloud's updated_at."""
    from datetime import timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


DEFAULT_SETTINGS = {
    "daily_goal": "20",
    "max_new_per_day": "20",
    "session_cap": "20",
    "font_size": "medium",
}

MASTERED_INTERVAL = 21

CARD_FIELDS = ("word", "definition", "pos", "greek", "swedish",
               "synonyms", "example", "hook")


def insert_card(conn, entry):
    """One new word plus its progress row, stamped for sync. The single
    insert path shared by import, the hub API and AI-written cards; the
    caller handles duplicates and commits. Returns the new id."""
    word_id = uuid.uuid4().hex
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    stamp = utc_stamp()
    conn.execute(
        f"INSERT INTO words (id, {', '.join(CARD_FIELDS)}, updated_at) "
        f"VALUES (?, {', '.join('?' * len(CARD_FIELDS))}, ?)",
        (word_id, *[(entry.get(field) or "").strip() for field in CARD_FIELDS], stamp))
    conn.execute(
        "INSERT INTO progress (word_id, interval, ease_factor, repetitions, "
        "due_date, updated_at) VALUES (?, 1, 2.5, 0, ?, ?)", (word_id, now, stamp))
    return word_id


def default_db_path():
    """The user's data folder (paths.py), moving a legacy deck in first."""
    import paths
    return paths.db_path()


BACKUP_KEEP = 7


class Database:
    def __init__(self, path=None):
        self.path = path or default_db_path()
        self._backup()
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        # Additive sync support: change-tracking columns + deletion tombstones.
        # Nullable columns and a new table — existing behavior untouched.
        wcols = {r[1] for r in self.conn.execute("PRAGMA table_info(words)")}
        if "hook" not in wcols:
            self.conn.execute("ALTER TABLE words ADD COLUMN hook TEXT")
        for table in ("words", "progress"):
            cols = {r[1] for r in self.conn.execute(f"PRAGMA table_info({table})")}
            if "updated_at" not in cols:
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN updated_at TEXT")
            # backfill so pre-existing rows count as changed for first sync
            self.conn.execute(
                f"UPDATE {table} SET updated_at=? WHERE updated_at IS NULL",
                (utc_stamp(),))
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS sync_tombstones ("
            "word_id TEXT PRIMARY KEY, at TEXT NOT NULL)")
        # Study history travels too (today's count, streak, stats), so every
        # session needs an id that means the same on every device. Rows that
        # predate this get one derived from their content: two machines that
        # started from the same backup derive the same id and merge into one.
        scols = {r[1] for r in self.conn.execute("PRAGMA table_info(sessions)")}
        if "uid" not in scols:
            self.conn.execute("ALTER TABLE sessions ADD COLUMN uid TEXT")
        if "updated_at" not in scols:
            self.conn.execute("ALTER TABLE sessions ADD COLUMN updated_at TEXT")
        for row in self.conn.execute(
                "SELECT id, date, cards_reviewed, again_count, hard_count, "
                "good_count, easy_count FROM sessions WHERE uid IS NULL").fetchall():
            digest = hashlib.sha1("|".join(str(v) for v in row).encode()).hexdigest()
            self.conn.execute("UPDATE sessions SET uid=?, updated_at=? WHERE id=?",
                              (digest[:32], utc_stamp(), row[0]))
        self.conn.commit()
        # Card illustrations live in their own tables and their own folder —
        # never as blobs in here, which _backup() copies whole every day.
        import images
        images.ensure_schema(self.conn, self.path)
        # Which languages this deck is about (legacy decks: English learned,
        # Greek + Swedish translations; fresh decks: English, no translations).
        import languages
        languages.ensure_defaults(self.conn)

    def _backup(self):
        """Copy the database to backups/ once per day; keep the last 7."""
        if not os.path.exists(self.path) or os.path.getsize(self.path) == 0:
            return
        backup_dir = os.path.join(os.path.dirname(self.path), "backups")
        try:
            os.makedirs(backup_dir, exist_ok=True)
            today = datetime.now().strftime("%Y-%m-%d")
            target = os.path.join(backup_dir, f"vocabmaster-{today}.db")
            if not os.path.exists(target):
                shutil.copy2(self.path, target)
            backups = sorted(glob.glob(os.path.join(backup_dir, "vocabmaster-*.db")))
            for old in backups[:-BACKUP_KEEP]:
                os.remove(old)
        except OSError:
            pass  # a failed backup must never block the app

    def close(self):
        """Idempotent: a restore closes the connection before the app's own
        shutdown gets to it."""
        if self.conn is not None:
            self.conn.close()
            self.conn = None

    # ------------------------------------------------------------- settings

    def get_setting(self, key, default=None):
        row = self.conn.execute(
            "SELECT value FROM settings WHERE key=?", (key,)
        ).fetchone()
        if row is not None:
            return row["value"]
        return DEFAULT_SETTINGS.get(key, default)

    def set_setting(self, key, value):
        self.conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )
        self.conn.commit()

    def get_int_setting(self, key, default):
        try:
            return int(self.get_setting(key, default))
        except (TypeError, ValueError):
            return default

    # ---------------------------------------------------------------- words

    def word_count(self):
        return self.conn.execute("SELECT COUNT(*) FROM words").fetchone()[0]

    def add_words(self, entries, replace=False):
        """Insert parsed word dicts. Returns number of words inserted."""
        if replace:
            self.conn.execute("DELETE FROM progress")
            self.conn.execute("DELETE FROM words")
        existing = {
            row["word"].strip().lower()
            for row in self.conn.execute("SELECT word FROM words")
        }
        inserted = 0
        for entry in entries:
            key = entry["word"].strip().lower()
            if key in existing:
                continue
            existing.add(key)
            insert_card(self.conn, entry)
            inserted += 1
        self.conn.commit()
        return inserted

    def update_word(self, word_id, fields):
        allowed = set(CARD_FIELDS)
        sets, values = [], []
        for key, value in fields.items():
            if key in allowed:
                sets.append(f"{key}=?")
                values.append(value)
        if not sets:
            return
        sets.append("updated_at=?")
        values.append(utc_stamp())
        values.append(word_id)
        self.conn.execute(f"UPDATE words SET {', '.join(sets)} WHERE id=?", values)
        self.conn.commit()

    def delete_word(self, word_id):
        import images

        self.conn.execute("DELETE FROM progress WHERE word_id=?", (word_id,))
        self.conn.execute("DELETE FROM words WHERE id=?", (word_id,))
        self.conn.execute("DELETE FROM word_images WHERE word_id=?", (word_id,))
        self.conn.execute(
            "INSERT OR REPLACE INTO sync_tombstones (word_id, at) VALUES (?, ?)",
            (word_id, utc_stamp()))
        self.conn.commit()
        # The picture goes too, so images/ does not keep files no card shows.
        try:
            path = images.image_file(self.path, word_id)
            if path:
                os.remove(path)
        except OSError:
            pass

    def reset_progress(self, word_id):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.conn.execute(
            "UPDATE progress SET interval=1, ease_factor=2.5, repetitions=0, "
            "due_date=?, last_studied=NULL, updated_at=? WHERE word_id=?",
            (now, utc_stamp(), word_id),
        )
        self.conn.commit()

    def get_words(self, search="", status_filter="all"):
        """Return joined word+progress rows, optionally filtered."""
        query = (
            "SELECT w.*, p.interval, p.ease_factor, p.repetitions, p.due_date, p.last_studied "
            "FROM words w JOIN progress p ON p.word_id = w.id"
        )
        clauses, params = [], []
        if search:
            # Any face of the card: the word, its meaning, its translations.
            clauses.append("(w.word LIKE ? OR w.definition LIKE ? OR w.greek LIKE ? "
                           "OR w.swedish LIKE ? OR w.synonyms LIKE ?)")
            like = f"%{search}%"
            params.extend([like] * 5)
        today_end = datetime.now().strftime("%Y-%m-%d 23:59:59")
        if status_filter == "due":
            clauses.append("p.due_date <= ?")
            params.append(today_end)
        elif status_filter == "new":
            clauses.append("p.repetitions = 0")
        elif status_filter == "learning":
            clauses.append("p.repetitions > 0 AND p.interval < ?")
            params.append(MASTERED_INTERVAL)
        elif status_filter == "mastered":
            clauses.append("p.repetitions > 0 AND p.interval >= ?")
            params.append(MASTERED_INTERVAL)
        elif status_filter == "difficult":
            # Cards repeatedly rated Again/Hard drift toward the 1.3 ease floor.
            clauses.append("p.repetitions > 0 AND p.ease_factor <= 1.8")
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY w.word COLLATE NOCASE"
        return [dict(row) for row in self.conn.execute(query, params)]

    def get_word(self, word_id):
        row = self.conn.execute(
            "SELECT w.*, p.interval, p.ease_factor, p.repetitions, p.due_date, p.last_studied "
            "FROM words w JOIN progress p ON p.word_id = w.id WHERE w.id=?",
            (word_id,),
        ).fetchone()
        return dict(row) if row else None

    # ------------------------------------------------------------ SRS queue

    def get_due_words(self, limit=None, max_new=None):
        """Cards due now: seen cards first (oldest due first), then new cards."""
        today_end = datetime.now().strftime("%Y-%m-%d 23:59:59")
        seen = [
            dict(row)
            for row in self.conn.execute(
                "SELECT w.*, p.interval, p.ease_factor, p.repetitions, p.due_date "
                "FROM words w JOIN progress p ON p.word_id = w.id "
                "WHERE p.repetitions > 0 AND p.due_date <= ? ORDER BY p.due_date",
                (today_end,),
            )
        ]
        new = [
            dict(row)
            for row in self.conn.execute(
                # The due filter matters: a card rated Again mid-session goes
                # back to repetitions=0 with due_date tomorrow — without the
                # filter it would jump into the SAME day's next session.
                "SELECT w.*, p.interval, p.ease_factor, p.repetitions, p.due_date "
                "FROM words w JOIN progress p ON p.word_id = w.id "
                "WHERE p.repetitions = 0 AND p.due_date <= ? ORDER BY w.rowid",
                (today_end,),
            )
        ]
        if max_new is not None:
            new_today = self.new_cards_studied_today()
            remaining = max(0, max_new - new_today)
            new = new[:remaining]
        queue = seen + new
        if limit is not None:
            queue = queue[:limit]
        return queue

    def reviewed_today(self):
        today = datetime.now().strftime("%Y-%m-%d")
        row = self.conn.execute(
            "SELECT COALESCE(SUM(cards_reviewed),0) FROM sessions WHERE date=?",
            (today,),
        ).fetchone()
        return row[0]

    def new_cards_studied_today(self):
        today = datetime.now().strftime("%Y-%m-%d")
        row = self.conn.execute(
            "SELECT COUNT(*) FROM progress WHERE repetitions = 1 "
            "AND last_studied LIKE ?",
            (today + "%",),
        ).fetchone()
        return row[0]

    def due_count(self):
        today_end = datetime.now().strftime("%Y-%m-%d 23:59:59")
        return self.conn.execute(
            "SELECT COUNT(*) FROM progress WHERE due_date <= ?", (today_end,)
        ).fetchone()[0]

    def next_due_datetime(self):
        row = self.conn.execute(
            "SELECT MIN(due_date) FROM progress"
        ).fetchone()
        if row and row[0]:
            try:
                return datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S")
            except ValueError:
                pass
        return None

    def progress_of(self, word_id):
        """The raw progress row, for an undo snapshot."""
        row = self.conn.execute(
            "SELECT interval, ease_factor, repetitions, due_date, last_studied "
            "FROM progress WHERE word_id=?", (word_id,)).fetchone()
        return dict(row) if row else None

    def restore_progress(self, word_id, snapshot):
        """Put a progress row back exactly as it was (undo of a rating).
        Stamped as a change so the other computer follows."""
        self.conn.execute(
            "UPDATE progress SET interval=?, ease_factor=?, repetitions=?, "
            "due_date=?, last_studied=?, updated_at=? WHERE word_id=?",
            (snapshot["interval"], snapshot["ease_factor"], snapshot["repetitions"],
             snapshot["due_date"], snapshot["last_studied"], utc_stamp(), word_id))
        self.conn.commit()

    def apply_review(self, word_id, interval, ease_factor, repetitions):
        due = (datetime.now() + timedelta(days=interval)).strftime("%Y-%m-%d %H:%M:%S")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.conn.execute(
            "UPDATE progress SET interval=?, ease_factor=?, repetitions=?, "
            "due_date=?, last_studied=?, updated_at=? WHERE word_id=?",
            (interval, ease_factor, repetitions, due, now, utc_stamp(), word_id),
        )
        self.conn.commit()

    # -------------------------------------------------------------- sessions

    def start_session(self):
        today = datetime.now().strftime("%Y-%m-%d")
        cursor = self.conn.execute(
            "INSERT INTO sessions (date, uid, updated_at) VALUES (?, ?, ?)",
            (today, uuid.uuid4().hex, utc_stamp()),
        )
        self.conn.commit()
        return cursor.lastrowid

    def record_rating(self, session_id, rating):
        column = ["again_count", "hard_count", "good_count", "easy_count"][rating]
        self.conn.execute(
            f"UPDATE sessions SET cards_reviewed = cards_reviewed + 1, "
            f"{column} = {column} + 1, updated_at=? WHERE id=?",
            (utc_stamp(), session_id),
        )
        self.conn.commit()

    def unrecord_rating(self, session_id, rating):
        """The opposite of record_rating, for undo."""
        column = ["again_count", "hard_count", "good_count", "easy_count"][rating]
        self.conn.execute(
            f"UPDATE sessions SET cards_reviewed = MAX(0, cards_reviewed - 1), "
            f"{column} = MAX(0, {column} - 1), updated_at=? WHERE id=?",
            (utc_stamp(), session_id),
        )
        self.conn.commit()

    def delete_empty_session(self, session_id):
        self.conn.execute(
            "DELETE FROM sessions WHERE id=? AND cards_reviewed=0", (session_id,)
        )
        self.conn.commit()

    # ----------------------------------------------------------------- stats

    def counts(self):
        total = self.word_count()
        new = self.conn.execute(
            "SELECT COUNT(*) FROM progress WHERE repetitions = 0"
        ).fetchone()[0]
        mastered = self.conn.execute(
            "SELECT COUNT(*) FROM progress WHERE repetitions > 0 AND interval >= ?",
            (MASTERED_INTERVAL,),
        ).fetchone()[0]
        learning = total - new - mastered
        return {
            "total": total,
            "new": new,
            "mastered": mastered,
            "learning": learning,
            "due": self.due_count(),
        }

    def reviews_per_day(self, days=30):
        """List of (date_str, count) for the last `days` days, oldest first."""
        result = []
        today = datetime.now().date()
        rows = dict(
            self.conn.execute(
                "SELECT date, SUM(cards_reviewed) FROM sessions "
                "WHERE cards_reviewed > 0 GROUP BY date"
            ).fetchall()
        )
        for offset in range(days - 1, -1, -1):
            day = (today - timedelta(days=offset)).strftime("%Y-%m-%d")
            result.append((day, rows.get(day, 0) or 0))
        return result

    def reviews_per_month(self):
        """(YYYY-MM, reviews) for every month from the first session to this
        one, zeros included — the long view the 30-day chart cannot give."""
        rows = dict(self.conn.execute(
            "SELECT substr(date, 1, 7), SUM(cards_reviewed) FROM sessions "
            "WHERE cards_reviewed > 0 GROUP BY 1").fetchall())
        if not rows:
            return []
        year, month = (int(part) for part in min(rows).split("-"))
        today = datetime.now()
        result = []
        while (year, month) <= (today.year, today.month):
            key = f"{year:04d}-{month:02d}"
            result.append((key, rows.get(key, 0) or 0))
            month += 1
            if month > 12:
                year, month = year + 1, 1
        return result

    def first_study_date(self):
        row = self.conn.execute(
            "SELECT MIN(date) FROM sessions WHERE cards_reviewed > 0").fetchone()
        return row[0] if row and row[0] else None

    def due_next_days(self, days=7):
        result = []
        today = datetime.now().date()
        for offset in range(days):
            day = today + timedelta(days=offset)
            if offset == 0:
                count = self.due_count()
            else:
                start = day.strftime("%Y-%m-%d 00:00:00")
                end = day.strftime("%Y-%m-%d 23:59:59")
                count = self.conn.execute(
                    "SELECT COUNT(*) FROM progress WHERE due_date >= ? AND due_date <= ?",
                    (start, end),
                ).fetchone()[0]
            result.append((day.strftime("%a"), count))
        return result

    def totals(self):
        row = self.conn.execute(
            "SELECT COALESCE(SUM(cards_reviewed),0), COUNT(*), "
            "COALESCE(SUM(again_count),0), COALESCE(SUM(hard_count),0), "
            "COALESCE(SUM(good_count),0), COALESCE(SUM(easy_count),0) "
            "FROM sessions WHERE cards_reviewed > 0"
        ).fetchone()
        reviewed, sessions, again, hard, good, easy = row
        accuracy = 0.0
        if reviewed:
            accuracy = (good + easy) / reviewed * 100
        return {
            "reviewed": reviewed,
            "sessions": sessions,
            "accuracy": accuracy,
            "again": again,
            "hard": hard,
            "good": good,
            "easy": easy,
        }

    def study_dates(self):
        return {
            row[0]
            for row in self.conn.execute(
                "SELECT DISTINCT date FROM sessions WHERE cards_reviewed > 0"
            )
        }

    def current_streak(self):
        dates = self.study_dates()
        if not dates:
            return 0
        streak = 0
        day = datetime.now().date()
        # A streak survives if today has no session yet but yesterday does.
        if day.strftime("%Y-%m-%d") not in dates:
            day -= timedelta(days=1)
        while day.strftime("%Y-%m-%d") in dates:
            streak += 1
            day -= timedelta(days=1)
        return streak

    def longest_streak(self):
        dates = sorted(
            datetime.strptime(d, "%Y-%m-%d").date() for d in self.study_dates()
        )
        longest = current = 0
        previous = None
        for day in dates:
            if previous is not None and (day - previous).days == 1:
                current += 1
            else:
                current = 1
            longest = max(longest, current)
            previous = day
        return longest

    # ---------------------------------------------------------------- export

    def export_csv(self, filepath):
        import csv

        rows = self.get_words()
        with open(filepath, "w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(
                [
                    "Word", "Definition", "Part of Speech", "Greek", "Swedish",
                    "Synonyms", "Example", "Interval (days)", "Ease Factor",
                    "Repetitions", "Due Date", "Last Studied",
                ]
            )
            for row in rows:
                writer.writerow(
                    [
                        row["word"], row["definition"], row["pos"], row["greek"],
                        row["swedish"], row["synonyms"], row["example"],
                        row["interval"], round(row["ease_factor"], 2),
                        row["repetitions"], row["due_date"], row["last_studied"] or "",
                    ]
                )
        return len(rows)

"""Where a user's data lives — outside the app folder, so updating the app
or unzipping a new copy can never touch it.

  Windows   %APPDATA%\\VocabMaster\\
  macOS     ~/Library/Application Support/VocabMaster/
  Linux     ~/.local/share/VocabMaster/
  anywhere  $VOCABMASTER_DATA, when set (tests, portable use)

Decks made before this lived next to main.py. The first launch moves them
in: copy through SQLite's backup API, verify (integrity check + row
counts), copy pictures and backups, and only then rename the originals to
*.moved-<date>. Nothing is ever deleted; a note is left behind.
"""

import os
import platform
import shutil
import sqlite3
from datetime import datetime

APP = "VocabMaster"
DB_NAME = "vocabmaster.db"
MOVED_NOTE = "MOVED.txt"


def app_dir():
    """The folder main.py lives in (the code)."""
    return os.path.dirname(os.path.abspath(__file__))


def install_root():
    """One level up: where setup scripts, .venv and tools sit."""
    return os.path.dirname(app_dir())


def data_dir():
    custom = os.environ.get("VOCABMASTER_DATA")
    if custom:
        base = custom
    elif platform.system() == "Windows":
        base = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), APP)
    elif platform.system() == "Darwin":
        base = os.path.join(os.path.expanduser("~/Library/Application Support"), APP)
    else:
        base = os.path.join(os.environ.get("XDG_DATA_HOME")
                            or os.path.expanduser("~/.local/share"), APP)
    os.makedirs(base, exist_ok=True)
    return base


def log_path():
    return os.path.join(data_dir(), "vocabmaster.log")


def db_path():
    """The database to open, moving a legacy one in first if there is one.
    Falls back to the legacy file only if the move could not be verified."""
    legacy = os.path.join(app_dir(), DB_NAME)
    target = os.path.join(data_dir(), DB_NAME)
    if os.path.exists(legacy) and not os.path.exists(target):
        if not _migrate(legacy, target):
            return legacy
    return target


def _counts(conn):
    out = {}
    for table in ("words", "progress", "sessions"):
        try:
            out[table] = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        except sqlite3.Error:
            out[table] = None
    return out


def _migrate(legacy, target):
    """Order matters. The verified copy waits as target.part; the legacy
    file is renamed FIRST (the one step that can fail when something else
    holds the database — then nothing has changed and the next launch
    simply tries again); only after that does the copy take its place. A
    stale copy can therefore never shadow a live legacy database."""
    partial = target + ".part"
    old_dir = os.path.dirname(legacy)
    new_dir = os.path.dirname(target)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    try:
        source = sqlite3.connect(legacy)
        copy = sqlite3.connect(partial)
        try:
            source.backup(copy)
            ok = copy.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            ok = ok and _counts(source) == _counts(copy)
        finally:
            source.close()
            copy.close()
        if not ok:
            os.remove(partial)
            return False
        for name in ("images", "backups"):
            src = os.path.join(old_dir, name)
            if os.path.isdir(src):
                shutil.copytree(src, os.path.join(new_dir, name), dirs_exist_ok=True)
        os.replace(legacy, f"{legacy}.moved-{stamp}")      # the point of no return
        os.replace(partial, target)
        for name in ("images", "backups"):
            src = os.path.join(old_dir, name)
            if os.path.isdir(src):
                try:
                    os.replace(src, f"{src}.moved-{stamp}")
                except OSError:
                    pass                      # copied already; a leftover is harmless
        with open(os.path.join(old_dir, MOVED_NOTE), "w", encoding="utf-8") as note:
            note.write(
                f"VocabMaster moved its data on {stamp[:8]} to:\n  {new_dir}\n\n"
                "The files here ending in .moved-<date> are the originals, kept as\n"
                "a safety copy. Delete them whenever you like.\n")
        return True
    except (OSError, sqlite3.Error):
        try:
            os.remove(partial)
        except OSError:
            pass
        return False


def open_folder(path):
    """Show a folder in Explorer / Finder / the file manager."""
    system = platform.system()
    try:
        if system == "Windows":
            os.startfile(path)                       # noqa: S606 — user's own folder
        elif system == "Darwin":
            import subprocess
            subprocess.Popen(["open", path])
        else:
            import subprocess
            subprocess.Popen(["xdg-open", path])
    except OSError:
        pass

"""Flashcard study screen with SM-2 rating and animated reveal."""

import html
import os
import platform
import subprocess
import threading

from PyQt6.QtCore import QPropertyAnimation, Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QDialog, QFrame, QGraphicsOpacityEffect, QGridLayout, QHBoxLayout, QLabel,
    QMenu, QMessageBox, QProgressBar, QPushButton, QScrollArea, QVBoxLayout,
    QWidget,
)

import cards_ai
import flags
import images
import languages
import srs
from styles import ACCENT, BORDER, DANGER, SUCCESS, TEXT, TEXT_MUTED, TEXT_SECONDARY, WARNING
from ui.image_card import ImageCard
from ui.word_tree import WordTreeWidget, _strip_prefix, _bullets

# Long lines are hard to read and harder to learn from; cap the text column,
# and keep the card itself card-shaped instead of a full-window band.
READING_WIDTH = 820
CARD_WIDTH = 980

_SPEAK_VBS = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "speak.vbs"
)


_mac_voices = {}      # locale prefix -> voice name, read from `say -v ?` once


def _mac_voice(locale):
    """A macOS voice for a locale prefix ("ko" -> "Yuna"), or None."""
    if not _mac_voices:
        try:
            listing = subprocess.run(["say", "-v", "?"], capture_output=True,
                                     text=True, timeout=5).stdout
        except (OSError, subprocess.SubprocessError):
            listing = ""
        for line in listing.splitlines():
            # "Yuna                ko_KR    # 안녕하세요…"
            parts = line.split("#")[0].rsplit(None, 1)
            if len(parts) == 2:
                _mac_voices.setdefault(parts[1].split("_")[0], parts[0].strip())
        _mac_voices.setdefault("", "")        # mark as loaded even if empty
    return _mac_voices.get(locale)


def speak(text, language=None):
    """Pronounce text with the system's own voice, without blocking the UI.

    Windows: SAPI through speak.vbs. macOS: the built-in `say`. Linux:
    speech-dispatcher when it is installed. When a voice for `language` is
    installed it is used; otherwise the default voice does its best.
    """
    lcid, locale = languages.voice(language)
    system = platform.system()
    if system == "Windows":
        command = ["cscript", "//nologo", _SPEAK_VBS, text] + ([lcid] if lcid else [])
    elif system == "Darwin":
        name = _mac_voice(locale) if locale else None
        command = ["say"] + (["-v", name] if name else []) + [text]
    else:
        command = ["spd-say"] + (["-l", locale] if locale else []) + [text]
    try:
        subprocess.Popen(
            command, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except OSError:
        pass  # no voice available — the button just does nothing


class FlashcardScreen(QWidget):
    # Generation runs off the UI thread; these carry the result back. Qt queues
    # a cross-thread signal onto the UI thread, which is the only place Qt
    # widgets may be touched.
    image_done = pyqtSignal(str, str)      # word_id, path ("" when none)
    image_failed = pyqtSignal(str, str)    # word_id, message

    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self.session = None
        self.session_id = None
        self.answer_shown = False
        self._image_busy = False
        self.langs = languages.load(db.get_setting)
        self._undo = None            # the last rating, until the next card
        self._reverse = False        # this card asks meaning -> word
        self._word_html = ""
        self.image_done.connect(self._on_image_done)
        self.image_failed.connect(self._on_image_failed)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 20, 32, 20)
        layout.setSpacing(14)

        # ------------------------------------------------------ top bar
        top_row = QHBoxLayout()
        self.back_button = QPushButton("← Back")
        self.back_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.back_button.clicked.connect(self.finish_session)
        self.counter_label = QLabel("")
        self.counter_label.setStyleSheet(f"color: {TEXT_SECONDARY}; font-weight: 600;")
        top_row.addWidget(self.back_button)
        top_row.addStretch()
        top_row.addWidget(self.counter_label)
        layout.addLayout(top_row)

        # Everything below the top bar shares one centred column, so the card,
        # the progress bar and the rating buttons line up as a single object.
        self.body_column = QWidget()
        self.body_column.setMaximumWidth(CARD_WIDTH)
        body = QVBoxLayout(self.body_column)
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(14)
        body_row = QHBoxLayout()
        body_row.setContentsMargins(0, 0, 0, 0)
        body_row.addStretch(1)
        body_row.addWidget(self.body_column, 12)
        body_row.addStretch(1)
        layout.addLayout(body_row)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setRange(0, 1000)
        body.addWidget(self.progress_bar)

        # --------------------------------------------------------- card
        self.card = QFrame()
        self.card.setObjectName("card")
        self.card.setMinimumHeight(320)
        card_layout = QVBoxLayout(self.card)
        card_layout.setContentsMargins(40, 16, 40, 36)
        card_layout.setSpacing(12)

        # Top row inside the card: speak button left, status tag right
        card_top = QHBoxLayout()
        self.speak_button = self._tool_button(
            "Say  P", "Hear the word in your computer's voice for this language (P)",
            self.speak_word)
        self.tree_button = self._tool_button(
            "Tree  T", "The same card drawn as a tree — meaning, example, "
            "translations and hook as branches (T)", self.toggle_tree)
        self.image_button = self._tool_button(
            "Image  I", "Draw a picture for this word with the AI — about a cent, "
            "within the daily picture budget (I)", self.generate_image)
        self.undo_button = self._tool_button(
            "Undo  U", "Take back the last rating — wrong key, changed your mind (U)",
            self.undo)
        self.undo_button.setEnabled(False)
        # Everything about THIS card that is not studying it.
        self.more_button = QPushButton("More")
        self.more_button.setStyleSheet(self.TOOL_STYLE)
        self.more_button.setFixedHeight(28)
        self.more_button.setToolTip("Edit this card, reset its progress, or remove it")
        self.more_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.more_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        more_menu = QMenu(self.more_button)
        more_menu.addAction("✏️  Edit this card…", self.edit_card)
        more_menu.addAction("🔄  Reset its progress", self.reset_card)
        more_menu.addSeparator()
        more_menu.addAction("🗑️  Remove from deck", self.remove_card)
        self.more_button.setMenu(more_menu)
        card_top.addWidget(self.speak_button)
        card_top.addWidget(self.tree_button)
        card_top.addWidget(self.image_button)
        card_top.addWidget(self.undo_button)
        card_top.addWidget(self.more_button)
        card_top.addStretch()
        self.status_label = QLabel("")
        self.status_label.setStyleSheet(f"color: {TEXT_MUTED}; font-size: 10pt;")
        card_top.addWidget(self.status_label)
        card_layout.addLayout(card_top)

        # Word + part of speech rendered inline: Pursue [ v ]
        self.word_label = QLabel("")
        self.word_label.setTextFormat(Qt.TextFormat.RichText)
        self.word_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.word_label.setWordWrap(True)

        # H reveals just the root-surgery line — a scaffold, not the answer.
        self.hint_label = QLabel("")
        self.hint_label.setTextFormat(Qt.TextFormat.PlainText)
        self.hint_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hint_label.setStyleSheet(f"color: {TEXT_MUTED}; font-style: italic;")
        self.hint_label.setWordWrap(True)

        # Back of the card (revealed together, faded in with an animation).
        # Transparent on purpose: the opacity effect renders the panel into its
        # own layer, so an inherited background would paint a dark band over
        # the card.
        self.answer_panel = QWidget()
        self.answer_panel.setStyleSheet("background: transparent;")
        answer_layout = QVBoxLayout(self.answer_panel)
        answer_layout.setContentsMargins(0, 8, 0, 0)
        answer_layout.setSpacing(9)

        # The stacked rows live in their own column, capped at a comfortable
        # reading width — full-window lines are hard to read and hard to learn
        # from. Centred with stretch spacers rather than an alignment flag,
        # which would stop the column expanding and squeeze the text.
        self.list_container = QWidget()
        self.list_container.setMaximumWidth(READING_WIDTH)
        list_layout = QVBoxLayout(self.list_container)
        list_layout.setContentsMargins(0, 0, 0, 0)
        list_layout.setSpacing(9)

        # The picture leads the answer, and sits OUTSIDE the stacked column so
        # it shows in tree mode too — the tree is a different way to read the
        # same card, not a reason to lose the image.
        self.image_card = ImageCard()
        self.image_card.hide()
        image_row = QHBoxLayout()
        image_row.setContentsMargins(0, 0, 0, 0)
        image_row.addStretch(1)
        image_row.addWidget(self.image_card, 12)
        image_row.addStretch(1)
        answer_layout.addLayout(image_row)

        column_row = QHBoxLayout()
        column_row.setContentsMargins(0, 0, 0, 0)
        column_row.addStretch(1)
        column_row.addWidget(self.list_container, 12)
        column_row.addStretch(1)
        answer_layout.addLayout(column_row)

        divider = QFrame()
        divider.setFixedHeight(1)
        divider.setStyleSheet(f"background-color: {BORDER};")
        list_layout.addWidget(divider)

        # The definition is the payload — it gets the most weight on the card.
        self.definition_label = QLabel("")
        self.definition_label.setTextFormat(Qt.TextFormat.PlainText)
        self.definition_label.setStyleSheet(
            f"font-size: 17pt; font-weight: 600; color: {TEXT};")
        self.definition_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.definition_label.setWordWrap(True)
        list_layout.addWidget(self.definition_label)

        self.example_label = QLabel("")
        self.example_label.setTextFormat(Qt.TextFormat.PlainText)
        self.example_label.setStyleSheet(
            f"font-style: italic; font-size: 12pt; color: {TEXT_SECONDARY};"
            f"border-left: 2px solid {BORDER}; padding: 2px 0 2px 14px;"
        )
        self.example_label.setWordWrap(True)
        list_layout.addWidget(self.example_label)

        # Supporting facts in one aligned column so the eye scans, not reads:
        # native language first, then the neighbourhood.
        self.meta_widget = QWidget()
        meta_grid = QGridLayout(self.meta_widget)
        meta_grid.setContentsMargins(0, 6, 0, 0)
        meta_grid.setHorizontalSpacing(20)
        meta_grid.setVerticalSpacing(6)
        meta_grid.setColumnStretch(1, 1)
        self.meta_rows = []
        for row in range(3):
            key = QLabel("")
            key.setStyleSheet(f"font-size: 8.5pt; font-weight: 700; color: {TEXT_SECONDARY};")
            key.setTextFormat(Qt.TextFormat.RichText)
            key.setFixedWidth(96)
            value = QLabel("")
            value.setTextFormat(Qt.TextFormat.PlainText)
            value.setWordWrap(True)
            meta_grid.addWidget(key, row, 0, Qt.AlignmentFlag.AlignTop)
            meta_grid.addWidget(value, row, 1)
            self.meta_rows.append((key, value))
        list_layout.addWidget(self.meta_widget)

        # The memory hook: roots, families, bridges — shown at the moment
        # of recall, which is exactly when the brain re-encodes.
        self.hook_label = QLabel("")
        self.hook_label.setTextFormat(Qt.TextFormat.RichText)
        self.hook_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.hook_label.setStyleSheet(
            f"background: rgba(59,130,246,0.07); border-left: 3px solid {ACCENT};"
            f"border-radius: 4px; padding: 11px 16px; margin-top: 6px;"
        )
        self.hook_label.setWordWrap(True)
        list_layout.addWidget(self.hook_label)

        # T swaps the stacked answer for the same fields drawn as a fan-right
        # tree. No new data — a second way to look, and a second way back:
        # every word keeps each branch in the same place.
        self.list_widgets = [
            self.definition_label, self.example_label,
            self.meta_widget, self.hook_label,
        ]
        self.tree_view = WordTreeWidget()
        self.tree_view.hide()
        answer_layout.addWidget(self.tree_view)
        self.tree_mode = self.db.get_setting("answer_view", "list") == "tree"
        self.list_has_content = [False] * len(self.list_widgets)

        self.answer_effect = QGraphicsOpacityEffect(self.answer_panel)
        self.answer_panel.setGraphicsEffect(self.answer_effect)
        self.answer_animation = QPropertyAnimation(self.answer_effect, b"opacity")
        self.answer_animation.setDuration(280)

        # Fixed space above the word, stretch only below: the word keeps the
        # same position before and after the reveal, so the eye never has to
        # hunt for it again.
        face = QWidget()
        face.setStyleSheet("background: transparent;")
        face_layout = QVBoxLayout(face)
        face_layout.setContentsMargins(0, 0, 0, 0)
        face_layout.setSpacing(12)
        face_layout.addStretch(1)
        face_layout.addWidget(self.word_label)
        face_layout.addWidget(self.hint_label)
        face_layout.addSpacing(6)
        face_layout.addWidget(self.answer_panel)
        face_layout.addStretch(1)
        self.face_scroll = QScrollArea()
        self.face_scroll.setWidgetResizable(True)
        self.face_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.face_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.face_scroll.setStyleSheet("background: transparent;")
        self.face_scroll.setWidget(face)
        card_layout.addWidget(self.face_scroll, 1)
        body.addWidget(self.card, 1)

        # ------------------------------------------------------- buttons
        self.show_button = QPushButton("Show Answer  (Space)")
        self.show_button.setObjectName("primary")
        self.show_button.setMinimumHeight(48)
        self.show_button.setToolTip(
            "Try to recall the meaning first — the effort is what builds the "
            "memory. Then reveal and rate yourself. H gives a hint.")
        self.show_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.show_button.clicked.connect(self.show_answer)
        body.addWidget(self.show_button)

        self.rating_row = QWidget()
        rating_outer = QVBoxLayout(self.rating_row)
        rating_outer.setContentsMargins(0, 0, 0, 0)
        rating_outer.setSpacing(6)
        rating_caption = QLabel("How well did you know it?")
        rating_caption.setAlignment(Qt.AlignmentFlag.AlignCenter)
        rating_caption.setStyleSheet(f"color: {TEXT_SECONDARY};")
        rating_outer.addWidget(rating_caption)
        rating_buttons_row = QWidget()
        rating_layout = QHBoxLayout(rating_buttons_row)
        rating_layout.setContentsMargins(0, 0, 0, 0)
        rating_layout.setSpacing(10)
        rating_outer.addWidget(rating_buttons_row)
        self.rating_buttons = []
        for rating, name, obj in [
            (srs.AGAIN, "Again", "rateAgain"),
            (srs.HARD, "Hard", "rateHard"),
            (srs.GOOD, "Good", "rateGood"),
            (srs.EASY, "Easy", "rateEasy"),
        ]:
            button = QPushButton(name)
            button.setObjectName(obj)
            button.setMinimumHeight(52)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _, r=rating: self.rate(r))
            rating_layout.addWidget(button)
            self.rating_buttons.append(button)
        body.addWidget(self.rating_row)

        self.tally_label = QLabel("")
        self.tally_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.tally_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        body.addWidget(self.tally_label)

        # Done / empty state
        self.done_label = QLabel("")
        self.done_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.done_label.setStyleSheet("font-size: 15pt; font-weight: 600;")
        self.done_label.setWordWrap(True)
        body.addWidget(self.done_label)

        self.next_session_button = QPushButton("")
        self.next_session_button.setObjectName("primary")
        self.next_session_button.setMinimumHeight(52)
        self.next_session_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.next_session_button.clicked.connect(self.refresh)
        self.next_session_button.hide()
        body.addWidget(self.next_session_button)

        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    # Words, not emoji: 'Segoe UI' carries no emoji glyphs and the app-wide QSS
    # font-family overrides setFont, so 🔊/🌳 rendered as empty boxes. A label
    # also beats an icon when you are trying to remember what the key does.
    TOOL_STYLE = ("font-size: 9pt; font-weight: 600; padding: 5px 12px;"
                  f"color: {TEXT_SECONDARY};")

    def _tool_button(self, text, tooltip, handler):
        """Small labelled button in the card's top row."""
        button = QPushButton(text)
        button.setStyleSheet(self.TOOL_STYLE)
        button.setFixedHeight(28)
        button.setToolTip(tooltip)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        button.clicked.connect(handler)
        return button

    # -------------------------------------------------------- session flow

    def refresh(self):
        """Called on navigation: start a fresh session from due cards."""
        self.end_session_bookkeeping()
        self.langs = languages.load(self.db.get_setting)
        self._undo = None
        cap = self.db.get_int_setting("session_cap", 20)
        max_new = self.db.get_int_setting("max_new_per_day", 20)
        cards = self.db.get_due_words(limit=cap, max_new=max_new)
        if not cards:
            self.session = None
            self._show_empty_state()
            return
        self.session = srs.StudySession(cards)
        self.session_id = self.db.start_session()
        self._show_study_widgets(True)
        self.show_card()
        self.setFocus()

    def _show_empty_state(self):
        self._show_study_widgets(False)
        counts = self.db.counts()
        if self.db.word_count() == 0:
            self.done_label.setText("No words yet — import your vocabulary list first (Ctrl+I).")
        elif counts["new"] > 0:
            max_new = self.db.get_int_setting("max_new_per_day", 20)
            self.done_label.setText(
                f"✅ Daily limit of {max_new} new words reached — great work!\n\n"
                f"Reviews of words you've already seen are always unlimited.\n"
                f"Want to learn more new words per day? Raise the limit in Settings."
            )
        else:
            self.done_label.setText(
                "🎉 All caught up! No cards are due right now.\n"
                "Come back later, or browse your words in the meantime."
            )
        self.done_label.show()

    def _show_study_widgets(self, visible):
        for widget in (self.card, self.progress_bar, self.tally_label):
            widget.setVisible(visible)
        self.show_button.setVisible(visible)
        self.rating_row.setVisible(False)
        self.done_label.setVisible(not visible)
        self.next_session_button.setVisible(False)

    def show_card(self):
        card = self.session.current()
        if card is None:
            self.session_complete()
            return
        self.answer_shown = False

        pos = html.escape((card.get("pos") or "").strip())
        word_html = (f'<span style="font-size:38px; font-weight:700;">'
                     f'{html.escape(card["word"])}</span>')
        if pos:
            word_html += (
                f' <span style="font-size:22px; color:{TEXT_MUTED};">[ {pos} ]</span>'
            )
        self._word_html = word_html
        direction = self.db.get_setting("study_direction", "forward")
        # Mixed: a stable coin per card, so an Again-requeued card keeps its side.
        self._reverse = direction == "reverse" or (
            direction == "mixed" and int(card["id"][:2], 16) % 2 == 1)
        if self._reverse:
            prompt = (f'<span style="font-size:22px; font-weight:600;">'
                      f'{html.escape(cards_ai.mask_word(card["definition"], card["word"]))}</span>')
            native = _bullets(card.get("greek"), ",")
            if native and self.langs.native_label:
                prompt += (f'<br><span style="font-size:15px; color:{TEXT_SECONDARY};">'
                           f'{flags.html(self.langs.native)}{html.escape(native)}</span>')
            prompt += (f'<br><span style="font-size:12px; color:{TEXT_MUTED};">'
                       f'which {self.langs.target} word?</span>')
            self.word_label.setText(prompt)
        else:
            self.word_label.setText(word_html)

        if card["repetitions"] == 0:
            self.status_label.setText("new")
        else:
            self.status_label.setText(f"{card['interval']}d interval")

        self.hint_label.setText("")
        self.definition_label.setText(card["definition"])
        example = (card.get("example") or "").strip()
        self.example_label.setText(f"“{example}”" if example else "")

        # Native language first — it is the fastest way back to the meaning.
        meta = []
        greek = _bullets(card.get("greek"), ",")
        if greek and self.langs.native_label:
            meta.append((flags.tag(self.langs.native, self.langs.native_label), greek,
                         f"font-size: 13pt; color: {TEXT};"))
        swedish = _bullets(card.get("swedish"), ",")
        if swedish and self.langs.second_label:
            meta.append((flags.tag(self.langs.second, self.langs.second_label), swedish,
                         f"font-size: 11.5pt; color: {TEXT_SECONDARY};"))
        synonyms = _bullets(card.get("synonyms"), "|")
        if synonyms:
            meta.append(("NEAR", synonyms, f"font-size: 11.5pt; color: {TEXT_SECONDARY};"))
        for index, (key, value) in enumerate(self.meta_rows):
            if index < len(meta):
                name, text, style = meta[index]
                key.setText(name)
                value.setText(text)
                value.setStyleSheet(style)
                key.setVisible(True)
                value.setVisible(True)
            else:
                key.setVisible(False)
                value.setVisible(False)

        hook = (card.get("hook") or "").strip()
        if hook:
            lines = [line.strip() for line in hook.splitlines() if line.strip()]
            markup = (f'<div style="color:{ACCENT}; font-size:11.5pt">'
                      f'{html.escape(_strip_prefix(lines[0]))}</div>')
            for line in lines[1:]:
                markup += (f'<div style="color:{TEXT_SECONDARY}; font-size:11pt; '
                           f'margin-top:5px">{html.escape(line)}</div>')
            self.hook_label.setText(markup)
        else:
            self.hook_label.setText("")

        self._load_image(card)
        self.list_has_content = [True, bool(example), bool(meta), bool(hook)]
        self.tree_view.set_card(card, self.langs)
        self._apply_answer_mode()

        self.answer_panel.setVisible(False)
        self.answer_effect.setOpacity(0.0)
        self.show_button.setVisible(True)
        self.rating_row.setVisible(False)

        self.counter_label.setText(self.session.progress_label())
        self.progress_bar.setValue(int(self.session.progress_fraction() * 1000))
        self.undo_button.setEnabled(self._undo is not None)
        self._update_rating_previews(card)
        self._update_tally()

    RATING_MEANING = [
        "Again — you blanked. Comes back later in this session and tomorrow.",
        "Hard — you got there, slowly. Comes back soon.",
        "Good — solid recall. The interval grows.",
        "Easy — instant. The interval grows fast.",
    ]

    def _update_rating_previews(self, card):
        names = ["Again", "Hard", "Good", "Easy"]
        for rating, button in enumerate(self.rating_buttons):
            preview = srs.preview_interval(
                card["interval"], card["ease_factor"], card["repetitions"], rating
            )
            button.setText(f"{names[rating]}\n{preview}")
            button.setToolTip(f"{self.RATING_MEANING[rating]}  Next: {preview}.  "
                              f"Press {rating + 1}.")

    def _update_tally(self):
        tally = self.session.tally
        self.tally_label.setText(
            f'<span style="color:{DANGER}">Again {tally[srs.AGAIN]}</span> &nbsp;•&nbsp; '
            f'<span style="color:{WARNING}">Hard {tally[srs.HARD]}</span> &nbsp;•&nbsp; '
            f'<span style="color:{SUCCESS}">Good {tally[srs.GOOD]}</span> &nbsp;•&nbsp; '
            f'<span style="color:{ACCENT}">Easy {tally[srs.EASY]}</span>'
        )

    def _apply_answer_mode(self):
        """Stacked rows or the tree — never both, same data either way."""
        for widget, has_content in zip(self.list_widgets, self.list_has_content):
            widget.setVisible(has_content)
        self.list_container.setVisible(not self.tree_mode)
        self.tree_view.setVisible(self.tree_mode)
        # The tree draws its own root word, so the header word would be a
        # duplicate; it stays put whenever the answer is still hidden.
        self.word_label.setVisible(not (self.tree_mode and self.answer_shown))
        self.tree_button.setStyleSheet(
            self.TOOL_STYLE + (
                f"background-color: rgba(59,130,246,0.16); border: 1px solid {ACCENT};"
                f"color: {ACCENT};" if self.tree_mode else ""
            )
        )

    def toggle_tree(self):
        self.tree_mode = not self.tree_mode
        self.db.set_setting("answer_view", "tree" if self.tree_mode else "list")
        self._apply_answer_mode()
        self.setFocus()  # clicking the button must not steal the rating keys

    def show_answer(self):
        if self.session is None or self.answer_shown or self.session.is_finished():
            return
        self.answer_shown = True
        if self._reverse:
            self.word_label.setText(self._word_html)     # the answer is the word
        self._apply_answer_mode()
        self.answer_panel.setVisible(True)
        self.answer_animation.stop()
        self.answer_animation.setStartValue(0.0)
        self.answer_animation.setEndValue(1.0)
        self.answer_animation.start()
        self.show_button.setVisible(False)
        self.rating_row.setVisible(True)

    def rate(self, rating):
        if self.session is None or not self.answer_shown:
            return
        card = self.session.current()
        # Everything a wrong keypress would need back: the progress row as
        # it was, and the session exactly as it stood.
        self._undo = {
            "word_id": card["id"], "rating": rating,
            "progress": self.db.progress_of(card["id"]),
            "queue": [dict(c) for c in self.session.queue],
            "position": self.session.position, "tally": dict(self.session.tally),
        }
        interval, ease, reps = srs.sm2_update(
            card["interval"], card["ease_factor"], card["repetitions"], rating
        )
        self.db.apply_review(card["id"], interval, ease, reps)
        self.db.record_rating(self.session_id, rating)
        updated = dict(card, interval=interval, ease_factor=ease, repetitions=reps)
        self.session.rate(rating, updated_card=updated)
        self.main_window.update_status()
        self.show_card()

    def undo(self):
        """Take back the last rating: the card returns to the front with
        its old schedule, the session tally steps back one."""
        if self._undo is None or self.session is None:
            return
        last, self._undo = self._undo, None
        if last["progress"]:
            self.db.restore_progress(last["word_id"], last["progress"])
        if self.session_id is not None:
            self.db.unrecord_rating(self.session_id, last["rating"])
        self.session.queue = last["queue"]
        self.session.position = last["position"]
        self.session.tally = last["tally"]
        self.main_window.update_status()
        self.show_card()
        self.setFocus()

    # ------------------------------------------------------- this card

    def _drop_current(self):
        """The current card leaves the session (removed, or reset to new);
        a card that was already seen in this sitting no longer counts."""
        self._undo = None
        self.session.queue.pop(0)
        self.session.total = max(1, self.session.total - 1)
        self.main_window.update_status()
        self.show_card()

    def edit_card(self):
        from ui.browse import EditWordDialog
        card = self.session.current() if self.session else None
        if card is None:
            return
        dialog = EditWordDialog(card, self.langs, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            self.setFocus()
            return
        values = dialog.values()
        if values["word"] and values["definition"]:
            self.db.update_word(card["id"], values)
            card.update(values)          # the session's copy, so the card redraws
            self.show_card()
        self.setFocus()

    def reset_card(self):
        card = self.session.current() if self.session else None
        if card is None:
            return
        if QMessageBox.question(
                self, "Reset progress",
                f"Forget how well you know “{card['word']}”? It becomes a new word.",
        ) == QMessageBox.StandardButton.Yes:
            self.db.reset_progress(card["id"])
            self._drop_current()
        self.setFocus()

    def remove_card(self):
        card = self.session.current() if self.session else None
        if card is None:
            return
        if QMessageBox.question(
                self, "Remove word",
                f"Remove “{card['word']}” from your deck, with its progress? "
                "This also removes it on your other computer.",
        ) == QMessageBox.StandardButton.Yes:
            self.db.delete_word(card["id"])
            self._drop_current()
        self.setFocus()

    def session_complete(self):
        tally = self.session.tally
        total = sum(tally.values())
        self._show_study_widgets(False)
        goal = self.db.get_int_setting("daily_goal", 20)
        reviewed = self.db.reviewed_today()
        streak = self.db.current_streak()
        today = (f"Today: {reviewed} / {goal}" + (" ✅ goal reached" if reviewed >= goal else "")
                 + f"   •   🔥 {streak} day streak")
        self.done_label.setText(
            f"🎉 Session complete!\n\nYou reviewed {total} cards:\n"
            f"Again {tally[srs.AGAIN]}  •  Hard {tally[srs.HARD]}  •  "
            f"Good {tally[srs.GOOD]}  •  Easy {tally[srs.EASY]}\n\n{today}"
        )
        self.session = None
        self._undo = None
        self.end_session_bookkeeping()
        self.main_window.start_sync()        # the other computer gets today's work
        # Offer to continue immediately if more cards are available today.
        max_new = self.db.get_int_setting("max_new_per_day", 20)
        remaining = len(self.db.get_due_words(max_new=max_new))
        if remaining > 0:
            cap = self.db.get_int_setting("session_cap", 20)
            self.next_session_button.setText(
                f"Start next session  ({min(remaining, cap)} cards)"
            )
            self.next_session_button.show()

    def end_session_bookkeeping(self):
        if self.session_id is not None:
            self.db.delete_empty_session(self.session_id)
            self.session_id = None

    def finish_session(self):
        self.main_window.navigate("dashboard")

    def speak_word(self):
        card = self.session.current() if self.session else None
        if card:
            speak(card["word"], self.langs.target)

    # -------------------------------------------------------------- pictures

    def _load_image(self, card):
        """Show this card's illustration if one has been generated."""
        path = images.image_file(self.db.path, card["id"])
        if not path:
            self.image_card.clear()
            return False
        self.image_card.set_image(
            path, images.load_callouts(self.db.conn, card["id"]))
        return self.image_card.has_image()

    def generate_image(self):
        """Draw a picture for the current word, on demand. Runs off the UI
        thread so a slow request never freezes a study session."""
        card = self.session.current() if self.session else None
        if card is None or self._image_busy:
            return
        engine = images.ImageEngine(self.db.path)
        try:
            # Checked against the brief, not the filesystem: on a second
            # device the picture is known before its bytes have arrived, and
            # redrawing in that gap means paying for it twice.
            if images.has_picture(self.db.conn, card["id"]):
                self.status_label.setText(
                    "this word already has a picture"
                    if images.image_file(self.db.path, card["id"])
                    else "picture already drawn — still syncing to this device")
                return
            if engine.affordable_images() < 1:
                spent = engine.spent_today()
                self.status_label.setText(
                    f"daily image budget spent (${spent:.3f} of "
                    f"${engine.cap():.2f}) — more tomorrow")
                return
        finally:
            engine.close()

        self._image_busy = True
        self.image_button.setText("Drawing…")
        word_id, word = card["id"], card["word"]
        entry = {"id": word_id, "word": word,
                 "definition": card["definition"], "pos": card.get("pos") or ""}

        def work():
            worker = images.ImageEngine(self.db.path)
            try:
                path = worker.generate_for(entry)
                self.image_done.emit(word_id, path or "")
            except Exception as exc:
                self.image_failed.emit(word_id, str(exc))
            finally:
                worker.close()

        threading.Thread(target=work, daemon=True).start()

    def _on_image_done(self, word_id, path):
        self._image_busy = False
        self.image_button.setText("Image  I")
        card = self.session.current() if self.session else None
        if not path:
            self.status_label.setText("no picture could show this word")
            return
        if card is None or card["id"] != word_id:
            return                        # moved on; it is saved for next time
        self._load_image(card)

    def _on_image_failed(self, word_id, message):
        self._image_busy = False
        self.image_button.setText("Image  I")
        card = self.session.current() if self.session else None
        if card is not None and card["id"] == word_id:
            self.status_label.setText(f"image failed: {message[:70]}")

    def show_hint(self):
        """First line of the hook only — the root surgery. Fight for the
        answer with a scaffold instead of giving up."""
        card = self.session.current() if self.session else None
        if card is None or self.answer_shown:
            return
        hook = (card.get("hook") or "").strip()
        if hook:
            self.hint_label.setText(f"💡 {hook.splitlines()[0]}")  # plain text label

    # ------------------------------------------------------------ keyboard

    def resizeEvent(self, event):
        # The picture takes at most a third of the screen's height, so the
        # words under it always have room on a small window.
        self.image_card.set_max_height(max(110, int(self.height() * 0.34)))
        super().resizeEvent(event)

    def keyPressEvent(self, event):
        key = event.key()
        if self.session is not None:
            if key == Qt.Key.Key_Space:
                self.show_answer()
                return
            if key == Qt.Key.Key_P:
                self.speak_word()
                return
            if key == Qt.Key.Key_H:
                self.show_hint()
                return
            if key == Qt.Key.Key_T:
                self.toggle_tree()
                return
            if key == Qt.Key.Key_I:
                self.generate_image()
                return
            if key == Qt.Key.Key_U or (
                    key == Qt.Key.Key_Z
                    and event.modifiers() & Qt.KeyboardModifier.ControlModifier):
                self.undo()
                return
            if self.answer_shown and key in (
                Qt.Key.Key_1, Qt.Key.Key_2, Qt.Key.Key_3, Qt.Key.Key_4
            ):
                self.rate(key - Qt.Key.Key_1)
                return
        super().keyPressEvent(event)

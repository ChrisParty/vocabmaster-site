"""Learn the alphabet: a chart you can open beside any card, and a drill
that teaches the sounds step by step — each new symbol shown before it is
asked, a few at a time, a symbol is yours after three right answers in a
row. Hangul ends with syllable blocks, because that is what you actually
read; Japanese has a hiragana and a katakana track.
"""

import random

from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QFontMetrics
from PyQt6.QtWidgets import (
    QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QProgressBar,
    QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

import alphabets
import languages
from ui.flashcard import has_voice, listen_button_text, listen_button_tip
from ui.widgets import ComboBox
from styles import (
    ACCENT, BORDER, DANGER, SUCCESS, SURFACE, SURFACE_HOVER, TEXT, TEXT_MUTED,
    TEXT_SECONDARY, wrapping,
)

MASTER_STREAK = 3
TILE_WIDTH = 80
WORKING_SET = 5        # symbols being learned at once
STEP_DONE = 0.8        # share of a step known before the next step opens
REVIEW_SHARE = 0.2     # how often a known symbol comes back for review


def _speak(symbol, language):
    from ui.flashcard import speak
    speak(alphabets.speakable(symbol), language)


class Tile(QFrame):
    """One symbol with its reading. Click to hear it."""

    clicked = pyqtSignal(str)

    def __init__(self, symbol, reading, note):
        super().__init__()
        self.symbol = symbol
        self.setFixedWidth(TILE_WIDTH)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(note or f"{symbol} — {reading}. Click to hear it.")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 8, 6, 8)
        layout.setSpacing(2)
        big = QLabel(symbol)
        big.setAlignment(Qt.AlignmentFlag.AlignCenter)
        # 20pt, or smaller when a wide symbol ("ゃ ゅ ょ") would not fit the tile.
        size = 20
        font = QFont(big.font())
        font.setWeight(QFont.Weight.DemiBold)
        while size > 11:
            font.setPointSize(size)
            if QFontMetrics(font).horizontalAdvance(symbol) <= TILE_WIDTH - 14:
                break
            size -= 1
        big.setStyleSheet(f"font-size: {size}pt; font-weight: 600; color: {TEXT}; background: transparent;")
        small = QLabel(reading)
        small.setAlignment(Qt.AlignmentFlag.AlignCenter)
        small.setStyleSheet(f"font-size: 9pt; color: {TEXT_SECONDARY}; background: transparent;")
        layout.addWidget(big)
        layout.addWidget(small)
        self.set_mastered(False)

    def set_mastered(self, mastered):
        border = SUCCESS if mastered else BORDER
        self.setStyleSheet(
            f"Tile {{ background-color: {SURFACE}; border: 1px solid {border}; border-radius: 10px; }}"
            f"Tile:hover {{ background-color: {SURFACE_HOVER}; }}")

    def mousePressEvent(self, event):
        self.clicked.emit(self.symbol)
        super().mousePressEvent(event)


class AlphabetChart(QWidget):
    """The groups of an alphabet as tiles; mastered ones outlined green."""

    def __init__(self, alphabet, language):
        super().__init__()
        self.language = language
        self.tiles = {}
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(14)
        for title, group in alphabet["groups"]:
            head = QLabel(title)
            head.setStyleSheet(f"font-weight: 700; color: {TEXT_SECONDARY}; background: transparent;")
            layout.addWidget(head)
            grid = QGridLayout()
            grid.setHorizontalSpacing(8)
            grid.setVerticalSpacing(8)
            columns = 8
            for index, (symbol, reading, note) in enumerate(group):
                tile = Tile(symbol, reading, note)
                tile.clicked.connect(lambda s, lang=language: _speak(s, lang))
                grid.addWidget(tile, index // columns, index % columns)
                self.tiles[symbol] = tile
            grid.setColumnStretch(columns, 1)
            layout.addLayout(grid)

    def set_progress(self, progress):
        for symbol, tile in self.tiles.items():
            tile.set_mastered(progress.get(symbol, 0) >= MASTER_STREAK)


class AlphabetDialog(QDialog):
    """The chart beside the study screen: non-modal, stays open while you
    study, so a forgotten letter costs one glance."""

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowFlag(Qt.WindowType.Tool, True)
        self.setMinimumSize(560, 520)
        self.resize(640, 700)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        self.title = QLabel("")
        self.title.setStyleSheet("font-size: 14pt; font-weight: 700;")
        layout.addWidget(self.title)
        hint = QLabel("Click any symbol to hear it. Green outline = you know it.")
        hint.setStyleSheet(f"color: {TEXT_MUTED};")
        layout.addWidget(hint)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        layout.addWidget(self.scroll, 1)
        self.chart = None
        self.language = None

    def refresh(self):
        langs = languages.load(self.db.get_setting)
        alphabet = alphabets.for_language(langs.target)
        if alphabet is None:
            return False
        if self.language != langs.target:
            self.language = langs.target
            self.chart = AlphabetChart(alphabet, langs.target)
            self.scroll.setWidget(self.chart)
            self.setWindowTitle(alphabet["title"])
            self.title.setText(alphabet["title"])
        self.chart.set_progress(self.db.alphabet_progress(langs.target))
        return True


class AlphabetScreen(QWidget):
    """Intro, practice, chart — in that order, because the practice is the
    part that teaches.

    The practice walks the alphabet step by step (alphabets.tracks): a new
    symbol is first SHOWN with its sound, then asked; about WORKING_SET
    symbols are in play at once, so the first minutes end with "you know 5",
    not with 40 different symbols half-seen. The next step opens when most
    of the current one is known. Japanese has two tracks to choose from,
    hiragana and katakana."""

    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self.language = None
        self.alphabet = None
        self.items = []            # every drill item: (symbol, reading, family)
        self.tracks = []           # [(title, [step items, ...])]
        self.track = 0
        self.step = 0
        self.notes = {}
        self.progress = {}         # symbol -> right answers in a row (introduced = present)
        self.current = None
        self.options = []
        self.answered = False
        self.recent = []
        self.since_intro = 0
        self.mode = "symbol"       # "intro", "symbol" (-> reading) or "reading" (-> symbol)
        self.chart = None
        self._loading = False
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)

        self.header = QLabel("Alphabet")
        self.header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(self.header)

        intro_card = QFrame()
        intro_card.setObjectName("card")
        intro_layout = QVBoxLayout(intro_card)
        intro_layout.setContentsMargins(24, 18, 24, 18)
        self.intro = wrapping(QLabel(""))
        self.intro.setStyleSheet("font-size: 11pt;")
        intro_layout.addWidget(self.intro)
        layout.addWidget(intro_card)

        # ---- practice
        self.practice_card = QFrame()
        self.practice_card.setObjectName("card")
        practice = QVBoxLayout(self.practice_card)
        practice.setContentsMargins(24, 18, 24, 18)
        practice.setSpacing(12)
        top = QHBoxLayout()
        title = QLabel("Practice")
        title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        top.addWidget(title)
        self.track_box = ComboBox()
        self.track_box.setToolTip("Which set of symbols to practise. Hiragana first is "
                                  "the usual way; switch to katakana once you know it.")
        self.track_box.currentIndexChanged.connect(self.change_track)
        top.addWidget(self.track_box)
        top.addStretch()
        self.progress_label = QLabel("")
        self.progress_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        top.addWidget(self.progress_label)
        practice.addLayout(top)
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setTextVisible(False)
        practice.addWidget(self.progress_bar)
        self.step_label = wrapping(QLabel(""))
        self.step_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        practice.addWidget(self.step_label)

        self.ask = QLabel("")
        self.ask.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ask.setStyleSheet(f"color: {TEXT_SECONDARY};")
        practice.addWidget(self.ask)
        self.prompt = QLabel("")
        self.prompt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.prompt.setStyleSheet("font-size: 64pt; font-weight: 700;")
        self.prompt.setMinimumHeight(110)
        practice.addWidget(self.prompt)

        row = QHBoxLayout()
        row.setSpacing(10)
        self.buttons = []
        for index in range(4):
            button = QPushButton("")
            button.setMinimumHeight(64)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setToolTip(f"Press {index + 1}")
            button.clicked.connect(lambda _, i=index: self.choose(i))
            row.addWidget(button)
            self.buttons.append(button)
        practice.addLayout(row)

        bottom = QHBoxLayout()
        self.feedback = wrapping(QLabel(""))
        self.feedback.setStyleSheet(f"color: {TEXT_SECONDARY};")
        bottom.addWidget(self.feedback, 1)
        self.say_button = QPushButton("🔊  Listen")
        self.say_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.say_button.clicked.connect(self.say)
        bottom.addWidget(self.say_button)
        self.next_button = QPushButton("Next  (Space)")
        self.next_button.setObjectName("primary")
        self.next_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.next_button.clicked.connect(self.next_question)
        bottom.addWidget(self.next_button)
        practice.addLayout(bottom)
        layout.addWidget(self.practice_card)

        # ---- chart
        self.chart_card = QFrame()
        self.chart_card.setObjectName("card")
        self.chart_layout = QVBoxLayout(self.chart_card)
        self.chart_layout.setContentsMargins(24, 18, 24, 18)
        chart_title = QLabel("All the symbols")
        chart_title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        self.chart_layout.addWidget(chart_title)
        chart_hint = wrapping(QLabel(
            "Click any symbol to hear it. Green outline = you know it. On the Study "
            "screen, the Alphabet button (A) opens this chart beside your card."))
        chart_hint.setStyleSheet(f"color: {TEXT_MUTED};")
        self.chart_layout.addWidget(chart_hint)
        layout.addWidget(self.chart_card)

        self.none_label = wrapping(QLabel(
            "The language you are learning uses the Latin alphabet — nothing to "
            "learn here. Choose a language in Settings → Languages."))
        self.none_label.setStyleSheet(f"color: {TEXT_SECONDARY}; font-size: 11pt;")
        layout.addWidget(self.none_label)
        layout.addStretch()

    # ----------------------------------------------------------- loading

    def refresh(self):
        langs = languages.load(self.db.get_setting)
        alphabet = alphabets.for_language(langs.target)
        has = alphabet is not None
        for widget in (self.practice_card, self.chart_card):
            widget.setVisible(has)
        self.none_label.setVisible(not has)
        if not has:
            self.header.setText("Alphabet")
            self.intro.setText("")
            return
        if self.language != langs.target:
            self.language = langs.target
            self.alphabet = alphabet
            self.header.setText(alphabet["title"])
            self.intro.setText(alphabet["intro"])
            self.tracks = alphabets.tracks(alphabet)
            self.items = [item for _, steps in self.tracks for step in steps for item in step]
            self.letter_count = len(self.items)
            self.notes = alphabets.notes(alphabet)
            self._loading = True
            self.track_box.clear()
            self.track_box.addItems([title for title, _ in self.tracks])
            self._loading = False
            self.track_box.setVisible(len(self.tracks) > 1)
            if self.chart is not None:
                self.chart.setParent(None)
            self.chart = AlphabetChart(alphabet, langs.target)
            self.chart_layout.addWidget(self.chart)
            self.recent = []
        saved = self.db.get_int_setting(self._track_setting(), 0)
        self.track = saved if 0 <= saved < len(self.tracks) else 0
        self._loading = True
        self.track_box.setCurrentIndex(self.track)
        self._loading = False
        self.progress = self.db.alphabet_progress(langs.target)
        self.chart.set_progress(self.progress)
        self.say_button.setText(listen_button_text(self.language))
        self.say_button.setToolTip(listen_button_tip(self.language, "the symbol"))
        self.update_progress()
        self.next_question()
        self.setFocus()

    def _track_setting(self):
        return f"alphabet_track_{(self.language or '').lower()}"

    def change_track(self, index):
        if self._loading or index < 0:
            return
        self.track = index
        self.db.set_setting(self._track_setting(), index)
        self.recent = []
        self.since_intro = 0
        self.update_progress()
        self.next_question()
        self.setFocus()

    def _known(self, symbol):
        return self.progress.get(symbol, 0) >= MASTER_STREAK

    def _pool(self):
        """The symbols open in the chosen track: every step up to the first one
        that is not yet mostly known (that step is the current one)."""
        steps = self.tracks[self.track][1] if self.tracks else []
        pool = []
        self.step = 0
        for index, step in enumerate(steps):
            pool += step
            self.step = index
            known = sum(1 for s, _, _ in step if self._known(s))
            if known < len(step) * STEP_DONE:
                break
        return pool

    def update_progress(self):
        if not self.tracks:
            return
        title, steps = self.tracks[self.track]
        self._pool()                                   # sets self.step
        everything = [item for step in steps for item in step]
        known = sum(1 for s, _, _ in everything if self._known(s))
        unit = self.alphabet.get("unit", "letters") if self.alphabet else "letters"
        text = f"{title}: you know {known} of {len(everything)}"
        if len(steps) > 1:
            text += f" · step {self.step + 1} of {len(steps)}"
        self.progress_label.setText(text)
        self.progress_bar.setValue(int(known / len(everything) * 100) if everything else 0)
        step_items = steps[self.step]
        family = step_items[0][2] if step_items else ""
        note = self.alphabet.get("steps", {}).get(family, "") if self.alphabet else ""
        if known == len(everything):
            others = [t for i, (t, _) in enumerate(self.tracks) if i != self.track]
            note = (f"All {len(everything)} {title.lower()} {unit} are yours ✓"
                    + (f" — choose {others[0]} above when you are ready." if others else "."))
        self.step_label.setText(note)
        self.step_label.setVisible(bool(note))

    # ---------------------------------------------------------- practice

    def next_question(self):
        if not self.tracks:
            return
        pool = self._pool()
        learning = [i for i in pool if i[0] in self.progress and not self._known(i[0])]
        fresh = [i for i in pool if i[0] not in self.progress]
        known = [i for i in pool if self._known(i[0])]
        recent = self.recent[-2:]
        if fresh and (not learning or (len(learning) < WORKING_SET and self.since_intro >= 2)):
            self._introduce(fresh[0])
            return
        if learning and (not known or random.random() > REVIEW_SHARE):
            # Weaker symbols come back more often (0 right: 3x, 2 right: 1x).
            choices = [i for i in learning if i[0] not in recent] or learning
            weights = [MASTER_STREAK - min(self.progress.get(i[0], 0), MASTER_STREAK - 1)
                       for i in choices]
            item = random.choices(choices, weights=weights)[0]
        elif known:
            item = random.choice([i for i in known if i[0] not in recent] or known)
        else:
            item = random.choice(pool)
        self._ask(item, pool)

    def _introduce(self, item):
        """Show a new symbol with its sound before ever asking it."""
        symbol, reading, _ = item
        self.current = item
        self.mode = "intro"
        self.options = []
        self.answered = True                  # Space / Next moves on
        self.since_intro = 0
        self.recent.append(symbol)
        self.progress[symbol] = self.db.alphabet_introduce(self.language, symbol)
        self.ask.setText("New — have a look, then press Next")
        self.prompt.setText(symbol)
        for button in self.buttons:
            button.setVisible(False)
        note = self.notes.get(symbol, "")
        self.feedback.setText(f"{symbol} = {reading}" + (f"  ·  {note}" if note else ""))
        self.next_button.setEnabled(True)
        self.chart.set_progress(self.progress)
        self.update_progress()
        if has_voice(self.language):
            _speak(symbol, self.language)

    def _ask(self, item, pool):
        symbol, reading, family = item
        self.current = item
        self.answered = False
        self.since_intro += 1
        self.recent.append(symbol)
        # Wrong answers drawn from what the learner has already met where
        # possible, then from the same family.
        def ok(i):
            return i[0] != symbol and i[1] != reading
        seen = [i for i in pool if ok(i) and i[0] in self.progress]
        same = [i for i in self.items if ok(i) and i[2] == family and i not in seen]
        random.shuffle(seen)
        random.shuffle(same)
        distractors = []
        for i in seen + same:
            if all(i[1] != d[1] for d in distractors):
                distractors.append(i)
            if len(distractors) == 3:
                break
        self.mode = random.choice(["symbol", "symbol", "reading"])
        self.options = distractors + [item]
        random.shuffle(self.options)
        for button in self.buttons:
            button.setVisible(True)
        if self.mode == "symbol":
            self.ask.setText("How does this sound?")
            self.prompt.setText(symbol)
            for button, option in zip(self.buttons, self.options):
                button.setText(option[1])
                button.setStyleSheet("font-size: 14pt;")
        else:
            self.ask.setText("Which one sounds like this?")
            self.prompt.setText(reading)
            for button, option in zip(self.buttons, self.options):
                button.setText(option[0])
                button.setStyleSheet("font-size: 22pt;")
        for index, button in enumerate(self.buttons):
            button.setVisible(index < len(self.options))
            button.setEnabled(True)
        self.feedback.setText("")
        self.next_button.setEnabled(False)

    def choose(self, index):
        if self.answered or self.mode == "intro" or index >= len(self.options):
            return
        self.answered = True
        symbol, reading, _ = self.current
        correct = self.options[index][0] == symbol
        for i, (button, item) in enumerate(zip(self.buttons, self.options)):
            button.setEnabled(False)
            if item[0] == symbol:
                button.setStyleSheet(button.styleSheet() + f"border: 2px solid {SUCCESS}; color: {SUCCESS};")
            elif i == index:
                button.setStyleSheet(button.styleSheet() + f"border: 2px solid {DANGER}; color: {DANGER};")
        self.progress[symbol] = self.db.alphabet_record(self.language, symbol, correct)
        note = self.notes.get(symbol, "")
        if correct:
            streak = self.progress[symbol]
            self.feedback.setText(
                f"✓  {symbol} = {reading}" + ("  — yours now." if streak == MASTER_STREAK
                                              else f"  ({streak} in a row)"))
        else:
            self.feedback.setText(f"✗  {symbol} = {reading}" + (f"  ·  {note}" if note else "")
                                  + ". It comes back soon.")
        self.chart.set_progress(self.progress)
        self.update_progress()
        self.next_button.setEnabled(True)
        if has_voice(self.language):
            _speak(symbol, self.language)
        if correct:
            QTimer.singleShot(900, lambda: self.answered and self.mode != "intro"
                              and self.next_question())

    def say(self):
        if not self.current:
            return
        if not has_voice(self.language):
            self.feedback.setText(listen_button_tip(self.language, "the symbol"))
            return
        _speak(self.current[0], self.language)

    def keyPressEvent(self, event):
        key = event.key()
        if key in (Qt.Key.Key_1, Qt.Key.Key_2, Qt.Key.Key_3, Qt.Key.Key_4):
            self.choose(key - Qt.Key.Key_1)
            return
        if key in (Qt.Key.Key_Space, Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.answered:
            self.next_question()
            return
        if key == Qt.Key.Key_P:
            self.say()
            return
        super().keyPressEvent(event)

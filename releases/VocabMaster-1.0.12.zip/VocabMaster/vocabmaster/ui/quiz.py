"""Multiple choice quiz screen: 4 options drawn from the deck, then SM-2 rating.

Question types are mixed for stronger recall: word→meaning, meaning→word,
and fill-in-the-blank using the card's own example sentence.
"""

import html
import random
import re

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QApplication, QHBoxLayout, QLabel, QLineEdit, QProgressBar, QPushButton, QVBoxLayout,
    QWidget,
)

import alphabets
import cards_ai
import flags
import languages
import srs
import wordview
from styles import (
    ACCENT, BORDER, DANGER, SUCCESS, SURFACE, TEXT_SECONDARY, WARNING,
)

def option_style(kind="base", pt=11.0):
    """Option button styles; `pt` grows for scripts that need bigger type."""
    if kind == "correct":
        return (f"QPushButton {{ background-color: rgba(34,197,94,0.18); border: 2px solid {SUCCESS};"
                f" border-radius: 10px; padding: 14px 18px; text-align: left; font-size: {pt:.1f}pt;"
                f" font-weight: 600; }}")
    if kind == "wrong":
        return (f"QPushButton {{ background-color: rgba(239,68,68,0.18); border: 2px solid {DANGER};"
                f" border-radius: 10px; padding: 14px 18px; text-align: left; font-size: {pt:.1f}pt; }}")
    return (f"QPushButton {{ background-color: {SURFACE}; border: 1px solid {BORDER};"
            f" border-radius: 10px; padding: 14px 18px; text-align: left; font-size: {pt:.1f}pt; }}"
            f" QPushButton:hover {{ border-color: {ACCENT}; }}")


OPTION_BASE_STYLE = option_style()
OPTION_CORRECT_STYLE = option_style("correct")
OPTION_WRONG_STYLE = option_style("wrong")


def _norm(text):
    return "".join(ch for ch in text.casefold().strip() if ch.isalnum() or ch == " ").strip()


def _distance(a, b):
    """Levenshtein, small strings only."""
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        current = [i]
        for j, cb in enumerate(b, 1):
            current.append(min(previous[j] + 1, current[j - 1] + 1,
                               previous[j - 1] + (ca != cb)))
        previous = current
    return previous[-1]


def _judge(typed, word):
    """'right', 'close' (one slip in a word of 5+), or 'wrong'. Judges the
    headword before any bracket tail."""
    target = _norm(word.split("[")[0])
    guess = _norm(typed)
    if guess == target:
        return "right"
    if len(target) >= 5 and _distance(guess, target) <= 1:
        return "close"
    return "wrong"


def _unspaced(text):
    """Written without spaces between words (Japanese kana / kanji, Chinese)."""
    return any(0x3040 <= ord(ch) <= 0x30FF or 0x4E00 <= ord(ch) <= 0x9FFF for ch in text or "")


_LONG = str.maketrans("āīūēōâîûêô", "aiueoaiueo")


def romaji_key(text):
    """Typed romaji compared without the long-vowel marks a beginner cannot
    type: kyō = kyo = kyou, gakkō = gakkou = gakko, oishii = oishi."""
    text = (text or "").casefold().translate(_LONG)
    for long, short in (("ou", "o"), ("oo", "o"), ("uu", "u"), ("aa", "a"),
                        ("ii", "i"), ("ee", "e")):
        text = text.replace(long, short)
    return text


def make_cloze(word, example):
    """Blank the word out of its example sentence: "The ship's rudder…" -> "The ship's _____…"

    Tries the word stem too, so inflected forms (tumbled, pursuing) still match.
    Returns None when the word doesn't appear in the sentence.
    """
    example = (example or "").strip()
    if _unspaced(word):
        # Japanese / Chinese: no spaces, so no word boundaries to lean on.
        # A verb or adjective changes its ending (食べる → 食べます): try
        # the whole word, then without its last character (3+ only, so a
        # one-character stem never matches inside another word).
        head = word.split("[")[0].strip()
        stems = [head] + ([head[:-1]] if len(head) >= 3 else [])
        for stem in stems:
            at = example.find(stem) if stem else -1
            if at >= 0:
                return example[:at] + "_____" + example[at + len(stem):]
        return None
    base = word.lower().split()[0].strip(".,;:")
    if not example or len(base) < 3:
        return None
    stems = [base]
    if len(base) > 4:
        stems.append(base[:-1])
    if len(base) > 5:
        stems.append(base[:-2])
    for stem in stems:
        match = re.search(rf"\b{re.escape(stem)}\w*", example, re.IGNORECASE)
        if match:
            return example[: match.start()] + "_____" + example[match.end():]
    return None


class QuizScreen(QWidget):
    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self.session = None
        self.session_id = None
        self.answered = False
        self.correct_index = -1
        self.practice_mode = False

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 20, 32, 20)
        layout.setSpacing(14)

        top_row = QHBoxLayout()
        back_button = QPushButton("← Back")
        back_button.setCursor(Qt.CursorShape.PointingHandCursor)
        back_button.clicked.connect(lambda: self.main_window.navigate("dashboard"))
        self.counter_label = QLabel("")
        self.counter_label.setStyleSheet(f"color: {TEXT_SECONDARY}; font-weight: 600;")
        self.alphabet_button = QPushButton("Alphabet")
        self.alphabet_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.alphabet_button.setToolTip("Open the alphabet chart beside the quiz (A)")
        self.alphabet_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.alphabet_button.clicked.connect(self.main_window.show_alphabet)
        top_row.addWidget(back_button)
        top_row.addWidget(self.alphabet_button)
        top_row.addStretch()
        top_row.addWidget(self.counter_label)
        layout.addLayout(top_row)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setRange(0, 1000)
        layout.addWidget(self.progress_bar)

        self.question_label = QLabel("")
        self.question_label.setTextFormat(Qt.TextFormat.PlainText)
        self.question_label.setStyleSheet("font-size: 20px; font-weight: 700;")
        self.question_label.setWordWrap(True)
        layout.addWidget(self.question_label)

        self.option_buttons = []
        for index in range(4):
            button = QPushButton("")
            button.setStyleSheet(OPTION_BASE_STYLE)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _, i=index: self.select_answer(i))
            layout.addWidget(button)
            self.option_buttons.append(button)

        # Typing style: an answer box instead of the four options.
        type_row = QHBoxLayout()
        type_row.setSpacing(10)
        self.answer_edit = QLineEdit()
        self.answer_edit.setPlaceholderText("type the word (or how it is read), then Enter")
        self.answer_edit.setMinimumHeight(44)
        self.answer_edit.returnPressed.connect(self.check_typed)
        self.check_button = QPushButton("Check")
        self.check_button.setMinimumHeight(44)
        self.check_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.check_button.clicked.connect(self.check_typed)
        type_row.addWidget(self.answer_edit, 1)
        # å ä ö (Swedish) as buttons: no Swedish keyboard needed. Filled in
        # refresh() for the learning language; Shift+click gives Å Ä Ö.
        self.letters_row = QHBoxLayout()
        self.letters_row.setSpacing(6)
        type_row.addLayout(self.letters_row)
        self.letter_buttons = []
        type_row.addWidget(self.check_button)
        self.type_widget = QWidget()
        self.type_widget.setLayout(type_row)
        self.type_widget.hide()
        layout.addWidget(self.type_widget)
        self.typing = False

        self.detail_label = QLabel("")
        self.detail_label.setWordWrap(True)
        self.detail_label.setStyleSheet(
            f"color: {TEXT_SECONDARY}; border-left: 3px solid {ACCENT}; padding-left: 12px;"
        )
        layout.addWidget(self.detail_label)

        self.rating_row = QWidget()
        rating_layout = QHBoxLayout(self.rating_row)
        rating_layout.setContentsMargins(0, 0, 0, 0)
        rating_layout.setSpacing(10)
        self.rating_buttons = []
        for rating, name, obj in [
            (srs.AGAIN, "Again", "rateAgain"),
            (srs.HARD, "Hard", "rateHard"),
            (srs.GOOD, "Good", "rateGood"),
            (srs.EASY, "Easy", "rateEasy"),
        ]:
            button = QPushButton(name)
            button.setObjectName(obj)
            button.setMinimumHeight(48)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _, r=rating: self.rate(r))
            rating_layout.addWidget(button)
            self.rating_buttons.append(button)
        layout.addWidget(self.rating_row)

        self.done_label = QLabel("")
        self.done_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.done_label.setStyleSheet("font-size: 15pt; font-weight: 600;")
        self.done_label.setWordWrap(True)
        layout.addWidget(self.done_label)

        self.next_session_button = QPushButton("Start next quiz")
        self.next_session_button.setObjectName("primary")
        self.next_session_button.setMinimumHeight(52)
        self.next_session_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.next_session_button.clicked.connect(self.refresh)
        self.next_session_button.hide()
        layout.addWidget(self.next_session_button)

        layout.addStretch()
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    # -------------------------------------------------------- session flow

    def refresh(self):
        self.end_session_bookkeeping()
        self.langs = languages.load(self.db.get_setting)
        alphabet = alphabets.for_language(self.langs.target)
        self.alphabet_button.setVisible(alphabet is not None)
        if alphabet is not None:
            self.alphabet_button.setText(f"{alphabet['icon']}  Alphabet")
        self._make_letter_buttons()
        self.scale = languages.script_scale(self.langs.target)
        self.question_label.setStyleSheet(f"font-size: {int(20 * self.scale)}px; font-weight: 700;")
        if self.db.word_count() < 4:
            self.session = None
            self._show_quiz_widgets(False)
            self.done_label.setText(
                "The quiz needs at least 4 words in your deck.\nImport more words first (Ctrl+I)."
            )
            return
        cap = self.db.get_int_setting("session_cap", 20)
        max_new = self.db.get_int_setting("max_new_per_day", 20)
        cards = self.db.get_due_words(limit=cap, max_new=max_new)
        self.practice_mode = not cards
        if not cards:
            # Nothing due — practice random words. Practice never touches the
            # SRS schedule (otherwise an "Again" here would drag a card that
            # wasn't due for weeks back into tomorrow's queue).
            cards = random.sample(self.db.get_words(), min(cap, self.db.word_count()))
        self.session = srs.StudySession(cards)
        self.session_id = self.db.start_session()
        self._show_quiz_widgets(True)
        self.show_question()
        self.setFocus()

    def _show_quiz_widgets(self, visible):
        for widget in [self.progress_bar, self.question_label] + self.option_buttons:
            widget.setVisible(visible)
        self.type_widget.setVisible(False)
        self.detail_label.setVisible(False)
        self.rating_row.setVisible(False)
        self.done_label.setVisible(not visible)
        self.next_session_button.setVisible(False)

    def show_question(self):
        card = self.session.current()
        if card is None:
            self.session_complete()
            return
        self.answered = False
        self.detail_label.setVisible(False)
        self.rating_row.setVisible(False)

        # Mix question types — recalling the word in different ways builds
        # stronger memory than one-way drilling.
        all_words = self.db.get_words()
        cloze = make_cloze(card["word"], card.get("example"))
        style = self.db.get_setting("quiz_mode", "choice")
        modes = ["forward", "reverse"] + (["cloze"] if cloze else [])
        if style == "typing":
            modes = ["type"]
        elif style == "mixed":
            modes.append("type")
        mode = random.choice(modes)
        self.typing = mode == "type"
        self.type_widget.setVisible(self.typing)
        for button in self.option_buttons:
            button.setVisible(not self.typing)
        if self.typing:
            prompt = f"Type the {self.langs.target} word for: “{cards_ai.mask_word(card['definition'], card['word'])}”"
            native = (card.get("greek") or "").strip()
            if native and self.langs.native_label:
                prompt += f"   ({native})"
            self.question_label.setText(prompt)
            self.answer_edit.clear()
            self.answer_edit.setEnabled(True)
            self.answer_edit.setFocus()
            self.counter_label.setText(self.session.progress_label())
            self.progress_bar.setValue(int(self.session.progress_fraction() * 1000))
            self._update_rating_previews(card)
            return
        if mode == "cloze":
            hint = (card.get("example_tr") or "").strip()
            self.question_label.setText(
                f"Complete the sentence:\n“{cloze}”" + (f"\n({hint})" if hint else ""))
            correct = self._word_option(card)
            distractors = [
                self._word_option(w) for w in all_words
                if w["id"] != card["id"] and w["word"] != card["word"]
            ]
        elif mode == "reverse":
            self.question_label.setText(
                f"Which word means: “{cards_ai.mask_word(card['definition'], card['word'])}”")
            correct = self._word_option(card)
            distractors = [
                self._word_option(w) for w in all_words
                if w["id"] != card["id"] and w["word"] != card["word"]
            ]
        else:
            head, reading = wordview.headline(card, self.langs.target, self.db.get_setting)
            self.question_label.setText(
                f"What does “{head}”" + (f" ({reading})" if reading else "") + " mean?")
            correct = card["definition"]
            distractors = [
                w["definition"] for w in all_words
                if w["id"] != card["id"] and w["definition"] != card["definition"]
            ]
        random.shuffle(distractors)
        options = distractors[:3] + [correct]
        random.shuffle(options)
        self.correct_index = options.index(correct)

        letters = ["A", "B", "C", "D"]
        # Options in the learner's script get the bigger type; definitions do not.
        self.option_pt = 11 * (self.scale if mode != "forward" else 1.0)
        for index, button in enumerate(self.option_buttons):
            if index < len(options):
                button.setText(f"{letters[index]}.   {options[index]}")
                button.setStyleSheet(option_style("base", self.option_pt))
                button.setEnabled(True)
                button.setVisible(True)
            else:
                button.setVisible(False)

        self.counter_label.setText(self.session.progress_label())
        self.progress_bar.setValue(int(self.session.progress_fraction() * 1000))
        self._update_rating_previews(card)

    def _update_rating_previews(self, card):
        names = ["Again", "Hard", "Good", "Easy"]
        for rating, button in enumerate(self.rating_buttons):
            preview = srs.preview_interval(
                card["interval"], card["ease_factor"], card["repetitions"], rating
            )
            button.setText(f"{names[rating]}\n{preview}")

    def _make_letter_buttons(self):
        for button in self.letter_buttons:
            self.letters_row.removeWidget(button)
            button.deleteLater()
        self.letter_buttons = []
        for letter in languages.extra_letters(self.langs.target):
            button = QPushButton(letter)
            button.setFixedSize(44, 44)
            button.setStyleSheet("font-size: 14pt; padding: 0;")
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setFocusPolicy(Qt.FocusPolicy.NoFocus)    # typing stays in the box
            button.setToolTip(f"Type {letter} — Shift+click for {letter.upper()}")
            button.clicked.connect(lambda _, l=letter: self._type_letter(l))
            self.letters_row.addWidget(button)
            self.letter_buttons.append(button)

    def _type_letter(self, letter):
        if not self.answer_edit.isEnabled():
            return
        shift = QApplication.keyboardModifiers() & Qt.KeyboardModifier.ShiftModifier
        self.answer_edit.insert(letter.upper() if shift else letter)
        self.answer_edit.setFocus()

    def check_typed(self):
        if self.answered or self.session is None or not self.typing:
            return
        card = self.session.current()
        typed = self.answer_edit.text().strip()
        if not typed:
            return
        self.answered = True
        self.answer_edit.setEnabled(False)
        # A beginner has no Korean keyboard yet: the reading counts as an answer.
        verdict = _judge(typed, card["word"])
        reading = (card.get("reading") or "").strip()
        # Japanese readings carry kana and romaji ("たべる · taberu"): either counts.
        japanese = self.langs.target.strip().lower() == "japanese"
        for form in [part.strip() for part in reading.split("·") if part.strip()]:
            if verdict == "right":
                break
            by_reading = (_judge(romaji_key(typed), romaji_key(form)) if japanese
                          else _judge(typed, form))
            if by_reading == "right" or (by_reading == "close" and verdict == "wrong"):
                verdict = by_reading
        shown = html.escape(typed)
        if verdict == "right":
            head = f'<span style="color:{SUCCESS}; font-weight:600">✓ Right</span>'
        elif verdict == "close":
            head = (f'<span style="color:{WARNING}; font-weight:600">≈ Almost — '
                    f'you typed “{shown}”</span>')
        else:
            head = f'<span style="color:{DANGER}; font-weight:600">✗ You typed “{shown}”</span>'
        self._show_detail(card, head + "<br>")
        self.setFocus()                      # 1–4 rate from here

    def select_answer(self, index):
        if self.answered or self.session is None:
            return
        self.answered = True
        card = self.session.current()

        for i, button in enumerate(self.option_buttons):
            button.setEnabled(False)
            if i == self.correct_index:
                button.setStyleSheet(option_style("correct", getattr(self, "option_pt", 11)))
                button.setText("✓  " + button.text())
            elif i == index:
                button.setStyleSheet(option_style("wrong", getattr(self, "option_pt", 11)))
                button.setText("✗  " + button.text())

        self._show_detail(card)

    def _word_option(self, card):
        return wordview.one_line(card, self.langs.target, self.db.get_setting)

    def _show_detail(self, card, prefix=""):
        head, reading = wordview.headline(card, self.langs.target, self.db.get_setting)
        detail = prefix + f"<b>{html.escape(head)}</b>"
        if reading:
            detail += f" <span style='color:{TEXT_SECONDARY}'>{html.escape(reading)}</span>"
        detail += f" — {html.escape(card['definition'])}"
        example = (card.get("example") or "").strip()
        if example:
            detail += f"<br><i>“{html.escape(example)}”</i>"
            for extra in ("example_reading", "example_tr"):
                text = (card.get(extra) or "").strip()
                if text:
                    detail += f"<br><span style='color:{TEXT_SECONDARY}'>{html.escape(text)}</span>"
        translations = []
        if (card.get("greek") or "").strip() and self.langs.native_label:
            translations.append(f"{flags.tag(self.langs.native, self.langs.native_label)}{html.escape(card['greek'].strip())}")
        if (card.get("swedish") or "").strip() and self.langs.second_label:
            translations.append(f"{flags.tag(self.langs.second, self.langs.second_label)}{html.escape(card['swedish'].strip())}")
        if translations:
            detail += "<br>" + "&nbsp;&nbsp;&nbsp;".join(translations)
        hook = ((card.get("hook") or "").strip()
                if self.db.get_setting("show_hook", "1") != "0" else "")
        if hook:
            detail += (f"<br><span style='color:{TEXT_SECONDARY}; font-size:8pt; font-weight:700;'>"
                       f"MEMORY HOOK</span><br>" + "<br>".join(
                f'<span style="color:#c8a96e; font-size:10pt;">{html.escape(line)}</span>'
                for line in hook.splitlines() if line.strip()))
        self.detail_label.setText(detail)
        self.detail_label.setVisible(True)
        self.rating_row.setVisible(True)

    def rate(self, rating):
        if self.session is None or not self.answered:
            return
        card = self.session.current()
        interval, ease, reps = srs.sm2_update(
            card["interval"], card["ease_factor"], card["repetitions"], rating
        )
        if not self.practice_mode:
            self.db.apply_review(card["id"], interval, ease, reps)
        self.db.record_rating(self.session_id, rating)
        updated = dict(card, interval=interval, ease_factor=ease, repetitions=reps)
        self.session.rate(rating, updated_card=updated)
        self.main_window.update_status()
        self.show_question()

    def session_complete(self):
        tally = self.session.tally
        total = sum(tally.values())
        self._show_quiz_widgets(False)
        self.done_label.setText(
            f"🎉 Quiz complete!\n\nYou answered {total} questions:\n"
            f"Again {tally[srs.AGAIN]}  •  Hard {tally[srs.HARD]}  •  "
            f"Good {tally[srs.GOOD]}  •  Easy {tally[srs.EASY]}"
        )
        self.session = None
        self.end_session_bookkeeping()
        self.main_window.start_sync()        # the other computer gets today's work
        if self.db.word_count() >= 4:
            self.next_session_button.show()

    def end_session_bookkeeping(self):
        if self.session_id is not None:
            self.db.delete_empty_session(self.session_id)
            self.session_id = None

    # ------------------------------------------------------------ keyboard

    def keyPressEvent(self, event):
        key = event.key()
        if key == Qt.Key.Key_A and self.alphabet_button.isVisible():
            self.main_window.show_alphabet()
            return
        if self.session is not None and key in (
            Qt.Key.Key_1, Qt.Key.Key_2, Qt.Key.Key_3, Qt.Key.Key_4
        ):
            index = key - Qt.Key.Key_1
            if not self.answered:
                self.select_answer(index)
            else:
                self.rate(index)
            return
        super().keyPressEvent(event)

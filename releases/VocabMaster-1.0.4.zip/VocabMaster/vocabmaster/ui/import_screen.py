"""Import screen: three ways to get words into an empty deck.

  paste / CSV      a spreadsheet, columns detected from the header row
  starter deck     the N most common words of the deck's language, cards
                   written by the AI in batches under the daily text budget
  add a word       one word → one full AI-written card

Plus the whole-deck move (restore a backup), because a fresh install lands
here first.
"""

import os
import threading

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit,
    QMessageBox, QPushButton, QScrollArea, QTableWidget, QTableWidgetItem,
    QTextEdit, QVBoxLayout, QWidget,
)

import cards_ai
import languages
import parser as vparser
from styles import ACCENT, DANGER, SUCCESS, TEXT_SECONDARY, wrapping
from ui.widgets import ComboBox

BADGE_STYLE = (
    "color: {color}; background-color: {bg}; border-radius: 9px;"
    "padding: 3px 10px; font-weight: 600;"
)

STARTER_SIZES = ["20", "50", "100", "300", "500", "1000", "2000"]


class PasteArea(QTextEdit):
    """Paste box that recovers the table structure from clipboard HTML.

    Copying from Excel/Sheets puts both plain text and an HTML table on the
    clipboard. Some sources produce plain text with one CELL per line (no
    tabs), which is unparseable — the HTML version always keeps the columns,
    so prefer it whenever it contains a table.
    """

    def insertFromMimeData(self, source):
        if source.hasHtml():
            tsv = vparser.html_table_to_tsv(source.html())
            if tsv:
                self.insertPlainText(tsv)
                return
        super().insertFromMimeData(source)


def _card(title):
    frame = QFrame()
    frame.setObjectName("card")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(24, 18, 24, 18)
    layout.setSpacing(10)
    label = QLabel(title)
    label.setStyleSheet("font-weight: 700; font-size: 12pt;")
    layout.addWidget(label)
    return frame, layout


class ImportScreen(QWidget):
    # AI work runs on worker threads; results come back through these.
    starter_progress = pyqtSignal(int, int, int)   # added, have, target
    starter_done = pyqtSignal(int, str)            # added, reason ("" = done)
    complete_done = pyqtSignal(int, str)
    add_done = pyqtSignal(str, str)                # word, message

    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self.entries = []
        self.langs = languages.load(db.get_setting)
        self._busy = False
        self.setAcceptDrops(True)
        self.starter_progress.connect(self._on_starter_progress)
        self.starter_done.connect(self._on_starter_done)
        self.complete_done.connect(self._on_complete_done)
        self.add_done.connect(self._on_add_done)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(14)

        header = QLabel("Add Words")
        header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(header)

        # ------------------------------------------------ starter deck
        starter_card, starter_layout = _card("Build a starter deck with AI")
        self.starter_info = QLabel("")
        self.starter_info.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(self.starter_info)
        starter_layout.addWidget(self.starter_info)
        starter_row = QHBoxLayout()
        starter_row.setSpacing(10)
        starter_row.addWidget(QLabel("The most common"))
        self.starter_size = ComboBox()
        self.starter_size.addItems(STARTER_SIZES)
        self.starter_size.setCurrentText("300")
        self.starter_size.setToolTip(
            "How big the deck should be when it is done. Only new words are "
            "added, so you can come back for more later.")
        starter_row.addWidget(self.starter_size)
        starter_row.addWidget(QLabel("words, for a"))
        self.starter_level = ComboBox()
        self.starter_level.addItems(list(cards_ai.LEVELS))
        self.starter_level.setToolTip(
            "beginner: the first weeks of the language. intermediate: everyday "
            "fluency. advanced: precise, less common words.")
        starter_row.addWidget(self.starter_level)
        starter_row.addWidget(QLabel("learner"))
        starter_row.addStretch()
        self.starter_button = QPushButton("✨  Generate")
        self.starter_button.setObjectName("primary")
        self.starter_button.setMinimumHeight(40)
        self.starter_button.setToolTip(
            "Writes full cards — definition, translations, example, memory hook — "
            "about $0.20 per 1,000 words on your key, never past the daily budget.")
        self.starter_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.starter_button.clicked.connect(self.build_starter)
        starter_row.addWidget(self.starter_button)
        starter_layout.addLayout(starter_row)
        self.starter_status = QLabel("")
        self.starter_status.setTextFormat(Qt.TextFormat.PlainText)
        self.starter_status.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(self.starter_status)
        starter_layout.addWidget(self.starter_status)
        layout.addWidget(starter_card)

        # --------------------------------------------------- add a word
        add_card, add_layout = _card("Add one word")
        add_row = QHBoxLayout()
        add_row.setSpacing(10)
        self.add_word = QLineEdit()
        self.add_word.setPlaceholderText("a word or phrase in the language you are learning")
        self.add_word.setToolTip("Type a word, press Enter: a full card is written and added.")
        self.add_word.returnPressed.connect(self.add_one)
        add_row.addWidget(self.add_word, 1)
        self.add_button = QPushButton("✨  Write the card")
        self.add_button.setMinimumHeight(40)
        self.add_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_button.clicked.connect(self.add_one)
        add_row.addWidget(self.add_button)
        add_layout.addLayout(add_row)
        self.add_status = QLabel("")
        self.add_status.setTextFormat(Qt.TextFormat.PlainText)
        self.add_status.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(self.add_status)
        add_layout.addWidget(self.add_status)
        layout.addWidget(add_card)

        # ---------------------------------------------- complete old cards
        self.complete_card, complete_layout = _card("Complete your existing cards")
        self.complete_info = wrapping(QLabel(""))
        self.complete_info.setStyleSheet(f"color: {TEXT_SECONDARY};")
        complete_layout.addWidget(self.complete_info)
        self.complete_button = QPushButton("✨  Add readings and translations")
        self.complete_button.setMinimumHeight(40)
        self.complete_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.complete_button.setToolTip(
            "Cards made before this were missing the example's translation and the "
            "word's reading. A fraction of a cent per card.")
        self.complete_button.clicked.connect(self.complete_missing)
        complete_layout.addWidget(self.complete_button)
        layout.addWidget(self.complete_card)
        self.complete_card.hide()

        # ------------------------------------------------ paste / file
        # The original way in, kept out of the way: a spreadsheet is how the
        # first deck arrived, not how a learner adds words day to day.
        self.paste_toggle = QPushButton("Paste a spreadsheet instead…")
        self.paste_toggle.setStyleSheet(
            f"color: {TEXT_SECONDARY}; background: transparent; border: none; "
            "text-align: left; padding: 4px 0;")
        self.paste_toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.paste_toggle.clicked.connect(lambda: self.toggle_paste())
        layout.addWidget(self.paste_toggle)
        paste_card, paste_layout = _card("Paste a spreadsheet")
        self.paste_card = paste_card
        paste_card.hide()
        instructions = QLabel(
            "Open your sheet → select all (Ctrl+A) → copy (Ctrl+C) → paste below. "
            "Columns are detected from the header row. You can also drag and "
            "drop a .csv file anywhere on this screen.\n"
            "Moving from another computer? Use “Restore from a backup” instead — "
            "it brings your progress and pictures along."
        )
        instructions.setStyleSheet(f"color: {TEXT_SECONDARY};")
        wrapping(instructions)
        paste_layout.addWidget(instructions)

        self.paste_area = PasteArea()
        self.paste_area.setPlaceholderText("Paste your spreadsheet data here…")
        self.paste_area.setMinimumHeight(120)
        self.paste_area.textChanged.connect(self.update_preview)
        paste_layout.addWidget(self.paste_area)

        self.badges_row = QHBoxLayout()
        self.badges_row.setSpacing(8)
        badges_container = QWidget()
        badges_container.setLayout(self.badges_row)
        paste_layout.addWidget(badges_container)

        self.error_label = QLabel("")
        self.error_label.setStyleSheet(f"color: {DANGER}; font-weight: 600;")
        wrapping(self.error_label)
        self.error_label.hide()
        paste_layout.addWidget(self.error_label)

        self.preview_label = QLabel("Preview (first 5 rows):")
        self.preview_label.setStyleSheet("font-weight: 600;")
        self.preview_label.hide()
        paste_layout.addWidget(self.preview_label)

        self.preview_table = QTableWidget()
        self.preview_table.setColumnCount(7)
        self.preview_table.verticalHeader().setVisible(False)
        self.preview_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.preview_table.setAlternatingRowColors(True)
        self.preview_table.horizontalHeader().setStretchLastSection(True)
        self.preview_table.setMaximumHeight(230)
        self.preview_table.hide()
        paste_layout.addWidget(self.preview_table)

        buttons_row = QHBoxLayout()
        buttons_row.setSpacing(10)

        # The whole-deck move lives in the main window (Settings offers it
        # too); a fresh install lands on this screen, so it belongs here as well.
        self.restore_button = QPushButton("📥  Restore from a backup…")
        self.restore_button.setMinimumHeight(48)
        self.restore_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.restore_button.clicked.connect(self.main_window.restore_backup)
        buttons_row.addWidget(self.restore_button)

        self.file_button = QPushButton("📂  Choose CSV file…")
        self.file_button.setMinimumHeight(48)
        self.file_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.file_button.clicked.connect(self.choose_file)
        buttons_row.addWidget(self.file_button)

        self.import_button = QPushButton("Import words")
        self.import_button.setObjectName("primary")
        self.import_button.setMinimumHeight(48)
        self.import_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.import_button.setEnabled(False)
        self.import_button.clicked.connect(self.do_import)
        buttons_row.addWidget(self.import_button, 1)
        paste_layout.addLayout(buttons_row)
        layout.addWidget(paste_card)

        layout.addStretch()

    def refresh(self):
        self.langs = languages.load(self.db.get_setting)
        self.preview_table.setHorizontalHeaderLabels([
            "Word", "Definition", "POS", self.langs.native or "Translation",
            self.langs.second or "Translation 2", "Synonyms", "Example"])
        writer = cards_ai.CardWriter(self.db.path)
        try:
            state = writer.summary()
            has_key = bool(writer.api_key())
        finally:
            writer.close()
        budget = (f"AI budget today: ${state['spent_today']:.3f} of ${state['cap']:.2f} "
                  f"(about $0.20 per 1,000 words)")
        self.starter_info.setText(
            f"Deck: {self.langs.describe()} — change in Settings. {budget}."
            + ("" if has_key else "  ⚠ No OpenAI key — add one in Settings first."))
        self.starter_button.setEnabled(has_key and not self._busy)
        self.add_button.setEnabled(has_key and not self._busy)
        writer = cards_ai.CardWriter(self.db.path)
        try:
            missing = len(writer.incomplete())
        finally:
            writer.close()
        self.complete_card.setVisible(missing > 0)
        self.complete_info.setText(
            f"{missing} card{'s' if missing != 1 else ''} lack a reading or the example's "
            f"translation — things a beginner needs. One click fills them in.")
        self.complete_button.setEnabled(has_key and not self._busy)

    # ------------------------------------------------------- starter deck

    def build_starter(self):
        if self._busy:
            return
        total = int(self.starter_size.currentText())
        level = self.starter_level.currentText()
        have = self.db.word_count()
        if have >= total:
            self.starter_status.setText(
                f"The deck already has {have} words — pick a larger size to add more.")
            return
        self._set_busy(True)
        self.starter_status.setText(
            f"Asking for the most common {self.langs.target} words… "
            f"each batch of 20 is saved as it arrives; stopping loses nothing.")

        def work():
            writer = cards_ai.CardWriter(self.db.path)
            try:
                added, reason = writer.build_starter(
                    total, level,
                    progress=lambda a, h, t: self.starter_progress.emit(a, h, t))
            except Exception as exc:
                added, reason = 0, str(exc)
            finally:
                writer.close()
            self.starter_done.emit(added, reason or "")

        threading.Thread(target=work, daemon=True).start()

    def _on_starter_progress(self, added, have, target):
        self.starter_status.setText(
            f"{added} new cards written — deck at {have} of {target} words…")

    def _on_starter_done(self, added, reason):
        self._set_busy(False)
        if reason:
            self.starter_status.setText(
                f"Stopped after {added} new cards: {reason}. "
                "Press Generate again to continue (tomorrow, if it was the budget).")
        else:
            self.starter_status.setText(f"Done — {added} new cards in the deck. 🎉")
        self.main_window.update_status()
        self.main_window.start_sync()
        self.refresh()

    def complete_missing(self):
        if self._busy:
            return
        self._set_busy(True)
        self.complete_info.setText("Filling in readings and translations…")

        def work():
            writer = cards_ai.CardWriter(self.db.path)
            try:
                done, reason = writer.complete_missing()
            except Exception as exc:
                done, reason = 0, str(exc)
            finally:
                writer.close()
            self.complete_done.emit(done, reason or "")

        threading.Thread(target=work, daemon=True).start()

    def _on_complete_done(self, done, reason):
        self._set_busy(False)
        self.main_window.start_sync()
        self.refresh()
        if reason:
            self.complete_info.setText(f"Stopped after {done}: {reason}. Press again to continue.")
        elif done:
            self.complete_info.setText(f"Done — {done} cards completed. 🎉")

    # ----------------------------------------------------------- add one

    def add_one(self):
        word = self.add_word.text().strip()
        if not word or self._busy:
            return
        self._set_busy(True)
        self.add_status.setText(f"Writing the card for “{word}”…")

        def work():
            writer = cards_ai.CardWriter(self.db.path)
            try:
                entry = writer.add_word(word)
                if entry is None:
                    message = "already in the deck, or the model produced nothing"
                else:
                    extras = [name for name, key in (
                        ("translation", "greek"), ("second translation", "swedish"),
                        ("synonyms", "synonyms"), ("example", "example"),
                        ("memory hook", "hook")) if entry.get(key)]
                    message = (f"added: {entry['definition']}  "
                               f"(+ {', '.join(extras)})" if extras
                               else f"added: {entry['definition']}")
            except Exception as exc:
                message = f"failed: {exc}"
            finally:
                writer.close()
            self.add_done.emit(word, message)

        threading.Thread(target=work, daemon=True).start()

    def _on_add_done(self, word, message):
        self._set_busy(False)
        self.add_status.setText(f"“{word}” — {message}")
        if message.startswith("added"):
            self.add_word.clear()
            self.main_window.update_status()
            self.main_window.start_sync()
        self.refresh()

    def toggle_paste(self, show=None):
        # isHidden(), not isVisible(): the latter is False whenever the page
        # itself is not on screen, which would make the toggle one-way.
        visible = self.paste_card.isHidden() if show is None else bool(show)
        self.paste_card.setVisible(visible)
        self.paste_toggle.setText("Hide the spreadsheet import" if visible
                                  else "Paste a spreadsheet instead…")

    def _set_busy(self, busy):
        self._busy = busy
        self.starter_button.setEnabled(not busy)
        self.add_button.setEnabled(not busy)
        self.complete_button.setEnabled(not busy)
        self.starter_button.setText("Working…" if busy else "✨  Generate")

    # -------------------------------------------------------------- preview

    def update_preview(self):
        text = self.paste_area.toPlainText()
        entries, columns, error = vparser.parse_text(text, self.langs)
        self.entries = entries
        self._render_badges(columns)

        if error and text.strip():
            self.error_label.setText(f"⚠️  {error}")
            self.error_label.show()
        else:
            self.error_label.hide()

        if entries:
            self.preview_label.show()
            self.preview_table.show()
            rows = entries[:5]
            self.preview_table.setRowCount(len(rows))
            fields = ["word", "definition", "pos", "greek", "swedish", "synonyms", "example"]
            for r, entry in enumerate(rows):
                for c, field in enumerate(fields):
                    value = entry.get(field, "")
                    if len(value) > 60:
                        value = value[:57] + "…"
                    self.preview_table.setItem(r, c, QTableWidgetItem(value))
            self.preview_table.resizeRowsToContents()
            self.import_button.setText(f"Import {len(entries)} words")
            self.import_button.setEnabled(True)
        else:
            self.preview_label.hide()
            self.preview_table.hide()
            self.import_button.setText("Import words")
            self.import_button.setEnabled(False)

    def _render_badges(self, columns):
        while self.badges_row.count():
            item = self.badges_row.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        if not columns:
            return
        colors = {
            "word": (ACCENT, "rgba(59,130,246,0.15)"),
            "definition": (SUCCESS, "rgba(34,197,94,0.15)"),
        }
        names = {"greek": self.langs.native or "translation",
                 "swedish": self.langs.second or "translation 2"}
        for field, header in columns.items():
            color, bg = colors.get(field, (TEXT_SECONDARY, "rgba(139,148,158,0.15)"))
            badge = QLabel(f"{names.get(field, field)}: {header}")
            badge.setStyleSheet(BADGE_STYLE.format(color=color, bg=bg))
            self.badges_row.addWidget(badge)
        self.badges_row.addStretch()

    # --------------------------------------------------------------- import

    def do_import(self):
        if not self.entries:
            return
        replace = False
        if self.db.word_count() > 0:
            box = QMessageBox(self)
            box.setWindowTitle("Words already exist")
            box.setText(
                f"You already have {self.db.word_count()} words.\n"
                "Append the new words, or replace everything?\n\n"
                "Replacing erases all existing words AND their progress."
            )
            append_button = box.addButton("Append", QMessageBox.ButtonRole.AcceptRole)
            replace_button = box.addButton("Replace all", QMessageBox.ButtonRole.DestructiveRole)
            box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            clicked = box.clickedButton()
            if clicked is replace_button:
                replace = True
            elif clicked is not append_button:
                return

        inserted = self.db.add_words(self.entries, replace=replace)
        skipped = len(self.entries) - inserted
        message = f"Imported {inserted} words."
        if skipped:
            message += f" Skipped {skipped} duplicates."
        QMessageBox.information(self, "Import complete", message)
        self.paste_area.clear()
        self.main_window.start_sync()
        self.main_window.navigate("dashboard")

    def choose_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose vocabulary file", "",
            "Spreadsheet files (*.csv *.tsv *.txt);;All files (*)",
        )
        if path:
            self._load_file(path)

    def _load_file(self, path):
        try:
            with open(path, "r", encoding="utf-8-sig", errors="replace") as handle:
                self.paste_area.setPlainText(handle.read())
            self.toggle_paste(True)
        except OSError as exc:
            QMessageBox.warning(self, "Import error", f"Could not read file: {exc}")

    # ---------------------------------------------------------- drag & drop

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            for url in event.mimeData().urls():
                if url.toLocalFile().lower().endswith((".csv", ".tsv", ".txt")):
                    event.acceptProposedAction()
                    return
        event.ignore()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            path = url.toLocalFile()
            if path.lower().endswith((".csv", ".tsv", ".txt")) and os.path.isfile(path):
                self._load_file(path)
                return

"""The app's version. Bump it, commit, then `python tools/publish_release.py`
— every installed copy offers the update on its next launch."""

VERSION = "1.0.4"

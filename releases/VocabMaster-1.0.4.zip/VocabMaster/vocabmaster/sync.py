"""VocabMaster cloud sync — local-first, additive, structurally loss-proof.

Transport: append-only JSON logs plus picture files in the user's cloud
(cloud.py: Google Drive by default, the original Supabase bucket still
understood). Every push uploads ONE new file of changes; nothing in the
cloud is ever modified or deleted. Pull = read all log files newer than the
cursor and merge. Loss-proof by construction: the cloud is an immutable
history — any past state is recoverable by replaying files.

Rules (agreed design, do not soften):
- Local database is the working copy; the app works fully offline.
- Deletions travel as tombstones inside logs; local applies them once,
  the cloud history keeps everything forever.
- Conflict rule, per word: most recent update wins; for study progress,
  the row STUDIED most recently wins.
- Card pictures travel as TWO separate things: the brief (prompt, callouts,
  skip decision) is text and rides inside the log as a fourth section; the
  .webp itself is binary and goes to the cloud as a real file, in its own
  folder. Base64 in the log was rejected — logs are append-only, so the same
  bytes would be carried forever, and a blob in the db would be re-copied by
  every daily backup. A device that already holds a picture never redraws
  or re-pays for it.
- Identity: with Google Drive the account IS the identity — sign in on each
  device and they share one history. Each device still gets an id, baked
  into the names of the logs it writes, so it can skip its own files.
  (Supabase era: one long random sync key per user, service secret embedded —
  owner's devices only.)

Sync is OFF until cloud.active_backend() finds a configured transport.
"""

import json
import os
import secrets
import sqlite3
from datetime import datetime, timezone

import cloud
import images

WORD_FIELDS = ["word", "definition", "pos", "greek", "swedish",
               "synonyms", "example", "hook", "reading", "example_tr"]
PROG_FIELDS = ["interval", "ease_factor", "repetitions", "due_date", "last_studied"]
# The brief, not the picture: text small enough to ride inside a log.
IMAGE_FIELDS = ["filename", "prompt", "callouts", "model", "quality", "status"]
# Study sessions: one row per sitting, so today's count, the streak and the
# stats are the same on every device. Keyed by uid, never by the local id.
SESSION_FIELDS = ["date", "cards_reviewed", "again_count", "hard_count",
                  "good_count", "easy_count"]

IMAGE_BATCH = 50          # per cycle, so one sync never stalls on a backlog


def utcnow() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def stamp_compact() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")[:-3] + "Z"


def _discard_image(db_path: str, word_id: str) -> None:
    """Remove a deleted word's picture file. Never fatal — a stray file is a
    nuisance, a crashed sync is not."""
    try:
        path = images.image_file(db_path, word_id)
        if path:
            os.remove(path)
    except OSError:
        pass


class SyncEngine:
    """Opens its OWN db connection so it can run from a background thread
    (the app's main connection is bound to the UI thread)."""

    def __init__(self, db):
        self.db_path = db.path
        self.conn = sqlite3.connect(db.path, timeout=5)
        self.conn.row_factory = sqlite3.Row

    def close(self):
        self.conn.close()

    # ---------- config ----------

    def setting(self, key, default=None):
        row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key, value):
        self.conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
        self.conn.commit()

    def store(self):
        return cloud.open_store(self.setting, self.set_setting, self.ensure_key)

    def enabled(self) -> bool:
        return cloud.active_backend(self.setting) != ""

    def ensure_key(self) -> str:
        key = self.setting("sync_key")
        if not key:
            key = "vk_" + secrets.token_urlsafe(24)
            self.set_setting("sync_key", key)
        return key

    def device_id(self) -> str:
        d = self.setting("sync_device")
        if not d:
            d = secrets.token_hex(4)
            self.set_setting("sync_device", d)
        return d

    def reset_for_new_backend(self):
        """A fresh cloud has no history: the next push must carry the whole
        deck, every picture must be offered again, and no cursor from the
        old cloud may hide the new one's files."""
        self.set_setting("sync_cursor", "")
        self.set_setting("sync_last_push", "1970")
        self.conn.execute("UPDATE word_images SET synced_at=NULL")
        self.conn.commit()

    # ---------- push (local -> cloud) ----------

    def collect_changes(self, since: str) -> dict:
        conn = self.conn
        words = [{**{f: w[f] for f in WORD_FIELDS}, "word_id": w["id"],
                  "updated_at": w["ua"] or utcnow()}
                 for w in conn.execute(
                     "SELECT w.*, COALESCE(w.updated_at,'') ua FROM words w "
                     "WHERE COALESCE(w.updated_at,'1970') > ?", (since,))]
        progress = [{**{f: p[f] for f in PROG_FIELDS}, "word_id": p["word_id"],
                     "updated_at": p["ua"] or utcnow()}
                    for p in conn.execute(
                        "SELECT p.*, COALESCE(p.updated_at,'') ua FROM progress p "
                        "WHERE COALESCE(p.updated_at,'1970') > ?", (since,))]
        tombstones = [{"word_id": t["word_id"], "updated_at": t["at"]}
                      for t in conn.execute(
                          "SELECT word_id, at FROM sync_tombstones WHERE at > ?",
                          (since,))]
        image_briefs = [{**{f: i[f] for f in IMAGE_FIELDS},
                         "word_id": i["word_id"], "updated_at": i["ua"]}
                        for i in conn.execute(
                            "SELECT i.*, COALESCE(i.updated_at,'') ua "
                            "FROM word_images i "
                            "WHERE COALESCE(i.updated_at,'1970') > ?", (since,))]
        sessions = [{**{f: s[f] for f in SESSION_FIELDS}, "uid": s["uid"],
                     "updated_at": s["ua"]}
                    for s in conn.execute(
                        "SELECT s.*, COALESCE(s.updated_at,'') ua FROM sessions s "
                        "WHERE s.uid IS NOT NULL AND s.cards_reviewed > 0 "
                        "AND COALESCE(s.updated_at,'1970') > ?", (since,))]
        return {"words": words, "progress": progress, "tombstones": tombstones,
                "images": image_briefs, "sessions": sessions}

    # ---------- pull (cloud -> local, merge) ----------

    def apply_log(self, doc: dict) -> int:
        conn = self.conn
        applied = 0
        for w in doc.get("words", []):
            local = conn.execute("SELECT id, COALESCE(updated_at,'') ua FROM words "
                                 "WHERE id=?", (w["word_id"],)).fetchone()
            if local and local["ua"] >= w["updated_at"]:
                continue                     # local same or newer wins
            fields = {f: w.get(f) for f in WORD_FIELDS}
            if local:
                sets = ", ".join(f"{f}=?" for f in fields)
                conn.execute(f"UPDATE words SET {sets}, updated_at=? WHERE id=?",
                             (*fields.values(), w["updated_at"], w["word_id"]))
            else:
                cols = ", ".join(["id"] + list(fields) + ["updated_at"])
                marks = ", ".join("?" * (len(fields) + 2))
                conn.execute(f"INSERT INTO words ({cols}) VALUES ({marks})",
                             (w["word_id"], *fields.values(), w["updated_at"]))
                conn.execute(
                    "INSERT OR IGNORE INTO progress (word_id, interval, ease_factor, "
                    "repetitions, due_date) VALUES (?, 1, 2.5, 0, datetime('now'))",
                    (w["word_id"],))
            applied += 1
        for p in doc.get("progress", []):
            local = conn.execute(
                "SELECT COALESCE(last_studied,'') ls, COALESCE(updated_at,'') ua "
                "FROM progress WHERE word_id=?", (p["word_id"],)).fetchone()
            if not local:
                continue
            cloud_ls = p.get("last_studied") or ""
            if local["ls"] > cloud_ls:
                continue                     # the most recently STUDIED row wins
            if local["ls"] == cloud_ls and local["ua"] >= p["updated_at"]:
                continue
            sets = ", ".join(f"{f}=?" for f in PROG_FIELDS)
            conn.execute(f"UPDATE progress SET {sets}, updated_at=? WHERE word_id=?",
                         (*[p.get(f) for f in PROG_FIELDS], p["updated_at"],
                          p["word_id"]))
            applied += 1
        # Image briefs. A row arriving with a filename is how this device
        # learns a picture exists in the cloud; pull_images fetches the bytes.
        for brief in doc.get("images", []):
            local = conn.execute(
                "SELECT COALESCE(updated_at,'') ua FROM word_images "
                "WHERE word_id=?", (brief["word_id"],)).fetchone()
            if local and local["ua"] >= brief["updated_at"]:
                continue
            fields = {f: brief.get(f) for f in IMAGE_FIELDS}
            if local:
                sets = ", ".join(f"{f}=?" for f in fields)
                conn.execute(
                    f"UPDATE word_images SET {sets}, updated_at=? WHERE word_id=?",
                    (*fields.values(), brief["updated_at"], brief["word_id"]))
            else:
                cols = ", ".join(["word_id"] + list(fields) + ["updated_at"])
                marks = ", ".join("?" * (len(fields) + 2))
                conn.execute(
                    f"INSERT INTO word_images ({cols}) VALUES ({marks})",
                    (brief["word_id"], *fields.values(), brief["updated_at"]))
            applied += 1
        for s in doc.get("sessions", []):
            local = conn.execute(
                "SELECT id, COALESCE(updated_at,'') ua FROM sessions WHERE uid=?",
                (s["uid"],)).fetchone()
            if local and local["ua"] >= s["updated_at"]:
                continue
            fields = {f: s.get(f) for f in SESSION_FIELDS}
            if local:
                sets = ", ".join(f"{f}=?" for f in fields)
                conn.execute(f"UPDATE sessions SET {sets}, updated_at=? WHERE id=?",
                             (*fields.values(), s["updated_at"], local["id"]))
            else:
                cols = ", ".join(list(fields) + ["uid", "updated_at"])
                marks = ", ".join("?" * (len(fields) + 2))
                conn.execute(f"INSERT INTO sessions ({cols}) VALUES ({marks})",
                             (*fields.values(), s["uid"], s["updated_at"]))
            applied += 1
        for t in doc.get("tombstones", []):
            local = conn.execute("SELECT id, COALESCE(updated_at,'') ua FROM words "
                                 "WHERE id=?", (t["word_id"],)).fetchone()
            if local and local["ua"] <= t["updated_at"]:
                conn.execute("DELETE FROM progress WHERE word_id=?", (t["word_id"],))
                conn.execute("DELETE FROM words WHERE id=?", (t["word_id"],))
                # A deleted word takes its picture with it, or images/ fills
                # up with files no card will ever show again.
                conn.execute("DELETE FROM word_images WHERE word_id=?",
                             (t["word_id"],))
                _discard_image(self.db_path, t["word_id"])
                applied += 1
        conn.commit()
        return applied

    # ---------- pictures (binary, real files, never inside a log) ----------

    def push_images(self, store) -> int:
        """Upload pictures this device drew and the cloud has not got yet."""
        rows = self.conn.execute(
            "SELECT word_id, filename FROM word_images "
            "WHERE filename IS NOT NULL AND synced_at IS NULL "
            "ORDER BY updated_at DESC LIMIT ?", (IMAGE_BATCH,)).fetchall()
        sent = 0
        for row in rows:
            path = os.path.join(images.images_dir(self.db_path), row["filename"])
            if not os.path.exists(path):
                continue          # the brief arrived from another device
            with open(path, "rb") as handle:
                body = handle.read()
            store.put_image(row["filename"], body)
            self.conn.execute(
                "UPDATE word_images SET synced_at=? WHERE word_id=?",
                (utcnow(), row["word_id"]))
            self.conn.commit()
            sent += 1
        return sent

    def pull_images(self, store) -> int:
        """Fetch pictures whose brief says they exist but whose file is not
        on this device. NotFound just means the other device has not pushed
        the bytes yet — the next cycle tries again."""
        directory = images.images_dir(self.db_path)
        os.makedirs(directory, exist_ok=True)
        rows = self.conn.execute(
            "SELECT word_id, filename FROM word_images "
            "WHERE filename IS NOT NULL ORDER BY updated_at DESC").fetchall()
        fetched = 0
        for row in rows:
            if fetched >= IMAGE_BATCH:
                break
            target = os.path.join(directory, row["filename"])
            if os.path.exists(target):
                continue
            try:
                body = store.get_image(row["filename"])
            except cloud.NotFound:
                continue
            partial = target + ".part"
            with open(partial, "wb") as handle:
                handle.write(body)
            os.replace(partial, target)    # never leave a half-written image
            # It is in the cloud by definition, so this device owes no upload.
            self.conn.execute(
                "UPDATE word_images SET synced_at=COALESCE(synced_at, ?) "
                "WHERE word_id=?", (utcnow(), row["word_id"]))
            self.conn.commit()
            fetched += 1
        return fetched

    # ---------- the whole cycle ----------

    def sync(self) -> dict:
        store = self.store()
        if store is None:
            return {"ok": False, "reason": "sync not configured"}
        device = self.device_id()
        try:
            # Collect this device's own changes BEFORE pulling: rows that
            # arrive from the cloud keep their cloud timestamps, and gathering
            # afterwards would echo every one of them straight back up (a
            # fresh device would re-upload the entire deck it just received).
            since = self.setting("sync_last_push", "1970")
            now = utcnow()
            changes = self.collect_changes(since)

            # PULL: apply every log file newer than the cursor. Files this
            # device wrote advance the cursor without downloading (their
            # content IS local); files from other devices always apply.
            cursor = self.setting("sync_cursor", "")
            own_suffix = f"_{device}.json"
            pulled = 0
            for name in store.list_logs():
                if name <= cursor:
                    continue
                if not name.endswith(own_suffix):
                    pulled += self.apply_log(json.loads(store.get_log(name).decode()))
                self.set_setting("sync_cursor", name)

            # PUSH: one new immutable log of local changes, if any. A row the
            # pull just overwrote may still be in here with its older stamp;
            # every receiver compares timestamps, so it is simply ignored.
            pushed = sum(len(v) for v in changes.values())
            if pushed:
                store.put_log(f"{stamp_compact()}_{device}.json",
                              json.dumps(changes, ensure_ascii=False).encode())
            self.set_setting("sync_last_push", now)
            self.set_setting("sync_last_ok", now)

            # Pictures ride separately, and never at the cost of the words:
            # a storage hiccup here leaves the text sync already committed.
            try:
                sent = self.push_images(store)
                fetched = self.pull_images(store)
            except Exception:
                sent = fetched = 0

            return {"ok": True, "backend": store.label, "pulled": pulled,
                    "pushed": pushed, "images_sent": sent, "images_fetched": fetched}
        except cloud.CloudError as e:
            return {"ok": False, "reason": str(e)}
        except Exception as e:
            return {"ok": False, "reason": f"offline or unreachable ({type(e).__name__})"}

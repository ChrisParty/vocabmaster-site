"""Multiple choice quiz screen: 4 options drawn from the deck, then SM-2 rating.

Question types are mixed for stronger recall: word→meaning, meaning→word,
and fill-in-the-blank using the card's own example sentence.
"""

import html
import random
import re

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QHBoxLayout, QLabel, QLineEdit, QProgressBar, QPushButton, QVBoxLayout, QWidget,
)

import flags
import languages
import srs
from styles import (
    ACCENT, BORDER, DANGER, SUCCESS, SURFACE, TEXT_SECONDARY, WARNING,
)

OPTION_BASE_STYLE = f"""
    QPushButton {{
        background-color: {SURFACE};
        border: 1px solid {BORDER};
        border-radius: 10px;
        padding: 14px 18px;
        text-align: left;
        font-size: 11pt;
    }}
    QPushButton:hover {{ border-color: {ACCENT}; }}
"""
OPTION_CORRECT_STYLE = f"""
    QPushButton {{
        background-color: rgba(34,197,94,0.18);
        border: 2px solid {SUCCESS};
        border-radius: 10px; padding: 14px 18px;
        text-align: left; font-size: 11pt; font-weight: 600;
    }}
"""
OPTION_WRONG_STYLE = f"""
    QPushButton {{
        background-color: rgba(239,68,68,0.18);
        border: 2px solid {DANGER};
        border-radius: 10px; padding: 14px 18px;
        text-align: left; font-size: 11pt;
    }}
"""


def _norm(text):
    return "".join(ch for ch in text.casefold().strip() if ch.isalnum() or ch == " ").strip()


def _distance(a, b):
    """Levenshtein, small strings only."""
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        current = [i]
        for j, cb in enumerate(b, 1):
            current.append(min(previous[j] + 1, current[j - 1] + 1,
                               previous[j - 1] + (ca != cb)))
        previous = current
    return previous[-1]


def _judge(typed, word):
    """'right', 'close' (one slip in a word of 5+), or 'wrong'. Judges the
    headword before any bracket tail."""
    target = _norm(word.split("[")[0])
    guess = _norm(typed)
    if guess == target:
        return "right"
    if len(target) >= 5 and _distance(guess, target) <= 1:
        return "close"
    return "wrong"


def make_cloze(word, example):
    """Blank the word out of its example sentence: "The ship's rudder…" -> "The ship's _____…"

    Tries the word stem too, so inflected forms (tumbled, pursuing) still match.
    Returns None when the word doesn't appear in the sentence.
    """
    example = (example or "").strip()
    base = word.lower().split()[0].strip(".,;:")
    if not example or len(base) < 3:
        return None
    stems = [base]
    if len(base) > 4:
        stems.append(base[:-1])
    if len(base) > 5:
        stems.append(base[:-2])
    for stem in stems:
        match = re.search(rf"\b{re.escape(stem)}\w*", example, re.IGNORECASE)
        if match:
            return example[: match.start()] + "_____" + example[match.end():]
    return None


class QuizScreen(QWidget):
    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self.session = None
        self.session_id = None
        self.answered = False
        self.correct_index = -1
        self.practice_mode = False

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 20, 32, 20)
        layout.setSpacing(14)

        top_row = QHBoxLayout()
        back_button = QPushButton("← Back")
        back_button.setCursor(Qt.CursorShape.PointingHandCursor)
        back_button.clicked.connect(lambda: self.main_window.navigate("dashboard"))
        self.counter_label = QLabel("")
        self.counter_label.setStyleSheet(f"color: {TEXT_SECONDARY}; font-weight: 600;")
        top_row.addWidget(back_button)
        top_row.addStretch()
        top_row.addWidget(self.counter_label)
        layout.addLayout(top_row)

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setRange(0, 1000)
        layout.addWidget(self.progress_bar)

        self.question_label = QLabel("")
        self.question_label.setTextFormat(Qt.TextFormat.PlainText)
        self.question_label.setStyleSheet("font-size: 20px; font-weight: 700;")
        self.question_label.setWordWrap(True)
        layout.addWidget(self.question_label)

        self.option_buttons = []
        for index in range(4):
            button = QPushButton("")
            button.setStyleSheet(OPTION_BASE_STYLE)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _, i=index: self.select_answer(i))
            layout.addWidget(button)
            self.option_buttons.append(button)

        # Typing style: an answer box instead of the four options.
        type_row = QHBoxLayout()
        type_row.setSpacing(10)
        self.answer_edit = QLineEdit()
        self.answer_edit.setPlaceholderText("type the word, then Enter")
        self.answer_edit.setMinimumHeight(44)
        self.answer_edit.returnPressed.connect(self.check_typed)
        self.check_button = QPushButton("Check")
        self.check_button.setMinimumHeight(44)
        self.check_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.check_button.clicked.connect(self.check_typed)
        type_row.addWidget(self.answer_edit, 1)
        type_row.addWidget(self.check_button)
        self.type_widget = QWidget()
        self.type_widget.setLayout(type_row)
        self.type_widget.hide()
        layout.addWidget(self.type_widget)
        self.typing = False

        self.detail_label = QLabel("")
        self.detail_label.setWordWrap(True)
        self.detail_label.setStyleSheet(
            f"color: {TEXT_SECONDARY}; border-left: 3px solid {ACCENT}; padding-left: 12px;"
        )
        layout.addWidget(self.detail_label)

        self.rating_row = QWidget()
        rating_layout = QHBoxLayout(self.rating_row)
        rating_layout.setContentsMargins(0, 0, 0, 0)
        rating_layout.setSpacing(10)
        self.rating_buttons = []
        for rating, name, obj in [
            (srs.AGAIN, "Again", "rateAgain"),
            (srs.HARD, "Hard", "rateHard"),
            (srs.GOOD, "Good", "rateGood"),
            (srs.EASY, "Easy", "rateEasy"),
        ]:
            button = QPushButton(name)
            button.setObjectName(obj)
            button.setMinimumHeight(48)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _, r=rating: self.rate(r))
            rating_layout.addWidget(button)
            self.rating_buttons.append(button)
        layout.addWidget(self.rating_row)

        self.done_label = QLabel("")
        self.done_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.done_label.setStyleSheet("font-size: 15pt; font-weight: 600;")
        self.done_label.setWordWrap(True)
        layout.addWidget(self.done_label)

        self.next_session_button = QPushButton("Start next quiz")
        self.next_session_button.setObjectName("primary")
        self.next_session_button.setMinimumHeight(52)
        self.next_session_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.next_session_button.clicked.connect(self.refresh)
        self.next_session_button.hide()
        layout.addWidget(self.next_session_button)

        layout.addStretch()
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    # -------------------------------------------------------- session flow

    def refresh(self):
        self.end_session_bookkeeping()
        self.langs = languages.load(self.db.get_setting)
        if self.db.word_count() < 4:
            self.session = None
            self._show_quiz_widgets(False)
            self.done_label.setText(
                "The quiz needs at least 4 words in your deck.\nImport more words first (Ctrl+I)."
            )
            return
        cap = self.db.get_int_setting("session_cap", 20)
        max_new = self.db.get_int_setting("max_new_per_day", 20)
        cards = self.db.get_due_words(limit=cap, max_new=max_new)
        self.practice_mode = not cards
        if not cards:
            # Nothing due — practice random words. Practice never touches the
            # SRS schedule (otherwise an "Again" here would drag a card that
            # wasn't due for weeks back into tomorrow's queue).
            cards = random.sample(self.db.get_words(), min(cap, self.db.word_count()))
        self.session = srs.StudySession(cards)
        self.session_id = self.db.start_session()
        self._show_quiz_widgets(True)
        self.show_question()
        self.setFocus()

    def _show_quiz_widgets(self, visible):
        for widget in [self.progress_bar, self.question_label] + self.option_buttons:
            widget.setVisible(visible)
        self.type_widget.setVisible(False)
        self.detail_label.setVisible(False)
        self.rating_row.setVisible(False)
        self.done_label.setVisible(not visible)
        self.next_session_button.setVisible(False)

    def show_question(self):
        card = self.session.current()
        if card is None:
            self.session_complete()
            return
        self.answered = False
        self.detail_label.setVisible(False)
        self.rating_row.setVisible(False)

        # Mix question types — recalling the word in different ways builds
        # stronger memory than one-way drilling.
        all_words = self.db.get_words()
        cloze = make_cloze(card["word"], card.get("example"))
        style = self.db.get_setting("quiz_mode", "choice")
        modes = ["forward", "reverse"] + (["cloze"] if cloze else [])
        if style == "typing":
            modes = ["type"]
        elif style == "mixed":
            modes.append("type")
        mode = random.choice(modes)
        self.typing = mode == "type"
        self.type_widget.setVisible(self.typing)
        for button in self.option_buttons:
            button.setVisible(not self.typing)
        if self.typing:
            prompt = f"Type the {self.langs.target} word for: “{card['definition']}”"
            native = (card.get("greek") or "").strip()
            if native and self.langs.native_label:
                prompt += f"   ({native})"
            self.question_label.setText(prompt)
            self.answer_edit.clear()
            self.answer_edit.setEnabled(True)
            self.answer_edit.setFocus()
            self.counter_label.setText(self.session.progress_label())
            self.progress_bar.setValue(int(self.session.progress_fraction() * 1000))
            self._update_rating_previews(card)
            return
        if mode == "cloze":
            self.question_label.setText(f"Complete the sentence:\n“{cloze}”")
            correct = card["word"]
            distractors = [
                w["word"] for w in all_words
                if w["id"] != card["id"] and w["word"] != card["word"]
            ]
        elif mode == "reverse":
            self.question_label.setText(f"Which word means: “{card['definition']}”")
            correct = card["word"]
            distractors = [
                w["word"] for w in all_words
                if w["id"] != card["id"] and w["word"] != card["word"]
            ]
        else:
            self.question_label.setText(f"What does “{card['word']}” mean?")
            correct = card["definition"]
            distractors = [
                w["definition"] for w in all_words
                if w["id"] != card["id"] and w["definition"] != card["definition"]
            ]
        random.shuffle(distractors)
        options = distractors[:3] + [correct]
        random.shuffle(options)
        self.correct_index = options.index(correct)

        letters = ["A", "B", "C", "D"]
        for index, button in enumerate(self.option_buttons):
            if index < len(options):
                button.setText(f"{letters[index]}.   {options[index]}")
                button.setStyleSheet(OPTION_BASE_STYLE)
                button.setEnabled(True)
                button.setVisible(True)
            else:
                button.setVisible(False)

        self.counter_label.setText(self.session.progress_label())
        self.progress_bar.setValue(int(self.session.progress_fraction() * 1000))
        self._update_rating_previews(card)

    def _update_rating_previews(self, card):
        names = ["Again", "Hard", "Good", "Easy"]
        for rating, button in enumerate(self.rating_buttons):
            preview = srs.preview_interval(
                card["interval"], card["ease_factor"], card["repetitions"], rating
            )
            button.setText(f"{names[rating]}\n{preview}")

    def check_typed(self):
        if self.answered or self.session is None or not self.typing:
            return
        card = self.session.current()
        typed = self.answer_edit.text().strip()
        if not typed:
            return
        self.answered = True
        self.answer_edit.setEnabled(False)
        verdict = _judge(typed, card["word"])
        shown = html.escape(typed)
        if verdict == "right":
            head = f'<span style="color:{SUCCESS}; font-weight:600">✓ Right</span>'
        elif verdict == "close":
            head = (f'<span style="color:{WARNING}; font-weight:600">≈ Almost — '
                    f'you typed “{shown}”</span>')
        else:
            head = f'<span style="color:{DANGER}; font-weight:600">✗ You typed “{shown}”</span>'
        self._show_detail(card, head + "<br>")
        self.setFocus()                      # 1–4 rate from here

    def select_answer(self, index):
        if self.answered or self.session is None:
            return
        self.answered = True
        card = self.session.current()

        for i, button in enumerate(self.option_buttons):
            button.setEnabled(False)
            if i == self.correct_index:
                button.setStyleSheet(OPTION_CORRECT_STYLE)
                button.setText("✓  " + button.text())
            elif i == index:
                button.setStyleSheet(OPTION_WRONG_STYLE)
                button.setText("✗  " + button.text())

        self._show_detail(card)

    def _show_detail(self, card, prefix=""):
        detail = prefix + f"<b>{html.escape(card['word'])}</b> — {html.escape(card['definition'])}"
        example = (card.get("example") or "").strip()
        if example:
            detail += f"<br><i>“{html.escape(example)}”</i>"
        translations = []
        if (card.get("greek") or "").strip() and self.langs.native_label:
            translations.append(f"{flags.tag(self.langs.native, self.langs.native_label)}{html.escape(card['greek'].strip())}")
        if (card.get("swedish") or "").strip() and self.langs.second_label:
            translations.append(f"{flags.tag(self.langs.second, self.langs.second_label)}{html.escape(card['swedish'].strip())}")
        if translations:
            detail += "<br>" + "&nbsp;&nbsp;&nbsp;".join(translations)
        hook = (card.get("hook") or "").strip()
        if hook:
            detail += "<br>" + "<br>".join(
                f'<span style="color:#c8a96e; font-size:10pt;">💡 {html.escape(line)}</span>'
                for line in hook.splitlines())
        self.detail_label.setText(detail)
        self.detail_label.setVisible(True)
        self.rating_row.setVisible(True)

    def rate(self, rating):
        if self.session is None or not self.answered:
            return
        card = self.session.current()
        interval, ease, reps = srs.sm2_update(
            card["interval"], card["ease_factor"], card["repetitions"], rating
        )
        if not self.practice_mode:
            self.db.apply_review(card["id"], interval, ease, reps)
        self.db.record_rating(self.session_id, rating)
        updated = dict(card, interval=interval, ease_factor=ease, repetitions=reps)
        self.session.rate(rating, updated_card=updated)
        self.main_window.update_status()
        self.show_question()

    def session_complete(self):
        tally = self.session.tally
        total = sum(tally.values())
        self._show_quiz_widgets(False)
        self.done_label.setText(
            f"🎉 Quiz complete!\n\nYou answered {total} questions:\n"
            f"Again {tally[srs.AGAIN]}  •  Hard {tally[srs.HARD]}  •  "
            f"Good {tally[srs.GOOD]}  •  Easy {tally[srs.EASY]}"
        )
        self.session = None
        self.end_session_bookkeeping()
        self.main_window.start_sync()        # the other computer gets today's work
        if self.db.word_count() >= 4:
            self.next_session_button.show()

    def end_session_bookkeeping(self):
        if self.session_id is not None:
            self.db.delete_empty_session(self.session_id)
            self.session_id = None

    # ------------------------------------------------------------ keyboard

    def keyPressEvent(self, event):
        key = event.key()
        if self.session is not None and key in (
            Qt.Key.Key_1, Qt.Key.Key_2, Qt.Key.Key_3, Qt.Key.Key_4
        ):
            index = key - Qt.Key.Key_1
            if not self.answered:
                self.select_answer(index)
            else:
                self.rate(index)
            return
        super().keyPressEvent(event)

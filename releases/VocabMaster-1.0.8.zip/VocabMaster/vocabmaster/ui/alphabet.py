"""Learn the alphabet: a chart you can open beside any card, and a drill
that teaches the sounds — unknown symbols first, a symbol is yours after
three right answers in a row. Hangul adds syllable blocks once the letters
are known, because that is what you actually read.
"""

import random

from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QFontMetrics
from PyQt6.QtWidgets import (
    QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QProgressBar,
    QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

import alphabets
import languages
from styles import (
    ACCENT, BORDER, DANGER, SUCCESS, SURFACE, SURFACE_HOVER, TEXT, TEXT_MUTED,
    TEXT_SECONDARY, wrapping,
)

MASTER_STREAK = 3
TILE_WIDTH = 80
LETTERS_BEFORE_BLOCKS = 0.7      # share of letters mastered before Hangul blocks join


def _speak(symbol, language):
    from ui.flashcard import speak
    speak(alphabets.speakable(symbol), language)


class Tile(QFrame):
    """One symbol with its reading. Click to hear it."""

    clicked = pyqtSignal(str)

    def __init__(self, symbol, reading, note):
        super().__init__()
        self.symbol = symbol
        self.setFixedWidth(TILE_WIDTH)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(note or f"{symbol} — {reading}. Click to hear it.")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 8, 6, 8)
        layout.setSpacing(2)
        big = QLabel(symbol)
        big.setAlignment(Qt.AlignmentFlag.AlignCenter)
        # 20pt, or smaller when a wide symbol ("ゃ ゅ ょ") would not fit the tile.
        size = 20
        font = QFont(big.font())
        font.setWeight(QFont.Weight.DemiBold)
        while size > 11:
            font.setPointSize(size)
            if QFontMetrics(font).horizontalAdvance(symbol) <= TILE_WIDTH - 14:
                break
            size -= 1
        big.setStyleSheet(f"font-size: {size}pt; font-weight: 600; color: {TEXT}; background: transparent;")
        small = QLabel(reading)
        small.setAlignment(Qt.AlignmentFlag.AlignCenter)
        small.setStyleSheet(f"font-size: 9pt; color: {TEXT_SECONDARY}; background: transparent;")
        layout.addWidget(big)
        layout.addWidget(small)
        self.set_mastered(False)

    def set_mastered(self, mastered):
        border = SUCCESS if mastered else BORDER
        self.setStyleSheet(
            f"Tile {{ background-color: {SURFACE}; border: 1px solid {border}; border-radius: 10px; }}"
            f"Tile:hover {{ background-color: {SURFACE_HOVER}; }}")

    def mousePressEvent(self, event):
        self.clicked.emit(self.symbol)
        super().mousePressEvent(event)


class AlphabetChart(QWidget):
    """The groups of an alphabet as tiles; mastered ones outlined green."""

    def __init__(self, alphabet, language):
        super().__init__()
        self.language = language
        self.tiles = {}
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(14)
        for title, group in alphabet["groups"]:
            head = QLabel(title)
            head.setStyleSheet(f"font-weight: 700; color: {TEXT_SECONDARY}; background: transparent;")
            layout.addWidget(head)
            grid = QGridLayout()
            grid.setHorizontalSpacing(8)
            grid.setVerticalSpacing(8)
            columns = 8
            for index, (symbol, reading, note) in enumerate(group):
                tile = Tile(symbol, reading, note)
                tile.clicked.connect(lambda s, lang=language: _speak(s, lang))
                grid.addWidget(tile, index // columns, index % columns)
                self.tiles[symbol] = tile
            grid.setColumnStretch(columns, 1)
            layout.addLayout(grid)

    def set_progress(self, progress):
        for symbol, tile in self.tiles.items():
            tile.set_mastered(progress.get(symbol, 0) >= MASTER_STREAK)


class AlphabetDialog(QDialog):
    """The chart beside the study screen: non-modal, stays open while you
    study, so a forgotten letter costs one glance."""

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowFlag(Qt.WindowType.Tool, True)
        self.setMinimumSize(560, 520)
        self.resize(640, 700)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        self.title = QLabel("")
        self.title.setStyleSheet("font-size: 14pt; font-weight: 700;")
        layout.addWidget(self.title)
        hint = QLabel("Click any symbol to hear it. Green outline = you know it.")
        hint.setStyleSheet(f"color: {TEXT_MUTED};")
        layout.addWidget(hint)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        layout.addWidget(self.scroll, 1)
        self.chart = None
        self.language = None

    def refresh(self):
        langs = languages.load(self.db.get_setting)
        alphabet = alphabets.for_language(langs.target)
        if alphabet is None:
            return False
        if self.language != langs.target:
            self.language = langs.target
            self.chart = AlphabetChart(alphabet, langs.target)
            self.scroll.setWidget(self.chart)
            self.setWindowTitle(alphabet["title"])
            self.title.setText(alphabet["title"])
        self.chart.set_progress(self.db.alphabet_progress(langs.target))
        return True


class AlphabetScreen(QWidget):
    """Intro, practice, chart — in that order, because the practice is the
    part that teaches."""

    def __init__(self, db, main_window):
        super().__init__()
        self.db = db
        self.main_window = main_window
        self.language = None
        self.alphabet = None
        self.items = []            # (symbol, reading, family)
        self.progress = {}
        self.current = None
        self.options = []
        self.answered = False
        self.recent = []
        self.mode = "symbol"       # symbol -> reading, or reading -> symbol
        self.chart = None
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)

        self.header = QLabel("Alphabet")
        self.header.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addWidget(self.header)

        intro_card = QFrame()
        intro_card.setObjectName("card")
        intro_layout = QVBoxLayout(intro_card)
        intro_layout.setContentsMargins(24, 18, 24, 18)
        self.intro = wrapping(QLabel(""))
        self.intro.setStyleSheet("font-size: 11pt;")
        intro_layout.addWidget(self.intro)
        layout.addWidget(intro_card)

        # ---- practice
        self.practice_card = QFrame()
        self.practice_card.setObjectName("card")
        practice = QVBoxLayout(self.practice_card)
        practice.setContentsMargins(24, 18, 24, 18)
        practice.setSpacing(12)
        top = QHBoxLayout()
        title = QLabel("Practice")
        title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        top.addWidget(title)
        top.addStretch()
        self.progress_label = QLabel("")
        self.progress_label.setStyleSheet(f"color: {TEXT_SECONDARY};")
        top.addWidget(self.progress_label)
        practice.addLayout(top)
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setTextVisible(False)
        practice.addWidget(self.progress_bar)

        self.ask = QLabel("")
        self.ask.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ask.setStyleSheet(f"color: {TEXT_SECONDARY};")
        practice.addWidget(self.ask)
        self.prompt = QLabel("")
        self.prompt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.prompt.setStyleSheet("font-size: 64pt; font-weight: 700;")
        self.prompt.setMinimumHeight(110)
        practice.addWidget(self.prompt)

        row = QHBoxLayout()
        row.setSpacing(10)
        self.buttons = []
        for index in range(4):
            button = QPushButton("")
            button.setMinimumHeight(64)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setToolTip(f"Press {index + 1}")
            button.clicked.connect(lambda _, i=index: self.choose(i))
            row.addWidget(button)
            self.buttons.append(button)
        practice.addLayout(row)

        bottom = QHBoxLayout()
        self.feedback = QLabel("")
        self.feedback.setStyleSheet(f"color: {TEXT_SECONDARY};")
        bottom.addWidget(self.feedback, 1)
        self.say_button = QPushButton("Say  P")
        self.say_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.say_button.setToolTip("Hear it (P)")
        self.say_button.clicked.connect(self.say)
        bottom.addWidget(self.say_button)
        self.next_button = QPushButton("Next  Space")
        self.next_button.setObjectName("primary")
        self.next_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.next_button.clicked.connect(self.next_question)
        bottom.addWidget(self.next_button)
        practice.addLayout(bottom)
        layout.addWidget(self.practice_card)

        # ---- chart
        self.chart_card = QFrame()
        self.chart_card.setObjectName("card")
        self.chart_layout = QVBoxLayout(self.chart_card)
        self.chart_layout.setContentsMargins(24, 18, 24, 18)
        chart_title = QLabel("All the symbols")
        chart_title.setStyleSheet("font-weight: 700; font-size: 12pt;")
        self.chart_layout.addWidget(chart_title)
        chart_hint = QLabel("Click any symbol to hear it. Green outline = you know it. "
                            "On the Study screen, A opens this chart beside your card.")
        chart_hint.setStyleSheet(f"color: {TEXT_MUTED};")
        self.chart_layout.addWidget(chart_hint)
        layout.addWidget(self.chart_card)

        self.none_label = wrapping(QLabel(
            "The language you are learning uses the Latin alphabet — nothing to "
            "learn here. Choose a language in Settings → Languages."))
        self.none_label.setStyleSheet(f"color: {TEXT_SECONDARY}; font-size: 11pt;")
        layout.addWidget(self.none_label)
        layout.addStretch()

    # ----------------------------------------------------------- loading

    def refresh(self):
        langs = languages.load(self.db.get_setting)
        alphabet = alphabets.for_language(langs.target)
        has = alphabet is not None
        for widget in (self.practice_card, self.chart_card):
            widget.setVisible(has)
        self.none_label.setVisible(not has)
        if not has:
            self.header.setText("Alphabet")
            self.intro.setText("")
            return
        if self.language != langs.target:
            self.language = langs.target
            self.alphabet = alphabet
            self.header.setText(alphabet["title"])
            self.intro.setText(alphabet["intro"])
            self.items = [(s, r, title) for title, group in alphabets.drill_groups(alphabet)
                          for s, r, _ in group]
            self.letter_count = len(self.items)
            if alphabet.get("syllables"):
                self.items += [(s, r, "Syllable blocks") for s, r in alphabets.hangul_syllables()]
            if self.chart is not None:
                self.chart.setParent(None)
            self.chart = AlphabetChart(alphabet, langs.target)
            self.chart_layout.addWidget(self.chart)
            self.recent = []
        self.progress = self.db.alphabet_progress(langs.target)
        self.chart.set_progress(self.progress)
        self.update_progress()
        self.next_question()
        self.setFocus()

    def update_progress(self):
        letters = [s for s, _, fam in self.items if fam != "Syllable blocks"]
        known = sum(1 for s in letters if self.progress.get(s, 0) >= MASTER_STREAK)
        text = f"You know {known} of {len(letters)} {self.alphabet.get('unit', 'letters')}"
        blocks = [s for s, _, fam in self.items if fam == "Syllable blocks"]
        if blocks:
            known_blocks = sum(1 for s in blocks if self.progress.get(s, 0) >= MASTER_STREAK)
            if known_blocks or known >= len(letters) * LETTERS_BEFORE_BLOCKS:
                text += f" · {known_blocks} of {len(blocks)} syllable blocks"
        self.progress_label.setText(text + f" · {MASTER_STREAK} right in a row makes one yours")
        total = len(letters) + len(blocks)
        done = known + (sum(1 for s in blocks if self.progress.get(s, 0) >= MASTER_STREAK) if blocks else 0)
        self.progress_bar.setValue(int(done / total * 100) if total else 0)

    # ---------------------------------------------------------- practice

    def _pool(self):
        letters = [i for i in self.items if i[2] != "Syllable blocks"]
        known = sum(1 for s, _, _ in letters if self.progress.get(s, 0) >= MASTER_STREAK)
        pool = list(letters)
        if known >= len(letters) * LETTERS_BEFORE_BLOCKS:
            pool += [i for i in self.items if i[2] == "Syllable blocks"]
        return pool

    def _pick(self):
        pool = [i for i in self._pool() if i[0] not in self.recent[-4:]] or self._pool()
        weak = [i for i in pool if self.progress.get(i[0], 0) < MASTER_STREAK]
        if weak and random.random() < 0.85:
            lowest = min(self.progress.get(i[0], 0) for i in weak)
            front = [i for i in weak if self.progress.get(i[0], 0) == lowest]
            # Unseen symbols trickle in a few at a time, not all at once.
            return random.choice(front[:6] if lowest == 0 else front)
        return random.choice(pool)

    def next_question(self):
        if not self.items:
            return
        self.answered = False
        self.current = self._pick()
        self.recent.append(self.current[0])
        symbol, reading, family = self.current
        same = [i for i in self.items if i[2] == family and i[0] != symbol and i[1] != reading]
        distractors = random.sample(same, min(3, len(same)))
        self.mode = random.choice(["symbol", "symbol", "reading"])
        self.options = distractors + [self.current]
        random.shuffle(self.options)
        if self.mode == "symbol":
            self.ask.setText("How does this sound?")
            self.prompt.setText(symbol)
            for button, item in zip(self.buttons, self.options):
                button.setText(item[1])
                button.setStyleSheet("font-size: 14pt;")
        else:
            self.ask.setText("Which one sounds like this?")
            self.prompt.setText(reading)
            for button, item in zip(self.buttons, self.options):
                button.setText(item[0])
                button.setStyleSheet("font-size: 22pt;")
        for button in self.buttons:
            button.setEnabled(True)
        self.feedback.setText("")
        self.next_button.setEnabled(False)

    def choose(self, index):
        if self.answered or index >= len(self.options):
            return
        self.answered = True
        symbol, reading, _ = self.current
        correct = self.options[index][0] == symbol
        for i, (button, item) in enumerate(zip(self.buttons, self.options)):
            button.setEnabled(False)
            if item[0] == symbol:
                button.setStyleSheet(button.styleSheet() + f"border: 2px solid {SUCCESS}; color: {SUCCESS};")
            elif i == index:
                button.setStyleSheet(button.styleSheet() + f"border: 2px solid {DANGER}; color: {DANGER};")
        self.progress[symbol] = self.db.alphabet_record(self.language, symbol, correct)
        if correct:
            streak = self.progress[symbol]
            self.feedback.setText(
                f"✓  {symbol} = {reading}" + ("  — yours now." if streak == MASTER_STREAK
                                              else f"  ({streak} in a row)"))
        else:
            self.feedback.setText(f"✗  {symbol} = {reading}. It comes back soon.")
        self.chart.set_progress(self.progress)
        self.update_progress()
        self.next_button.setEnabled(True)
        _speak(symbol, self.language)
        if correct:
            QTimer.singleShot(900, lambda: self.answered and self.next_question())

    def say(self):
        if self.current:
            _speak(self.current[0], self.language)

    def keyPressEvent(self, event):
        key = event.key()
        if key in (Qt.Key.Key_1, Qt.Key.Key_2, Qt.Key.Key_3, Qt.Key.Key_4):
            self.choose(key - Qt.Key.Key_1)
            return
        if key in (Qt.Key.Key_Space, Qt.Key.Key_Return, Qt.Key.Key_Enter) and self.answered:
            self.next_question()
            return
        if key == Qt.Key.Key_P:
            self.say()
            return
        super().keyPressEvent(event)

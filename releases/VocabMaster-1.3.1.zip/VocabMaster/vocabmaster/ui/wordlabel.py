"""Text the learner can select and copy — and a word in the language being
learned can go straight into the deck: select it, right-click, "＋ Add".

WordLabel is a QLabel whose text can be selected with the mouse (Ctrl+C
and a right-click Copy work). When it holds learning-language text
(`addable=True`) and the screen it sits on has `word_to_add(text)` and
`add_selected_word(word)`, the right-click menu also offers to add the
selected word. WordAdder writes the card off the UI thread (the same AI
call as Add one word, under the same daily budget).
"""

import threading

from PyQt6.QtCore import QEvent, QObject, QPointF, Qt, pyqtSignal
from PyQt6.QtGui import QMouseEvent
from PyQt6.QtWidgets import QApplication, QLabel, QMenu

import cards_ai

PUNCTUATION = " \t\r\n.,!?;:\"'“”‘’„«»()[]{}…—–-·。、！？「」『』（）"


def addable(text, target):
    """The selection as a word or short phrase worth a card in `target`,
    or '' (too long, no letters, or not in the learning language's script)."""
    word = (text or "").strip(PUNCTUATION)
    if not word or len(word) > 40 or "\n" in word or " " in word or len(word.split()) > 4:
        return ""
    if not any(ch.isalpha() for ch in word):
        return ""
    if (target or "").lower() in cards_ai.SCRIPTS:
        return word if cards_ai.script_share(word, target) >= 0.5 else ""
    # A Latin-script language: letters from another script are a translation.
    return word if all(ord(ch) < 0x0370 for ch in word if ch.isalpha()) else ""


class WordLabel(QLabel):

    def __init__(self, text="", addable=False):
        super().__init__(text)
        self.addable = addable
        self.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

    def _owner(self):
        widget = self.parentWidget()
        while widget is not None and not hasattr(widget, "add_selected_word"):
            widget = widget.parentWidget()
        return widget

    def menu_for(self, chosen):
        """The right-click menu for the selected text (built separately so
        it can be tested without a mouse)."""
        # Parented to the window, not the label: a label's own font size (a
        # story line is 19 pt) would otherwise make the menu huge.
        menu = QMenu(self.window())
        copy = menu.addAction("Copy")
        copy.setEnabled(bool(chosen))
        copy.triggered.connect(lambda: QApplication.clipboard().setText(chosen))
        owner = self._owner() if self.addable else None
        if owner is not None:
            menu.addSeparator()
            word = owner.word_to_add(chosen) if chosen else ""
            if word:
                menu.addAction(f"＋  Add “{word}” to my deck",
                               lambda: owner.add_selected_word(word))
            else:
                hint = menu.addAction("Select a word to add it to your deck")
                hint.setEnabled(False)
        return menu

    def word_at(self, pos):
        """Nothing selected: select the word under the pointer, as a double
        click would, and return it — a right-click on a word is enough."""
        point = QPointF(pos)
        for kind in (QEvent.Type.MouseButtonDblClick, QEvent.Type.MouseButtonRelease):
            QApplication.sendEvent(self, QMouseEvent(
                kind, point, self.mapToGlobal(point), Qt.MouseButton.LeftButton,
                Qt.MouseButton.LeftButton if kind == QEvent.Type.MouseButtonDblClick
                else Qt.MouseButton.NoButton, Qt.KeyboardModifier.NoModifier))
        return self.selectedText().strip()

    def contextMenuEvent(self, event):
        chosen = self.selectedText().strip() or self.word_at(event.pos())
        self.menu_for(chosen).exec(event.globalPos())


class WordAdder(QObject):
    """One word → one full card, off the UI thread; `done(word, message)`."""
    done = pyqtSignal(str, str)

    def __init__(self, db_path, parent=None):
        super().__init__(parent)
        self.db_path = db_path
        self._busy = False

    def busy(self):
        return self._busy

    def add(self, word):
        if self._busy:
            return False
        self._busy = True

        def work():
            writer = cards_ai.CardWriter(self.db_path)
            try:
                entry = writer.add_word(word, as_found=True)
                if entry is None:
                    message = "already in your deck"
                elif entry["word"].strip().lower() != word.strip().lower():
                    message = f"added to your deck as “{entry['word']}” ✓"
                else:
                    message = "added to your deck ✓"
            except Exception as exc:
                message = f"not added: {exc}"
            finally:
                writer.close()
            self._busy = False
            self.done.emit(word, message)

        threading.Thread(target=work, daemon=True).start()
        return True
